from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from supraxis.block import state_commitment
from supraxis.state import SupraxisState
from .checkpoint import Checkpoint, validators_hash
from .signed_checkpoint import SignedCheckpoint, verify_signed_checkpoint
from .hotstuff import quorum_threshold
from .validator_set import validators_for_epoch

@dataclass
class LightClient:
    chain_id: int
    trusted: Optional[Checkpoint] = None

    def verify_checkpoint_self_consistent(self, state: SupraxisState, ck: Checkpoint) -> Tuple[bool,str]:
        if int(ck.chain_id) != int(self.chain_id):
            return False, "wrong_chain"
        # Verify validators hash matches snapshot
        snap = state.storage.get(f"validators.epoch.{int(ck.epoch)}")
        if snap is None and int(ck.epoch) > 0:
            snap = state.storage.get(f"validators.epoch.{int(ck.epoch)-1}")
        if snap is None:
            return False, "missing_validator_snapshot"
        vh = validators_hash(list(snap))
        if str(vh) != str(ck.validators_hash):
            return False, "bad_validators_hash"
        return True, "ok"

    def accept_signed_checkpoint(self, state: SupraxisState, scp: SignedCheckpoint) -> Tuple[bool,str]:
        ck = scp.checkpoint
        ok, why = self.verify_checkpoint_self_consistent(state, ck)
        if not ok:
            return False, why

        # Determine validator set for that epoch and compute quorum power
        vals = validators_for_epoch(state, int(ck.epoch))
        q = quorum_threshold(vals)

        snap = state.storage.get(f"validators.epoch.{int(ck.epoch)}")
        if snap is None and int(ck.epoch) > 0:
            snap = state.storage.get(f"validators.epoch.{int(ck.epoch)-1}")
        ok2, why2, signed_power = verify_signed_checkpoint(scp, list(snap or []), q)
        if not ok2:
            return False, why2

        # Monotonic acceptance
        if self.trusted is not None:
            if int(ck.height) <= int(self.trusted.height):
                return False, "non_increasing_height"
        self.trusted = ck
        return True, "ok"

    
    def sync_headers(self, state: SupraxisState, headers: list) -> tuple[bool,str]:
        """Header-only sync from an already trusted checkpoint.
        Verifies parent linkage + contiguous height, and performs structural QC quorum checks.
        Also updates validator set when epoch changes based on header.epoch.
        """
        if self.trusted is None:
            return False, "no_trusted_checkpoint"

        prev_hash = str(self.trusted.block_hash)
        prev_h = int(self.trusted.height)

        # current epoch/validator set starts from trusted checkpoint epoch
        cur_epoch = int(self.trusted.epoch)
        # validator snapshot for current epoch
        snap = state.storage.get(f"validators.epoch.{cur_epoch}")
        if snap is None and cur_epoch > 0:
            snap = state.storage.get(f"validators.epoch.{cur_epoch-1}")
        if snap is None:
            return False, "missing_validator_snapshot"

        from supraxis.consensus.validator_set import validators_for_epoch, vmap as make_vmap
        from supraxis.consensus.hotstuff import quorum_threshold
        from supraxis.consensus.qc_verify import verify_qc_structural

        vals = validators_for_epoch(state, cur_epoch)
        qpower = quorum_threshold(vals)
        vm = make_vmap(vals)

        for h in headers:
            if int(h.chain_id) != int(self.chain_id):
                return False, "wrong_chain"
            if str(h.parent_hash) != prev_hash:
                return False, "bad_parent_link"
            if int(h.height) != prev_h + 1:
                return False, "non_contiguous_height"

            # epoch-aware validator update
            hep = int(getattr(h, "epoch", cur_epoch))
            if hep != cur_epoch:
                cur_epoch = hep
                vals = validators_for_epoch(state, cur_epoch)
                qpower = quorum_threshold(vals)
                vm = make_vmap(vals)

            # QC structural verification if present
            if getattr(h, "qc", None) is not None:
                ok, why, sp = verify_qc_structural(h.qc, vm, qpower)
                if not ok:
                    return False, why

            # optional validators_hash consistency check if provided
            vhash = str(getattr(h, "validators_hash", ""))
            if vhash:
                snap2 = state.storage.get(f"validators.epoch.{cur_epoch}")
                if snap2 is None and cur_epoch > 0:
                    snap2 = state.storage.get(f"validators.epoch.{cur_epoch-1}")
                if snap2 is None:
                    return False, "missing_validator_snapshot"
                from supraxis.consensus.checkpoint import validators_hash
                if str(validators_hash(list(snap2))) != vhash:
                    return False, "bad_validators_hash"

            prev_hash = str(h.block_hash)
            prev_h = int(h.height)

        # Update trusted head to latest header; state_root unchanged for header-only mode
        self.trusted = Checkpoint(chain_id=self.chain_id, epoch=cur_epoch, height=prev_h,
                                  state_root=str(self.trusted.state_root), block_hash=prev_hash,
                                  validators_hash=str(getattr(headers[-1], "validators_hash", self.trusted.validators_hash)) if headers else str(self.trusted.validators_hash))
        return True, "ok"
