from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from .signed_checkpoint import SignedCheckpoint
from .headerchain import Header, HeaderChain

@dataclass
class GossipStore:
    """In-memory cache for networkless simulation: stores signed checkpoints and headers."""
    checkpoints: Dict[int, List[SignedCheckpoint]] = field(default_factory=dict)  # epoch -> list
    headers: HeaderChain = field(default_factory=HeaderChain)

    def add_checkpoint(self, scp: SignedCheckpoint) -> None:
        ep = int(scp.checkpoint.epoch)
        lst = self.checkpoints.get(ep, [])
        lst.append(scp)
        self.checkpoints[ep] = lst

    def best_checkpoint(self, min_height: int = 0) -> Optional[SignedCheckpoint]:
        best = None
        for ep, lst in self.checkpoints.items():
            for scp in lst:
                if int(scp.checkpoint.height) < int(min_height):
                    continue
                if best is None or int(scp.checkpoint.height) > int(best.checkpoint.height):
                    best = scp
        return best

    def add_header(self, h: Header) -> None:
        self.headers.add(h)

    def tip_header(self, chain_id: int) -> Optional[Header]:
        return self.headers.tip(chain_id)

    def headers_from(self, start_hash: str, end_hash: str) -> List[Header]:
        return self.headers.path_from(start_hash, end_hash)
