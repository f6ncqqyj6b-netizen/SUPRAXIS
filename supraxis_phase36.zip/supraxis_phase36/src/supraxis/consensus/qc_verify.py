from __future__ import annotations
from typing import Dict, Tuple, Set, Any
from .types import QC, Validator

def verify_qc_structural(qc: QC, vmap: Dict[str, Validator], quorum_power: int) -> Tuple[bool,str,int]:
    """Structural QC verification (no crypto sig checks in this reference build).

    QC format in this codebase: qc.sigs is Dict[voter_vid -> bytes].
    Rules:
    - voters unique (dict keys)
    - voters must be in validator set
    - signed power sum reaches quorum threshold

    Returns (ok, reason, signed_power).
    """
    sigs: Any = getattr(qc, "sigs", {})
    if not isinstance(sigs, dict):
        return False, "bad_qc_format", 0

    signed_power = 0
    seen: Set[str] = set()
    for voter in sigs.keys():
        voter = str(voter)
        if voter in seen:
            continue
        v = vmap.get(voter)
        if v is None:
            continue
        seen.add(voter)
        signed_power += int(v.power)

    if signed_power < int(quorum_power):
        return False, "insufficient_qc_power", signed_power

    return True, "ok", signed_power
