from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Optional, Union, Literal
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

Hex = str

def msg_id(obj: Any) -> Hex:
    return sha256(canonical_json(obj)).hex()

@dataclass(frozen=True)
class TxAnnounce:
    tx_id: Hex

@dataclass(frozen=True)
class TxRequest:
    tx_id: Hex

@dataclass(frozen=True)
class TxPayload:
    tx_id: Hex
    envelope: dict  # serialized EnvelopeV2

# Consensus messages are imported as plain dicts for now (Phase 29 tightens typing)
@dataclass(frozen=True)
class BlockProposal:
    proposal: dict

@dataclass(frozen=True)
class VoteMsg:
    vote: dict

@dataclass(frozen=True)
class QCMsg:
    qc: dict

@dataclass(frozen=True)
class TimeoutMsg:
    timeout: dict

@dataclass(frozen=True)
class TCMsg:
    tc: dict

NetMessage = Union[TxAnnounce, TxRequest, TxPayload, BlockProposal, VoteMsg, QCMsg, TimeoutMsg, TCMsg]
