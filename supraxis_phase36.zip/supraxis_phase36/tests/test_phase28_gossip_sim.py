import unittest
from supraxis.net.gossip import GossipSim
from supraxis.net.messages import TxPayload

def env(sender_hex: str, nonce: int, gas: int = 10):
    return {
        "version": 2,
        "origin_chain": 1,
        "origin_tx": "0x" + "00"*31 + "01",
        "origin_sender": sender_hex,
        "target_chain": 100,
        "target_contract": "0x" + "aa"*32,
        "nonce": nonce,
        "gas_limit": gas,
        "payload_hash": "0x" + "11"*32,
        "cap_refs": [],
    }

class TestGossipSim(unittest.TestCase):
    def test_tx_propagates(self):
        sim = GossipSim()
        a = sim.add_peer("A")
        b = sim.add_peer("B")
        c = sim.add_peer("C")

        e = env("0x"+"01"*32, 1)
        # inject payload to A and broadcast announce through sim by sending payload then broadcasted announces
        sim.send("A","A", TxPayload(tx_id="x", envelope=e))
        sim.step()
        # multiple steps to propagate request/payload
        for _ in range(10):
            sim.step()

        self.assertEqual(len(b.mempool.txs), 1)
        self.assertEqual(len(c.mempool.txs), 1)

if __name__ == "__main__":
    unittest.main()
