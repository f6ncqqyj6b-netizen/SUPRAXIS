import unittest
from supraxis.consensus.types import Validator
from supraxis.consensus.hotstuff import proposer_for, quorum_threshold
from supraxis.consensus.sim import DeterministicSim

class Phase27Consensus(unittest.TestCase):
    def test_proposer_deterministic(self):
        vals = [Validator("A", 10), Validator("B", 10), Validator("C", 10), Validator("D", 10)]
        p1 = proposer_for(1, 10, 0, vals)
        p2 = proposer_for(1, 10, 0, vals)
        self.assertEqual(p1, p2)

    def test_quorum_threshold(self):
        vals = [Validator("A", 10), Validator("B", 10), Validator("C", 10)]
        # total 30 => 2/3*30=20 => +1 => 21
        self.assertEqual(quorum_threshold(vals), 21)

    def test_one_height_quorum_and_commit_rule(self):
        vals = [Validator("A", 10), Validator("B", 10), Validator("C", 10), Validator("D", 10)]
        sim = DeterministicSim(1, vals)
        parent = "00"*32
        r1 = sim.step(1, parent)
        self.assertEqual(r1["committed"], [])
        r2 = sim.step(2, r1["block_hash"])
        self.assertEqual(r2["committed"], [])
        r3 = sim.step(3, r2["block_hash"])
        self.assertEqual(len(r3["committed"]), 1)

if __name__ == "__main__":
    unittest.main()
