import unittest
from supraxis.state import SupraxisState
from supraxis.consensus.lightclient import LightClient
from supraxis.consensus.headerchain import Header
from supraxis.consensus.types import QC
from supraxis.consensus.checkpoint import Checkpoint, validators_hash

class TestPhase36(unittest.TestCase):
    def test_qc_power_verified(self):
        st = SupraxisState()
        # epoch 0 validator set: v1 power 10, v2 power 10 => quorum (2/3) -> 14
        v1 = "0x"+"01"*32
        v2 = "0x"+"02"*32
        st.storage["validators.epoch.0"] = [{"vid": v1, "power": 10}, {"vid": v2, "power": 10}]
        vh = validators_hash(st.storage["validators.epoch.0"])
        lc = LightClient(chain_id=1, trusted=Checkpoint(chain_id=1, epoch=0, height=1, state_root="aa"*32, block_hash="01"*32, validators_hash=vh))

        # QC with only one voter => power 10 < quorum 14 should fail
        qc = QC(height=2, round=0, block_hash="02"*32, power=10, sigs={v1: b""})
        hs = [Header(chain_id=1, epoch=0, height=2, round=0, block_hash="02"*32, parent_hash="01"*32, proposer="p", validators_hash=vh, qc=qc)]
        ok, why = lc.sync_headers(st, hs)
        self.assertFalse(ok)
        self.assertEqual(why, "insufficient_qc_power")

    def test_epoch_aware_validator_update(self):
        st = SupraxisState()
        v1 = "0x"+"01"*32
        v2 = "0x"+"02"*32
        st.storage["validators.epoch.0"] = [{"vid": v1, "power": 10}, {"vid": v2, "power": 10}]
        vh0 = validators_hash(st.storage["validators.epoch.0"])
        # epoch 1 validator set: only v1 power 30 (quorum 20)
        st.storage["validators.epoch.1"] = [{"vid": v1, "power": 30}]
        vh1 = validators_hash(st.storage["validators.epoch.1"])

        lc = LightClient(chain_id=1, trusted=Checkpoint(chain_id=1, epoch=0, height=1, state_root="aa"*32, block_hash="01"*32, validators_hash=vh0))

        # header 2 is epoch 0 ok qc power 20 (both)
        qc2 = QC(height=2, round=0, block_hash="02"*32, power=20, sigs={v1: b"", v2: b""})
        h2 = Header(chain_id=1, epoch=0, height=2, round=0, block_hash="02"*32, parent_hash="01"*32, proposer="p", validators_hash=vh0, qc=qc2)

        # header 3 is epoch 1, qc signed by v1 alone power 30 should pass after epoch update
        qc3 = QC(height=3, round=0, block_hash="03"*32, power=30, sigs={v1: b""})
        h3 = Header(chain_id=1, epoch=1, height=3, round=0, block_hash="03"*32, parent_hash="02"*32, proposer="p", validators_hash=vh1, qc=qc3)

        ok, why = lc.sync_headers(st, [h2, h3])
        self.assertTrue(ok)
        self.assertEqual(lc.trusted.epoch, 1)
        self.assertEqual(lc.trusted.height, 3)

if __name__ == "__main__":
    unittest.main()
