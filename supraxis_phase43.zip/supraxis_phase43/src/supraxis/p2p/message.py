from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Tuple
import json

# Very small reference framing: length-prefixed JSON.
# In production: use protobuf/ssz + authenticated transport.

@dataclass(frozen=True)
class Msg:
    t: str
    payload: Dict[str, Any]

def encode(msg: Msg) -> bytes:
    raw = json.dumps({"t": msg.t, "payload": msg.payload}, separators=(",", ":"), sort_keys=True).encode("utf-8")
    n = len(raw)
    return n.to_bytes(4, "big") + raw

def decode(buf: bytes) -> Tuple[Msg, bytes]:
    if len(buf) < 4:
        raise ValueError("short_frame")
    n = int.from_bytes(buf[:4], "big")
    if len(buf) < 4 + n:
        raise ValueError("incomplete_frame")
    raw = buf[4:4+n]
    rest = buf[4+n:]
    d = json.loads(raw.decode("utf-8"))
    return Msg(t=str(d["t"]), payload=dict(d.get("payload") or {})), rest
