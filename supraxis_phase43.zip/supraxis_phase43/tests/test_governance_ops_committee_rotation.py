import unittest
from supraxis.state import SupraxisState
from supraxis.committee import Committee
from supraxis.envelope import EnvelopeV2, EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.crypto import sha256
from supraxis.canonical import bitset_len, bitset_set
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class GovernanceOpsCommitteeRotationTests(unittest.TestCase):
    def test_register_committee_json_then_accept_v3(self):
        # committee to be registered on-chain (via runtime op)
        committee_obj = {
            "members":[
                {"pubkey":"0x706b31","weight":4,"schemes":[1]},
                {"pubkey":"0x706b32","weight":3,"schemes":[1]},
            ]
        }
        committee = Committee.from_dict(committee_obj)
        cid = bytes.fromhex(committee.committee_id())

        # Program: GOV_REGISTER_COMMITTEE_JSON(epoch=7, committee=committee_obj); RET
        functions = {
            "main": [
                {"op":"GOV_REGISTER_COMMITTEE_JSON", "epoch": 7, "committee": committee_obj},
                {"op":"RET"}
            ]
        }
        prog = SirBinProgram(version=1, functions=functions)

        # Prepare state with governance capability enabled on chain 100
        st = SupraxisState()
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global", "chain":100, "expires": 10**18}

        # Envelope 1 (v2) triggers governance op. Same sender/target so nonce monotonic.
        payload1=b'{"gov":1}'
        env1_base = EnvelopeV2(2, 1, b32(1), b32(2), 100, b32(0xAA), 1, 5_000_000, 1, payload1, sha256(payload1), [], [])
        sig1 = make_stub_signature(1, b"pk_gov", env1_base.signing_message())
        env1 = EnvelopeV2(2, 1, b32(1), b32(2), 100, b32(0xAA), 1, 5_000_000, 1, payload1, sha256(payload1), [], [sig1])

        # Envelope 2 (v3) uses quorum proof bound to committee/epoch=7
        payload2=b'{"v3":1}'
        ph2 = sha256(payload2)
        base_v3 = EnvelopeV3(3, 7, cid, 1, b32(1), b32(2), 100, b32(0xAA), 2, 5_000_000, 1, payload2, ph2, [], [], None)
        msg2 = base_v3.signing_message()
        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)
        s0=make_stub_signature(1,b"pk1",msg2)
        s1=make_stub_signature(1,b"pk2",msg2)
        qp = QuorumProofV1(bytes(bm), [Signature(s0.scheme,b"",s0.sig), Signature(s1.scheme,b"",s1.sig)])
        env2 = EnvelopeV3(3, 7, cid, 1, b32(1), b32(2), 100, b32(0xAA), 2, 5_000_000, 1, payload2, ph2, [], [], qp)

        # Run block with two envelopes. Provide signature policy with min_weight=7 but no committee: should be attached from state after gov op executes.
        res = run_block(
            st,
            prog.functions,
            [env1, env2],
            require_signatures=True,
            sig_policy=SignaturePolicy(min_weight=7),
            enforce_committee_registry=True,
        )

        # After block, committee should be registered in state and stored
        self.assertEqual(st.committee_registry.get("7"), committee.committee_id())
        self.assertIn(committee.committee_id(), st.committee_store)
        self.assertIsInstance(res.block_hash, str)

if __name__ == "__main__":
    unittest.main()
