from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List
import time
import json
from pathlib import Path

from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

GENESIS_VERSION = 1

@dataclass(frozen=True)
class Genesis:
    version: int
    chain_id: int
    network_name: str
    created_ts: int
    initial_validators: List[dict]   # [{"pubkey": "...", "stake": 123}, ...]
    initial_params: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": int(self.version),
            "chain_id": int(self.chain_id),
            "network_name": str(self.network_name),
            "created_ts": int(self.created_ts),
            "initial_validators": list(self.initial_validators),
            "initial_params": dict(self.initial_params),
        }

    def hash_hex(self) -> str:
        return sha256(canonical_json(self.to_dict())).hex()

def make_genesis(chain_id: int, network_name: str, initial_validators: List[dict], initial_params: Dict[str, Any]) -> Genesis:
    return Genesis(
        version=GENESIS_VERSION,
        chain_id=int(chain_id),
        network_name=str(network_name),
        created_ts=int(time.time()),
        initial_validators=list(initial_validators),
        initial_params=dict(initial_params),
    )

def write_genesis(path: Path, g: Genesis) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(g.to_dict(), indent=2, sort_keys=True), encoding="utf-8")
    return g.hash_hex()

def read_genesis(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))
