from __future__ import annotations
import json
from supraxis.state import SupraxisState
from supraxis.consensus.gossip import GossipStore
from supraxis.consensus.fastsync import fast_sync
from supraxis.consensus.persist import dumps

def main():
    # Create empty state/gossip (user can replace with loaded JSON)
    st = SupraxisState()
    g = GossipStore()
    ok, why, lc = fast_sync(st, g, chain_id=1)
    print(json.dumps({"ok": ok, "why": why, "trusted": None if lc.trusted is None else {
        "epoch": lc.trusted.epoch, "height": lc.trusted.height, "block_hash": lc.trusted.block_hash
    }}, indent=2))

if __name__ == "__main__":
    main()
