from __future__ import annotations
from typing import List, Dict, Optional
from .types import Validator, Vote, QC, Proposal
from .hotstuff import ConsensusState, proposer_for, form_qc, quorum_threshold, make_block

class DeterministicSim:
    def __init__(self, chain_id: int, validators: List[Validator]):
        self.chain_id = chain_id
        self.validators = validators
        self.state = ConsensusState(chain_id=chain_id, validators=validators)

    def step(self, height: int, parent_hash: str, round: int = 0) -> Dict[str, object]:
        st = self.state
        vmap = st.vmap()
        prop = proposer_for(self.chain_id, height, round, self.validators)
        blk = make_block(self.chain_id, height, round, parent_hash, prop, body=[{"op":"NOOP"}])
        bh = blk.hash()
        st.register_block(bh, parent_hash)
        proposal = Proposal(block=blk, high_qc=st.high_qc)

        if not st.on_proposal(proposal):
            raise RuntimeError("proposal rejected")

        votes: List[Vote] = []
        for v in self.validators:
            votes.append(Vote(height=height, round=round, block_hash=bh, voter=v.vid, sig=b""))
        qc = form_qc(height, round, bh, votes, vmap)
        need = quorum_threshold(self.validators)
        if qc.power < need:
            raise RuntimeError("no quorum")
        st.on_qc(qc)
        return {"block_hash": bh, "qc": qc, "committed": list(st.committed)}

def run_three_heights(chain_id: int, validators: List[Validator]) -> Dict[str, object]:
    sim = DeterministicSim(chain_id, validators)
    parent = "00"*32
    r1 = sim.step(1, parent)
    r2 = sim.step(2, r1["block_hash"])
    r3 = sim.step(3, r2["block_hash"])
    return {"r1": r1, "r2": r2, "r3": r3}
