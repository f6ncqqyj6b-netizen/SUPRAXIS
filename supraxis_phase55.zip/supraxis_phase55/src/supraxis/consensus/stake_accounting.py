from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple
import time

@dataclass
class StakeValidator:
    pubkey: str
    stake: int
    jailed: bool = False
    slashed: bool = False

@dataclass
class StakeSet:
    validators: Dict[str, StakeValidator] = field(default_factory=dict)

    def upsert(self, pubkey: str, stake: int) -> None:
        pk = str(pubkey)
        v = self.validators.get(pk)
        if v is None:
            self.validators[pk] = StakeValidator(pubkey=pk, stake=int(stake))
        else:
            v.stake = int(stake)

    def slash(self, pubkey: str, fraction_numer: int = 1, fraction_denom: int = 10) -> Tuple[bool,str]:
        pk = str(pubkey)
        v = self.validators.get(pk)
        if v is None:
            return False, "missing_validator"
        if v.slashed:
            return False, "already_slashed"
        cut = (int(v.stake) * int(fraction_numer)) // int(fraction_denom)
        v.stake = max(0, int(v.stake) - int(cut))
        v.slashed = True
        v.jailed = True
        return True, "ok"

    def to_dict(self) -> dict:
        return {"validators": {k: {"pubkey": v.pubkey, "stake": v.stake, "jailed": v.jailed, "slashed": v.slashed} for k,v in self.validators.items()}}

    @staticmethod
    def from_dict(d: dict) -> "StakeSet":
        ss = StakeSet()
        for k, vv in (d.get("validators") or {}).items():
            ss.validators[str(k)] = StakeValidator(pubkey=str(vv.get("pubkey",k)), stake=int(vv.get("stake",0)), jailed=bool(vv.get("jailed",False)), slashed=bool(vv.get("slashed",False)))
        return ss
