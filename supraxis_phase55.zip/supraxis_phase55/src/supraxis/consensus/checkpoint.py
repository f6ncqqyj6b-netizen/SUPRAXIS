from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

@dataclass(frozen=True)
class Checkpoint:
    chain_id: int
    epoch: int
    height: int
    state_root: str      # hex
    block_hash: str      # hex
    validators_hash: str # sha256 of canonical validator snapshot

    def signing_message(self) -> bytes:
        payload = {
            "t":"SUPRAXIS_CHECKPOINT_V1",
            "chain_id": int(self.chain_id),
            "epoch": int(self.epoch),
            "height": int(self.height),
            "state_root": str(self.state_root),
            "block_hash": str(self.block_hash),
            "validators_hash": str(self.validators_hash),
        }
        return b"SUPRAXIS|CHECKPOINT|V1|" + canonical_json(payload)

def validators_hash(snapshot: list) -> str:
    return sha256(canonical_json(snapshot)).hex()
