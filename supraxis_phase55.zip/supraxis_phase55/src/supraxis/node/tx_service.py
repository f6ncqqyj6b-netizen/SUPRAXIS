from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, List, Tuple

from supraxis.mempool import Mempool
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P

@dataclass
class TxService:
    mempool: Mempool

    async def handle_txs(self, msg: Msg) -> Msg:
        txs = list(msg.payload.get("txs") or [])
        accepted = []
        rejected = []
        for d in txs:
            ok, why, h = self.mempool.add_tx_dict(d)
            if ok:
                accepted.append(h)
            else:
                rejected.append({"why": why})
        return Msg(P.RSP_TXS, {"accepted": accepted, "rejected": rejected, "mempool": self.mempool.size()})
