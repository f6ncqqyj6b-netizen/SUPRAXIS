#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from urllib import request, parse

def _get(url: str) -> dict:
    with request.urlopen(url, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))

def _post(url: str, obj: dict) -> dict:
    raw = json.dumps(obj).encode("utf-8")
    req = request.Request(url, data=raw, headers={"Content-Type":"application/json"})
    with request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))

def main():
    ap = argparse.ArgumentParser(description="Supraxis CLI (minimal) for RPC")
    ap.add_argument("--rpc", default="http://127.0.0.1:8545")
    sub = ap.add_subparsers(dest="cmd", required=True)

    sub.add_parser("health")

    mp = sub.add_parser("mempool")
    mp.add_argument("--limit", type=int, default=100)

    tx = sub.add_parser("tx-submit")
    tx.add_argument("--tx", required=True, help="Path to tx.json")

    bl = sub.add_parser("block-get")
    bl.add_argument("--hash", required=True)

    evs = sub.add_parser("evidence-submit")
    evs.add_argument("--evidence", required=True, help="Path to evidence.json")

    evq = sub.add_parser("evidence-status")
    evq.add_argument("--pubkey", required=True)

    gs = sub.add_parser("gov-submit")
    gs.add_argument("--req", required=True, help="Path to gov_submit.json {kind,title,payload,proposer}")

    gq = sub.add_parser("gov-queue")
    gq.add_argument("--id", required=True)

    ge = sub.add_parser("gov-execute")
    ge.add_argument("--id", required=True)

    gstat = sub.add_parser("gov-status")
    gstat.add_argument("--id", required=True)

    args = ap.parse_args()
    base = args.rpc.rstrip("/")

    if args.cmd == "health":
        print(json.dumps(_get(base + "/health"), indent=2, sort_keys=True)); return
    if args.cmd == "mempool":
        print(json.dumps(_get(base + f"/mempool?limit={args.limit}"), indent=2, sort_keys=True)); return
    if args.cmd == "tx-submit":
        d = json.loads(open(args.tx,"r",encoding="utf-8").read())
        print(json.dumps(_post(base + "/tx/submit", {"tx": d}), indent=2, sort_keys=True)); return
    if args.cmd == "block-get":
        print(json.dumps(_get(base + f"/block/{args.hash}"), indent=2, sort_keys=True)); return
    if args.cmd == "evidence-submit":
        d = json.loads(open(args.evidence,"r",encoding="utf-8").read())
        print(json.dumps(_post(base + "/evidence/submit", {"evidence": d}), indent=2, sort_keys=True)); return
    if args.cmd == "evidence-status":
        q = parse.quote(args.pubkey)
        print(json.dumps(_get(base + f"/evidence/status?pubkey={q}"), indent=2, sort_keys=True)); return
    if args.cmd == "gov-submit":
        d = json.loads(open(args.req,"r",encoding="utf-8").read())
        print(json.dumps(_post(base + "/governance/submit", d), indent=2, sort_keys=True)); return
    if args.cmd == "gov-queue":
        print(json.dumps(_post(base + "/governance/queue", {"id": args.id}), indent=2, sort_keys=True)); return
    if args.cmd == "gov-execute":
        print(json.dumps(_post(base + "/governance/execute", {"id": args.id}), indent=2, sort_keys=True)); return
    if args.cmd == "gov-status":
        q = parse.quote(args.id)
        print(json.dumps(_get(base + f"/governance/status?id={q}"), indent=2, sort_keys=True)); return

if __name__ == "__main__":
    main()
