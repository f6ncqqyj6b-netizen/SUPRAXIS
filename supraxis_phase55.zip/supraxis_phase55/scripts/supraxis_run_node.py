#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from pathlib import Path

from supraxis.config import read_config
from supraxis.genesis import read_genesis

from supraxis.node.db import NodeDB
from supraxis.node.peerdb import PeerDB
from supraxis.p2p.discovery import DiscoveryService
from supraxis.consensus.gossip import GossipStore
from supraxis.node.blockstore import BlockStore
from supraxis.node.service import NodeService

from supraxis.mempool import Mempool
from supraxis.node.tx_service import TxService
from supraxis.node.block_builder import BlockBuilder
from supraxis.node.block_gossip import BlockGossipService

from supraxis.node.evidence_store import EvidenceStore
from supraxis.node.evidence_service import EvidenceService
from supraxis.governance import GovernanceEngine
from supraxis.node.governance_service import GovernanceService
from supraxis.ledger_state import LedgerState
from supraxis.node.state_service import StateService

from supraxis.p2p.transport import AsyncTCPServer, TransportConfig
from supraxis.rpc.server import RPCContext, start_rpc_server
from supraxis.p2p.peer_manager import PeerPolicy
from supraxis.p2p.antispam import GlobalLimits

import asyncio

async def main_async(args):
    cfg = read_config(Path(args.config))
    genesis = read_genesis(Path(args.genesis))

    data_dir = Path(cfg.get("data_dir","./data"))
    data_dir.mkdir(parents=True, exist_ok=True)

    db = NodeDB(data_dir)
    peerdb = PeerDB(data_dir / "peers.json")
    disc = DiscoveryService(peerdb)

    # seed nodes into peerdb
    for s in (cfg.get("seed_nodes") or []):
        try:
            host, port = s.split(":")
            disc.add_peer(host, int(port))
        except Exception:
            continue

    blocks = BlockStore()
    gossip = GossipStore()

    mp = Mempool(chain_id=int(cfg["chain_id"]))
    txsvc = TxService(mp)
    builder = BlockBuilder(chain_id=int(cfg["chain_id"]), proposer=args.node_id, mempool=mp)
    bg = BlockGossipService(blockstore=blocks, builder=builder)

    
    stsvc = StateService(state=LedgerState(), db=db)
    stsvc.load_from_db()

    evid = EvidenceService(store=EvidenceStore(), db=db)
    evid.load_from_db()

    gov = GovernanceService(engine=GovernanceEngine(), db=db)
    gov.load_from_db()

    svc = NodeService(
        chain_id=int(cfg["chain_id"]),
        gossip=gossip,
        blocks=blocks,
        discovery=disc,
        db=db,
        tx_service=txsvc,
        block_gossip=bg,
        evidence_service=evid,
        governance_service=gov,
    )

    pol = PeerPolicy(); pol.reqs_per_sec = 200.0; pol.burst = 200.0
    gl = GlobalLimits(); gl.max_reqs_per_sec = 500.0; gl.burst = 500.0
    tcfg = TransportConfig(chain_id=int(cfg["chain_id"]), max_frame_bytes=int(cfg.get("max_frame_bytes",2_000_000)),
                           idle_timeout_sec=15, policy=pol, global_limits=gl)

    
    # Start RPC server (HTTP/JSON)
    rpc_ctx = RPCContext(
        chain_id=int(cfg["chain_id"]),
        mempool=mp,
        blocks=blocks,
        evidence=evid,
        governance=gov,
        state=stsvc,
    )
    rpcd, _t = start_rpc_server(args.host, int(cfg.get("rpc_port", 8545)), rpc_ctx)
    print(f"rpc listening on {args.host}:{rpcd.server_port}")

    server = AsyncTCPServer(args.host, int(args.port), tcfg, svc.handle)
    await server.start()
    print(f"node {args.node_id} listening on {args.host}:{server.port}")

    # run forever
    while True:
        await asyncio.sleep(3600)

def main():
    ap = argparse.ArgumentParser(description="Run Supraxis node (reference)")
    ap.add_argument("--config", required=True)
    ap.add_argument("--genesis", required=True)
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=30303)
    ap.add_argument("--node-id", type=str, default="node")
    args = ap.parse_args()
    asyncio.run(main_async(args))

if __name__ == "__main__":
    main()
