import unittest
import tempfile
from pathlib import Path
import asyncio

from supraxis.mempool import Mempool
from supraxis.tx import make_tx
from supraxis.node.block_builder import BlockBuilder
from supraxis.node.block_gossip import BlockGossipService
from supraxis.node.blockstore import BlockStore

from supraxis.p2p.transport import AsyncTCPServer, AsyncTCPClient, TransportConfig
from supraxis.p2p.discovery import DiscoveryService
from supraxis.node.peerdb import PeerDB
from supraxis.node.service import NodeService
from supraxis.consensus.gossip import GossipStore
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P
from supraxis.p2p.peer_manager import PeerPolicy
from supraxis.p2p.antispam import GlobalLimits

class TestPhase49(unittest.IsolatedAsyncioTestCase):
    async def test_build_and_gossip_block(self):
        mp = Mempool(chain_id=1)
        t1 = make_tx(1, 0, "a", "b", "m", {"x":1}, max_fee=10**9).to_dict()
        ok, _, h1 = mp.add_tx_dict(t1)
        self.assertTrue(ok)
        builder = BlockBuilder(chain_id=1, proposer="val1", mempool=mp)
        block = builder.build(height=1, parent_hash="0"*64)
        self.assertTrue(len(block.txs) >= 1)
        bh = block.hash_hex()

        # server node with block gossip
        store = BlockStore()
        bg = BlockGossipService(blockstore=store, builder=builder)
        peerdb = PeerDB(Path(tempfile.gettempdir())/"_peers_tmp.json")
        disc = DiscoveryService(peerdb)
        svc = NodeService(chain_id=1, gossip=GossipStore(), blocks=store, discovery=disc, block_gossip=bg)

        pol = PeerPolicy(); pol.reqs_per_sec = 500.0; pol.burst = 500.0
        gl = GlobalLimits(); gl.max_reqs_per_sec = 500.0; gl.burst = 500.0
        cfg = TransportConfig(chain_id=1, max_frame_bytes=2_000_000, idle_timeout_sec=5, policy=pol, global_limits=gl)
        server = AsyncTCPServer("127.0.0.1", 0, cfg, svc.handle)
        await server.start()
        port = server._server.sockets[0].getsockname()[1]

        c = AsyncTCPClient("127.0.0.1", port)
        await c.connect()
        await c.send(Msg(P.REQ_HELLO, {"node_id":"x","chain_id":1,"version":"v"}))
        await c.recv_one()
        await c.send(Msg(P.REQ_NEW_BLOCK, {"block": block.to_dict()}))
        rsp = await c.recv_one(timeout=3.0)
        self.assertEqual(rsp.t, P.RSP_NEW_BLOCK)
        self.assertTrue(rsp.payload.get("ok"))
        self.assertIn("hash", rsp.payload)
        # block stored
        self.assertIsNotNone(store.get_block(rsp.payload["hash"]))
        # tx removed from mempool by builder accept
        self.assertEqual(mp.size(), 0)

        await c.close()
        await server.close()

if __name__ == "__main__":
    unittest.main()
