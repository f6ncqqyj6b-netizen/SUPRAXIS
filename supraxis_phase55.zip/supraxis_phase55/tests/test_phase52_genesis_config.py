import unittest
import tempfile
from pathlib import Path
import json

from supraxis.genesis import make_genesis, write_genesis, read_genesis
from supraxis.config import NetworkConfig, write_config, read_config, config_hash

class TestPhase52(unittest.TestCase):
    def test_genesis_hash_stable(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/"genesis.json"
            g = make_genesis(1, "n", [{"pubkey":"p","stake":1}], {"x":1})
            h1 = write_genesis(p, g)
            d = read_genesis(p)
            # recompute by rebuilding with same dict ordering
            h2 = g.hash_hex()
            self.assertEqual(h1, h2)
            self.assertEqual(d["chain_id"], 1)

    def test_config_hash_written(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/"network_config.json"
            cfg = NetworkConfig(version=1, chain_id=1, network_name="n", seed_nodes=["a:1"], genesis_hash="0"*64)
            h = write_config(p, cfg)
            d = read_config(p)
            self.assertEqual(h, config_hash(d))

if __name__ == "__main__":
    unittest.main()
