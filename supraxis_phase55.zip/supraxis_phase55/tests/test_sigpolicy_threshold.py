import unittest
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.sigverify import make_stub_signature
from supraxis.crypto import sha256

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class SigPolicyThresholdTests(unittest.TestCase):
    def test_threshold_k_of_n(self):
        payload=b'{"t":1}'
        ph=sha256(payload)
        base = EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[])
        msg = base.signing_message()

        s_good1 = make_stub_signature(1, b"pk1", msg)
        s_good2 = make_stub_signature(1, b"pk2", msg)
        s_bad = make_stub_signature(1, b"pk3", msg)
        s_bad = s_bad.__class__(s_bad.scheme, s_bad.pubkey, b"xxxx")  # corrupt

        env = EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[s_good1, s_good2, s_bad])

        env.validate(require_signatures=True, policy=SignaturePolicy(min_valid=2))
        with self.assertRaises(Exception):
            env.validate(require_signatures=True, policy=SignaturePolicy(min_valid=3))

if __name__ == "__main__":
    unittest.main()
