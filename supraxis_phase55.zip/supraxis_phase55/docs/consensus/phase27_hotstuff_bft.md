# Phase 27 — HotStuff-style BFT Consensus (Spec + Reference Scaffolding)

This document defines a **minimal, deterministic, HotStuff-style BFT** consensus layer for Supraxis as a sovereign L1.

> Scope: consensus *only*. Execution remains Supraxis runtime. Block validity includes replay + invariants (Phase 26).

---

## Goals

- **Deterministic finality** under partial synchrony.
- **Stake-weighted voting** (fixed supply compatible; no inflation required).
- **Slashing-proof friendly** message formats for:
  - double-vote
  - equivocation
  - invalid proposal (optional)
- **Deterministic replay**: any honest node reconstructs the same finalized chain.

---

## Terminology

- `height`: block number (genesis height = 0)
- `round`: consensus round at a height (increments on timeout)
- `proposer`: validator chosen for `(height, round)` deterministically
- `QC` (Quorum Certificate): aggregated signatures from ≥ 2/3 of voting power for a proposal
- `commit`: finalization event (block becomes irreversible)

Assumption:
- Validator set `V` is known at each height (can be updated by governance later; Phase 33).
- Voting power = `stake_weight` (integer).

Threshold:
- `quorum_power = floor(2/3 * total_power) + 1`

---

## Block Structure (Consensus Header)

A Supraxis block is:

- `header` (consensus fields)
- `body` (transactions/envelopes)
- `execution_result` (events, final block hash, state commitment chain)

Consensus header fields:

- `chain_id`
- `height`
- `round`
- `parent_hash`
- `proposer_id`
- `tx_root` (optional)
- `state_commitment_root` (optional future; Phase 31+)

Block hash:
- `block_hash = sha256(canonical_json(block))`

---

## Deterministic Proposer Selection

For height `h`, round `r`, with validator ids sorted ascending:

```
idx = sha256(chain_id || h || r) mod len(validators)
proposer = validators[idx]
```

(Stake-weighted proposer selection can be introduced later; this minimal version is uniform over ids.)

---

## HotStuff-Style Phases (Minimal)

We use a **single-leader, three-step** pipeline in simplified form:

1) **PROPOSE**
- Proposer broadcasts `Proposal(block, highQC)`

2) **VOTE**
- Validators verify:
  - correct proposer for (h,r)
  - block extends known parent
  - block is structurally valid
  - highQC is valid (if present)
- Validators send `Vote(height, round, block_hash)` to proposer

3) **QC FORMATION**
- Proposer aggregates votes into `QC(block_hash, height, round, sigs, power)`

4) **COMMIT RULE (3-chain commit)**
- Track a chain of QCs: `b0 <- b1 <- b2`
- When a block `b` gets a QC and `b.parent` has a QC and `b.grandparent` has a QC:
  - commit `b.grandparent`

This yields deterministic finality under partial synchrony.

---

## Timeouts / Round Change

If a validator does not see progress at `(h,r)` within `timeout_ms`:

- broadcast `Timeout(height, round, highQC)` (signed)
- when proposer (or anyone) collects ≥ quorum timeout power:
  - form `TC` (Timeout Certificate)
  - advance to next round `r+1` using highest QC/TC as `highQC`

---

## Slashing Proofs (Consensus-Level)

### Double-vote
A validator signs two different `Vote` messages for same `(height, round)` but different `block_hash`.

Proof = (vote1, vote2, validator_signature)

### Equivocating proposer
Proposer sends two different `Proposal` blocks for same `(height, round)`.

Proof = (proposal1, proposal2, proposer_signature)

(Enforcement wired in Phase 30/33.)

---

## What Phase 27 Provides

- Message types (proposal/vote/timeout/QC/TC) with canonical hashing.
- Deterministic proposer selection.
- Reference simulator to validate:
  - quorum formation
  - QC verification
  - 3-chain commit rule
- Unit tests for deterministic behavior.

Next phases:
- Phase 28: P2P gossip + mempool ordering
- Phase 29: production signatures + aggregation formats
- Phase 30: validator economics + slashing integration
