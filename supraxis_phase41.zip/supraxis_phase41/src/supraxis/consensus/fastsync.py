from __future__ import annotations
from typing import Tuple, Optional
from supraxis.state import SupraxisState
from .gossip import GossipStore
from .lightclient import LightClient

def fast_sync(state: SupraxisState, gossip: GossipStore, chain_id: int) -> Tuple[bool,str,LightClient]:
    """End-to-end fast sync:

    1) Pick best signed checkpoint from gossip
    2) Create light client and accept that checkpoint
    3) Prefer signed headers from checkpoint to signed tip
    4) Fallback to unsigned headers (requires QC) if signed headers path not available

    Returns (ok, reason, lightclient).
    """
    scp = gossip.best_checkpoint(min_height=0)
    lc = LightClient(chain_id=chain_id)
    if scp is None:
        return False, "no_checkpoint", lc

    ok, why = lc.accept_signed_checkpoint(state, scp)
    if not ok:
        return False, f"checkpoint_rejected:{why}", lc

    tip_sh = gossip.tip_signed_header(chain_id)
    if tip_sh is not None:
        path = gossip.signed_headers_from(start_hash=scp.checkpoint.block_hash, end_hash=tip_sh.header.block_hash)
        if path and path[-1].header.block_hash == tip_sh.header.block_hash:
            ok2, why2 = lc.sync_signed_headers(state, path)
            if not ok2:
                return False, f"signed_header_sync_failed:{why2}", lc
            return True, "ok", lc

    # Fallback: raw headers to raw tip
    tip_h = gossip.tip_header(chain_id)
    if tip_h is None:
        return True, "ok_no_tip", lc
    path2 = gossip.headers_from(start_hash=scp.checkpoint.block_hash, end_hash=tip_h.block_hash)
    if path2:
        ok3, why3 = lc.sync_headers(state, path2)
        if not ok3:
            return False, f"header_sync_failed:{why3}", lc
    return True, "ok", lc
