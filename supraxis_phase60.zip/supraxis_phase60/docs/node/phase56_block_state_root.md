# Phase 56 — Block State Root (Compute + Verify)

This phase wires the Phase 55 ledger state root into blocks:

- BlockBuilder computes `state_root` when building a block (using a cloned LedgerState)
- BlockBuilder verifies incoming blocks by recomputing `state_root` against local state
- On successful acceptance, the local LedgerState is advanced and persisted

Files:
- `src/supraxis/netblock.py` — helper `make_netblock_with_root(...)`
- `src/supraxis/node/block_builder.py` — compute/verify/apply state_root
- `scripts/supraxis_run_node.py` — passes StateService into BlockBuilder

Next:
Phase 57 — Persist blocks and state together with height/parent checks.
