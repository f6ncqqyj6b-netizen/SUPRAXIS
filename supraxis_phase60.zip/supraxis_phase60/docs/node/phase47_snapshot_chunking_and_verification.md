# Phase 47 — Snapshot Chunking + Verification + State-Sync Improvements

This phase enables **large state snapshots** to be transferred over P2P safely.

## Snapshot Chunking
`src/supraxis/node/snapshot_chunks.py`
- deterministic snapshot serialization
- chunking (64KB default)
- snapshot meta:
  - total size
  - chunk hashes
  - full snapshot hash
- verification of chunk hashes + full hash

## Protocol Extensions
`src/supraxis/p2p/protocol.py`
- `snapshot_meta` / `snapshot_meta_ok`
- `snapshot_chunk` / `snapshot_chunk_ok`

## Node Serving
`src/supraxis/node/service.py`
- serves snapshot meta + chunks from `NodeDB.load_snapshot()` (latest)
- legacy `snapshot` request returns `use_snapshot_meta`

## Client Fetch + Store
`src/supraxis/node/snapshot_sync.py`
- pulls meta, downloads all chunks, verifies hashes, stores snapshot via `NodeDB.save_snapshot`

## Next
Phase 48: transaction format + mempool + fee model baseline.
