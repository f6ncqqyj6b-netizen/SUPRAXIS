# Phase 52 — Genesis Tooling + Seed Node Bootstrapping + Reproducible Configs

This phase introduces:
- `genesis.json` (deterministic hash)
- `network_config.json` (references genesis hash + seed nodes)
- reference scripts to generate artifacts and run a seed node.

## Files
- `src/supraxis/genesis.py` — genesis structure + hash
- `src/supraxis/config.py` — network config schema
- `scripts/supraxis_genesis.py` — generates `genesis.json` + `network_config.json`
- `scripts/supraxis_run_node.py` — loads config+genesis, seeds discovery, starts P2P server
- `artifacts/example_validators.json`
- `artifacts/example_params.json`

## Quickstart
1. Generate artifacts:
   - `python scripts/supraxis_genesis.py --chain-id 1 --network-name supraxis-dev \
        --validators artifacts/example_validators.json --params artifacts/example_params.json \
        --seed 127.0.0.1:30303 --out-dir artifacts/out`

2. Run a node:
   - `PYTHONPATH=src python scripts/supraxis_run_node.py \
        --config artifacts/out/network_config.json \
        --genesis artifacts/out/genesis.json \
        --port 30303 --node-id seed1`
