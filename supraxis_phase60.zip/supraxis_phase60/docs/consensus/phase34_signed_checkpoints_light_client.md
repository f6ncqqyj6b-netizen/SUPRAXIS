# Phase 34 — Signed Checkpoints + Light Client Verification

This phase upgrades checkpoints (Phase 33) into a **fast-sync** primitive.

## SignedCheckpoint

`src/supraxis/consensus/signed_checkpoint.py`

- `Checkpoint` (domain-separated signing message)
- `SignedCheckpoint` = `Checkpoint` + signatures from validators

Signatures:
- Each signature record includes:
  - `vid` (validator id)
  - `scheme` (11=Ed25519, 12=secp256k1 ECDSA)
  - `sig` (hex)

In Supraxis epoch snapshots, **vid == validator pubkey hex** (by design), so verification can use
`Signature(pubkey=vid_bytes, sig=sig_bytes)`.

Verification:
- De-duplicate by `vid`
- Verify each signature over `Checkpoint.signing_message()`
- Accumulate signed validator power using the epoch snapshot powers
- Require `signed_power >= quorum_power`

## Light Client

`src/supraxis/consensus/lightclient.py`

A minimal light client that can:
- validate that `validators_hash` matches the on-chain epoch snapshot
- verify quorum signatures for the epoch
- accept checkpoint only if height increases

## Next

Phase 35: checkpoint gossip + caching + “header-only sync” from trusted checkpoint to head.
