import unittest
import tempfile
from pathlib import Path
import asyncio

from supraxis.node.tx_service import TxService
from supraxis.mempool import Mempool
from supraxis.tx import make_tx
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P

class TestPhase48TxGossip(unittest.IsolatedAsyncioTestCase):
    async def test_tx_service_accepts(self):
        mp = Mempool(chain_id=1)
        svc = TxService(mp)
        tx = make_tx(1, 0, "a", "b", "m", {"x":1}, max_fee=10**9).to_dict()
        rsp = await svc.handle_txs(Msg(P.REQ_TXS, {"txs":[tx]}))
        self.assertEqual(rsp.t, P.RSP_TXS)
        self.assertEqual(len(rsp.payload.get("accepted")), 1)
        self.assertEqual(mp.size(), 1)

if __name__ == "__main__":
    unittest.main()
