import unittest
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.sigverify import Signature
from supraxis.crypto import sha256

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class CryptoEd25519OptionalTests(unittest.TestCase):
    def test_ed25519_verification_if_available(self):
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
            from cryptography.hazmat.primitives import serialization
        except Exception:
            self.skipTest("cryptography not installed")

        payload=b'{"z":1}'
        ph=sha256(payload)
        base = EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[])
        msg = base.signing_message()

        sk = Ed25519PrivateKey.generate()
        pk = sk.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )
        sig = sk.sign(msg)

        env = EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[Signature(11, pk, sig)])
        env.validate(require_signatures=True, policy=SignaturePolicy(min_valid=1, allowed_schemes={11}))

if __name__ == "__main__":
    unittest.main()
