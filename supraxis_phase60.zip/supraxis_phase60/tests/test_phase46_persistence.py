import unittest
import tempfile
from pathlib import Path

from supraxis.node.db import NodeDB
from supraxis.consensus.gossip import GossipStore
from supraxis.node.blockstore import BlockStore

class TestPhase46(unittest.TestCase):
    def test_snapshot_versioning_and_latest(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            sid1 = db.save_snapshot({"storage":{"a":1}}, snapshot_id="one")
            sid2 = db.save_snapshot({"storage":{"a":2}}, snapshot_id="two")
            self.assertEqual(sid1, "one")
            self.assertEqual(sid2, "two")
            snap = db.load_snapshot()
            self.assertEqual(snap["storage"]["a"], 2)

    def test_checksum_detects_corruption(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            bs = BlockStore()
            bs.put("h1", {"x":1})
            db.save_blocks(bs)
            p = Path(td)/"blocks.json"
            # corrupt file
            raw = p.read_bytes()
            p.write_bytes(raw + b"corrupt")
            b2 = db.load_blocks()
            # should fall back to empty due to checksum mismatch
            self.assertIsNone(b2.get_block("h1"))

    def test_gossip_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            g = GossipStore()
            db.save_gossip(g)
            g2 = db.load_gossip()
            self.assertIsNotNone(g2)

if __name__ == "__main__":
    unittest.main()
