import unittest
from supraxis.mempool import Mempool
from supraxis.tx import make_tx
from supraxis.node.block_builder import BlockBuilder
from supraxis.node.state_service import StateService
from supraxis.ledger_state import LedgerState

class TestPhase56(unittest.TestCase):
    def test_build_and_accept(self):
        mp = Mempool(chain_id=1)
        stsvc = StateService(state=LedgerState(), db=None)
        stsvc.state.get("alice").balance = 100

        tx = make_tx(1, 0, "alice", "bob", "transfer", {"amount": 10}, max_fee=10**9)
        mp.add_tx_dict(tx.to_dict())
        bb = BlockBuilder(chain_id=1, proposer="n1", mempool=mp, state=stsvc)
        b = bb.build(height=1, parent_hash="0"*64)
        d = b.to_dict()
        self.assertTrue(isinstance(d["state_root"], str))
        self.assertNotEqual(d["state_root"], "")

        ok, why, h = bb.accept_block(d)
        self.assertTrue(ok, why)
        self.assertEqual(stsvc.state.get("alice").balance, 90)
        self.assertEqual(stsvc.state.get("bob").balance, 10)

    def test_reject_bad_root(self):
        mp = Mempool(chain_id=1)
        stsvc = StateService(state=LedgerState(), db=None)
        stsvc.state.get("alice").balance = 100

        tx = make_tx(1, 0, "alice", "bob", "transfer", {"amount": 10}, max_fee=10**9)
        mp.add_tx_dict(tx.to_dict())
        bb = BlockBuilder(chain_id=1, proposer="n1", mempool=mp, state=stsvc)
        b = bb.build(height=1, parent_hash="0"*64)
        d = b.to_dict()
        d["state_root"] = "1"*64
        ok, why, _ = bb.accept_block(d)
        self.assertFalse(ok)
        self.assertEqual(why, "bad_state_root")

if __name__ == "__main__":
    unittest.main()
