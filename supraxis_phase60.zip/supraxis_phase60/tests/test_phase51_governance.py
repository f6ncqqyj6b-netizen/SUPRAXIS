import unittest
import tempfile
from pathlib import Path
import asyncio
import time

from supraxis.governance import GovernanceEngine, GovState, GovParams, make_proposal, KIND_PARAM_CHANGE
from supraxis.node.db import NodeDB
from supraxis.node.governance_service import GovernanceService
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P

from supraxis.node.evidence_store import EvidenceStore
from supraxis.consensus.stake_accounting import StakeSet
from supraxis.node.slash_adapter import SlashingAdapter

class TestPhase51(unittest.IsolatedAsyncioTestCase):
    async def test_timelock_execute(self):
        eng = GovernanceEngine()
        eng.state.params = GovParams(timelock_sec=2, grace_period_sec=2, guardian_pubkeys=["g1"], min_guardians=1)
        prop = make_proposal(KIND_PARAM_CHANGE, "t", {"x":1}, "alice", created_ts=1)
        ok, _ = eng.submit(prop)
        self.assertTrue(ok)
        ok, _ = eng.queue(prop.id, now=10)
        self.assertTrue(ok)
        ok2, why2, _ = eng.execute(prop.id, now=11)
        self.assertFalse(ok2)
        self.assertEqual(why2, "timelocked")
        ok3, why3, pr = eng.execute(prop.id, now=12)
        self.assertTrue(ok3)
        self.assertEqual(pr["id"], prop.id)

    async def test_expiry(self):
        eng = GovernanceEngine()
        eng.state.params = GovParams(timelock_sec=1, grace_period_sec=1, guardian_pubkeys=["g1"], min_guardians=1)
        prop = make_proposal(KIND_PARAM_CHANGE, "t", {"x":1}, "alice", created_ts=1)
        eng.submit(prop)
        eng.queue(prop.id, now=10)
        ok, why, _ = eng.execute(prop.id, now=13)
        self.assertFalse(ok)
        self.assertEqual(why, "expired")

    async def test_emergency_brake(self):
        eng = GovernanceEngine()
        eng.state.params = GovParams(timelock_sec=1, grace_period_sec=1, guardian_pubkeys=["g1","g2"], min_guardians=2)
        ok, why = eng.emergency_halt(["g1"])
        self.assertFalse(ok)
        ok2, why2 = eng.emergency_halt(["g1","g2"])
        self.assertTrue(ok2)
        prop = make_proposal(KIND_PARAM_CHANGE, "t", {"x":1}, "alice", created_ts=1)
        ok3, why3 = eng.submit(prop)
        self.assertFalse(ok3)
        self.assertEqual(why3, "halted")

    async def test_persist(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            eng = GovernanceEngine()
            gs = GovernanceService(engine=eng, db=db)
            rsp = await gs.handle_submit(Msg(P.REQ_GOV_SUBMIT, {"kind":"param_change","title":"t","payload":{"x":1},"proposer":"alice"}))
            self.assertTrue(rsp.payload.get("ok"))
            gs2 = GovernanceService(engine=GovernanceEngine(), db=db)
            gs2.load_from_db()
            self.assertTrue(len(gs2.engine.state.proposals) >= 1)

    async def test_slash_adapter(self):
        es = EvidenceStore()
        vs = StakeSet()
        pk = "0x" + "11"*32
        vs.upsert(pk, 1000)
        es.slashed[pk] = time.time()
        ad = SlashingAdapter(es, vs)
        n = ad.apply_new_slashes()
        self.assertEqual(n, 1)
        self.assertTrue(vs.validators[pk].slashed)
        self.assertTrue(vs.validators[pk].jailed)

if __name__ == "__main__":
    unittest.main()
