# SUPRAXIS (Phase 7)

Phase 7 adds:
- **Envelope v2 signatures**: structured TLV (scheme/pubkey/sig) with canonical ordering
- **Signature enforcement**: `require_signatures=True` validates at least one signature
- **Multi-envelope block fixtures**
- **Sandbox driver adapter**: drains inbox -> runs block deterministically

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
