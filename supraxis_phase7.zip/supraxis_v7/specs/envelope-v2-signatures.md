# Envelope v2 Signatures (SCES v2)

Signature section encoding:
- sig_count: u16
- repeated sig records, sorted canonically by:
  `scheme(u16) || pubkey || sig`

Each signature record:
- scheme: u16
- pubkey_len: u16 + pubkey bytes
- sig_len: u16 + sig bytes

Signing preimage:
- canonical envelope bytes with **sig_count=0** (i.e., signatures omitted)

Validation rule (Phase 7):
- If `require_signatures=True`, at least one signature must verify over the signing preimage.
