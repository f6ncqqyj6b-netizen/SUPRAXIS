from __future__ import annotations
import argparse, json
from pathlib import Path
from .state import SupraxisState
from .crypto import sha256
from .envelope import EnvelopeV1, EnvelopeV2, decode_envelope
from .sigverify import make_stub_signature, Signature
from .sirbin import SirBinProgram, disasm as sir_disasm
from .block import run_block, block_hash

def _bytes32(s: str) -> bytes:
    s=s.lower().strip()
    if s.startswith("0x"): s=s[2:]
    b=bytes.fromhex(s)
    if len(b)!=32: raise SystemExit("expected 32-byte hex")
    return b

def cmd_env_verify(a):
    env=decode_envelope(Path(a.infile).read_bytes())
    env.validate(require_signatures=a.require_sigs)
    print("OK")

def cmd_env_create_v2(a):
    payload_obj=json.loads(Path(a.payload_json).read_text(encoding="utf-8"))
    payload=json.dumps(payload_obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ph=sha256(payload)
    sigs=[]
    env0 = EnvelopeV2(
        2, int(a.origin_chain), _bytes32(a.origin_tx), _bytes32(a.origin_sender),
        int(a.target_chain), _bytes32(a.target_contract),
        int(a.nonce), int(a.gas_limit), int(a.payload_type),
        payload, ph, [], []
    )
    msg = env0.signing_message()
    if a.stub_sig_scheme is not None:
        pk = bytes.fromhex(a.stub_pubkey[2:] if a.stub_pubkey.startswith("0x") else a.stub_pubkey)
        sigs=[make_stub_signature(int(a.stub_sig_scheme), pk, msg)]
    env = EnvelopeV2(
        2, int(a.origin_chain), _bytes32(a.origin_tx), _bytes32(a.origin_sender),
        int(a.target_chain), _bytes32(a.target_contract),
        int(a.nonce), int(a.gas_limit), int(a.payload_type),
        payload, ph, [], sigs
    )
    Path(a.out).write_bytes(env.canonical_bytes())
    print(a.out)

def cmd_sir_compile(a):
    obj=json.loads(Path(a.infile).read_text(encoding="utf-8"))
    prog=SirBinProgram(version=1, functions=obj["functions"])
    Path(a.out).write_bytes(prog.encode())
    print(a.out)

def cmd_sir_disasm(a):
    print(sir_disasm(Path(a.infile).read_bytes()), end="")

def cmd_state_init(a):
    Path(a.out).write_text(SupraxisState().to_json(), encoding="utf-8")
    print(a.out)

def cmd_block_run(a):
    st=SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8"))
    prog=SirBinProgram.decode(Path(a.sirb).read_bytes())
    envs=[decode_envelope(Path(p).read_bytes()) for p in a.envelopes]
    res=run_block(st, prog.functions, envs, entry=a.entry, require_signatures=a.require_sigs)
    out={"state": json.loads(res.state_json), "events": res.events, "block_hash": res.block_hash}
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True), encoding="utf-8")
    print(res.block_hash)

def cmd_block_hash(a):
    print(block_hash(Path(a.infile).read_text(encoding="utf-8")))

def build():
    p=argparse.ArgumentParser(prog="supraxis")
    sp=p.add_subparsers(dest="cmd", required=True)

    st=sp.add_parser("state"); sps=st.add_subparsers(dest="sub", required=True)
    x=sps.add_parser("init"); x.add_argument("--out", required=True); x.set_defaults(func=cmd_state_init)

    env=sp.add_parser("envelope"); eps=env.add_subparsers(dest="sub", required=True)
    x=eps.add_parser("verify"); x.add_argument("--in", dest="infile", required=True)
    x.add_argument("--require-sigs", action="store_true"); x.set_defaults(func=cmd_env_verify)

    x=eps.add_parser("create-v2")
    x.add_argument("--origin-chain", required=True, type=int); x.add_argument("--origin-tx", required=True); x.add_argument("--origin-sender", required=True)
    x.add_argument("--target-chain", required=True, type=int); x.add_argument("--target-contract", required=True)
    x.add_argument("--nonce", required=True, type=int); x.add_argument("--gas-limit", required=True, type=int); x.add_argument("--payload-type", required=True, type=int)
    x.add_argument("--payload-json", required=True)
    x.add_argument("--stub-sig-scheme", type=int, default=None, help="0/1/2 for deterministic stub signature")
    x.add_argument("--stub-pubkey", default="0x01", help="hex bytes for stub pubkey (any length)")
    x.add_argument("--out", required=True)
    x.set_defaults(func=cmd_env_create_v2)

    sir=sp.add_parser("sir"); sps=sir.add_subparsers(dest="sub", required=True)
    x=sps.add_parser("compile"); x.add_argument("--in", dest="infile", required=True); x.add_argument("--out", required=True); x.set_defaults(func=cmd_sir_compile)
    x=sps.add_parser("disasm"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_sir_disasm)

    blk=sp.add_parser("block"); bps=blk.add_subparsers(dest="sub", required=True)
    x=bps.add_parser("run"); x.add_argument("--sirb", required=True); x.add_argument("--state", required=True); x.add_argument("--envelopes", nargs="+", required=True)
    x.add_argument("--entry", default="main"); x.add_argument("--require-sigs", action="store_true"); x.add_argument("--out", required=True); x.set_defaults(func=cmd_block_run)
    x=bps.add_parser("hash"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_block_hash)

    return p

def main():
    p=build()
    a=p.parse_args()
    a.func(a)

if __name__=="__main__":
    main()
