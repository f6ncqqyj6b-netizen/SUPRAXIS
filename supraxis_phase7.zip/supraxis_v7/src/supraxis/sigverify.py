from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol, Optional
import hashlib

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

@dataclass(frozen=True)
class Signature:
    scheme: int  # u16
    pubkey: bytes
    sig: bytes

class Verifier(Protocol):
    def verify(self, sig: Signature, message: bytes) -> bool: ...

class StubVerifier:
    """Deterministic verifier.
    - scheme 0: NONE (pubkey/sig must be empty)
    - scheme 1: sig must match sha256(pubkey||msg) prefix (first 16 bytes)
    - scheme 2: sig must match sha256(msg||pubkey) prefix (first 16 bytes)
    """
    PREFIX_LEN = 16

    def verify(self, sig: Signature, message: bytes) -> bool:
        if sig.scheme == 0:
            return sig.pubkey == b"" and sig.sig == b""
        if sig.scheme == 1:
            h = sha256(sig.pubkey + message)
            return sig.sig[:self.PREFIX_LEN] == h[:self.PREFIX_LEN]
        if sig.scheme == 2:
            h = sha256(message + sig.pubkey)
            return sig.sig[:self.PREFIX_LEN] == h[:self.PREFIX_LEN]
        return False

def default_verifier() -> Verifier:
    # Phase 7 keeps tests deterministic; plug real crypto later.
    return StubVerifier()

def make_stub_signature(scheme: int, pubkey: bytes, message: bytes) -> Signature:
    v = StubVerifier()
    if scheme == 0:
        return Signature(0, b"", b"")
    if scheme == 1:
        h = sha256(pubkey + message)
        return Signature(1, pubkey, h[:v.PREFIX_LEN])
    if scheme == 2:
        h = sha256(message + pubkey)
        return Signature(2, pubkey, h[:v.PREFIX_LEN])
    raise ValueError("unsupported stub scheme")
