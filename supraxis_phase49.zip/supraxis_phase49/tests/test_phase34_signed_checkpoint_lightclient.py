import unittest
from supraxis.state import SupraxisState
from supraxis.consensus.checkpoint import Checkpoint, validators_hash
from supraxis.consensus.signed_checkpoint import SignedCheckpoint, CheckpointSig, verify_signed_checkpoint
from supraxis.consensus.lightclient import LightClient
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign
from supraxis.consensus.hotstuff import quorum_threshold
from supraxis.consensus.validator_set import validators_for_epoch

class TestPhase34(unittest.TestCase):
    def test_signed_checkpoint_quorum(self):
        st = SupraxisState()
        st.storage["epoch"] = 0
        # make two validators with powers 10 and 20, vid is pubkey hex
        k1 = ed25519_keygen(seed=b"\x01"*32)
        k2 = ed25519_keygen(seed=b"\x02"*32)
        v1 = "0x"+k1.public.hex()
        v2 = "0x"+k2.public.hex()
        snap = [{"vid": v1, "power": 10}, {"vid": v2, "power": 20}]
        st.storage["validators.epoch.0"] = snap

        ck = Checkpoint(chain_id=1, epoch=0, height=5, state_root="aa"*32, block_hash="bb"*32, validators_hash=validators_hash(snap))
        msg = ck.signing_message()
        s1 = "0x"+ed25519_sign(k1.private, msg).hex()
        s2 = "0x"+ed25519_sign(k2.private, msg).hex()
        scp = SignedCheckpoint(checkpoint=ck, sigs=[CheckpointSig(vid=v1, scheme=11, sig=s1),
                                                   CheckpointSig(vid=v2, scheme=11, sig=s2)])
        vals = validators_for_epoch(st, 0)
        q = quorum_threshold(vals)
        ok, why, power = verify_signed_checkpoint(scp, snap, q)
        self.assertTrue(ok)
        self.assertTrue(power >= q)

    def test_lightclient_accepts_monotonic(self):
        st = SupraxisState()
        st.storage["epoch"] = 0
        k1 = ed25519_keygen(seed=b"\x03"*32)
        k2 = ed25519_keygen(seed=b"\x04"*32)
        v1 = "0x"+k1.public.hex()
        v2 = "0x"+k2.public.hex()
        snap = [{"vid": v1, "power": 10}, {"vid": v2, "power": 10}]
        st.storage["validators.epoch.0"] = snap

        ck1 = Checkpoint(chain_id=1, epoch=0, height=1, state_root="11"*32, block_hash="22"*32, validators_hash=validators_hash(snap))
        msg1 = ck1.signing_message()
        scp1 = SignedCheckpoint(checkpoint=ck1, sigs=[
            CheckpointSig(vid=v1, scheme=11, sig="0x"+ed25519_sign(k1.private, msg1).hex()),
            CheckpointSig(vid=v2, scheme=11, sig="0x"+ed25519_sign(k2.private, msg1).hex()),
        ])

        lc = LightClient(chain_id=1)
        ok, why = lc.accept_signed_checkpoint(st, scp1)
        self.assertTrue(ok)

        # same height should be rejected
        ok2, why2 = lc.accept_signed_checkpoint(st, scp1)
        self.assertFalse(ok2)

if __name__ == "__main__":
    unittest.main()
