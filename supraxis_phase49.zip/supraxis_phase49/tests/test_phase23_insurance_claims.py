import unittest
from supraxis.state import SupraxisState
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.crypto import sha256
from supraxis.sigverify import make_stub_signature

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class Phase23InsuranceClaims(unittest.TestCase):
    def _env(self, sender:int, nonce:int):
        payload=b'{"n":%d}'%nonce
        base = EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
            target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=1_000_000_000_000,
            payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[],
        )
        sig=make_stub_signature(1,b"pk_any", base.signing_message())
        return EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
            target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=1_000_000_000_000,
            payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[sig],
        )

    def test_claim_submit_fee_and_pay_with_cooldown(self):
        st = SupraxisState()
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global", "chain":100, "expires": 10**18}

        st.insurance_pool = 200
        st.storage["insurance.claim_fee"]=5
        st.storage["insurance.max_payout"]=100
        st.storage["insurance.cooldown"]=10

        claimant = b32(9).hex()
        st.credit(claimant, 10)  # fee balance
        to = b32(0xABC).hex()

        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"INSURANCE_CLAIM","to":"0x"+to,"amount":60,"nonce":1,"tick":100},
            {"op":"RET"},
        ]})
        res = run_block(st, prog.functions, [self._env(9,1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(any(e["event"]=="CLAIM_SUBMITTED" for e in res.events))
        self.assertEqual(st.balance_of(claimant), 5)
        self.assertEqual(st.treasury, 5)

        claim_id = [e["payload"]["claim_id"] for e in res.events if e["event"]=="CLAIM_SUBMITTED"][0]

        prog2 = SirBinProgram(version=1, functions={"main":[
            {"op":"INSURANCE_CLAIM_PAY","claim_id":"0x"+claim_id,"tick":105},
            {"op":"RET"},
        ]})
        res2 = run_block(st, prog2.functions, [self._env(123,2)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(any(e["event"]=="CLAIM_PAID" for e in res2.events))
        self.assertEqual(st.insurance_pool, 140)
        self.assertEqual(st.balance_of(to), 60)

        # another claim to same address before cooldown should fail
        prog3 = SirBinProgram(version=1, functions={"main":[
            {"op":"INSURANCE_CLAIM","to":"0x"+to,"amount":10,"nonce":2,"tick":110},
            {"op":"RET"},
        ]})
        st.credit(claimant, 5)
        res3 = run_block(st, prog3.functions, [self._env(9,3)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        claim2 = [e["payload"]["claim_id"] for e in res3.events if e["event"]=="CLAIM_SUBMITTED"][0]

        prog4 = SirBinProgram(version=1, functions={"main":[
            {"op":"INSURANCE_CLAIM_PAY","claim_id":"0x"+claim2,"tick":112},
            {"op":"RET"},
        ]})
        with self.assertRaises(Exception):
            run_block(st, prog4.functions, [self._env(123,4)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)

    def test_auto_treasury_to_insurance(self):
        st = SupraxisState()
        st.treasury = 1000
        st.storage["treasury.to_insurance_interval"]=5
        st.storage["treasury.to_insurance_bps"]=2000  # 20%

        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"AUTO_TREASURY_TO_INSURANCE","tick":10},
            {"op":"AUTO_TREASURY_TO_INSURANCE","tick":12},
            {"op":"RET"},
        ]})
        res = run_block(st, prog.functions, [self._env(1,10)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(any(e["event"]=="TREASURY_TO_INSURANCE_MOVED" for e in res.events))
        self.assertTrue(any(e["event"]=="TREASURY_TO_INSURANCE_SKIPPED" for e in res.events))
        self.assertEqual(st.insurance_pool, 200)
        self.assertEqual(st.treasury, 800)

if __name__ == "__main__":
    unittest.main()
