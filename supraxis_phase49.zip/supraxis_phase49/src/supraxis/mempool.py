from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import time

from supraxis.tx import Tx, tx_from_dict, validate_tx_dict
from supraxis.fees import FeeParams, estimate_fee, estimate_tx_bytes

@dataclass
class MempoolPolicy:
    max_size: int = 5000
    max_per_sender: int = 256
    max_age_sec: int = 1800
    fee_params: FeeParams = field(default_factory=FeeParams)

@dataclass
class MempoolItem:
    tx: Tx
    tx_hash: str
    fee_required: int
    added_at: float

class Mempool:
    def __init__(self, chain_id: int, policy: Optional[MempoolPolicy] = None):
        self.chain_id = int(chain_id)
        self.policy = policy or MempoolPolicy()
        self.by_hash: Dict[str, MempoolItem] = {}
        self.by_sender: Dict[str, List[str]] = {}  # sender -> [tx_hash]

    def _evict_expired(self, now: Optional[float] = None) -> None:
        if now is None:
            now = time.time()
        cutoff = float(now) - float(self.policy.max_age_sec)
        remove = [h for h, it in self.by_hash.items() if it.added_at < cutoff]
        for h in remove:
            self.remove(h)

    def remove(self, tx_hash: str) -> None:
        it = self.by_hash.pop(tx_hash, None)
        if it is None:
            return
        lst = self.by_sender.get(it.tx.sender, [])
        if tx_hash in lst:
            lst.remove(tx_hash)
        if not lst and it.tx.sender in self.by_sender:
            self.by_sender.pop(it.tx.sender, None)

    def add_tx_dict(self, d: dict) -> Tuple[bool,str,Optional[str]]:
        ok, why = validate_tx_dict(d)
        if not ok:
            return False, why, None
        if int(d["chain_id"]) != self.chain_id:
            return False, "wrong_chain", None

        # size cap
        b = estimate_tx_bytes(d)
        if b > int(self.policy.fee_params.max_tx_bytes):
            return False, "tx_too_large", None

        fee_req = estimate_fee(d, self.policy.fee_params)
        if int(d.get("max_fee", 0)) < fee_req:
            return False, "insufficient_max_fee", None

        self._evict_expired()

        tx = tx_from_dict(d)
        h = tx.hash_hex()
        if h in self.by_hash:
            return False, "duplicate", h

        if len(self.by_hash) >= int(self.policy.max_size):
            # simple eviction: remove lowest fee item
            low = min(self.by_hash.values(), key=lambda it: it.fee_required)
            self.remove(low.tx_hash)

        sender_list = self.by_sender.get(tx.sender, [])
        if len(sender_list) >= int(self.policy.max_per_sender):
            return False, "sender_queue_full", None

        item = MempoolItem(tx=tx, tx_hash=h, fee_required=fee_req, added_at=time.time())
        self.by_hash[h] = item
        sender_list.append(h)
        self.by_sender[tx.sender] = sender_list
        return True, "ok", h

    def get(self, tx_hash: str) -> Optional[Tx]:
        it = self.by_hash.get(tx_hash)
        return it.tx if it else None

    def top(self, limit: int = 1000) -> List[Tx]:
        self._evict_expired()
        items = sorted(self.by_hash.values(), key=lambda it: it.fee_required, reverse=True)
        return [it.tx for it in items[: int(limit)]]

    def size(self) -> int:
        self._evict_expired()
        return len(self.by_hash)
