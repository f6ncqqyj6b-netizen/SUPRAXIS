from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple
import time

from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

TX_VERSION = 1

@dataclass(frozen=True)
class Tx:
    version: int
    chain_id: int
    nonce: int
    sender: str            # 0x-prefixed pubkey or address string (reference)
    to: str                # recipient / contract address (reference)
    method: str            # e.g., "transfer", "call", "put"
    params: Dict[str, Any] # deterministic JSON object
    max_fee: int           # fee cap in base units
    ts: int                # unix seconds

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": int(self.version),
            "chain_id": int(self.chain_id),
            "nonce": int(self.nonce),
            "sender": str(self.sender),
            "to": str(self.to),
            "method": str(self.method),
            "params": dict(self.params),
            "max_fee": int(self.max_fee),
            "ts": int(self.ts),
        }

    def hash_hex(self) -> str:
        return sha256(canonical_json(self.to_dict())).hex()

def validate_tx_dict(d: Dict[str, Any]) -> Tuple[bool,str]:
    try:
        if int(d.get("version")) != TX_VERSION:
            return False, "bad_version"
        for k in ["chain_id","nonce","max_fee","ts"]:
            if k not in d or not isinstance(d[k], int):
                return False, f"bad_{k}"
        for k in ["sender","to","method"]:
            if k not in d or not isinstance(d[k], str) or d[k] == "":
                return False, f"bad_{k}"
        params = d.get("params")
        if not isinstance(params, dict):
            return False, "bad_params"
        if d["nonce"] < 0:
            return False, "bad_nonce"
        if d["max_fee"] < 0:
            return False, "bad_max_fee"
        if d["ts"] <= 0:
            return False, "bad_ts"
        return True, "ok"
    except Exception:
        return False, "exception"

def tx_from_dict(d: Dict[str, Any]) -> Tx:
    ok, why = validate_tx_dict(d)
    if not ok:
        raise ValueError(why)
    return Tx(
        version=int(d["version"]),
        chain_id=int(d["chain_id"]),
        nonce=int(d["nonce"]),
        sender=str(d["sender"]),
        to=str(d["to"]),
        method=str(d["method"]),
        params=dict(d["params"]),
        max_fee=int(d["max_fee"]),
        ts=int(d["ts"]),
    )

def make_tx(chain_id: int, nonce: int, sender: str, to: str, method: str, params: Dict[str, Any], max_fee: int) -> Tx:
    return Tx(
        version=TX_VERSION,
        chain_id=int(chain_id),
        nonce=int(nonce),
        sender=str(sender),
        to=str(to),
        method=str(method),
        params=dict(params),
        max_fee=int(max_fee),
        ts=int(time.time()),
    )
