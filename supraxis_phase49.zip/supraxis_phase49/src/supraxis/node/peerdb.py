from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import json
import time

@dataclass
class PeerRecord:
    host: str
    port: int
    last_seen: float = 0.0
    score: float = 0.0
    failures: int = 0
    banned_until: float = 0.0

    def key(self) -> str:
        return f"{self.host}:{int(self.port)}"

@dataclass
class PeerDB:
    path: Path
    peers: Dict[str, PeerRecord] = field(default_factory=dict)

    def load(self) -> None:
        if not self.path.exists():
            return
        d = json.loads(self.path.read_text(encoding="utf-8"))
        peers = {}
        for k, v in (d.get("peers") or {}).items():
            peers[str(k)] = PeerRecord(
                host=str(v["host"]),
                port=int(v["port"]),
                last_seen=float(v.get("last_seen",0.0)),
                score=float(v.get("score",0.0)),
                failures=int(v.get("failures",0)),
                banned_until=float(v.get("banned_until",0.0)),
            )
        self.peers = peers

    def save(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        d = {"peers": {k: {
            "host": r.host, "port": r.port, "last_seen": r.last_seen,
            "score": r.score, "failures": r.failures, "banned_until": r.banned_until
        } for k, r in self.peers.items()}}
        self.path.write_text(json.dumps(d, indent=2), encoding="utf-8")

    def upsert(self, host: str, port: int, seen: bool = True, score_delta: float = 0.0) -> PeerRecord:
        k = f"{host}:{int(port)}"
        r = self.peers.get(k) or PeerRecord(host=host, port=int(port))
        if seen:
            r.last_seen = time.time()
        r.score += float(score_delta)
        self.peers[k] = r
        return r

    def mark_failure(self, host: str, port: int) -> None:
        r = self.upsert(host, port, seen=False, score_delta=-1.0)
        r.failures += 1

    def ban(self, host: str, port: int, seconds: int = 300) -> None:
        r = self.upsert(host, port, seen=False, score_delta=-5.0)
        r.banned_until = time.time() + int(seconds)

    def candidates(self, limit: int = 16) -> List[PeerRecord]:
        now = time.time()
        vals = [r for r in self.peers.values() if float(r.banned_until) <= now]
        # Prefer higher score then recent last_seen
        vals.sort(key=lambda r: (r.score, r.last_seen), reverse=True)
        return vals[: int(limit)]
