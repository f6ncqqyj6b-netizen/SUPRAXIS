from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Protocol, List, Any
from supraxis.state import SupraxisState
from supraxis.consensus.gossip import GossipStore
from supraxis.consensus.fastsync import fast_sync
from supraxis.consensus.persist import dumps
from supraxis.consensus.checkpoint import Checkpoint

class BlockProvider(Protocol):
    def get_block(self, block_hash: str) -> Optional[Any]:
        ...

@dataclass
class BootstrapResult:
    ok: bool
    reason: str
    trusted: Optional[Checkpoint]
    verified: bool

def apply_state_snapshot(state: SupraxisState, snapshot: dict) -> None:
    # snapshot is plain dict of storage
    state.storage = dict(snapshot.get("storage", {}))

def state_snapshot(state: SupraxisState) -> dict:
    return {"storage": dict(state.storage)}

def verify_state_root_from_blocks(state: SupraxisState, blocks: List[Any], expected_state_root: str) -> Tuple[bool,str]:
    """Deterministically re-exec blocks to recompute state root and compare.

    Reference implementation: uses SupraxisState.apply_block if available.
    Falls back to no-op if block execution not implemented in this build.
    """
    # If apply_block exists, use it
    if not hasattr(state, "apply_block"):
        # Cannot verify in this minimal build
        return False, "no_block_executor"

    for b in blocks:
        state.apply_block(b)

    got = getattr(state, "state_root", None)
    if callable(got):
        got = state.state_root()
    if got is None:
        # fallback: if storage hash exists
        if hasattr(state, "storage_root"):
            got = state.storage_root()
        else:
            return False, "no_state_root"
    if str(got) != str(expected_state_root):
        return False, "state_root_mismatch"
    return True, "ok"

def bootstrap_node(state: SupraxisState, gossip: GossipStore, provider: BlockProvider, chain_id: int,
                   snapshot: Optional[dict]=None, blocks_needed: int=0) -> BootstrapResult:
    """Full node bootstrap:

    1) Optional: apply a state snapshot (accelerates sync)
    2) Fast sync headers from best checkpoint -> tip
    3) Optionally fetch last N blocks and deterministically verify state_root vs checkpoint/state claims

    Returns BootstrapResult.
    """
    if snapshot is not None:
        apply_state_snapshot(state, snapshot)

    ok, why, lc = fast_sync(state, gossip, chain_id=chain_id)
    if not ok:
        return BootstrapResult(ok=False, reason=why, trusted=None, verified=False)

    trusted = lc.trusted
    if trusted is None:
        return BootstrapResult(ok=True, reason="ok_no_trusted", trusted=None, verified=False)

    # Optional verification: fetch a suffix of blocks ending at trusted head
    verified = False
    if blocks_needed > 0:
        blocks = []
        # In this reference build, we only know trusted head hash; provider must supply blocks with parent linkage.
        h = trusted.block_hash
        for _ in range(int(blocks_needed)):
            b = provider.get_block(h)
            if b is None:
                return BootstrapResult(ok=False, reason="missing_block", trusted=trusted, verified=False)
            blocks.append(b)
            # parent_hash discovery
            ph = getattr(getattr(b, "header", None), "parent_hash", None)
            if ph is None:
                ph = getattr(b, "parent_hash", None)
            if ph is None:
                break
            h = str(ph)

        blocks.reverse()
        okv, whyv = verify_state_root_from_blocks(state, blocks, expected_state_root=str(trusted.state_root))
        if not okv:
            return BootstrapResult(ok=False, reason=f"verify_failed:{whyv}", trusted=trusted, verified=False)
        verified = True

    return BootstrapResult(ok=True, reason="ok", trusted=trusted, verified=verified)
