from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol
import hashlib

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

@dataclass(frozen=True)
class Signature:
    scheme: int  # u16
    pubkey: bytes
    sig: bytes

class Verifier(Protocol):
    def verify(self, sig: Signature, message: bytes) -> bool: ...

class StubVerifier:
    """Deterministic verifier (always available).
    - scheme 0: NONE (pubkey/sig must be empty)
    - scheme 1: sig == sha256(pubkey||msg)[:16]
    - scheme 2: sig == sha256(msg||pubkey)[:16]
    """
    PREFIX_LEN = 16
    def verify(self, sig: Signature, message: bytes) -> bool:
        if sig.scheme == 0:
            return sig.pubkey == b"" and sig.sig == b""
        if sig.scheme == 1:
            h = sha256(sig.pubkey + message)
            return sig.sig[:self.PREFIX_LEN] == h[:self.PREFIX_LEN]
        if sig.scheme == 2:
            h = sha256(message + sig.pubkey)
            return sig.sig[:self.PREFIX_LEN] == h[:self.PREFIX_LEN]
        return False

class CryptoVerifier:
    """Real crypto verification (optional, requires `cryptography`).

    Schemes:
    - 11: Ed25519 (pubkey 32 bytes; sig 64 bytes)
    - 12: secp256k1 ECDSA over SHA-256 (sig DER; pubkey can be DER SubjectPublicKeyInfo or uncompressed 65-byte 0x04||x||y)
    """
    def __init__(self) -> None:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        from cryptography.hazmat.primitives.asymmetric import ec
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.serialization import load_der_public_key
        self.Ed25519PublicKey = Ed25519PublicKey
        self.ec = ec
        self.hashes = hashes
        self.load_der_public_key = load_der_public_key

    def verify(self, sig: Signature, message: bytes) -> bool:
        try:
            if int(sig.scheme) == 11:
                # Ed25519 (raw public key bytes)
                pk = self.Ed25519PublicKey.from_public_bytes(sig.pubkey)
                pk.verify(sig.sig, message)
                return True
            if int(sig.scheme) == 12:
                # secp256k1 ECDSA over SHA-256
                pk = None
                try:
                    pk = self.load_der_public_key(sig.pubkey)
                except Exception:
                    if len(sig.pubkey) == 65 and sig.pubkey[0] == 4:
                        x = int.from_bytes(sig.pubkey[1:33], "big")
                        y = int.from_bytes(sig.pubkey[33:65], "big")
                        pk = self.ec.EllipticCurvePublicNumbers(x, y, self.ec.SECP256K1()).public_key()
                    else:
                        return False
                pk.verify(sig.sig, message, self.ec.ECDSA(self.hashes.SHA256()))
                return True
        except Exception:
            return False
        return False

class CompositeVerifier:
    def __init__(self, crypto: CryptoVerifier | None):
        self._stub = StubVerifier()
        self._crypto = crypto

    def verify(self, sig: Signature, message: bytes) -> bool:
        if sig.scheme in (0, 1, 2):
            return self._stub.verify(sig, message)
        if self._crypto is not None:
            return self._crypto.verify(sig, message)
        return False

def default_verifier() -> Verifier:
    try:
        return CompositeVerifier(CryptoVerifier())
    except Exception:
        return CompositeVerifier(None)

def make_stub_signature(scheme: int, pubkey: bytes, message: bytes) -> Signature:
    v = StubVerifier()
    if scheme == 0:
        return Signature(0, b"", b"")
    if scheme == 1:
        h = sha256(pubkey + message)
        return Signature(1, pubkey, h[:v.PREFIX_LEN])
    if scheme == 2:
        h = sha256(message + pubkey)
        return Signature(2, pubkey, h[:v.PREFIX_LEN])
    raise ValueError("unsupported stub scheme")


def make_ed25519_signature(pubkey: bytes, sig_bytes: bytes) -> Signature:
    return Signature(11, pubkey, sig_bytes)
