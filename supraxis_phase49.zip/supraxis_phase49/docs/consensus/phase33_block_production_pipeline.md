# Phase 33 — End-to-End Block Production Pipeline + Checkpoint Hooks

This phase provides a deterministic reference pipeline that ties together:

- Phase 28 mempool ordering
- Phase 30 fee + staking economics
- Phase 31 epoch transitions + validator snapshots
- Phase 32 epoch validator-set–driven consensus membership
- Phase 27 HotStuff-style QC formation

## New Components

### 1) L1Pipeline (reference)

`src/supraxis/consensus/pipeline.py`

Responsibilities:
- Accept tx envelopes into mempool
- Deterministically assemble a tx list for a block
- Execute the tx list via `run_block(...)` to mutate state
- Create a consensus block header and compute a deterministic block hash
- Collect votes and form a QC for the proposed block
- Produce a checkpoint object on epoch boundaries

This is **not** networked; it is a canonical integration harness.

### 2) Checkpoints (fast sync primitive)

`src/supraxis/consensus/checkpoint.py`

Checkpoint contains:
- chain_id, epoch, height
- state_root (state hash)
- block_hash (head)
- validators_hash (sha256 of epoch snapshot)

In later phases:
- validators sign checkpoints
- clients can fast sync to the latest signed checkpoint + replay headers.

## Determinism Rules

- Mempool ordering is deterministic (sender, nonce, tx_id; round-robin)
- Validator set is deterministic per epoch snapshot
- Proposer selection is deterministic from (chain_id, height, round, validator list)

## Next

Phase 34: add signature-backed checkpoint quorums + light client verification flow.
