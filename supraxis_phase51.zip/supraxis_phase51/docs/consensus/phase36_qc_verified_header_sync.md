# Phase 36 — QC-Verified Header Sync + Epoch-Aware Validator Updates

This phase hardens Phase 35 header sync by adding:

1) **QC structural verification** during header sync (quorum power threshold).
2) **Epoch-aware validator set updates** while syncing headers.

## Header Extensions

`Header` now includes:
- `epoch`: which validator snapshot applies to this header
- `validators_hash`: hash of that epoch snapshot (optional; checked if provided)

## QC Verification

`src/supraxis/consensus/qc_verify.py`

`verify_qc_structural(qc, vmap, quorum_power)` verifies:
- voters unique
- voters are members of validator set
- power sum reaches quorum threshold

(Reference build does not verify cryptographic vote signatures yet.)

## Light Client Sync

`LightClient.sync_headers(state, headers)` now:
- checks parent linkage + contiguous heights
- updates validator set when `header.epoch` changes
- verifies QC power if header includes a QC
- optionally checks header.validators_hash against the epoch snapshot

## Next

Phase 37: cryptographic QC signature verification and validator-key registration enforcement.
