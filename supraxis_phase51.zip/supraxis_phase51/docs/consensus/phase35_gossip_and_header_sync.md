# Phase 35 — Checkpoint Gossip + Header-Only Sync

This phase adds the missing glue for a practical light-client sync:

1) **Gossip cache** of signed checkpoints.
2) **Header-only chain** storage for block headers.
3) A light client method to **sync forward from a trusted checkpoint** using headers only.

## GossipStore

`src/supraxis/consensus/gossip.py`

- caches:
  - `SignedCheckpoint` objects by epoch
  - block headers in a `HeaderChain`
- provides:
  - `best_checkpoint(min_height=0)` to pick the highest known checkpoint
  - `headers_from(start_hash, end_hash)` to fetch a parent-linked path

## HeaderChain

`src/supraxis/consensus/headerchain.py`

- stores `Header` objects by `block_hash`
- maintains a per-chain tip (highest height seen)
- can return a path of headers from a known hash to a newer tip via parent links

## LightClient Header Sync

`LightClient.sync_headers(headers)`:

- requires a previously accepted (quorum-signed) checkpoint
- verifies:
  - chain_id matches
  - parent linkage is contiguous from checkpoint block_hash
  - height increments by 1
- updates trusted head block_hash + height (state_root unchanged in header-only mode)

## Next

Phase 36: QC verification on headers (not just linkage), and "epoch-aware" validator updates during header sync.
