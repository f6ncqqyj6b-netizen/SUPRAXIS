from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

# Message types for initial sync (reference)

# Requests
REQ_HELLO = "hello"
REQ_PEERS = "peers"
REQ_TXS = "txs"
REQ_NEW_BLOCK = "new_block"
REQ_EVIDENCE_SUBMIT = "evidence_submit"
REQ_EVIDENCE_STATUS = "evidence_status"
REQ_GOV_SUBMIT = "gov_submit"
REQ_GOV_QUEUE = "gov_queue"
REQ_GOV_EXECUTE = "gov_execute"
REQ_GOV_STATUS = "gov_status"
REQ_GOV_EMERGENCY = "gov_emergency"
REQ_BEST_CHECKPOINT = "best_checkpoint"
REQ_SIGNED_HEADERS = "signed_headers"
REQ_BLOCKS = "blocks"
REQ_SNAPSHOT = "snapshot"
REQ_SNAPSHOT_META = "snapshot_meta"
REQ_SNAPSHOT_CHUNK = "snapshot_chunk"

# Responses
RSP_HELLO = "hello_ok"
RSP_PEERS = "peers_ok"
RSP_TXS = "txs_ok"
RSP_NEW_BLOCK = "new_block_ok"
RSP_EVIDENCE = "evidence_ok"
RSP_EVIDENCE_STATUS = "evidence_status_ok"
RSP_GOV = "gov_ok"
RSP_GOV_STATUS = "gov_status_ok"
RSP_BEST_CHECKPOINT = "best_checkpoint_ok"
RSP_SIGNED_HEADERS = "signed_headers_ok"
RSP_BLOCKS = "blocks_ok"
RSP_SNAPSHOT = "snapshot_ok"
RSP_SNAPSHOT_META = "snapshot_meta_ok"
RSP_SNAPSHOT_CHUNK = "snapshot_chunk_ok"
RSP_ERROR = "error"

@dataclass(frozen=True)
class Hello:
    node_id: str
    chain_id: int
    version: str

@dataclass(frozen=True)
class BestCheckpointReq:
    min_height: int = 0

@dataclass(frozen=True)
class SignedHeadersReq:
    start_hash: str
    end_hash: str

@dataclass(frozen=True)
class BlocksReq:
    hashes: List[str]

@dataclass(frozen=True)
class SnapshotReq:
    # optional state snapshot; in production include height/epoch/versioning
    want: bool = True


@dataclass(frozen=True)
class PeersReq:
    limit: int = 32

@dataclass(frozen=True)
class PeersOk:
    peers: List[dict]

@dataclass(frozen=True)
class SnapshotMetaReq:
    want: bool = True

@dataclass(frozen=True)
class SnapshotChunkReq:
    snapshot_id: str
    index: int



@dataclass(frozen=True)
class TxsReq:
    txs: List[dict]


@dataclass(frozen=True)
class NewBlockReq:
    block: dict


@dataclass(frozen=True)
class EvidenceSubmitReq:
    evidence: dict

@dataclass(frozen=True)
class EvidenceStatusReq:
    pubkey: str
