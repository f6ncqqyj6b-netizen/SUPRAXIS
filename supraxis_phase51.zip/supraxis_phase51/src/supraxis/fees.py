from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any
import math

from supraxis.canonjson import canonical_json

@dataclass(frozen=True)
class FeeParams:
    base_fee: int = 1000           # minimum fee
    per_byte_fee: int = 1          # fee per byte of tx canonical json
    per_param_fee: int = 10        # fee per param entry (keys)
    max_tx_bytes: int = 50_000     # hard cap in mempool

def estimate_tx_bytes(tx_dict: Dict[str, Any]) -> int:
    return len(canonical_json(tx_dict))

def estimate_fee(tx_dict: Dict[str, Any], fp: FeeParams = FeeParams()) -> int:
    b = estimate_tx_bytes(tx_dict)
    # params complexity
    params = tx_dict.get("params") or {}
    nkeys = len(params.keys()) if isinstance(params, dict) else 0
    fee = int(fp.base_fee) + int(fp.per_byte_fee) * int(b) + int(fp.per_param_fee) * int(nkeys)
    return int(max(0, fee))
