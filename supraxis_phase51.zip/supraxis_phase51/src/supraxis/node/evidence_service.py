from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from supraxis.node.evidence_store import EvidenceStore
from supraxis.node.db import NodeDB
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P

@dataclass
class EvidenceService:
    store: EvidenceStore
    db: Optional[NodeDB] = None

    def load_from_db(self) -> None:
        if self.db is None:
            return
        d = self.db.load_evidence()
        if d is None:
            return
        self.store = EvidenceStore.from_dict(d)

    def persist(self) -> None:
        if self.db is None:
            return
        self.db.save_evidence(self.store.to_dict())

    async def handle_submit(self, msg: Msg) -> Msg:
        ev = msg.payload.get("evidence") or {}
        ok, why, h = self.store.submit(ev)
        if ok:
            self.persist()
        return Msg(P.RSP_EVIDENCE, {"ok": ok, "why": why, "hash": h})

    async def handle_status(self, msg: Msg) -> Msg:
        pk = str(msg.payload.get("pubkey",""))
        sl = self.store.slashed.get(pk)
        return Msg(P.RSP_EVIDENCE_STATUS, {"pubkey": pk, "slashed": sl is not None, "slashed_ts": sl})
