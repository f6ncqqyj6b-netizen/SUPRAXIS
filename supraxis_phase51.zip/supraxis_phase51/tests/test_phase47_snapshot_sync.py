import unittest
import tempfile
from pathlib import Path
import asyncio

from supraxis.node.snapshot_chunks import build_meta, verify_chunks, bytes_to_snapshot, snapshot_to_bytes
from supraxis.node.db import NodeDB
from supraxis.node.snapshot_sync import SnapshotSync, SnapshotSyncConfig

from supraxis.p2p.transport import AsyncTCPServer, TransportConfig
from supraxis.p2p.discovery import DiscoveryService
from supraxis.node.peerdb import PeerDB
from supraxis.node.service import NodeService
from supraxis.consensus.gossip import GossipStore
from supraxis.node.blockstore import BlockStore
from supraxis.p2p.peer_manager import PeerPolicy
from supraxis.p2p.antispam import GlobalLimits

class TestPhase47(unittest.IsolatedAsyncioTestCase):
    async def test_chunk_verify(self):
        snap = {"storage":{"a":1,"b":"x"}}
        meta, chunks = build_meta("latest", snap, chunk_size=8)
        ok, why = verify_chunks(meta, chunks)
        self.assertTrue(ok)

    async def test_snapshot_sync_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            db_server = NodeDB(Path(td)/"serverdb")
            db_client = NodeDB(Path(td)/"clientdb")
            # store a snapshot on server
            db_server.save_snapshot({"storage":{"k":"v","n":123}}, snapshot_id="latest")

            peerdb = PeerDB(Path(td)/"peers.json")
            disc = DiscoveryService(peerdb)
            svc = NodeService(chain_id=1, gossip=GossipStore(), blocks=BlockStore(), discovery=disc, db=db_server)

            pol = PeerPolicy()
            pol.reqs_per_sec = 500.0
            pol.burst = 500.0
            gl = GlobalLimits()
            gl.max_reqs_per_sec = 500.0
            gl.burst = 500.0
            cfg = TransportConfig(chain_id=1, max_frame_bytes=2_000_000, idle_timeout_sec=5, policy=pol, global_limits=gl)

            server = AsyncTCPServer("127.0.0.1", 0, cfg, svc.handle)
            await server.start()
            port = server._server.sockets[0].getsockname()[1]

            ss = SnapshotSync(db_client, SnapshotSyncConfig(chain_id=1, timeout=3.0))
            ok, why, sid = await ss.fetch_snapshot("127.0.0.1", port)
            self.assertTrue(ok, why)
            self.assertEqual(sid, "latest")
            snap = db_client.load_snapshot()
            self.assertEqual(snap["storage"]["k"], "v")

            await server.close()

if __name__ == "__main__":
    unittest.main()
