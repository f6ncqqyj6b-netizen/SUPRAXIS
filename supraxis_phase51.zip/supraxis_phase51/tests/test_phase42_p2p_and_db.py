import unittest
import tempfile
from pathlib import Path

from supraxis.p2p.message import Msg, encode, decode
from supraxis.node.db import NodeDB
from supraxis.node.blockstore import BlockStore
from supraxis.node.sync import InMemoryPeer, SyncClient
from supraxis.consensus.gossip import GossipStore
from supraxis.consensus.headerchain import Header
from supraxis.consensus.signed_header import SignedHeader, header_message
from supraxis.consensus.signed_checkpoint import SignedCheckpoint, CheckpointSig
from supraxis.consensus.checkpoint import Checkpoint, validators_hash
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign
from supraxis.consensus.vote_signing import SCHEME_ED25519

class TestPhase42(unittest.TestCase):
    def test_framing_roundtrip(self):
        b = encode(Msg("x", {"a":1})) + encode(Msg("y", {"b":2}))
        m1, rest = decode(b)
        self.assertEqual(m1.t, "x")
        m2, rest2 = decode(rest)
        self.assertEqual(m2.t, "y")
        self.assertEqual(rest2, b"")

    def test_db_persistence(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            g = GossipStore()
            bs = BlockStore()
            bs.put("h", {"parent_hash":"p", "txs":[]})
            snap = {"storage":{"k":"v"}}
            db.save_gossip(g)
            db.save_blocks(bs)
            db.save_snapshot(snap)
            g2 = db.load_gossip()
            b2 = db.load_blocks()
            s2 = db.load_snapshot()
            self.assertIsNotNone(g2)
            self.assertEqual(b2.get_block("h")["parent_hash"], "p")
            self.assertEqual(s2["storage"]["k"], "v")

    def test_sync_ingest(self):
        # Build a peer with a signed checkpoint + signed headers + snapshot
        peer_g = GossipStore()
        peer_bs = BlockStore()
        snapshot = {"storage":{"hello":"world"}}

        k1 = ed25519_keygen(seed=bytes([1])*32)
        k2 = ed25519_keygen(seed=bytes([2])*32)
        v1 = "0x"+k1.public.hex()
        v2 = "0x"+k2.public.hex()

        # for checkpoint signing we only need validators hash; store it in snapshot-less gossip
        vh = validators_hash([{"vid": v1, "power": 10}, {"vid": v2, "power": 10}])

        ck = Checkpoint(chain_id=1, epoch=0, height=1, state_root="aa"*32, block_hash="01"*32, validators_hash=vh)
        msg = ck.signing_message()
        scp = SignedCheckpoint(checkpoint=ck, sigs=[
            CheckpointSig(vid=v1, scheme=SCHEME_ED25519, sig="0x"+ed25519_sign(k1.private, msg).hex()),
            CheckpointSig(vid=v2, scheme=SCHEME_ED25519, sig="0x"+ed25519_sign(k2.private, msg).hex()),
        ])
        peer_g.add_checkpoint(scp)

        # signed headers 2..3
        parent = "01"*32
        for hgt in [2,3]:
            bh = f"{hgt:02x}"*32
            h = Header(chain_id=1, epoch=0, height=hgt, round=0, block_hash=bh, parent_hash=parent, proposer="p", validators_hash=vh, qc=None)
            hm = header_message(h)
            sh = SignedHeader(header=h, sigs={
                v1: {"scheme": SCHEME_ED25519, "sig": ed25519_sign(k1.private, hm)},
                v2: {"scheme": SCHEME_ED25519, "sig": ed25519_sign(k2.private, hm)},
            })
            peer_g.add_signed_header(sh)
            parent = bh

        peer = InMemoryPeer(node_id="peer1", chain_id=1, version="0.42.0", gossip=peer_g, snapshot=snapshot, blocks=peer_bs)
        client = SyncClient(chain_id=1, peers=[peer])

        local_g = GossipStore()
        local_bs = BlockStore()
        snap = client.ingest_into_local(local_g, local_bs, want_snapshot=True)
        self.assertEqual(snap["storage"]["hello"], "world")
        self.assertIsNotNone(local_g.best_checkpoint())
        tip = local_g.tip_signed_header(1)
        self.assertIsNotNone(tip)
        self.assertEqual(tip.header.height, 3)

if __name__ == "__main__":
    unittest.main()
