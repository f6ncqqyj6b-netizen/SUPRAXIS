import unittest
from supraxis.state import SupraxisState
from supraxis.sirbin import SirBinProgram
from supraxis.crypto import sha256
from supraxis.consensus.node import ConsensusNode
from supraxis.consensus.pipeline import L1Pipeline
from supraxis.net.mempool import tx_id_from_envelope_dict

def env(sender_hex: str, nonce: int, gas: int = 10**12):
    return {
        "version": 2,
        "origin_chain": 1,
        "origin_tx": "0x" + "00"*31 + "01",
        "origin_sender": sender_hex,
        "target_chain": 100,
        "target_contract": "0x" + "aa"*32,
        "nonce": nonce,
        "gas_limit": gas,
        "payload_hash": "0x44136fa355b3678a1146ad16f7e8649e94fb4fc21fe77e8310c060f61caaff8a",
        "cap_refs": [],
    }

class TestPhase33Pipeline(unittest.TestCase):
    def test_pipeline_propose_qc_checkpoint(self):
        st = SupraxisState()
        # install a simple program in state.storage so pipeline can execute
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"EMIT","event":"HELLO","payload":{}},
            {"op":"RET"},
        ]})
        st.storage["program.functions"] = prog.functions

        # seed epoch snapshots (epoch 0)
        st.storage["epoch"] = 0
        st.storage["validators.epoch.0"] = [{"vid":"0x"+"01"*32,"power":10},{"vid":"0x"+"02"*32,"power":10}]
        node = ConsensusNode(chain_id=1, state=st)
        pipe = L1Pipeline(chain_id=1, state=st, node=node)

        # submit 2 tx
        pipe.submit_tx(env("0x"+"10"*32, 1))
        pipe.submit_tx(env("0x"+"11"*32, 1))

        pb = pipe.propose_block(max_txs=10, max_gas=1000, round=0)
        self.assertEqual(pb.height, 1)
        qc = pipe.vote_and_form_qc(pb)
        self.assertTrue(qc.power >= node.quorum())

        ck = pipe.maybe_checkpoint()
        self.assertIsNotNone(ck)
        self.assertEqual(ck.epoch, 0)
        self.assertEqual(ck.height, 1)

if __name__ == "__main__":
    unittest.main()
