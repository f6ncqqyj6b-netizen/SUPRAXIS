import unittest
from supraxis.state import SupraxisState
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.crypto import sha256
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign, make_ed25519_signature
from supraxis.canonjson import canonical_json

def b32(x:int)->bytes: return x.to_bytes(32,"big")

def mk_env(nonce:int, kp):
    payload=b'{"n":%d}'%nonce
    env0 = EnvelopeV2(
        version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(1),
        target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=10**12,
        payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[]
    )
    msg = env0.signing_message()
    sigb = ed25519_sign(kp.private, msg)
    sig = make_ed25519_signature(kp.public, sigb)
    return EnvelopeV2(
        version=env0.version, origin_chain=env0.origin_chain, origin_tx=env0.origin_tx, origin_sender=env0.origin_sender,
        target_chain=env0.target_chain, target_contract=env0.target_contract, nonce=env0.nonce, gas_limit=env0.gas_limit,
        payload_type=env0.payload_type, payload=env0.payload, payload_hash=env0.payload_hash, cap_refs=env0.cap_refs, signatures=[sig]
    )

class Phase31(unittest.TestCase):
    def test_slashable_unbond(self):
        st = SupraxisState()
        st.storage["tick"]=0
        st.storage["stake.unbond_delay_ticks"]=100
        pub="0x"+"aa"*32
        addr="0x"+b32(9).hex()
        st.credit(addr, 2000)
        # bond 1000
        prog1 = SirBinProgram(version=1, functions={"main":[
            {"op":"STAKE_BOND","pubkey":pub,"from":addr,"amount":1000,"lock_until_epoch":0},
            {"op":"RET"},
        ]})
        kp = ed25519_keygen(seed=b"\x11"*32)
        run_block(st, prog1.functions, [mk_env(1,kp)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        # request unbond 600
        prog2 = SirBinProgram(version=1, functions={"main":[
            {"op":"STAKE_UNBOND_REQUEST","pubkey":pub,"to":addr,"amount":600},
            {"op":"RET"},
        ]})
        run_block(st, prog2.functions, [mk_env(2,kp)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertEqual(st.stake_of(pub)[0], 400)
        # slash 500 at tick 0 should take 400 from stake + 100 from pending unbond
        taken = st.slash_with_pending(pub, 500, tick=0)
        self.assertEqual(taken, 500)
        self.assertEqual(st.stake_of(pub)[0], 0)
        recs = st.storage.get(f"unbond.{pub}", [])
        # pending originally 600, now 500 left
        self.assertEqual(int(recs[0]["amount"]), 500)

    def test_epoch_rollover_snapshot(self):
        st = SupraxisState()
        # set policy: epoch len 3 ticks; max validators 2
        gov = sha256(b"GOVERNANCE").hex()
        st.caps[gov] = {"scope":"global","chain":100,"expires":10**18}
        st.storage["epoch.len_ticks"]=3
        st.storage["epoch.max_validators"]=2
        # three stakers
        st.stake_add("0x"+"01"*32, 100, 0)
        st.stake_add("0x"+"02"*32, 300, 0)
        st.stake_add("0x"+"03"*32, 200, 0)
        # advance 3 ticks to rollover
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"EPOCH_ADVANCE"},
            {"op":"EPOCH_ADVANCE"},
            {"op":"EPOCH_ADVANCE"},
            {"op":"RET"},
        ]})
        kp = ed25519_keygen(seed=b"\x22"*32)
        run_block(st, prog.functions, [mk_env(1,kp)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertEqual(int(st.storage.get("epoch",0)), 1)
        snap = st.storage.get("validators.epoch.1")
        self.assertEqual(len(snap), 2)
        # top 2 are 0x02 (300) then 0x03 (200)
        self.assertEqual(snap[0]["vid"], "0x"+"02"*32)
        self.assertEqual(snap[1]["vid"], "0x"+"03"*32)

if __name__ == "__main__":
    unittest.main()
