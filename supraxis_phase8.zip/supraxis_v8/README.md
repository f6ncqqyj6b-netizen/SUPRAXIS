# SUPRAXIS (Phase 8)

Phase 8 adds:
- **Real signature verification backends** (when `cryptography` is available):
  - scheme **11**: Ed25519
  - scheme **12**: secp256k1 ECDSA over SHA-256
- **SignaturePolicy** threshold enforcement (k-of-n valid signatures)
- **Explicit cap_ref binding** into signing preimage (cap_refs are included in canonical bytes; signatures are omitted)

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```

## CLI examples

Verify an envelope requiring 2 valid signatures (threshold=2):
```bash
PYTHONPATH=src python -m supraxis.cli envelope verify --in path.bin --require-sigs --sig-threshold 2
```

Restrict to Ed25519 only:
```bash
PYTHONPATH=src python -m supraxis.cli envelope verify --in path.bin --require-sigs --allowed-schemes 11
```
