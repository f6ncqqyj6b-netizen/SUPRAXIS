import unittest
from supraxis.sirbin import SirBinProgram
from supraxis.envelope import EnvelopeV2
from supraxis.sigverify import make_stub_signature
from supraxis.crypto import sha256
from supraxis.state import SupraxisState
from supraxis.block import run_block

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class BlockTwoEnvTests(unittest.TestCase):
    def test_two_envelopes_nonce_order(self):
        prog_json = {
          "version": 1,
          "functions": {
            "main": [
              {"op":"EMIT","event":"E","payload":{"ok": True}},
              {"op":"RET"}
            ]
          }
        }
        prog = SirBinProgram(version=1, functions=prog_json["functions"])
        dec = SirBinProgram.decode(prog.encode())
        st = SupraxisState()

        payload=b'{"x":1}'
        ph=sha256(payload)

        base1=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[])
        sig1=make_stub_signature(1, b"pub", base1.signing_message())
        e1=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[sig1])

        base2=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),2,500000,1,payload,ph,[],[])
        sig2=make_stub_signature(1, b"pub", base2.signing_message())
        e2=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),2,500000,1,payload,ph,[],[sig2])

        res=run_block(st, dec.functions, [e2,e1], entry="main", require_signatures=True)
        self.assertEqual(len(res.events), 2)
        self.assertTrue(res.block_hash)

if __name__ == "__main__":
    unittest.main()
