from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict
import json

def _key(oc: int, os: bytes, tc: int, tct: bytes) -> str:
    return f"{oc}:{os.hex()}->{tc}:{tct.hex()}"

@dataclass
class SupraxisState:
    nonces: Dict[str, int] = field(default_factory=dict)
    storage: Dict[str, Any] = field(default_factory=dict)
    caps: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def get_last_nonce(self, oc: int, os: bytes, tc: int, tct: bytes) -> int:
        return int(self.nonces.get(_key(oc, os, tc, tct), 0))

    def set_last_nonce(self, oc: int, os: bytes, tc: int, tct: bytes, nonce: int) -> None:
        self.nonces[_key(oc, os, tc, tct)] = int(nonce)

    def to_json(self) -> str:
        return json.dumps({"nonces": self.nonces, "storage": self.storage, "caps": self.caps},
                          sort_keys=True, separators=(",", ":"))

    @staticmethod
    def from_json(s: str) -> "SupraxisState":
        obj = json.loads(s)
        return SupraxisState(nonces=obj.get("nonces", {}), storage=obj.get("storage", {}), caps=obj.get("caps", {}))
