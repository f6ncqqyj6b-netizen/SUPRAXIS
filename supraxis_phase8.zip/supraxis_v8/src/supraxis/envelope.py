from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Union, Optional, Iterable, Set
from .canonical import pack_u16, pack_u32, pack_u64, read_u16, read_u32, read_u64
from .crypto import sha256, verify_signature
from .sigverify import Signature
from .errors import EnvelopeValidationError, ReplayError

MAGIC = b"SCES"  # Supraxis Canonical Envelope Stream
V1 = 1
V2 = 2

def _pack_bytes(b: bytes) -> bytes:
    return pack_u32(len(b)) + b

def _read_bytes(buf: bytes, off: int) -> Tuple[bytes, int]:
    n, off = read_u32(buf, off)
    if off + n > len(buf):
        raise ReplayError("EOF bytes")
    return buf[off:off+n], off + n

def _ensure32(b: bytes, what: str) -> None:
    if len(b) != 32:
        raise EnvelopeValidationError(f"{what} must be 32 bytes")

def _sort_caps(caps: List[bytes]) -> List[bytes]:
    return sorted(caps)

def _sig_sort_key(s: Signature) -> bytes:
    return pack_u16(int(s.scheme)) + s.pubkey + s.sig

@dataclass(frozen=True)
class SignaturePolicy:
    """Policy for signature validation.

    - min_valid: minimum number of signatures that must verify over signing preimage
    - allowed_schemes: if set, only these scheme ids are considered
    - allowed_pubkeys: if set, only signatures whose pubkey matches one of these are considered
    """
    min_valid: int = 1
    allowed_schemes: Optional[Set[int]] = None
    allowed_pubkeys: Optional[Set[bytes]] = None

    def filter(self, sigs: Iterable[Signature]) -> List[Signature]:
        out: List[Signature] = []
        for s in sigs:
            if self.allowed_schemes is not None and int(s.scheme) not in self.allowed_schemes:
                continue
            if self.allowed_pubkeys is not None and s.pubkey not in self.allowed_pubkeys:
                continue
            out.append(s)
        return out

@dataclass(frozen=True)
class EnvelopeV1:
    version: int
    origin_chain: int
    origin_tx: bytes
    origin_sender: bytes
    target_chain: int
    target_contract: bytes
    nonce: int
    gas_limit: int
    payload_type: int
    payload: bytes
    payload_hash: bytes
    cap_refs: List[bytes]
    signatures: List[bytes]  # legacy opaque bytes

    def canonical_bytes(self) -> bytes:
        _ensure32(self.origin_tx, "origin_tx"); _ensure32(self.origin_sender, "origin_sender"); _ensure32(self.target_contract, "target_contract")
        out = bytearray()
        out += MAGIC
        out += pack_u16(V1)
        out += pack_u32(self.origin_chain)
        out += self.origin_tx
        out += self.origin_sender
        out += pack_u32(self.target_chain)
        out += self.target_contract
        out += pack_u64(self.nonce)
        out += pack_u64(self.gas_limit)
        out += pack_u16(self.payload_type)
        out += _pack_bytes(self.payload)
        out += self.payload_hash
        caps = _sort_caps(self.cap_refs)
        out += pack_u16(len(caps))
        for c in caps:
            _ensure32(c, "cap_ref")
            out += c
        out += pack_u16(len(self.signatures))
        for s in self.signatures:
            out += _pack_bytes(s)
        return bytes(out)

    def signing_message(self) -> bytes:
        # v1 had no defined signing preimage; use canonical without signatures
        return EnvelopeV1(
            version=self.version,
            origin_chain=self.origin_chain,
            origin_tx=self.origin_tx,
            origin_sender=self.origin_sender,
            target_chain=self.target_chain,
            target_contract=self.target_contract,
            nonce=self.nonce,
            gas_limit=self.gas_limit,
            payload_type=self.payload_type,
            payload=self.payload,
            payload_hash=self.payload_hash,
            cap_refs=self.cap_refs,
            signatures=[],
        ).canonical_bytes()

    def validate(self, require_signatures: bool = False) -> None:
        if self.payload_hash != sha256(self.payload):
            raise EnvelopeValidationError("payload hash mismatch")
        if require_signatures and len(self.signatures) == 0:
            raise EnvelopeValidationError("missing signatures (v1)")
        b = self.canonical_bytes()
        if EnvelopeV1.decode(b).canonical_bytes() != b:
            raise EnvelopeValidationError("canonicalization mismatch (v1)")

    @staticmethod
    def decode(buf: bytes) -> "EnvelopeV1":
        if len(buf) < 4 or buf[:4] != MAGIC:
            raise ReplayError("bad envelope magic")
        off = 4
        ver, off = read_u16(buf, off)
        if ver != V1:
            raise ReplayError("not v1")
        oc, off = read_u32(buf, off)
        if off + 64 > len(buf): raise ReplayError("EOF ids")
        origin_tx = buf[off:off+32]; off += 32
        origin_sender = buf[off:off+32]; off += 32
        tc, off = read_u32(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF target")
        target_contract = buf[off:off+32]; off += 32
        nonce, off = read_u64(buf, off)
        gas, off = read_u64(buf, off)
        ptype, off = read_u16(buf, off)
        payload, off = _read_bytes(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF payload_hash")
        ph = buf[off:off+32]; off += 32
        ncap, off = read_u16(buf, off)
        caps = []
        for _ in range(ncap):
            if off + 32 > len(buf): raise ReplayError("EOF cap")
            caps.append(buf[off:off+32]); off += 32
        nsig, off = read_u16(buf, off)
        sigs = []
        for _ in range(nsig):
            s, off = _read_bytes(buf, off)
            sigs.append(s)
        if off != len(buf): raise ReplayError("trailing bytes envelope v1")
        return EnvelopeV1(V1, oc, origin_tx, origin_sender, tc, target_contract, nonce, gas, ptype, payload, ph, caps, sigs)

@dataclass(frozen=True)
class EnvelopeV2:
    version: int
    origin_chain: int
    origin_tx: bytes
    origin_sender: bytes
    target_chain: int
    target_contract: bytes
    nonce: int
    gas_limit: int
    payload_type: int
    payload: bytes
    payload_hash: bytes
    cap_refs: List[bytes]
    signatures: List[Signature]

    def signing_message(self) -> bytes:
        # canonical bytes without signatures section (cap_refs included => cap binding)
        x = EnvelopeV2(
            version=self.version,
            origin_chain=self.origin_chain,
            origin_tx=self.origin_tx,
            origin_sender=self.origin_sender,
            target_chain=self.target_chain,
            target_contract=self.target_contract,
            nonce=self.nonce,
            gas_limit=self.gas_limit,
            payload_type=self.payload_type,
            payload=self.payload,
            payload_hash=self.payload_hash,
            cap_refs=self.cap_refs,
            signatures=[],
        )
        return x.canonical_bytes()

    def canonical_bytes(self) -> bytes:
        _ensure32(self.origin_tx, "origin_tx"); _ensure32(self.origin_sender, "origin_sender"); _ensure32(self.target_contract, "target_contract")
        out = bytearray()
        out += MAGIC
        out += pack_u16(V2)
        out += pack_u32(self.origin_chain)
        out += self.origin_tx
        out += self.origin_sender
        out += pack_u32(self.target_chain)
        out += self.target_contract
        out += pack_u64(self.nonce)
        out += pack_u64(self.gas_limit)
        out += pack_u16(self.payload_type)
        out += _pack_bytes(self.payload)
        out += self.payload_hash
        caps = _sort_caps(self.cap_refs)
        out += pack_u16(len(caps))
        for c in caps:
            _ensure32(c, "cap_ref")
            out += c

        sigs = sorted(self.signatures, key=_sig_sort_key)
        out += pack_u16(len(sigs))
        for s in sigs:
            out += pack_u16(int(s.scheme))
            out += pack_u16(len(s.pubkey)) + s.pubkey
            out += pack_u16(len(s.sig)) + s.sig
        return bytes(out)

    def validate(self, require_signatures: bool = False, policy: Optional[SignaturePolicy] = None) -> None:
        if self.payload_hash != sha256(self.payload):
            raise EnvelopeValidationError("payload hash mismatch")

        # Signature enforcement: threshold + allowlists
        if require_signatures:
            pol = policy or SignaturePolicy(min_valid=1)
            if pol.min_valid <= 0:
                raise EnvelopeValidationError("invalid policy: min_valid must be >= 1")
            msg = self.signing_message()
            cand = pol.filter(self.signatures)
            if len(cand) == 0:
                raise EnvelopeValidationError("no signatures match policy")
            valid = 0
            for s in cand:
                if verify_signature(s, msg):
                    valid += 1
                    if valid >= pol.min_valid:
                        break
            if valid < pol.min_valid:
                raise EnvelopeValidationError("signature threshold not met")

        # canonicalization check (including signature ordering)
        b = self.canonical_bytes()
        if decode_envelope(b).canonical_bytes() != b:
            raise EnvelopeValidationError("canonicalization mismatch (v2)")

    @staticmethod
    def decode(buf: bytes) -> "EnvelopeV2":
        if len(buf) < 4 or buf[:4] != MAGIC:
            raise ReplayError("bad envelope magic")
        off = 4
        ver, off = read_u16(buf, off)
        if ver != V2:
            raise ReplayError("not v2")
        oc, off = read_u32(buf, off)
        if off + 64 > len(buf): raise ReplayError("EOF ids")
        origin_tx = buf[off:off+32]; off += 32
        origin_sender = buf[off:off+32]; off += 32
        tc, off = read_u32(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF target")
        target_contract = buf[off:off+32]; off += 32
        nonce, off = read_u64(buf, off)
        gas, off = read_u64(buf, off)
        ptype, off = read_u16(buf, off)
        payload, off = _read_bytes(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF payload_hash")
        ph = buf[off:off+32]; off += 32
        ncap, off = read_u16(buf, off)
        caps = []
        for _ in range(ncap):
            if off + 32 > len(buf): raise ReplayError("EOF cap")
            caps.append(buf[off:off+32]); off += 32
        nsig, off = read_u16(buf, off)
        sigs: List[Signature] = []
        for _ in range(nsig):
            scheme, off = read_u16(buf, off)
            pk_len, off = read_u16(buf, off)
            if off + pk_len > len(buf): raise ReplayError("EOF pubkey")
            pk = buf[off:off+pk_len]; off += pk_len
            sig_len, off = read_u16(buf, off)
            if off + sig_len > len(buf): raise ReplayError("EOF sig")
            sg = buf[off:off+sig_len]; off += sig_len
            sigs.append(Signature(int(scheme), pk, sg))
        if off != len(buf): raise ReplayError("trailing bytes envelope v2")
        return EnvelopeV2(V2, oc, origin_tx, origin_sender, tc, target_contract, nonce, gas, ptype, payload, ph, caps, sigs)

Envelope = Union[EnvelopeV1, EnvelopeV2]

def decode_envelope(buf: bytes) -> Envelope:
    if len(buf) < 6 or buf[:4] != MAGIC:
        raise ReplayError("bad envelope magic")
    ver = int.from_bytes(buf[4:6], "big")
    if ver == V1:
        return EnvelopeV1.decode(buf)
    if ver == V2:
        return EnvelopeV2.decode(buf)
    raise ReplayError(f"unsupported envelope version: {ver}")

def envelope_sort_key(env: Envelope):
    return (env.target_chain, env.target_contract, env.origin_chain, env.origin_sender, env.nonce)
