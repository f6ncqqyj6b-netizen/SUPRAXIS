GAS_TABLE = {
    "CAP_REQUIRE": 500,
    "EMIT": 200,
    "STORE": 800,
    "ASSERT": 50,
    "CALL": 100,
    "RET": 0,

    # Governance ops
    "GOV_REGISTER_COMMITTEE_JSON": 50_000,
    "GOV_REGISTER_COMMITTEE_ID": 10_000,
    "GOV_SET_GRACE": 5_000,
    "GOV_SET_SLASH_PARAM": 2_000,

    # Stake + slashing
    "GOV_STAKE": 10_000,
    "GOV_UNSTAKE": 10_000,
    "GOV_SLASH": 15_000,
    "GOV_REGISTER_COMMITTEE_FROM_STAKE": 75_000,
}
def gas_cost(op_name: str) -> int:
    return int(GAS_TABLE.get(op_name, 10_000_000))
