# SUPRAXIS (Phase 15)

Phase 15 adds **misbehavior detection** and **automatic slashing proofs** for a core offense:

## Double-sign (same nonce, different payload)

If a sender produces two envelopes with the **same (origin_chain, origin_sender, target_chain, target_contract, nonce)** but
a different `payload_hash`, that is treated as **double-sign / equivocation**.

### Deterministic behavior
- The first envelope (highest sort order) is processed normally.
- If a second envelope arrives with the **same nonce** and a **different payload_hash**:
  - It is **rejected** (not executed, nonce not advanced)
  - If it is an **EnvelopeV3** with a `QuorumProofV1`, the protocol **automatically slashes** the quorum participants
    (based on bitmap indices) using stake ledger.
  - An event `AUTO_SLASH_DOUBLE_SIGN` is emitted per slashed signer.
  - The block continues deterministically.

### Slash amount parameter
Slash amount is read from state storage key:
- `storage["slash.double_sign"]` (default: `1`)

Governance can set this deterministically using the new runtime op:
- `GOV_SET_SLASH_PARAM(offense, amount)`

## New State Fields
- `nonce_payloads`: stores the payload_hash for the latest processed nonce per message stream key.

## New Governance Op (SIRB + runtime)
- `GOV_SET_SLASH_PARAM(offense, amount)`

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
