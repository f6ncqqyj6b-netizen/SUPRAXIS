from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional
from .signed_checkpoint import SignedCheckpoint
from .headerchain import Header, HeaderChain
from .signed_header import SignedHeader
from .persist import dump_signed_checkpoint, load_signed_checkpoint, dump_signed_header, load_signed_header

@dataclass
class GossipStore:
    """In-memory cache for networkless simulation: stores signed checkpoints and headers.

    Phase 39: supports both raw headers and quorum-signed headers.
    Phase 40: adds persistence (to_dict/from_dict).
    """
    checkpoints: Dict[int, List[SignedCheckpoint]] = field(default_factory=dict)  # epoch -> list
    headers: HeaderChain = field(default_factory=HeaderChain)
    signed_headers: Dict[str, SignedHeader] = field(default_factory=dict)  # block_hash -> SignedHeader

    def add_checkpoint(self, scp: SignedCheckpoint) -> None:
        ep = int(scp.checkpoint.epoch)
        lst = self.checkpoints.get(ep, [])
        lst.append(scp)
        self.checkpoints[ep] = lst

    def best_checkpoint(self, min_height: int = 0) -> Optional[SignedCheckpoint]:
        best = None
        for _, lst in self.checkpoints.items():
            for scp in lst:
                if int(scp.checkpoint.height) < int(min_height):
                    continue
                if best is None or int(scp.checkpoint.height) > int(best.checkpoint.height):
                    best = scp
        return best

    def add_header(self, h: Header) -> None:
        self.headers.add(h)

    def add_signed_header(self, sh: SignedHeader) -> None:
        self.signed_headers[str(sh.header.block_hash)] = sh
        self.headers.add(sh.header)

    def tip_header(self, chain_id: int) -> Optional[Header]:
        return self.headers.tip(chain_id)

    def tip_signed_header(self, chain_id: int) -> Optional[SignedHeader]:
        tip = self.headers.tip(chain_id)
        if tip is None:
            return None
        return self.signed_headers.get(str(tip.block_hash))

    def headers_from(self, start_hash: str, end_hash: str) -> List[Header]:
        return self.headers.path_from(start_hash, end_hash)

    def signed_headers_from(self, start_hash: str, end_hash: str) -> List[SignedHeader]:
        hs = self.headers.path_from(start_hash, end_hash)
        out: List[SignedHeader] = []
        for h in hs:
            sh = self.signed_headers.get(str(h.block_hash))
            if sh is None:
                break
            out.append(sh)
        return out

    def to_dict(self) -> dict:
        cps = {int(ep): [dump_signed_checkpoint(s) for s in lst] for ep, lst in self.checkpoints.items()}
        shs = {bh: dump_signed_header(sh) for bh, sh in self.signed_headers.items()}
        hdrs = [dump_signed_header(sh)["header"] for sh in self.signed_headers.values()]
        # also include any raw headers not covered by signed headers
        for bh, h in self.headers.headers.items():
            if bh not in self.signed_headers:
                hdrs.append({
                    "chain_id": h.chain_id, "epoch": h.epoch, "height": h.height, "round": h.round,
                    "block_hash": h.block_hash, "parent_hash": h.parent_hash, "proposer": h.proposer,
                    "validators_hash": h.validators_hash, "qc": None,
                })
        return {"checkpoints": cps, "signed_headers": shs, "headers": hdrs}

    @staticmethod
    def from_dict(d: dict) -> "GossipStore":
        g = GossipStore()
        for ep, lst in (d.get("checkpoints") or {}).items():
            g.checkpoints[int(ep)] = [load_signed_checkpoint(x) for x in list(lst)]
        for bh, shd in (d.get("signed_headers") or {}).items():
            g.add_signed_header(load_signed_header(shd))
        # raw headers
        from .persist import load_header
        for hd in list(d.get("headers") or []):
            h = load_header(hd)
            g.add_header(h)
        return g
