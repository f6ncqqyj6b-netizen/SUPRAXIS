from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Tuple, Optional, Set
from supraxis.sigverify import Signature, default_verifier
from supraxis.canonjson import canonical_json
from .checkpoint import Checkpoint

def _b(x: str) -> bytes:
    x = str(x)
    if x.startswith("0x"):
        x = x[2:]
    return bytes.fromhex(x) if x else b""

@dataclass(frozen=True)
class CheckpointSig:
    # vid is validator id (in Supraxis snapshots, vid == pubkey hex)
    vid: str
    scheme: int
    sig: str  # hex string 0x...

    def as_signature(self) -> Signature:
        return Signature(int(self.scheme), _b(self.vid), _b(self.sig))

@dataclass(frozen=True)
class SignedCheckpoint:
    checkpoint: Checkpoint
    sigs: List[CheckpointSig]

    def canonical(self) -> bytes:
        # canonical bytes for hashing / transport
        return canonical_json({
            "checkpoint": {
                "chain_id": self.checkpoint.chain_id,
                "epoch": self.checkpoint.epoch,
                "height": self.checkpoint.height,
                "state_root": self.checkpoint.state_root,
                "block_hash": self.checkpoint.block_hash,
                "validators_hash": self.checkpoint.validators_hash,
            },
            "sigs": [
                {"vid": s.vid, "scheme": int(s.scheme), "sig": s.sig}
                for s in self.sigs
            ],
        })

def verify_signed_checkpoint(scp: SignedCheckpoint, validator_snapshot: list, quorum_power: int) -> Tuple[bool, str, int]:
    """Verify SignedCheckpoint against a validator snapshot (list of {vid,power}).

    Returns: (ok, reason, signed_power)
    """
    # build power map
    power: Dict[str,int] = {}
    for r in list(validator_snapshot or []):
        vid = str(r.get("vid",""))
        if not vid.startswith("0x"):
            vid = "0x"+vid
        p = int(r.get("power",0))
        if vid and p>0:
            power[vid] = p

    msg = scp.checkpoint.signing_message()
    verifier = default_verifier()

    seen: Set[str] = set()
    signed_power = 0
    for s in scp.sigs:
        vid = str(s.vid)
        if not vid.startswith("0x"):
            vid = "0x"+vid
        if vid in seen:
            continue
        if vid not in power:
            continue
        sig = s.as_signature()
        if verifier.verify(sig, msg):
            seen.add(vid)
            signed_power += int(power[vid])

    if signed_power < int(quorum_power):
        return False, "insufficient_quorum_power", signed_power

    return True, "ok", signed_power
