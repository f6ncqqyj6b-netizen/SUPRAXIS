from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from supraxis.state import SupraxisState
from .types import Validator, Proposal, Vote, QC, Block
from .hotstuff import ConsensusState, proposer_for, quorum_threshold, form_qc
from .validator_set import validators_for_epoch, vmap

@dataclass
class ConsensusNode:
    chain_id: int
    state: SupraxisState
    cs: ConsensusState = field(init=False)

    def __post_init__(self):
        vals = validators_for_epoch(self.state)
        self.cs = ConsensusState(chain_id=self.chain_id, validators=vals, epoch=int(self.state.storage.get("epoch",0)))

    def on_epoch_change(self) -> None:
        ep = int(self.state.storage.get("epoch", 0))
        vals = validators_for_epoch(self.state, ep)
        self.cs.update_validators(vals, ep)

    def current_validators(self) -> List[Validator]:
        return list(self.cs.validators)

    def proposer(self, height: int, round: int) -> str:
        return proposer_for(self.chain_id, height, round, self.cs.validators)

    def quorum(self) -> int:
        return quorum_threshold(self.cs.validators)

    def verify_qc_power(self, qc: QC) -> bool:
        return qc.power >= self.quorum()

    def vmap(self) -> Dict[str, Validator]:
        return vmap(self.cs.validators)
