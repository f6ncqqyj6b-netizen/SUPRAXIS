from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Any, Tuple
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

Hex = str

def h(obj: Any) -> Hex:
    return sha256(canonical_json(obj)).hex()

@dataclass(frozen=True)
class Validator:
    vid: str               # hex or short id
    power: int             # stake-weighted voting power

@dataclass(frozen=True)
class Vote:
    height: int
    round: int
    block_hash: Hex
    voter: str
    sig: bytes = b""       # placeholder (Phase 29)

    def message(self) -> bytes:
        return canonical_json({"t":"vote","h":self.height,"r":self.round,"bh":self.block_hash,"v":self.voter})

@dataclass(frozen=True)
class Timeout:
    height: int
    round: int
    high_qc_hash: Hex
    voter: str
    sig: bytes = b""

    def message(self) -> bytes:
        return canonical_json({"t":"timeout","h":self.height,"r":self.round,"qc":self.high_qc_hash,"v":self.voter})

@dataclass(frozen=True)
class QC:
    height: int
    round: int
    block_hash: Hex
    sigs: Dict[str, dict]      # voter -> sig placeholder
    power: int                  # total power represented

    def digest(self) -> Hex:
        return h({"h":self.height,"r":self.round,"bh":self.block_hash,"p":self.power,"s":sorted(self.sigs.keys())})

@dataclass(frozen=True)
class TC:
    height: int
    round: int
    high_qc_hash: Hex
    sigs: Dict[str, dict]
    power: int

    def digest(self) -> Hex:
        return h({"h":self.height,"r":self.round,"qc":self.high_qc_hash,"p":self.power,"s":sorted(self.sigs.keys())})

@dataclass
class BlockHeader:
    chain_id: int
    height: int
    round: int
    parent_hash: Hex
    proposer: str

@dataclass
class Block:
    header: BlockHeader
    body: List[dict]

    def hash(self) -> Hex:
        return h({"hdr":{
            "chain_id": self.header.chain_id,
            "height": self.header.height,
            "round": self.header.round,
            "parent_hash": self.header.parent_hash,
            "proposer": self.header.proposer,
        }, "body": self.body})

@dataclass
class Proposal:
    block: Block
    high_qc: Optional[QC] = None
    sig: bytes = b""

    def message(self) -> bytes:
        return canonical_json({"t":"prop","bh":self.block.hash(),"h":self.block.header.height,"r":self.block.header.round,"p":self.block.header.proposer,"hq": self.high_qc.digest() if self.high_qc else None})
