from __future__ import annotations
from typing import Dict, Tuple, Any
from .types import QC, Validator
from .vote_signing import vote_message, verify_vote_sig, SCHEME_ED25519, SCHEME_SECP256K1

def verify_qc_crypto(qc: QC, vmap: Dict[str, Validator], quorum_power: int, chain_id: int) -> Tuple[bool,str,int]:
    """Cryptographic QC verification (supports Ed25519 + secp256k1).

    QC format: qc.sigs is Dict[voter_vid -> {"scheme": int, "sig": bytes}].
    """
    sigs: Any = getattr(qc, "sigs", {})
    if not isinstance(sigs, dict):
        return False, "bad_qc_format", 0

    msg = vote_message(chain_id=int(chain_id), height=int(qc.height), round=int(qc.round), block_hash=str(qc.block_hash))
    signed_power = 0

    for voter, entry in sigs.items():
        voter = str(voter)
        v = vmap.get(voter)
        if v is None:
            continue
        if not isinstance(entry, dict):
            continue
        scheme = int(entry.get("scheme", SCHEME_ED25519))
        sigb = entry.get("sig", b"")
        if not isinstance(sigb, (bytes, bytearray)):
            continue
        if scheme not in (SCHEME_ED25519, SCHEME_SECP256K1):
            continue
        if verify_vote_sig(voter, scheme, bytes(sigb), msg):
            signed_power += int(v.power)

    if signed_power < int(quorum_power):
        return False, "insufficient_qc_power", signed_power

    return True, "ok", signed_power
