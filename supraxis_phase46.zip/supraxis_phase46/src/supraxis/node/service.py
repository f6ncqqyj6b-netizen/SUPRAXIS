from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P
from supraxis.consensus.gossip import GossipStore
from supraxis.node.blockstore import BlockStore
from supraxis.p2p.discovery import DiscoveryService

from supraxis.consensus.persist import dump_signed_checkpoint, dump_signed_header

@dataclass
class NodeService:
    chain_id: int
    gossip: GossipStore
    blocks: BlockStore
    discovery: DiscoveryService

    async def handle(self, conn_id: str, msg: Msg) -> Optional[Msg]:
        if msg.t == P.REQ_HELLO:
            return Msg(P.RSP_HELLO, {"node_id": "node", "chain_id": int(self.chain_id), "version": "0.44.0"})

        if msg.t == P.REQ_BEST_CHECKPOINT:
            scp = self.gossip.best_checkpoint(min_height=int(msg.payload.get("min_height",0)))
            if scp is None:
                return Msg(P.RSP_ERROR, {"why":"no_checkpoint"})
            return Msg(P.RSP_BEST_CHECKPOINT, {"scp": dump_signed_checkpoint(scp)})

        if msg.t == P.REQ_SIGNED_HEADERS:
            start = str(msg.payload.get("start_hash",""))
            end = str(msg.payload.get("end_hash",""))
            path = self.gossip.signed_headers_from(start, end)
            return Msg(P.RSP_SIGNED_HEADERS, {"path": [dump_signed_header(sh) for sh in path]})

        if msg.t == P.REQ_BLOCKS:
            hashes = list(msg.payload.get("hashes") or [])
            out = {}
            for h in hashes:
                b = self.blocks.get_block(h)
                if b is not None:
                    out[str(h)] = b
            return Msg(P.RSP_BLOCKS, {"blocks": out})

        if msg.t == P.REQ_SNAPSHOT:
            # snapshot serving is handled elsewhere in this reference build
            return Msg(P.RSP_ERROR, {"why":"no_snapshot"})

        if msg.t == P.REQ_PEERS:
            limit = int(msg.payload.get("limit",32))
            peers = self.discovery.get_peers(limit=limit)
            return Msg(P.RSP_PEERS, {"peers": peers})

        return Msg(P.RSP_ERROR, {"why":"unknown_request"})
