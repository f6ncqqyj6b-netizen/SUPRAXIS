import unittest
from supraxis.state import SupraxisState
from supraxis.crypto import sha256
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.canonical import bitset_len, bitset_set

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class EvidenceEquivocationV3Tests(unittest.TestCase):
    def _setup_committee(self):
        st = SupraxisState()
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global","chain":100,"expires":10**18}
        # set quorum threshold used by evidence verification
        st.storage["quorum.min_weight"] = 7
        # Governance: stake + committee epoch 7
        functions = {"main":[
            {"op":"GOV_STAKE","pubkey":"0x706b31","amount":4,"lock_epochs":0},
            {"op":"GOV_STAKE","pubkey":"0x706b32","amount":3,"lock_epochs":0},
            {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE","epoch":7,"size":2},
            {"op":"RET"},
        ]}
        prog = SirBinProgram(version=1, functions=functions)
        payload=b'{"gov":1}'
        envg_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[])
        sigg=make_stub_signature(1,b"pk_gov", envg_base.signing_message())
        envg=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[sigg])
        run_block(st, prog.functions, [envg], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))
        cid = st.committee_registry["7"]
        return st, cid

    def _make_v3_pair(self, st, cid_hex):
        cid_bytes = bytes.fromhex(cid_hex)
        committee = st.get_committee_by_id(cid_hex)
        assert committee is not None
        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)

        payloadA=b'{"A":1}'
        phA=sha256(payloadA)
        baseA=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloadA,phA,[],[],None)
        msgA=baseA.signing_message()
        s0A=make_stub_signature(1,b"pk1",msgA); s1A=make_stub_signature(1,b"pk2",msgA)
        qpA=QuorumProofV1(bytes(bm), [Signature(s0A.scheme,b"",s0A.sig), Signature(s1A.scheme,b"",s1A.sig)])
        envA=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloadA,phA,[],[],qpA)

        payloadB=b'{"B":2}'
        phB=sha256(payloadB)
        baseB=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloadB,phB,[],[],None)
        msgB=baseB.signing_message()
        s0B=make_stub_signature(1,b"pk1",msgB); s1B=make_stub_signature(1,b"pk2",msgB)
        qpB=QuorumProofV1(bytes(bm), [Signature(s0B.scheme,b"",s0B.sig), Signature(s1B.scheme,b"",s1B.sig)])
        envB=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloadB,phB,[],[],qpB)

        return envA, envB

    def test_evidence_slashes_union_once(self):
        st, cid = self._setup_committee()
        envA, envB = self._make_v3_pair(st, cid)

        # Evidence program (permissionless) executed via a simple v2 envelope
        functions = {"main":[
            {"op":"EVIDENCE_EQUIVOCATION_V3", "env_a": "0x"+envA.canonical_bytes().hex(), "env_b": "0x"+envB.canonical_bytes().hex()},
            {"op":"RET"},
        ]}
        prog = SirBinProgram(version=1, functions=functions)

        # Run with a normal signed envelope to satisfy require_signatures
        payload=b'{"run":1}'
        env_run_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),10,10_000_000,1,payload,sha256(payload),[],[])
        sig=make_stub_signature(1,b"pk_any", env_run_base.signing_message())
        env_run=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),10,10_000_000,1,payload,sha256(payload),[],[sig])

        payload2=b'{"run":2}'
        env_run2_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),11,10_000_000,1,payload2,sha256(payload2),[],[])
        sig2=make_stub_signature(1,b"pk_any", env_run2_base.signing_message())
        env_run2=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),11,10_000_000,1,payload2,sha256(payload2),[],[sig2])

        run_block(st, prog.functions, [env_run], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))

        # Default slash.double_sign = 1, so both stakers reduced by 1
        amt1,_ = st.stake_of("0x706b31")
        amt2,_ = st.stake_of("0x706b32")
        self.assertEqual(amt1, 3)
        self.assertEqual(amt2, 2)

        # Submit same evidence again: should be ignored and not slash further
        run_block(st, prog.functions, [env_run2], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))
        amt1b,_ = st.stake_of("0x706b31")
        amt2b,_ = st.stake_of("0x706b32")
        self.assertEqual(amt1b, 3)
        self.assertEqual(amt2b, 2)

if __name__ == "__main__":
    unittest.main()
