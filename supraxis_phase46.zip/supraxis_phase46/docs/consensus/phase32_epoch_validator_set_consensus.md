# Phase 32 — Epoch Validator-Set–Driven Consensus Wiring

This phase connects **consensus membership** to Phase 31 epoch snapshots.

## Key requirement

Consensus MUST NOT use an ad-hoc validator list.
Instead, it derives membership from deterministic state:

- `storage["validators.epoch.<epoch>"]` (created at `EPOCH_ROLLOVER`)

## Validator Set Access

New module:
- `supraxis.consensus.validator_set`

Functions:
- `validators_for_epoch(state, epoch=None)`:
  - returns `List[Validator]` for the requested epoch
  - falls back to previous epoch snapshot if the exact epoch snapshot is absent

## Node Glue

New wrapper:
- `supraxis.consensus.node.ConsensusNode`

Responsibilities:
- build `ConsensusState` using `validators_for_epoch(state)`
- update validator set on epoch change via `on_epoch_change()`
- expose proposer selection and quorum threshold for the current set

## Determinism & Replay

- Snapshot entries always carry `vid` with a `0x` prefix.
- Validator list is sorted by `vid` for stable proposer selection.

Next: Phase 33 will bind block production to consensus membership (mempool → proposal → votes/QC)
and add checkpointing/fast-sync primitives referencing `validators.epoch.*`.
