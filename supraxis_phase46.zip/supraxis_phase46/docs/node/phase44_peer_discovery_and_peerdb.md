# Phase 44 — Peer Discovery + Persistent PeerDB + Reconnect/Backoff

Adds a minimal peer discovery and persistent peer database to support real networking.

## Protocol
- Adds `peers` request / `peers_ok` response.
- Payload: `{ "limit": int }`
- Response: `{ "peers": [ {"host": str, "port": int}, ... ] }`

## PeerDB
`src/supraxis/node/peerdb.py`
- persistent storage of peer addresses, last_seen, score, failures, ban windows
- selection of best candidates for dialing

## Discovery Service
`src/supraxis/p2p/discovery.py`
- serves peers from PeerDB

## PeerSync
`src/supraxis/node/peer_sync.py`
- pulls peer lists from a seed node
- inserts newly discovered peers into PeerDB
- uses exponential backoff per seed failures

## Node Service
`src/supraxis/node/service.py`
- reference handler for the TCP server
- answers `peers` requests via DiscoveryService

## Next
Phase 45: anti-spam hardening + protocol fuzz tests + request quotas (per-connection + global).
