# Phase 41 — Full Node Bootstrap + Snapshot + Replay Verification

Phase 40 created end-to-end fast sync for the light client.

Phase 41 wires that into a full-node bootstrap flow:

## Components

### Bootstrap
`src/supraxis/node/bootstrap.py`

- `bootstrap_node(state, gossip, provider, chain_id, snapshot=None, blocks_needed=0)`
- Steps:
  1) (optional) apply state snapshot
  2) fast sync headers from best signed checkpoint -> tip
  3) (optional) fetch last N blocks and deterministically re-execute to verify `state_root`

### Block Provider / Store
`src/supraxis/node/blockstore.py`
- in-memory `BlockStore` implements the `BlockProvider` protocol (`get_block`)

### Deterministic Replay Helper
`src/supraxis/node/state_exec.py`
- provides a minimal deterministic block executor for this reference build:
  - applies tx writes (fallback)
  - maintains a storage-root hash as `state_root`

## Next
Phase 42: networking ingestion + persistent DB:
- save/load snapshots + blockstore on disk
- peer sync: request signed checkpoint + signed headers + blocks
