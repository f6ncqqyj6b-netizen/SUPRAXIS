import unittest
from supraxis.state import SupraxisState
from supraxis.consensus.validator_set import validators_for_epoch
from supraxis.consensus.node import ConsensusNode
from supraxis.consensus.hotstuff import proposer_for, quorum_threshold
from supraxis.consensus.types import Validator

class Phase32ValidatorSet(unittest.TestCase):
    def test_validators_for_epoch_fallback(self):
        st = SupraxisState()
        st.storage["epoch"] = 2
        st.storage["validators.epoch.1"] = [{"vid":"0x"+"aa"*32,"power":10}]
        vals = validators_for_epoch(st)  # epoch 2 missing, fallback to 1
        self.assertEqual(len(vals), 1)
        self.assertEqual(vals[0].vid, "0x"+"aa"*32)

    def test_node_updates_on_epoch_change(self):
        st = SupraxisState()
        st.storage["epoch"] = 0
        st.storage["validators.epoch.0"] = [{"vid":"0x"+"01"*32,"power":10},{"vid":"0x"+"02"*32,"power":20}]
        node = ConsensusNode(chain_id=1, state=st)
        self.assertEqual(node.quorum(), quorum_threshold(node.current_validators()))
        p0 = node.proposer(10, 0)

        # epoch rollover
        st.storage["epoch"] = 1
        st.storage["validators.epoch.1"] = [{"vid":"0x"+"03"*32,"power":30},{"vid":"0x"+"04"*32,"power":40}]
        node.on_epoch_change()
        p1 = node.proposer(10, 0)
        self.assertNotEqual(p0, p1)
        self.assertEqual(len(node.current_validators()), 2)

if __name__ == "__main__":
    unittest.main()
