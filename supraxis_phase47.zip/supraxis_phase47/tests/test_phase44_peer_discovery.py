import unittest
import tempfile
from pathlib import Path
import asyncio

from supraxis.node.peerdb import PeerDB
from supraxis.p2p.discovery import DiscoveryService
from supraxis.node.peer_sync import PeerSync, Backoff
from supraxis.p2p.transport import AsyncTCPServer, TransportConfig, AsyncTCPClient
from supraxis.node.service import NodeService
from supraxis.consensus.gossip import GossipStore
from supraxis.node.blockstore import BlockStore
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P

class TestPhase44(unittest.TestCase):
    def test_peerdb_save_load(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/"peers.json"
            db = PeerDB(p)
            db.upsert("1.2.3.4", 1234, seen=True, score_delta=1.0)
            db.upsert("5.6.7.8", 5678, seen=False, score_delta=0.2)
            db.save()
            db2 = PeerDB(p)
            db2.load()
            self.assertIn("1.2.3.4:1234", db2.peers)
            self.assertIn("5.6.7.8:5678", db2.peers)

    def test_discovery_returns_candidates(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td)/"peers.json"
            db = PeerDB(p)
            db.upsert("a", 1, seen=True, score_delta=0.1)
            db.upsert("b", 2, seen=True, score_delta=2.0)
            svc = DiscoveryService(db)
            peers = svc.get_peers(limit=1)
            self.assertEqual(peers[0]["host"], "b")

class TestPhase44Async(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.peerdb = PeerDB(Path(self.tmp.name)/"peers.json")
        self.peerdb.upsert("127.0.0.1", 9999, seen=True, score_delta=1.0)  # dummy advertised

        self.discovery = DiscoveryService(self.peerdb)
        self.service = NodeService(chain_id=1, gossip=GossipStore(), blocks=BlockStore(), discovery=self.discovery)

        cfg = TransportConfig(chain_id=1, max_frame_bytes=16384, idle_timeout_sec=5)
        self.server = AsyncTCPServer("127.0.0.1", 0, cfg, self.service.handle)
        await self.server.start()
        self.port = self.server._server.sockets[0].getsockname()[1]

    async def asyncTearDown(self):
        await self.server.close()
        self.tmp.cleanup()

    async def test_peers_request_over_tcp(self):
        c = AsyncTCPClient("127.0.0.1", self.port)
        await c.connect()
        await c.send(Msg(P.REQ_HELLO, {"node_id":"x","chain_id":1,"version":"v"}))
        _ = await c.recv_one()
        await c.send(Msg(P.REQ_PEERS, {"limit": 10}))
        rsp = await c.recv_one()
        self.assertEqual(rsp.t, P.RSP_PEERS)
        self.assertTrue(len(rsp.payload.get("peers")) >= 1)
        await c.close()

    async def test_peersync_backoff(self):
        # point to this server as seed; it will return peers from our peerdb
        db = PeerDB(Path(self.tmp.name)/"local_peers.json")
        db.load()
        ps = PeerSync(chain_id=1, peerdb=db, backoff=Backoff(base=0.1, factor=2.0, cap=1.0))
        ok, why = await ps.step("127.0.0.1", self.port, limit=5)
        self.assertTrue(ok)
        # ensure discovered peer inserted
        self.assertTrue(any(k.endswith(":9999") for k in db.peers.keys()))

if __name__ == "__main__":
    unittest.main()
