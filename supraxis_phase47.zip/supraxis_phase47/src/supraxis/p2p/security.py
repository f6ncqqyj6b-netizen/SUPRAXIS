from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, Tuple
import time

DEFAULT_MAX_FRAME_BYTES = 1_000_000  # 1MB cap for reference build
DEFAULT_REQS_PER_SEC = 25
DEFAULT_BURST = 50

@dataclass
class RateLimiter:
    """Token-bucket rate limiter (deterministic per local clock)."""
    rate_per_sec: float = DEFAULT_REQS_PER_SEC
    burst: float = DEFAULT_BURST
    tokens: float = field(default=DEFAULT_BURST)
    last: float = field(default_factory=lambda: time.monotonic())

    def allow(self, cost: float = 1.0, now: Optional[float] = None) -> bool:
        if now is None:
            now = time.monotonic()
        dt = max(0.0, float(now) - float(self.last))
        self.last = float(now)
        self.tokens = min(self.burst, self.tokens + dt * self.rate_per_sec)
        if self.tokens >= cost:
            self.tokens -= cost
            return True
        return False

def validate_frame_size(length: int, max_bytes: int = DEFAULT_MAX_FRAME_BYTES) -> Tuple[bool,str]:
    if int(length) < 0:
        return False, "negative_length"
    if int(length) > int(max_bytes):
        return False, "frame_too_large"
    return True, "ok"

def validate_payload_schema(t: str, payload: Dict[str, Any]) -> Tuple[bool,str]:
    """Basic schema validation for known request types.

    Keep strict + minimal. Unknown types are rejected.
    """
    if not isinstance(t, str):
        return False, "bad_type"
    if not isinstance(payload, dict):
        return False, "bad_payload"

    # Minimal schema rules for Phase 42 protocol
    if t == "hello":
        if "node_id" in payload and not isinstance(payload["node_id"], str):
            return False, "bad_node_id"
        if "chain_id" in payload and not isinstance(payload["chain_id"], int):
            return False, "bad_chain_id"
        if "version" in payload and not isinstance(payload["version"], str):
            return False, "bad_version"
        return True, "ok"

    if t == "best_checkpoint":
        if "min_height" in payload and not isinstance(payload["min_height"], int):
            return False, "bad_min_height"
        return True, "ok"

    if t == "signed_headers":
        if not isinstance(payload.get("start_hash",""), str): return False, "bad_start_hash"
        if not isinstance(payload.get("end_hash",""), str): return False, "bad_end_hash"
        # range cap handled by peer manager, but ensure non-empty
        if payload.get("start_hash","") == "" or payload.get("end_hash","") == "":
            return False, "missing_hash"
        return True, "ok"

    if t == "blocks":
        hs = payload.get("hashes")
        if not isinstance(hs, list): return False, "bad_hashes"
        if any((not isinstance(x, str)) for x in hs): return False, "bad_hash_item"
        return True, "ok"

    
    if t == "peers":
        if "limit" in payload and not isinstance(payload["limit"], int):
            return False, "bad_limit"
        return True, "ok"

    
    if t == "snapshot_meta":
        if "want" in payload and not isinstance(payload["want"], bool):
            return False, "bad_want"
        return True, "ok"

    if t == "snapshot_chunk":
        if not isinstance(payload.get("snapshot_id",""), str):
            return False, "bad_snapshot_id"
        if "index" in payload and not isinstance(payload["index"], int):
            return False, "bad_index"
        if payload.get("snapshot_id","") == "":
            return False, "missing_snapshot_id"
        return True, "ok"

    if t == "snapshot":
        if "want" in payload and not isinstance(payload["want"], bool):
            return False, "bad_want"
        return True, "ok"

    # allow response types too (for transport)
    if t.endswith("_ok") or t == "error":
        return True, "ok"

    return False, "unknown_message_type"
