from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple
import time
from .security import RateLimiter

@dataclass
class PeerInfo:
    node_id: str
    chain_id: int
    version: str
    connected_at: float = field(default_factory=lambda: time.monotonic())
    last_seen: float = field(default_factory=lambda: time.monotonic())
    latency_ms: float = 0.0
    score: float = 0.0
    misbehavior: int = 0
    banned_until: float = 0.0
    limiter: RateLimiter = field(default_factory=RateLimiter)

    def is_banned(self, now: Optional[float] = None) -> bool:
        if now is None:
            now = time.monotonic()
        return float(now) < float(self.banned_until)

@dataclass
class PeerPolicy:
    min_score: float = -50.0
    ban_score: float = -100.0
    ban_seconds: int = 300
    decay_per_sec: float = 0.01  # score decays toward 0
    max_invalid: int = 20

    # request limits
    max_header_path: int = 256
    max_block_batch: int = 256

    # rate limiting
    reqs_per_sec: float = 25.0
    burst: float = 50.0

class PeerManager:
    """Tracks peer metadata, scoring, decay, and eviction decisions."""
    def __init__(self, policy: Optional[PeerPolicy] = None):
        self.policy = policy or PeerPolicy()
        self.peers: Dict[str, PeerInfo] = {}  # conn_id -> info
        self._last_decay = time.monotonic()

    def add(self, conn_id: str, info: PeerInfo) -> None:
        # apply policy rate limits
        info.limiter.rate_per_sec = float(self.policy.reqs_per_sec)
        info.limiter.burst = float(self.policy.burst)
        info.limiter.tokens = float(self.policy.burst)
        self.peers[str(conn_id)] = info

    def get(self, conn_id: str) -> Optional[PeerInfo]:
        return self.peers.get(str(conn_id))

    def remove(self, conn_id: str) -> None:
        self.peers.pop(str(conn_id), None)

    def touch(self, conn_id: str, now: Optional[float] = None) -> None:
        p = self.get(conn_id)
        if p is None:
            return
        if now is None:
            now = time.monotonic()
        p.last_seen = float(now)

    def score(self, conn_id: str, delta: float, reason: str = "") -> None:
        p = self.get(conn_id)
        if p is None:
            return
        p.score += float(delta)
        if delta < 0:
            p.misbehavior += 1

        # ban logic
        if p.score <= self.policy.ban_score or p.misbehavior >= self.policy.max_invalid:
            p.banned_until = time.monotonic() + int(self.policy.ban_seconds)

    def decay(self, now: Optional[float] = None) -> None:
        if now is None:
            now = time.monotonic()
        dt = max(0.0, float(now) - float(self._last_decay))
        self._last_decay = float(now)
        if dt <= 0:
            return
        for p in self.peers.values():
            # decay toward 0
            if p.score > 0:
                p.score = max(0.0, p.score - dt * self.policy.decay_per_sec)
            elif p.score < 0:
                p.score = min(0.0, p.score + dt * self.policy.decay_per_sec)

    def should_evict(self, conn_id: str) -> Tuple[bool,str]:
        p = self.get(conn_id)
        if p is None:
            return True, "unknown_peer"
        if p.is_banned():
            return True, "banned"
        if p.score < self.policy.min_score:
            return True, "low_score"
        return False, "ok"

    def check_request_limits(self, conn_id: str, msg_type: str, payload: dict) -> Tuple[bool,str]:
        p = self.get(conn_id)
        if p is None:
            return False, "unknown_peer"
        # token bucket
        if not p.limiter.allow(1.0):
            self.score(conn_id, -2.0, "rate_limit")
            return False, "rate_limited"

        if msg_type == "signed_headers":
            # cap path length by rough heuristic: difference in hashes isn't known; enforce by optional hint if present
            n = payload.get("max_items")
            if n is not None and isinstance(n, int) and n > self.policy.max_header_path:
                self.score(conn_id, -1.0, "header_path_too_large")
                return False, "header_path_too_large"
        if msg_type == "blocks":
            hs = payload.get("hashes") or []
            if len(hs) > self.policy.max_block_batch:
                self.score(conn_id, -1.0, "block_batch_too_large")
                return False, "block_batch_too_large"
        return True, "ok"
