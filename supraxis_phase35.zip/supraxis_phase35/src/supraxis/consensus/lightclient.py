from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from supraxis.block import state_commitment
from supraxis.state import SupraxisState
from .checkpoint import Checkpoint, validators_hash
from .signed_checkpoint import SignedCheckpoint, verify_signed_checkpoint
from .hotstuff import quorum_threshold
from .validator_set import validators_for_epoch

@dataclass
class LightClient:
    chain_id: int
    trusted: Optional[Checkpoint] = None

    def verify_checkpoint_self_consistent(self, state: SupraxisState, ck: Checkpoint) -> Tuple[bool,str]:
        if int(ck.chain_id) != int(self.chain_id):
            return False, "wrong_chain"
        # Verify validators hash matches snapshot
        snap = state.storage.get(f"validators.epoch.{int(ck.epoch)}")
        if snap is None and int(ck.epoch) > 0:
            snap = state.storage.get(f"validators.epoch.{int(ck.epoch)-1}")
        if snap is None:
            return False, "missing_validator_snapshot"
        vh = validators_hash(list(snap))
        if str(vh) != str(ck.validators_hash):
            return False, "bad_validators_hash"
        return True, "ok"

    def accept_signed_checkpoint(self, state: SupraxisState, scp: SignedCheckpoint) -> Tuple[bool,str]:
        ck = scp.checkpoint
        ok, why = self.verify_checkpoint_self_consistent(state, ck)
        if not ok:
            return False, why

        # Determine validator set for that epoch and compute quorum power
        vals = validators_for_epoch(state, int(ck.epoch))
        q = quorum_threshold(vals)

        snap = state.storage.get(f"validators.epoch.{int(ck.epoch)}")
        if snap is None and int(ck.epoch) > 0:
            snap = state.storage.get(f"validators.epoch.{int(ck.epoch)-1}")
        ok2, why2, signed_power = verify_signed_checkpoint(scp, list(snap or []), q)
        if not ok2:
            return False, why2

        # Monotonic acceptance
        if self.trusted is not None:
            if int(ck.height) <= int(self.trusted.height):
                return False, "non_increasing_height"
        self.trusted = ck
        return True, "ok"

    def sync_headers(self, headers: list) -> tuple[bool,str]:
        """Accept a sequence of headers (start-exclusive). Requires an existing trusted checkpoint."""
        if self.trusted is None:
            return False, "no_trusted_checkpoint"
        # Basic linkage + monotonic height checks
        prev_hash = str(self.trusted.block_hash)
        prev_h = int(self.trusted.height)
        for h in headers:
            if int(h.chain_id) != int(self.chain_id):
                return False, "wrong_chain"
            if str(h.parent_hash) != prev_hash:
                return False, "bad_parent_link"
            if int(h.height) != prev_h + 1:
                return False, "non_contiguous_height"
            prev_hash = str(h.block_hash)
            prev_h = int(h.height)
        # Update trusted head to latest header
        self.trusted = Checkpoint(chain_id=self.chain_id, epoch=int(self.trusted.epoch), height=prev_h,
                               state_root=str(self.trusted.state_root), block_hash=prev_hash, validators_hash=str(self.trusted.validators_hash))
        return True, "ok"
