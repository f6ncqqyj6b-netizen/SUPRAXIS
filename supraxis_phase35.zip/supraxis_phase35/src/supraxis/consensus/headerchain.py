from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional, List, Tuple, Any
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from .types import Block, QC

@dataclass
class Header:
    chain_id: int
    height: int
    round: int
    block_hash: str
    parent_hash: str
    proposer: str
    qc: Optional[QC] = None

    def canonical(self) -> bytes:
        return canonical_json({
            "chain_id": int(self.chain_id),
            "height": int(self.height),
            "round": int(self.round),
            "block_hash": str(self.block_hash),
            "parent_hash": str(self.parent_hash),
            "proposer": str(self.proposer),
            "qc": None if self.qc is None else {
                "height": self.qc.height,
                "round": self.qc.round,
                "block_hash": self.qc.block_hash,
                "power": self.qc.power,
                "sigs": [{"voter": s.voter, "sig": s.sig.hex()} for s in self.qc.sigs],
            }
        })

def header_from_block(block: Block, qc: Optional[QC]=None) -> Header:
    return Header(
        chain_id=int(block.header.chain_id),
        height=int(block.header.height),
        round=int(block.header.round),
        block_hash=str(block.hash()),
        parent_hash=str(block.header.parent_hash),
        proposer=str(block.header.proposer),
        qc=qc,
    )

class HeaderChain:
    """Stores a header-only chain with parent links; supports fast sync from a trusted checkpoint."""

    def __init__(self):
        self.headers: Dict[str, Header] = {}
        self.tips: Dict[int, str] = {}  # chain_id -> tip hash

    def add(self, h: Header) -> None:
        self.headers[h.block_hash] = h
        tip = self.tips.get(int(h.chain_id))
        # Choose greatest height as tip
        if tip is None or int(self.headers[tip].height) <= int(h.height):
            self.tips[int(h.chain_id)] = h.block_hash

    def get(self, block_hash: str) -> Optional[Header]:
        return self.headers.get(str(block_hash))

    def tip(self, chain_id: int) -> Optional[Header]:
        bh = self.tips.get(int(chain_id))
        return self.headers.get(bh) if bh else None

    def path_from(self, start_hash: str, end_hash: str) -> List[Header]:
        """Return headers from start(exclusive) -> end(inclusive) following parent links."""
        out: List[Header] = []
        cur = str(end_hash)
        seen = set()
        while cur and cur != str(start_hash):
            if cur in seen:
                break
            seen.add(cur)
            h = self.headers.get(cur)
            if h is None:
                break
            out.append(h)
            cur = str(h.parent_hash)
        out.reverse()
        return out
