import unittest
from supraxis.state import SupraxisState
from supraxis.consensus.checkpoint import Checkpoint, validators_hash
from supraxis.consensus.signed_checkpoint import SignedCheckpoint, CheckpointSig
from supraxis.consensus.gossip import GossipStore
from supraxis.consensus.headerchain import Header
from supraxis.consensus.lightclient import LightClient
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign

class TestPhase35(unittest.TestCase):
    def test_gossip_best_checkpoint(self):
        st = SupraxisState()
        k1 = ed25519_keygen(seed=b"\x01"*32)
        v1 = "0x"+k1.public.hex()
        snap = [{"vid": v1, "power": 10}]
        st.storage["validators.epoch.0"] = snap

        def mk(h):
            ck = Checkpoint(chain_id=1, epoch=0, height=h, state_root="11"*32, block_hash=f"{h:064x}", validators_hash=validators_hash(snap))
            msg = ck.signing_message()
            sig = "0x"+ed25519_sign(k1.private, msg).hex()
            return SignedCheckpoint(checkpoint=ck, sigs=[CheckpointSig(vid=v1, scheme=11, sig=sig)])

        g = GossipStore()
        g.add_checkpoint(mk(5))
        g.add_checkpoint(mk(9))
        best = g.best_checkpoint()
        self.assertEqual(best.checkpoint.height, 9)

    def test_lightclient_header_sync(self):
        # Make a light client with a trusted checkpoint
        lc = LightClient(chain_id=1, trusted=Checkpoint(chain_id=1, epoch=0, height=1, state_root="aa"*32, block_hash="01"*32, validators_hash="bb"*32))
        # Build a chain of headers 2..4
        hs = [
            Header(chain_id=1, height=2, round=0, block_hash="02"*32, parent_hash="01"*32, proposer="p", qc=None),
            Header(chain_id=1, height=3, round=0, block_hash="03"*32, parent_hash="02"*32, proposer="p", qc=None),
            Header(chain_id=1, height=4, round=0, block_hash="04"*32, parent_hash="03"*32, proposer="p", qc=None),
        ]
        ok, why = lc.sync_headers(hs)
        self.assertTrue(ok)
        self.assertEqual(lc.trusted.height, 4)
        self.assertEqual(lc.trusted.block_hash, "04"*32)

if __name__ == "__main__":
    unittest.main()
