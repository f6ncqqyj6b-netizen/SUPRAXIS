from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple, Optional
from supraxis.sigverify import Signature

# Domain separation is applied by EnvelopeV2.signing_message() already.

@dataclass(frozen=True)
class Ed25519Keypair:
    public: bytes  # 32
    private: bytes # 32 seed

def ed25519_keygen(seed: Optional[bytes]=None) -> Ed25519Keypair:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    import os
    if seed is None:
        seed = os.urandom(32)
    if len(seed) != 32:
        raise ValueError("seed must be 32 bytes")
    sk = Ed25519PrivateKey.from_private_bytes(seed)
    from cryptography.hazmat.primitives.serialization import Encoding, PublicFormat
    pk = sk.public_key().public_bytes(Encoding.Raw, PublicFormat.Raw)
    return Ed25519Keypair(public=pk, private=seed)

def ed25519_sign(private_seed: bytes, message: bytes) -> bytes:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    sk = Ed25519PrivateKey.from_private_bytes(private_seed)
    return sk.sign(message)

def make_ed25519_signature(public: bytes, sig: bytes) -> Signature:
    return Signature(scheme=11, pubkey=public, sig=sig)
