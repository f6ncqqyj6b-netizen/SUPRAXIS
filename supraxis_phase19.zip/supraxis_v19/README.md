# SUPRAXIS (Phase 19)

Phase 19 adds **evidence rewards (bounties)** and **spam controls** for permissionless evidence submission.

## Evidence Rewards

When evidence is accepted (Phase 17 / Phase 18):
- The protocol computes `total_slashed` (sum of actual stake removed).
- It splits this into:
  - **submitter bounty** = `total_slashed * evidence.bounty_bps / 10_000`
  - **treasury** = `total_slashed - bounty`

Defaults:
- `storage["evidence.bounty_bps"] = 1000` (10%)
- Treasury starts at `0`.

Balances:
- `state.balances[submitter] += bounty`
- `state.treasury += remainder`

The submitter account is derived deterministically from the executing envelope:
- `ctx["origin_sender"]` (32-byte hex)

## Spam Controls (Rate Limit)

State now tracks:
- `state.evidence_counter` (increments per accepted evidence)
- `state.evidence_last_counter[submitter]` (last accepted evidence index)

Rate limit parameter:
- `storage["evidence.cooldown"]` (default 0)

If cooldown > 0 and a submitter tries to submit evidence too soon:
- The evidence op does **not** execute
- Emits `EVIDENCE_RATE_LIMITED`

## Governance Controls

New governance ops:
- `GOV_SET_EVIDENCE_PARAMS(bounty_bps, cooldown)`
- `GOV_MINT(to, amount)` — deterministic mint to balances (for testing / bootstrap)

## SIRB + Gas
- `OP_GOV_SET_EVIDENCE_PARAMS = 0x28`
- `OP_GOV_MINT = 0x29`
- Gas:
  - `GOV_SET_EVIDENCE_PARAMS` = 2,000
  - `GOV_MINT` = 5,000

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
