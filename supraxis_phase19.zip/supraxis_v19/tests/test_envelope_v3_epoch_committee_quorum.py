import unittest
from supraxis.committee import Committee
from supraxis.envelope import EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.crypto import sha256
from supraxis.canonical import bitset_len, bitset_set

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class EnvelopeV3EpochCommitteeQuorumTests(unittest.TestCase):
    def test_epoch_is_in_signing_preimage(self):
        committee = Committee.from_dict({
            "members":[
                {"pubkey":"0x706b31","weight":4,"schemes":[1]},
                {"pubkey":"0x706b32","weight":3,"schemes":[1]},
            ]
        })
        cid = bytes.fromhex(committee.committee_id())
        payload=b'{"e":1}'
        ph=sha256(payload)

        base = EnvelopeV3(3, 1, cid, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [], None)
        msg = base.signing_message()
        sig = make_stub_signature(1, b"pk1", msg)

        env_epoch1 = EnvelopeV3(3, 1, cid, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [sig], None)
        pol = SignaturePolicy(min_weight=4, committee=committee)
        env_epoch1.validate(require_signatures=True, policy=pol)

        # reuse same signature but change epoch => should fail
        env_epoch2 = EnvelopeV3(3, 2, cid, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [sig], None)
        with self.assertRaises(Exception):
            env_epoch2.validate(require_signatures=True, policy=pol)

    def test_quorum_proof_bitmap(self):
        committee = Committee.from_dict({
            "members":[
                {"pubkey":"0x706b31","weight":4,"schemes":[1]},
                {"pubkey":"0x706b32","weight":3,"schemes":[1]},
                {"pubkey":"0x706b33","weight":2,"schemes":[1]},
            ]
        })
        cid = bytes.fromhex(committee.committee_id())
        payload=b'{"q":1}'
        ph=sha256(payload)

        base = EnvelopeV3(3, 7, cid, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [], None)
        msg = base.signing_message()

        # signers: member 0 and 1 (weights 4+3 = 7)
        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm, 0); bitset_set(bm, 1)

        s0 = make_stub_signature(1, b"pk1", msg)
        s1 = make_stub_signature(1, b"pk2", msg)

        qp = QuorumProofV1(bitmap=bytes(bm), sigs=[
            Signature(s0.scheme, b"", s0.sig),
            Signature(s1.scheme, b"", s1.sig),
        ])

        env = EnvelopeV3(3, 7, cid, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [], qp)

        pol = SignaturePolicy(min_weight=7, committee=committee)
        env.validate(require_signatures=True, policy=pol)

        # Wrong committee => mismatch committee_id
        committee2 = Committee.from_dict({"members":[{"pubkey":"0xaaaa","weight":10,"schemes":[1]}]})
        pol2 = SignaturePolicy(min_weight=1, committee=committee2)
        with self.assertRaises(Exception):
            env.validate(require_signatures=True, policy=pol2)

if __name__ == "__main__":
    unittest.main()
