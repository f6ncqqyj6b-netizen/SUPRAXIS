import unittest, json
from supraxis.envelope import EnvelopeV2, decode_envelope
from supraxis.crypto import sha256
from supraxis.sigverify import make_stub_signature

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class EnvelopeV2SigTests(unittest.TestCase):
    def test_v2_signature_enforced(self):
        payload=b'{"a":1}'
        ph=sha256(payload)
        base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[])
        msg=base.signing_message()
        sig=make_stub_signature(1, b"pub", msg)
        env=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[sig])
        env.validate(require_signatures=True)

        # corrupted sig should fail
        bad=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[sig.__class__(sig.scheme, sig.pubkey, b"xxxx")])
        with self.assertRaises(Exception):
            bad.validate(require_signatures=True)

    def test_canonical_sig_ordering(self):
        payload=b'{"a":1}'
        ph=sha256(payload)
        base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[])
        msg=base.signing_message()
        s1=make_stub_signature(1, b"b", msg)
        s2=make_stub_signature(1, b"a", msg)
        env=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[s1,s2])
        b=env.canonical_bytes()
        env2=decode_envelope(b)
        self.assertEqual(env2.canonical_bytes(), b)

if __name__ == "__main__":
    unittest.main()
