from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Union, Optional, Iterable, Set, Dict
from .canonical import (
    pack_u16, pack_u32, pack_u64, read_u16, read_u32, read_u64,
    pack_bytes_u32, read_bytes_u32, bitset_len, bitset_test
)
from .crypto import sha256, verify_signature
from .sigverify import Signature
from .committee import Committee
from .errors import EnvelopeValidationError, ReplayError

MAGIC = b"SCES"  # Supraxis Canonical Envelope Stream
V1 = 1
V2 = 2
V3 = 3

def _ensure32(b: bytes, what: str) -> None:
    if len(b) != 32:
        raise EnvelopeValidationError(f"{what} must be 32 bytes")

def _sort_caps(caps: List[bytes]) -> List[bytes]:
    return sorted(caps)

def _sig_sort_key(s: Signature) -> bytes:
    return pack_u16(int(s.scheme)) + s.pubkey + s.sig

@dataclass(frozen=True)
class SignaturePolicy:
    min_valid: int = 1
    min_weight: Optional[int] = None
    allowed_schemes: Optional[Set[int]] = None
    allowed_pubkeys: Optional[Set[bytes]] = None
    pubkey_weights: Optional[Dict[bytes, int]] = None
    pubkey_allowed_schemes: Optional[Dict[bytes, Optional[Set[int]]]] = None
    committee: Optional[Committee] = None
    require_committee_id: bool = True  # v3: env must match committee_id if committee supplied

    def normalized(self) -> "SignaturePolicy":
        if self.committee is None:
            return self
        return SignaturePolicy(
            min_valid=self.min_valid,
            min_weight=self.min_weight,
            allowed_schemes=self.allowed_schemes,
            allowed_pubkeys=self.allowed_pubkeys or self.committee.pubkeys_set(),
            pubkey_weights=self.pubkey_weights or self.committee.weights_map(),
            pubkey_allowed_schemes=self.pubkey_allowed_schemes or self.committee.schemes_map(),
            committee=self.committee,
            require_committee_id=self.require_committee_id,
        )

    def filter(self, sigs: Iterable[Signature]) -> List[Signature]:
        pol = self.normalized()
        out: List[Signature] = []
        for s in sigs:
            if pol.allowed_schemes is not None and int(s.scheme) not in pol.allowed_schemes:
                continue
            if pol.allowed_pubkeys is not None and s.pubkey not in pol.allowed_pubkeys:
                continue
            if pol.pubkey_allowed_schemes is not None and s.pubkey in pol.pubkey_allowed_schemes:
                allowed = pol.pubkey_allowed_schemes[s.pubkey]
                if allowed is not None and int(s.scheme) not in allowed:
                    continue
            out.append(s)
        return out

    def weight_for(self, pubkey: bytes) -> int:
        pol = self.normalized()
        if pol.pubkey_weights is None:
            return 1
        return int(pol.pubkey_weights.get(pubkey, 0))

@dataclass(frozen=True)
class QuorumProofV1:
    """Compact proof referencing a committee by index.

    Encoding:
    - bitmap_len: u16
    - bitmap bytes (big-endian bit order per byte; same as canonical.bitset_test)
    - sig_count: u16  (must equal number of set bits)
    - for each set bit in increasing index order:
        scheme(u16) | sig_len(u16) | sig_bytes

    Pubkeys are recovered from committee.members[index].
    """
    bitmap: bytes
    sigs: List[Signature]  # signature.pubkey is empty in storage; recovered during validation

    def canonical_bytes(self) -> bytes:
        out = bytearray()
        out += pack_u16(len(self.bitmap))
        out += self.bitmap
        out += pack_u16(len(self.sigs))
        # sigs already must be aligned to set bits in order; canonicalize by writing as-is
        for s in self.sigs:
            out += pack_u16(int(s.scheme))
            out += pack_u16(len(s.sig)) + s.sig
        return bytes(out)

    @staticmethod
    def decode(buf: bytes, off: int) -> Tuple["QuorumProofV1", int]:
        blen, off = read_u16(buf, off)
        if off + blen > len(buf): raise ReplayError("EOF bitmap")
        bitmap = buf[off:off+blen]; off += blen
        sc, off = read_u16(buf, off)
        sigs: List[Signature] = []
        for _ in range(sc):
            scheme, off = read_u16(buf, off)
            slen, off = read_u16(buf, off)
            if off + slen > len(buf): raise ReplayError("EOF sig")
            sigb = buf[off:off+slen]; off += slen
            sigs.append(Signature(int(scheme), b"", sigb))
        return QuorumProofV1(bitmap=bitmap, sigs=sigs), off

@dataclass(frozen=True)
class EnvelopeV1:
    version: int
    origin_chain: int
    origin_tx: bytes
    origin_sender: bytes
    target_chain: int
    target_contract: bytes
    nonce: int
    gas_limit: int
    payload_type: int
    payload: bytes
    payload_hash: bytes
    cap_refs: List[bytes]
    signatures: List[bytes]

    def canonical_bytes(self) -> bytes:
        _ensure32(self.origin_tx, "origin_tx"); _ensure32(self.origin_sender, "origin_sender"); _ensure32(self.target_contract, "target_contract")
        out = bytearray()
        out += MAGIC
        out += pack_u16(V1)
        out += pack_u32(self.origin_chain)
        out += self.origin_tx
        out += self.origin_sender
        out += pack_u32(self.target_chain)
        out += self.target_contract
        out += pack_u64(self.nonce)
        out += pack_u64(self.gas_limit)
        out += pack_u16(self.payload_type)
        out += pack_bytes_u32(self.payload)
        out += self.payload_hash
        caps = _sort_caps(self.cap_refs)
        out += pack_u16(len(caps))
        for c in caps:
            _ensure32(c, "cap_ref")
            out += c
        out += pack_u16(len(self.signatures))
        for s in self.signatures:
            out += pack_bytes_u32(s)
        return bytes(out)

    def validate(self, require_signatures: bool = False, **kwargs) -> None:
        if self.payload_hash != sha256(self.payload):
            raise EnvelopeValidationError("payload hash mismatch")
        if require_signatures and len(self.signatures) == 0:
            raise EnvelopeValidationError("missing signatures (v1)")
        b = self.canonical_bytes()
        if EnvelopeV1.decode(b).canonical_bytes() != b:
            raise EnvelopeValidationError("canonicalization mismatch (v1)")

    @staticmethod
    def decode(buf: bytes) -> "EnvelopeV1":
        if len(buf) < 6 or buf[:4] != MAGIC:
            raise ReplayError("bad envelope magic")
        off = 4
        ver, off = read_u16(buf, off)
        if ver != V1:
            raise ReplayError("not v1")
        oc, off = read_u32(buf, off)
        if off + 64 > len(buf): raise ReplayError("EOF ids")
        origin_tx = buf[off:off+32]; off += 32
        origin_sender = buf[off:off+32]; off += 32
        tc, off = read_u32(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF target")
        target_contract = buf[off:off+32]; off += 32
        nonce, off = read_u64(buf, off)
        gas, off = read_u64(buf, off)
        ptype, off = read_u16(buf, off)
        payload, off = read_bytes_u32(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF payload_hash")
        ph = buf[off:off+32]; off += 32
        ncap, off = read_u16(buf, off)
        caps = []
        for _ in range(ncap):
            if off + 32 > len(buf): raise ReplayError("EOF cap")
            caps.append(buf[off:off+32]); off += 32
        nsig, off = read_u16(buf, off)
        sigs = []
        for _ in range(nsig):
            s, off = read_bytes_u32(buf, off)
            sigs.append(s)
        if off != len(buf): raise ReplayError("trailing bytes envelope v1")
        return EnvelopeV1(V1, oc, origin_tx, origin_sender, tc, target_contract, nonce, gas, ptype, payload, ph, caps, sigs)

@dataclass(frozen=True)
class EnvelopeV2:
    version: int
    origin_chain: int
    origin_tx: bytes
    origin_sender: bytes
    target_chain: int
    target_contract: bytes
    nonce: int
    gas_limit: int
    payload_type: int
    payload: bytes
    payload_hash: bytes
    cap_refs: List[bytes]
    signatures: List[Signature]

    def signing_message(self) -> bytes:
        x = EnvelopeV2(
            version=self.version,
            origin_chain=self.origin_chain,
            origin_tx=self.origin_tx,
            origin_sender=self.origin_sender,
            target_chain=self.target_chain,
            target_contract=self.target_contract,
            nonce=self.nonce,
            gas_limit=self.gas_limit,
            payload_type=self.payload_type,
            payload=self.payload,
            payload_hash=self.payload_hash,
            cap_refs=self.cap_refs,
            signatures=[],
        )
        return x.canonical_bytes()

    def canonical_bytes(self) -> bytes:
        _ensure32(self.origin_tx, "origin_tx"); _ensure32(self.origin_sender, "origin_sender"); _ensure32(self.target_contract, "target_contract")
        out = bytearray()
        out += MAGIC
        out += pack_u16(V2)
        out += pack_u32(self.origin_chain)
        out += self.origin_tx
        out += self.origin_sender
        out += pack_u32(self.target_chain)
        out += self.target_contract
        out += pack_u64(self.nonce)
        out += pack_u64(self.gas_limit)
        out += pack_u16(self.payload_type)
        out += pack_bytes_u32(self.payload)
        out += self.payload_hash
        caps = _sort_caps(self.cap_refs)
        out += pack_u16(len(caps))
        for c in caps:
            _ensure32(c, "cap_ref")
            out += c
        sigs = sorted(self.signatures, key=_sig_sort_key)
        out += pack_u16(len(sigs))
        for s in sigs:
            out += pack_u16(int(s.scheme))
            out += pack_u16(len(s.pubkey)) + s.pubkey
            out += pack_u16(len(s.sig)) + s.sig
        return bytes(out)

    def validate(self, require_signatures: bool = False, policy: Optional[SignaturePolicy] = None) -> None:
        if self.payload_hash != sha256(self.payload):
            raise EnvelopeValidationError("payload hash mismatch")
        if require_signatures:
            pol = (policy or SignaturePolicy()).normalized()
            msg = self.signing_message()
            cand = sorted(pol.filter(self.signatures), key=_sig_sort_key)
            if not cand: raise EnvelopeValidationError("no signatures match policy")
            seen: Set[bytes] = set()
            valid_count=0
            total_weight=0
            for s in cand:
                if s.pubkey in seen: 
                    continue
                if verify_signature(s, msg):
                    seen.add(s.pubkey)
                    valid_count += 1
                    total_weight += pol.weight_for(s.pubkey)
            if pol.min_weight is not None:
                if total_weight < int(pol.min_weight): raise EnvelopeValidationError("signature weight threshold not met")
            else:
                if valid_count < int(pol.min_valid): raise EnvelopeValidationError("signature count threshold not met")
        b=self.canonical_bytes()
        if decode_envelope(b).canonical_bytes() != b:
            raise EnvelopeValidationError("canonicalization mismatch (v2)")

    @staticmethod
    def decode(buf: bytes) -> "EnvelopeV2":
        if len(buf) < 6 or buf[:4] != MAGIC:
            raise ReplayError("bad envelope magic")
        off = 4
        ver, off = read_u16(buf, off)
        if ver != V2:
            raise ReplayError("not v2")
        oc, off = read_u32(buf, off)
        if off + 64 > len(buf): raise ReplayError("EOF ids")
        origin_tx = buf[off:off+32]; off += 32
        origin_sender = buf[off:off+32]; off += 32
        tc, off = read_u32(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF target")
        target_contract = buf[off:off+32]; off += 32
        nonce, off = read_u64(buf, off)
        gas, off = read_u64(buf, off)
        ptype, off = read_u16(buf, off)
        payload, off = read_bytes_u32(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF payload_hash")
        ph = buf[off:off+32]; off += 32
        ncap, off = read_u16(buf, off)
        caps=[]
        for _ in range(ncap):
            if off+32>len(buf): raise ReplayError("EOF cap")
            caps.append(buf[off:off+32]); off+=32
        nsig, off = read_u16(buf, off)
        sigs=[]
        for _ in range(nsig):
            scheme, off = read_u16(buf, off)
            pk_len, off = read_u16(buf, off)
            if off+pk_len>len(buf): raise ReplayError("EOF pubkey")
            pk=buf[off:off+pk_len]; off+=pk_len
            slen, off = read_u16(buf, off)
            if off+slen>len(buf): raise ReplayError("EOF sig")
            sg=buf[off:off+slen]; off+=slen
            sigs.append(Signature(int(scheme), pk, sg))
        if off!=len(buf): raise ReplayError("trailing bytes envelope v2")
        return EnvelopeV2(V2, oc, origin_tx, origin_sender, tc, target_contract, nonce, gas, ptype, payload, ph, caps, sigs)

@dataclass(frozen=True)
class EnvelopeV3:
    """Envelope v3 adds epoch + committee_id and supports compact quorum proofs."""
    version: int
    epoch: int
    committee_id: bytes  # 32 bytes
    origin_chain: int
    origin_tx: bytes
    origin_sender: bytes
    target_chain: int
    target_contract: bytes
    nonce: int
    gas_limit: int
    payload_type: int
    payload: bytes
    payload_hash: bytes
    cap_refs: List[bytes]
    # Either signatures OR quorum_proof should be used. If both present, both are allowed, and union is considered.
    signatures: List[Signature]
    quorum_proof: Optional[QuorumProofV1] = None

    def signing_message(self) -> bytes:
        x = EnvelopeV3(
            version=self.version,
            epoch=self.epoch,
            committee_id=self.committee_id,
            origin_chain=self.origin_chain,
            origin_tx=self.origin_tx,
            origin_sender=self.origin_sender,
            target_chain=self.target_chain,
            target_contract=self.target_contract,
            nonce=self.nonce,
            gas_limit=self.gas_limit,
            payload_type=self.payload_type,
            payload=self.payload,
            payload_hash=self.payload_hash,
            cap_refs=self.cap_refs,
            signatures=[],
            quorum_proof=None,
        )
        return x.canonical_bytes()

    def canonical_bytes(self) -> bytes:
        _ensure32(self.committee_id, "committee_id")
        _ensure32(self.origin_tx, "origin_tx"); _ensure32(self.origin_sender, "origin_sender"); _ensure32(self.target_contract, "target_contract")
        out = bytearray()
        out += MAGIC
        out += pack_u16(V3)
        out += pack_u64(self.epoch)
        out += self.committee_id
        out += pack_u32(self.origin_chain)
        out += self.origin_tx
        out += self.origin_sender
        out += pack_u32(self.target_chain)
        out += self.target_contract
        out += pack_u64(self.nonce)
        out += pack_u64(self.gas_limit)
        out += pack_u16(self.payload_type)
        out += pack_bytes_u32(self.payload)
        out += self.payload_hash
        caps = _sort_caps(self.cap_refs)
        out += pack_u16(len(caps))
        for c in caps:
            _ensure32(c, "cap_ref")
            out += c

        # signatures (explicit)
        sigs = sorted(self.signatures, key=_sig_sort_key)
        out += pack_u16(len(sigs))
        for s in sigs:
            out += pack_u16(int(s.scheme))
            out += pack_u16(len(s.pubkey)) + s.pubkey
            out += pack_u16(len(s.sig)) + s.sig

        # quorum proof presence flag
        out += pack_u16(1 if self.quorum_proof is not None else 0)
        if self.quorum_proof is not None:
            out += self.quorum_proof.canonical_bytes()
        return bytes(out)

    def _collect_signatures(self, committee: Optional[Committee]) -> List[Signature]:
        sigs = list(self.signatures)
        if self.quorum_proof is not None:
            if committee is None:
                raise EnvelopeValidationError("quorum proof requires committee")
            # derive pubkeys for set bits and align with sigs in proof
            bitmap = self.quorum_proof.bitmap
            expected_len = bitset_len(committee.size())
            if len(bitmap) != expected_len:
                raise EnvelopeValidationError("bitmap length mismatch")
            # gather indices where bit set
            indices=[]
            for i in range(committee.size()):
                if bitset_test(bitmap, i):
                    indices.append(i)
            if len(indices) != len(self.quorum_proof.sigs):
                raise EnvelopeValidationError("sig_count mismatch to bitmap")
            for idx, s in zip(indices, self.quorum_proof.sigs):
                pk = committee.pubkey_at(idx)
                sigs.append(Signature(int(s.scheme), pk, s.sig))
        return sigs

    def validate(self, require_signatures: bool = False, policy: Optional[SignaturePolicy] = None) -> None:
        if self.payload_hash != sha256(self.payload):
            raise EnvelopeValidationError("payload hash mismatch")

        pol = (policy or SignaturePolicy()).normalized()
        committee = pol.committee

        if pol.committee is not None and pol.require_committee_id:
            cid = bytes.fromhex(pol.committee.committee_id())
            if cid != self.committee_id:
                raise EnvelopeValidationError("committee_id mismatch")

        if require_signatures:
            msg = self.signing_message()
            cand_all = self._collect_signatures(committee)
            cand = sorted(pol.filter(cand_all), key=_sig_sort_key)
            if not cand:
                raise EnvelopeValidationError("no signatures match policy")
            seen: Set[bytes] = set()
            valid_count=0
            total_weight=0
            for s in cand:
                if s.pubkey in seen:
                    continue
                if verify_signature(s, msg):
                    seen.add(s.pubkey)
                    valid_count += 1
                    total_weight += pol.weight_for(s.pubkey)
            if pol.min_weight is not None:
                if total_weight < int(pol.min_weight): raise EnvelopeValidationError("signature weight threshold not met")
            else:
                if valid_count < int(pol.min_valid): raise EnvelopeValidationError("signature count threshold not met")

        b=self.canonical_bytes()
        if decode_envelope(b).canonical_bytes() != b:
            raise EnvelopeValidationError("canonicalization mismatch (v3)")

    @staticmethod
    def decode(buf: bytes) -> "EnvelopeV3":
        if len(buf) < 6 or buf[:4] != MAGIC:
            raise ReplayError("bad envelope magic")
        off = 4
        ver, off = read_u16(buf, off)
        if ver != V3:
            raise ReplayError("not v3")
        epoch, off = read_u64(buf, off)
        if off+32>len(buf): raise ReplayError("EOF committee_id")
        committee_id = buf[off:off+32]; off+=32
        oc, off = read_u32(buf, off)
        if off+64>len(buf): raise ReplayError("EOF ids")
        origin_tx = buf[off:off+32]; off+=32
        origin_sender = buf[off:off+32]; off+=32
        tc, off = read_u32(buf, off)
        if off+32>len(buf): raise ReplayError("EOF target")
        target_contract = buf[off:off+32]; off+=32
        nonce, off = read_u64(buf, off)
        gas, off = read_u64(buf, off)
        ptype, off = read_u16(buf, off)
        payload, off = read_bytes_u32(buf, off)
        if off+32>len(buf): raise ReplayError("EOF payload_hash")
        ph = buf[off:off+32]; off+=32
        ncap, off = read_u16(buf, off)
        caps=[]
        for _ in range(ncap):
            if off+32>len(buf): raise ReplayError("EOF cap")
            caps.append(buf[off:off+32]); off+=32
        nsig, off = read_u16(buf, off)
        sigs=[]
        for _ in range(nsig):
            scheme, off = read_u16(buf, off)
            pk_len, off = read_u16(buf, off)
            if off+pk_len>len(buf): raise ReplayError("EOF pubkey")
            pk=buf[off:off+pk_len]; off+=pk_len
            slen, off = read_u16(buf, off)
            if off+slen>len(buf): raise ReplayError("EOF sig")
            sg=buf[off:off+slen]; off+=slen
            sigs.append(Signature(int(scheme), pk, sg))
        qp_flag, off = read_u16(buf, off)
        qp = None
        if qp_flag == 1:
            qp, off = QuorumProofV1.decode(buf, off)
        elif qp_flag != 0:
            raise ReplayError("bad quorum flag")
        if off!=len(buf): raise ReplayError("trailing bytes envelope v3")
        return EnvelopeV3(V3, epoch, committee_id, oc, origin_tx, origin_sender, tc, target_contract, nonce, gas, ptype, payload, ph, caps, sigs, qp)

Envelope = Union[EnvelopeV1, EnvelopeV2, EnvelopeV3]

def decode_envelope(buf: bytes) -> Envelope:
    if len(buf) < 6 or buf[:4] != MAGIC:
        raise ReplayError("bad envelope magic")
    ver = int.from_bytes(buf[4:6], "big")
    if ver == V1:
        return EnvelopeV1.decode(buf)
    if ver == V2:
        return EnvelopeV2.decode(buf)
    if ver == V3:
        return EnvelopeV3.decode(buf)
    raise ReplayError(f"unsupported envelope version: {ver}")

def envelope_sort_key(env: Envelope):
    # epoch binds ordering across rotations too
    ep = getattr(env, "epoch", 0)
    return (int(ep), env.target_chain, env.target_contract, env.origin_chain, env.origin_sender, env.nonce)
