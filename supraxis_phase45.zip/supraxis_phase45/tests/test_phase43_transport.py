import unittest
import asyncio

from supraxis.p2p.transport import AsyncTCPServer, AsyncTCPClient, TransportConfig
from supraxis.p2p.message import Msg

class TestPhase43(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        async def handler(conn_id, msg):
            if msg.t == "hello":
                return Msg("hello_ok", {"ok": True})
            if msg.t == "best_checkpoint":
                return Msg("best_checkpoint_ok", {"scp": None})
            return Msg("error", {"why":"unknown"})
        self.handler = handler
        from supraxis.p2p.peer_manager import PeerPolicy
        pol = PeerPolicy()
        pol.reqs_per_sec = 1.0
        pol.burst = 2.0
        self.config = TransportConfig(chain_id=1, max_frame_bytes=4096, idle_timeout_sec=5, policy=pol)
        self.server = AsyncTCPServer("127.0.0.1", 0, self.config, self.handler)
        await self.server.start()
        # get bound port
        sockets = self.server._server.sockets
        self.port = sockets[0].getsockname()[1]

    async def asyncTearDown(self):
        await self.server.close()

    async def test_wrong_chain_rejected(self):
        c = AsyncTCPClient("127.0.0.1", self.port)
        await c.connect()
        await c.send(Msg("hello", {"node_id":"x","chain_id":999,"version":"v"}))
        rsp = await c.recv_one()
        self.assertEqual(rsp.t, "error")
        self.assertEqual(rsp.payload.get("why"), "wrong_chain")
        await c.close()

    async def test_ok_hello_and_request(self):
        c = AsyncTCPClient("127.0.0.1", self.port)
        await c.connect()
        await c.send(Msg("hello", {"node_id":"x","chain_id":1,"version":"v"}))
        r1 = await c.recv_one()
        self.assertIn(r1.t, ("hello_ok","error"))
        await c.send(Msg("best_checkpoint", {"min_height":0}))
        r2 = await c.recv_one()
        self.assertEqual(r2.t, "best_checkpoint_ok")
        await c.close()

    async def test_unknown_type_penalized(self):
        c = AsyncTCPClient("127.0.0.1", self.port)
        await c.connect()
        await c.send(Msg("hello", {"node_id":"x","chain_id":1,"version":"v"}))
        await c.recv_one()
        await c.send(Msg("nope", {"x":1}))
        r = await c.recv_one()
        self.assertEqual(r.t, "error")
        await c.close()

    async def test_frame_too_large_disconnects(self):
        # send a crafted 4-byte length larger than max_frame_bytes
        reader, writer = await asyncio.open_connection("127.0.0.1", self.port)
        writer.write((50000).to_bytes(4,"big") + b"x"*10)
        await writer.drain()
        await asyncio.sleep(0.1)
        # server should close
        data = await reader.read(10)
        # either empty or error frame then close; accept empty
        writer.close()
        await writer.wait_closed()

    async def test_rate_limit(self):
        # server policy already sets low req/sec; blast requests and expect rate_limited
        c = AsyncTCPClient("127.0.0.1", self.port)
        await c.connect()
        await c.send(Msg("hello", {"node_id":"x","chain_id":1,"version":"v"}))
        await c.recv_one()
        # spam requests
        for _ in range(30):
            await c.send(Msg("best_checkpoint", {"min_height":0}))
        # read a few responses; at least one should be error rate_limited in most runs
        saw_rl = False
        for _ in range(30):
            m = await c.recv_one(timeout=2.0)
            if m.t == "error" and m.payload.get("why") == "rate_limited":
                saw_rl = True
                break
        await c.close()
        self.assertTrue(saw_rl)

if __name__ == "__main__":
    unittest.main()
