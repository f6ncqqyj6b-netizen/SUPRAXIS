import unittest
import tempfile
from pathlib import Path
import json
from urllib import request, parse

from supraxis.ledger_state import LedgerState
from supraxis.tx import make_tx
from supraxis.node.db import NodeDB
from supraxis.node.state_service import StateService
from supraxis.rpc.server import RPCContext, start_rpc_server

class TestPhase55(unittest.TestCase):
    def test_transfer_and_root(self):
        st = LedgerState()
        st.get("alice").balance = 100
        root0 = st.state_root()
        tx = make_tx(chain_id=1, nonce=0, sender="alice", to="bob", method="transfer", params={"amount": 25}, max_fee=10**9).to_dict()
        ok, why = st.apply_tx_dict(tx)
        self.assertTrue(ok, why)
        self.assertEqual(st.get("alice").balance, 75)
        self.assertEqual(st.get("bob").balance, 25)
        self.assertNotEqual(root0, st.state_root())

    def test_persist(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            svc = StateService(state=LedgerState(), db=db)
            svc.state.get("a").balance = 7
            svc.persist()
            svc2 = StateService(state=LedgerState(), db=db)
            svc2.load_from_db()
            self.assertEqual(svc2.state.get("a").balance, 7)

    def test_rpc_state(self):
        stsvc = StateService(state=LedgerState(), db=None)
        ctx = RPCContext(chain_id=1, mempool=None, blocks=None, evidence=None, governance=None, state=stsvc)
        httpd, _t = start_rpc_server("127.0.0.1", 0, ctx)
        base = f"http://127.0.0.1:{httpd.server_port}"

        def _get(url):
            with request.urlopen(url, timeout=5) as r:
                return json.loads(r.read().decode("utf-8"))

        def _post(url, obj):
            raw = json.dumps(obj).encode("utf-8")
            req = request.Request(url, data=raw, headers={"Content-Type":"application/json"})
            with request.urlopen(req, timeout=5) as r:
                return json.loads(r.read().decode("utf-8"))

        r = _post(base + "/state/fund", {"addr":"alice","amount":100})
        self.assertTrue(r["ok"])
        acc = _get(base + "/state/account?addr=alice")
        self.assertEqual(acc["account"]["balance"], 100)

        httpd.shutdown()
        httpd.server_close()

if __name__ == "__main__":
    unittest.main()
