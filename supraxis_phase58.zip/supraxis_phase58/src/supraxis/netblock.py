from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Tuple
import time

from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from supraxis.tx import validate_tx_dict, tx_from_dict

NETBLOCK_VERSION = 1

@dataclass(frozen=True)
class NetBlock:
    version: int
    chain_id: int
    height: int
    parent_hash: str
    proposer: str
    ts: int
    txs: List[dict]
    state_root: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": int(self.version),
            "chain_id": int(self.chain_id),
            "height": int(self.height),
            "parent_hash": str(self.parent_hash),
            "proposer": str(self.proposer),
            "ts": int(self.ts),
            "txs": list(self.txs),
            "state_root": str(self.state_root),
        }

    def hash_hex(self) -> str:
        return sha256(canonical_json(self.to_dict())).hex()

def validate_netblock_dict(d: Dict[str, Any]) -> Tuple[bool,str]:
    try:
        if int(d.get("version")) != NETBLOCK_VERSION:
            return False, "bad_version"
        for k in ["chain_id","height","ts"]:
            if k not in d or not isinstance(d[k], int):
                return False, f"bad_{k}"
        for k in ["parent_hash","proposer","state_root"]:
            if k not in d or not isinstance(d[k], str):
                return False, f"bad_{k}"
        txs = d.get("txs")
        if not isinstance(txs, list):
            return False, "bad_txs"
        for txd in txs:
            if not isinstance(txd, dict):
                return False, "bad_tx_item"
            ok, why = validate_tx_dict(txd)
            if not ok:
                return False, f"bad_tx:{why}"
        return True, "ok"
    except Exception:
        return False, "exception"

def netblock_from_dict(d: Dict[str, Any]) -> NetBlock:
    ok, why = validate_netblock_dict(d)
    if not ok:
        raise ValueError(why)
    return NetBlock(
        version=int(d["version"]),
        chain_id=int(d["chain_id"]),
        height=int(d["height"]),
        parent_hash=str(d["parent_hash"]),
        proposer=str(d["proposer"]),
        ts=int(d["ts"]),
        txs=list(d["txs"]),
        state_root=str(d.get("state_root","")),
    )

def make_netblock(chain_id: int, height: int, parent_hash: str, proposer: str, txs: List[dict]) -> NetBlockk:
    return NetBlock(
        version=NETBLOCK_VERSION,
        chain_id=int(chain_id),
        height=int(height),
        parent_hash=str(parent_hash),
        proposer=str(proposer),
        ts=int(time.time()),
        txs=list(txs),
        state_root="",
    )


def make_netblock_with_root(chain_id: int, height: int, parent_hash: str, proposer: str, txs: List[dict], state_root: str) -> NetBlock:
    b = make_netblock(chain_id, height, parent_hash, proposer, txs)
    return NetBlock(
        version=b.version,
        chain_id=b.chain_id,
        height=b.height,
        parent_hash=b.parent_hash,
        proposer=b.proposer,
        ts=b.ts,
        txs=b.txs,
        state_root=str(state_root),
    )
