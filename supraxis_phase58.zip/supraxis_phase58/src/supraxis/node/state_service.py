from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from supraxis.ledger_state import LedgerState, Account
from supraxis.node.db import NodeDB

@dataclass
class StateService:
    state: LedgerState
    db: Optional[NodeDB] = None

    def load_from_db(self) -> None:
        if self.db is None:
            return
        d = self.db.load_state()
        if not d:
            return
        self.state = LedgerState.from_snapshot(d)

    def persist(self) -> None:
        if self.db is None:
            return
        self.db.save_state(self.state.snapshot_dict())


    def clone_state(self) -> LedgerState:
        return self.state.clone()
