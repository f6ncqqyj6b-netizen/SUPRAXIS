from __future__ import annotations
from dataclasses import asdict
from typing import Any, Dict, List
from supraxis.canonjson import canonical_json
from supraxis.crypto import sha256
from .signed_checkpoint import SignedCheckpoint, CheckpointSig
from .checkpoint import Checkpoint
from .headerchain import Header
from .signed_header import SignedHeader

def _bhex(x: str) -> bytes:
    x = str(x)
    if x.startswith("0x"):
        x = x[2:]
    return bytes.fromhex(x) if x else b""

def _hex(b: bytes) -> str:
    return "0x"+b.hex()

def dump_signed_checkpoint(scp: SignedCheckpoint) -> Dict[str, Any]:
    return {
        "checkpoint": {
            "chain_id": scp.checkpoint.chain_id,
            "epoch": scp.checkpoint.epoch,
            "height": scp.checkpoint.height,
            "state_root": scp.checkpoint.state_root,
            "block_hash": scp.checkpoint.block_hash,
            "validators_hash": scp.checkpoint.validators_hash,
        },
        "sigs": [{"vid": s.vid, "scheme": int(s.scheme), "sig": s.sig} for s in scp.sigs],
    }

def load_signed_checkpoint(d: Dict[str, Any]) -> SignedCheckpoint:
    ck = d["checkpoint"]
    c = Checkpoint(chain_id=int(ck["chain_id"]), epoch=int(ck["epoch"]), height=int(ck["height"]),
                   state_root=str(ck["state_root"]), block_hash=str(ck["block_hash"]), validators_hash=str(ck["validators_hash"]))
    sigs = [CheckpointSig(vid=str(s["vid"]), scheme=int(s["scheme"]), sig=str(s["sig"])) for s in list(d.get("sigs",[]))]
    return SignedCheckpoint(checkpoint=c, sigs=sigs)

def dump_header(h: Header) -> Dict[str, Any]:
    qc = None
    if h.qc is not None:
        qc = {
            "height": h.qc.height, "round": h.qc.round, "block_hash": h.qc.block_hash, "power": h.qc.power,
            "sigs": {k: {"scheme": int(v.get("scheme",11)), "sig": _hex(v.get("sig",b""))} for k,v in h.qc.sigs.items()}
        }
    return {
        "chain_id": h.chain_id,
        "epoch": h.epoch,
        "height": h.height,
        "round": h.round,
        "block_hash": h.block_hash,
        "parent_hash": h.parent_hash,
        "proposer": h.proposer,
        "validators_hash": h.validators_hash,
        "qc": qc,
    }

def load_header(d: Dict[str, Any]) -> Header:
    from .types import QC
    qc = None
    if d.get("qc") is not None:
        q = d["qc"]
        sigs = {k: {"scheme": int(v.get("scheme",11)), "sig": _bhex(v.get("sig","0x"))} for k,v in q.get("sigs",{}).items()}
        qc = QC(height=int(q["height"]), round=int(q["round"]), block_hash=str(q["block_hash"]), power=int(q.get("power",0)), sigs=sigs)
    return Header(chain_id=int(d["chain_id"]), epoch=int(d["epoch"]), height=int(d["height"]), round=int(d["round"]),
                  block_hash=str(d["block_hash"]), parent_hash=str(d["parent_hash"]), proposer=str(d["proposer"]),
                  validators_hash=str(d.get("validators_hash","")), qc=qc)

def dump_signed_header(sh: SignedHeader) -> Dict[str, Any]:
    return {
        "header": dump_header(sh.header),
        "sigs": {k: {"scheme": int(v.get("scheme",11)), "sig": _hex(v.get("sig",b""))} for k,v in sh.sigs.items()},
    }

def load_signed_header(d: Dict[str, Any]) -> SignedHeader:
    h = load_header(d["header"])
    sigs = {k: {"scheme": int(v.get("scheme",11)), "sig": _bhex(v.get("sig","0x"))} for k,v in d.get("sigs",{}).items()}
    return SignedHeader(header=h, sigs=sigs)

def dumps(obj: Any) -> str:
    return canonical_json(obj).decode("utf-8")

def sha(obj: Any) -> str:
    return sha256(canonical_json(obj)).hex()
