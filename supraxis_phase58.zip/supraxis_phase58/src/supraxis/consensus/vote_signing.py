from __future__ import annotations
from typing import Tuple, Optional
from supraxis.canonjson import canonical_json
from supraxis.sigverify import Signature, default_verifier

SCHEME_ED25519 = 11
SCHEME_SECP256K1 = 12

def vote_message(chain_id: int, height: int, round: int, block_hash: str) -> bytes:
    payload = {
        "t":"SUPRAXIS_VOTE_V1",
        "chain_id": int(chain_id),
        "height": int(height),
        "round": int(round),
        "block_hash": str(block_hash),
    }
    return b"SUPRAXIS|VOTE|V1|" + canonical_json(payload)

def _bhex(x: str) -> bytes:
    x = str(x)
    if x.startswith("0x"):
        x = x[2:]
    return bytes.fromhex(x) if x else b""

def verify_vote_sig(voter_vid: str, scheme: int, sig_bytes: bytes, msg: bytes) -> bool:
    sig = Signature(scheme=int(scheme), pubkey=_bhex(voter_vid), sig=sig_bytes)
    return default_verifier().verify(sig, msg)
