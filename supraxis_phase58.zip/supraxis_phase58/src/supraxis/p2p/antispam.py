from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional, Tuple
import time

@dataclass
class TokenBucket:
    rate_per_sec: float
    burst: float
    tokens: float = field(init=False)
    last: float = field(default_factory=lambda: time.monotonic())

    def __post_init__(self):
        self.tokens = float(self.burst)

    def allow(self, cost: float = 1.0, now: Optional[float] = None) -> bool:
        if now is None:
            now = time.monotonic()
        dt = max(0.0, float(now) - float(self.last))
        self.last = float(now)
        self.tokens = min(float(self.burst), self.tokens + dt * float(self.rate_per_sec))
        if self.tokens >= cost:
            self.tokens -= cost
            return True
        return False

@dataclass
class GlobalLimits:
    max_conns: int = 128
    max_reqs_per_sec: float = 200.0
    burst: float = 400.0
    max_header_path_items: int = 256
    max_block_batch: int = 256

class GlobalLimiter:
    def __init__(self, limits: Optional[GlobalLimits] = None):
        self.limits = limits or GlobalLimits()
        self.bucket = TokenBucket(rate_per_sec=self.limits.max_reqs_per_sec, burst=self.limits.burst)

    def allow(self, cost: float = 1.0) -> bool:
        return self.bucket.allow(cost)

    def check_quota(self, msg_type: str, payload: dict) -> Tuple[bool,str]:
        if msg_type == "signed_headers":
            # enforce explicit max_items hint if present else apply hard cap to requested range via default
            mi = payload.get("max_items")
            if mi is not None and isinstance(mi, int) and mi > self.limits.max_header_path_items:
                return False, "global_header_quota"
        if msg_type == "blocks":
            hs = payload.get("hashes") or []
            if len(hs) > self.limits.max_block_batch:
                return False, "global_block_quota"
        return True, "ok"
