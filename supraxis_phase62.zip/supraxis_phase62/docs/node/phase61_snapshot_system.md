# Phase 61 — Snapshots (Create/Get/Restore) with Verification

This phase adds a complete snapshot system (GitHub-friendly, deterministic):

- Snapshot structure: `{id, height, state, state_root, ts}`
- Storage: `db/snapshots/snap_<id>.json` + checksum
- Latest pointer: `db/snapshot_latest.json`

## RPC
- `POST /snapshot/create`
- `GET /snapshot/latest`
- `GET /snapshot/<id>`
- `POST /snapshot/restore` with `{ "id": "<id>" }` or `{ "snapshot": {...} }`

## Verification
`restore_snapshot(...)` recomputes `state_root` from the embedded ledger state and refuses restore if mismatched.

Next:
Phase 62 — Fast sync flow (download latest snapshot + apply remaining blocks).
