# Phase 62 — Block Persistence + Fast Sync Plan

Adds:
- Persist accepted blocks in NodeDB: `db/blocks/<hash>.json` (+ checksum)
- RPC: `GET /sync/plan` returns:
  - latest snapshot (if any)
  - list of blocks with height > snapshot.height (metadata only)

Files:
- `src/supraxis/node/db.py` (save_block/load_block/list_blocks)
- `src/supraxis/node/db_blockstore.py`
- `src/supraxis/node/block_builder.py` (persist blocks to db on accept)
- `src/supraxis/rpc/server.py` (`/sync/plan`)

Next:
Phase 63 — Fast sync apply: restore snapshot then download/apply missing blocks.
