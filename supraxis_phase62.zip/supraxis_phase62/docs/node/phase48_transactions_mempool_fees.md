# Phase 48 — Transaction Format + Mempool + Fee Model (Baseline)

Adds a deterministic transaction object, fee estimation rules, and a mempool to enable block production.

## Transaction Format
`src/supraxis/tx.py`
- canonical JSON encoding (deterministic)
- stable `tx_hash = sha256(canonical_json(tx))`
- required fields:
  - version, chain_id, nonce, sender, to, method, params, max_fee, ts

## Fee Model
`src/supraxis/fees.py`
- baseline estimation:
  - base_fee + per_byte_fee * tx_bytes + per_param_fee * number_of_param_keys
- mempool enforces `max_fee >= estimated_fee`

## Mempool
`src/supraxis/mempool.py`
- bounded size + per-sender limits
- expires old txs
- simple eviction of lowest-fee tx when full

## P2P TX Gossip
`src/supraxis/p2p/protocol.py`
- `txs` / `txs_ok`
`src/supraxis/node/tx_service.py`
- accepts tx batches and inserts into mempool

`src/supraxis/node/service.py`
- handles `txs` if `tx_service` is provided

## Next
Phase 49: block builder/proposer pipeline + tx/block gossip integration.
