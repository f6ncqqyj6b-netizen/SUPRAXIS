# Phase 51 — Governance Hardening (Upgrade Gates, Timelocks, Emergency Brakes)

This phase introduces a reference governance engine with:
- proposal records
- timelock queue/execute semantics
- expiry window (grace period)
- emergency halt/resume gated by guardian threshold

It also adds early hooks for slashing to affect validator/stake accounting.

## Governance Engine
`src/supraxis/governance.py`
- Proposal kinds:
  - `param_change`
  - `upgrade`
  - `emergency`
- Status lifecycle:
  - pending → queued → executed (or canceled/expired)
- `timelock_sec` enforced between queue and execute
- `grace_period_sec` expires queued proposals
- `emergency_halt` blocks non-emergency proposals

## Node Governance Service
`src/supraxis/node/governance_service.py`
- P2P endpoints:
  - `gov_submit`, `gov_queue`, `gov_execute`, `gov_status`, `gov_emergency`
- Persists `governance.json` via NodeDB (atomic + checksum)

## Validator/Stake Hook Stubs
`src/supraxis/consensus/stake_accounting.py` (stake accounting hook)
`src/supraxis/node/slash_adapter.py`
- Minimal stake set that supports slashing/jailling
- Adapter applies slashes recorded by EvidenceStore (Phase 50) into ValidatorSet

## Next
Phase 52: genesis tooling + seed node bootstrapping + reproducible configs.
