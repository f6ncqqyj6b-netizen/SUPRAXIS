from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Dict, Any
import json
import hashlib

DEFAULT_CHUNK_SIZE = 64 * 1024  # 64KB

def sha256_hex(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def snapshot_to_bytes(snapshot: dict) -> bytes:
    # deterministic json encoding
    return json.dumps(snapshot, sort_keys=True, separators=(",", ":")).encode("utf-8")

def bytes_to_snapshot(b: bytes) -> dict:
    return json.loads(b.decode("utf-8"))

@dataclass(frozen=True)
class SnapshotMeta:
    snapshot_id: str
    total_bytes: int
    chunk_size: int
    chunks: int
    sha256: str
    chunk_sha256: List[str]

def make_chunks(data: bytes, chunk_size: int = DEFAULT_CHUNK_SIZE) -> List[bytes]:
    cs = int(chunk_size)
    if cs <= 0:
        raise ValueError("bad_chunk_size")
    return [data[i:i+cs] for i in range(0, len(data), cs)] or [b""]

def build_meta(snapshot_id: str, snapshot: dict, chunk_size: int = DEFAULT_CHUNK_SIZE) -> Tuple[SnapshotMeta, List[bytes]]:
    data = snapshot_to_bytes(snapshot)
    chunks = make_chunks(data, chunk_size=chunk_size)
    chks = [sha256_hex(c) for c in chunks]
    meta = SnapshotMeta(
        snapshot_id=str(snapshot_id),
        total_bytes=len(data),
        chunk_size=int(chunk_size),
        chunks=len(chunks),
        sha256=sha256_hex(data),
        chunk_sha256=chks,
    )
    return meta, chunks

def verify_chunks(meta: SnapshotMeta, chunks: List[bytes]) -> Tuple[bool,str]:
    if len(chunks) != int(meta.chunks):
        return False, "chunk_count_mismatch"
    for i, c in enumerate(chunks):
        if sha256_hex(c) != meta.chunk_sha256[i]:
            return False, f"chunk_hash_mismatch:{i}"
    data = b"".join(chunks)
    if len(data) != int(meta.total_bytes):
        return False, "total_bytes_mismatch"
    if sha256_hex(data) != meta.sha256:
        return False, "snapshot_hash_mismatch"
    return True, "ok"

def meta_to_dict(meta: SnapshotMeta) -> Dict[str, Any]:
    return {
        "snapshot_id": meta.snapshot_id,
        "total_bytes": meta.total_bytes,
        "chunk_size": meta.chunk_size,
        "chunks": meta.chunks,
        "sha256": meta.sha256,
        "chunk_sha256": list(meta.chunk_sha256),
    }

def meta_from_dict(d: dict) -> SnapshotMeta:
    return SnapshotMeta(
        snapshot_id=str(d["snapshot_id"]),
        total_bytes=int(d["total_bytes"]),
        chunk_size=int(d["chunk_size"]),
        chunks=int(d["chunks"]),
        sha256=str(d["sha256"]),
        chunk_sha256=[str(x) for x in list(d.get("chunk_sha256") or [])],
    )
