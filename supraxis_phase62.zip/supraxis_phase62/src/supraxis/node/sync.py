from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional, Any, List, Tuple
import json

from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P
from supraxis.consensus.gossip import GossipStore
from supraxis.consensus.persist import dump_signed_checkpoint, dump_signed_header
from supraxis.consensus.persist import load_signed_checkpoint, load_signed_header
from supraxis.node.blockstore import BlockStore

class Peer(ProtocolError := Exception):
    pass

@dataclass
class InMemoryPeer:
    """Simulated peer that serves gossip/snapshot/blocks."""
    node_id: str
    chain_id: int
    version: str
    gossip: GossipStore
    snapshot: Optional[dict]
    blocks: BlockStore

    def handle(self, msg: Msg) -> Msg:
        try:
            if msg.t == P.REQ_HELLO:
                return Msg(P.RSP_HELLO, {"node_id": self.node_id, "chain_id": self.chain_id, "version": self.version})
            if msg.t == P.REQ_BEST_CHECKPOINT:
                min_h = int(msg.payload.get("min_height", 0))
                scp = self.gossip.best_checkpoint(min_height=min_h)
                if scp is None:
                    return Msg(P.RSP_ERROR, {"why":"no_checkpoint"})
                return Msg(P.RSP_BEST_CHECKPOINT, {"scp": dump_signed_checkpoint(scp)})
            if msg.t == P.REQ_SIGNED_HEADERS:
                start = str(msg.payload.get("start_hash",""))
                end = str(msg.payload.get("end_hash",""))
                path = self.gossip.signed_headers_from(start, end)
                return Msg(P.RSP_SIGNED_HEADERS, {"path":[dump_signed_header(sh) for sh in path]})
            if msg.t == P.REQ_BLOCKS:
                hashes = list(msg.payload.get("hashes") or [])
                out = {}
                for h in hashes:
                    b = self.blocks.get_block(h)
                    if b is not None:
                        out[str(h)] = b
                return Msg(P.RSP_BLOCKS, {"blocks": out})
            if msg.t == P.REQ_SNAPSHOT:
                if self.snapshot is None:
                    return Msg(P.RSP_ERROR, {"why":"no_snapshot"})
                return Msg(P.RSP_SNAPSHOT, {"snapshot": self.snapshot})
            return Msg(P.RSP_ERROR, {"why":"unknown_request"})
        except Exception as e:
            return Msg(P.RSP_ERROR, {"why": "exception", "err": str(e)})

@dataclass
class SyncClient:
    chain_id: int
    peers: List[InMemoryPeer]

    def fetch_best_checkpoint(self) -> Optional[dict]:
        for p in self.peers:
            rsp = p.handle(Msg(P.REQ_BEST_CHECKPOINT, {"min_height": 0}))
            if rsp.t == P.RSP_BEST_CHECKPOINT:
                return rsp.payload["scp"]
        return None

    def fetch_signed_headers(self, start_hash: str, end_hash: str) -> List[dict]:
        for p in self.peers:
            rsp = p.handle(Msg(P.REQ_SIGNED_HEADERS, {"start_hash": start_hash, "end_hash": end_hash}))
            if rsp.t == P.RSP_SIGNED_HEADERS:
                return list(rsp.payload.get("path") or [])
        return []

    def fetch_snapshot(self) -> Optional[dict]:
        for p in self.peers:
            rsp = p.handle(Msg(P.REQ_SNAPSHOT, {"want": True}))
            if rsp.t == P.RSP_SNAPSHOT:
                return rsp.payload.get("snapshot")
        return None

    def fetch_blocks(self, hashes: List[str]) -> Dict[str, Any]:
        for p in self.peers:
            rsp = p.handle(Msg(P.REQ_BLOCKS, {"hashes": list(hashes)}))
            if rsp.t == P.RSP_BLOCKS:
                return dict(rsp.payload.get("blocks") or {})
        return {}

    def ingest_into_local(self, local_gossip: GossipStore, local_store: BlockStore, want_snapshot: bool=True) -> Optional[dict]:
        # pull best checkpoint
        scp_d = self.fetch_best_checkpoint()
        if scp_d is None:
            return None
        scp = load_signed_checkpoint(scp_d)
        local_gossip.add_checkpoint(scp)

        # attempt signed headers from checkpoint to peer signed tip if available: ask peer for tip hash by using their header tip
        # In reference: use peer0 tip_signed_header if exists.
        tip = None
        if self.peers:
            tsh = self.peers[0].gossip.tip_signed_header(self.chain_id)
            if tsh is not None:
                tip = tsh.header.block_hash
        if tip is not None:
            path = self.fetch_signed_headers(scp.checkpoint.block_hash, tip)
            for shd in path:
                local_gossip.add_signed_header(load_signed_header(shd))

        # snapshot
        if want_snapshot:
            return self.fetch_snapshot()
        return None
