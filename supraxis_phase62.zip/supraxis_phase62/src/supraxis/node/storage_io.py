from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional, Tuple
import json
import os
import hashlib
import time

def _sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()

def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with open(tmp, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)

def atomic_write_json(path: Path, obj: Any) -> bytes:
    raw = json.dumps(obj, indent=2, sort_keys=True).encode("utf-8")
    atomic_write_bytes(path, raw)
    return raw

def write_checksum(path: Path, raw: bytes) -> None:
    chk = {"sha256": _sha256_bytes(raw), "bytes": len(raw), "ts": time.time()}
    atomic_write_json(path.with_suffix(path.suffix + ".sha256.json"), chk)

def read_json_with_checksum(path: Path) -> Tuple[Optional[Any], str]:
    """Reads JSON, verifies checksum if sidecar exists."""
    if not path.exists():
        return None, "missing"
    raw = path.read_bytes()
    side = path.with_suffix(path.suffix + ".sha256.json")
    if side.exists():
        chk = json.loads(side.read_text(encoding="utf-8"))
        want = str(chk.get("sha256",""))
        got = _sha256_bytes(raw)
        if want and want != got:
            return None, "checksum_mismatch"
    try:
        return json.loads(raw.decode("utf-8")), "ok"
    except Exception:
        return None, "decode_error"
