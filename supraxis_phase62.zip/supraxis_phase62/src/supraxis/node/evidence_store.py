from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple, List
import time

from supraxis.consensus.evidence import Evidence, evidence_from_dict, verify_evidence

@dataclass
class EvidenceStore:
    by_hash: Dict[str, Evidence] = field(default_factory=dict)
    slashed: Dict[str, float] = field(default_factory=dict)  # pubkey -> ts

    def submit(self, ev_dict: dict) -> Tuple[bool,str,Optional[str]]:
        try:
            ev = evidence_from_dict(ev_dict)
        except Exception as e:
            return False, "bad_evidence", None

        ok, why, pk = verify_evidence(ev)
        if not ok:
            return False, f"invalid:{why}", None

        h = ev.hash_hex()
        if h in self.by_hash:
            return False, "duplicate", h

        self.by_hash[h] = ev
        if pk:
            self.slashed[pk] = time.time()
        return True, "ok", h

    def to_dict(self) -> dict:
        return {
            "evidence": {h: ev.to_dict() for h, ev in self.by_hash.items()},
            "slashed": dict(self.slashed),
        }

    @staticmethod
    def from_dict(d: dict) -> "EvidenceStore":
        es = EvidenceStore()
        evs = (d.get("evidence") or {})
        for h, evd in evs.items():
            try:
                es.by_hash[str(h)] = evidence_from_dict(evd)
            except Exception:
                continue
        es.slashed = {str(k): float(v) for k, v in (d.get("slashed") or {}).items()}
        return es
