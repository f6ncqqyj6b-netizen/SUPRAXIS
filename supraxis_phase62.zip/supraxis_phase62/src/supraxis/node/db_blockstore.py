from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from supraxis.node.db import NodeDB

@dataclass
class DBBlockStore:
    db: NodeDB

    def put(self, h: str, block_dict: dict) -> None:
        self.db.save_block(str(h), block_dict)

    def get_block(self, h: str) -> Optional[dict]:
        return self.db.load_block(str(h))

    def list_hashes(self) -> list[str]:
        # returns file stems like '<hash>' from '<hash>.json'
        return [x.replace('.json','') for x in self.db.list_block_files()]
