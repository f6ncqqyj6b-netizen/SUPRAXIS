from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Any, Dict
import json
import time

from supraxis.consensus.gossip import GossipStore
from supraxis.node.blockstore import BlockStore
from supraxis.node.storage_io import atomic_write_json, write_checksum, read_json_with_checksum

@dataclass
class NodeDB:
    """Disk persistence (hardened) for reference build.

    Layout:
      db/
        gossip.json (+ checksum)
        blocks.json (+ checksum)
        peers.json (+ checksum)
        evidence.json (+ checksum)
        governance.json (+ checksum)
        state.json (+ checksum)
        snapshots/
          snap_<id>.json (+ checksum)
        snapshot_latest.json (+ checksum)  -> { "id": "...", "path": "snapshots/snap_<id>.json" }

    Notes:
    - Writes are atomic (temp + rename).
    - Checksum sidecars detect corruption.
    """
    path: Path

    def _p(self, name: str) -> Path:
        self.path.mkdir(parents=True, exist_ok=True)
        return self.path / name

    # ---------- Gossip ----------
    def save_gossip(self, gossip: GossipStore) -> None:
        p = self._p("gossip.json")
        raw = atomic_write_json(p, gossip.to_dict())
        write_checksum(p, raw)

    def load_gossip(self) -> GossipStore:
        p = self._p("gossip.json")
        d, st = read_json_with_checksum(p)
        if d is None:
            return GossipStore()
        return GossipStore.from_dict(d)

    # ---------- Blocks ----------
    def save_blocks(self, store: BlockStore) -> None:
        p = self._p("blocks.json")
        raw = atomic_write_json(p, store.blocks)
        write_checksum(p, raw)

    def load_blocks(self) -> BlockStore:
        p = self._p("blocks.json")
        st = BlockStore()
        d, _ = read_json_with_checksum(p)
        if d is None:
            return st
        st.blocks = d
        return st

    # ---------- Peers ----------
    def save_block(self, block_hash: str, block: dict) -> None:
        p = self._p("blocks") / f"{str(block_hash)}.json"
        raw = atomic_write_json(p, block)
        write_checksum(p, raw)

    def load_block(self, block_hash: str):
        p = self._p("blocks") / f"{str(block_hash)}.json"
        d, _ = read_json_with_checksum(p)
        return d

    def list_block_files(self) -> list[str]:
        bdir = self._p("blocks")
        if not bdir.exists():
            return []
        return [fp.name for fp in sorted(bdir.glob('*.json'))]

    def save_peers(self, peers: dict) -> None:
        p = self._p("peers.json")
        raw = atomic_write_json(p, peers)
        write_checksum(p, raw)

    def load_peers(self) -> Optional[dict]:
        p = self._p("peers.json")
        d, _ = read_json_with_checksum(p)
        return d

    # ---------- Snapshots (versioned) ----------
    def save_snapshot(self, snapshot: dict, snapshot_id: Optional[str] = None) -> str:
        sid = snapshot_id or str(int(time.time()*1000))
        sp = self._p("snapshots") / f"snap_{sid}.json"
        sp.parent.mkdir(parents=True, exist_ok=True)
        raw = atomic_write_json(sp, snapshot)
        write_checksum(sp, raw)

        latest = self._p("snapshot_latest.json")
        raw2 = atomic_write_json(latest, {"id": sid, "path": str(sp.relative_to(self.path))})
        write_checksum(latest, raw2)
        return sid

    def load_snapshot(self, snapshot_id: str | None = None) -> Optional[dict]:
        # If snapshot_id provided, load that snapshot file; else load latest.
        if snapshot_id:
            sp = self._p("snapshots") / f"snap_{str(snapshot_id)}.json"
            snap, _ = read_json_with_checksum(sp)
            return snap
        latest = self._p("snapshot_latest.json")
        meta, _ = read_json_with_checksum(latest)
        if meta is None:
            return None
        rel = meta.get("path")
        if not rel:
            return None
        sp = self.path / rel
        snap, _ = read_json_with_checksum(sp)
        return snap

    def save_evidence(self, evidence: dict) -> None:
        p = self._p("evidence.json")
        raw = atomic_write_json(p, evidence)
        write_checksum(p, raw)

    def load_evidence(self) -> Optional[dict]:
        p = self._p("evidence.json")
        d, _ = read_json_with_checksum(p)
        return d


    # ---------- Governance ----------
    def save_governance(self, gov: dict) -> None:
        p = self._p("governance.json")
        raw = atomic_write_json(p, gov)
        write_checksum(p, raw)

    def load_governance(self) -> Optional[dict]:
        p = self._p("governance.json")
        d, _ = read_json_with_checksum(p)
        return d


    # ---------- State ----------
    def save_state(self, state: dict) -> None:
        p = self._p("state.json")
        raw = atomic_write_json(p, state)
        write_checksum(p, raw)

    def load_state(self) -> Optional[dict]:
        p = self._p("state.json")
        d, _ = read_json_with_checksum(p)
        return d
