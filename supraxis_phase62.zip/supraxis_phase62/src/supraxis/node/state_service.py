from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from supraxis.ledger_state import LedgerState, Account
from supraxis.node.db import NodeDB

@dataclass
class StateService:
    state: LedgerState
    db: Optional[NodeDB] = None

    def load_from_db(self) -> None:
        if self.db is None:
            return
        d = self.db.load_state()
        if not d:
            return
        self.state = LedgerState.from_snapshot(d)

    def persist(self) -> None:
        if self.db is None:
            return
        self.db.save_state(self.state.snapshot_dict())


    def clone_state(self) -> LedgerState:
        return self.state.clone()

    def restore_snapshot(self, snapshot: dict) -> tuple[bool, str]:
        """Restore state from snapshot dict after verifying state_root."""
        if not isinstance(snapshot, dict):
            return False, 'bad_snapshot'
        try:
            snap_state = snapshot.get('state') or {}
            sr = str(snapshot.get('state_root',''))
            st = LedgerState.from_snapshot(snap_state)
            if st.state_root() != sr:
                return False, 'bad_snapshot_state_root'
            self.state = st
            self.persist()
            return True, 'ok'
        except Exception:
            return False, 'restore_failed'

    def restore_snapshot_id(self, snapshot_id: str) -> tuple[bool, str]:
        if self.db is None:
            return False, 'no_db'
        snap = self.db.load_snapshot(str(snapshot_id))
        if not snap:
            return False, 'not_found'
        return self.restore_snapshot(snap)



    def create_snapshot(self) -> dict | None:
        if self.db is None:
            return None
        from supraxis.snapshot import make_snapshot
        snap = make_snapshot(self.state.height, self.state.snapshot_dict(), self.state.state_root())
        sid = self.db.save_snapshot(snap.to_dict(), snapshot_id=snap.id)
        snap.id = sid
        return snap.to_dict()
