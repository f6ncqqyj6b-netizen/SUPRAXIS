from __future__ import annotations
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from dataclasses import dataclass
from typing import Optional, Callable, Dict, Any, Tuple
from urllib.parse import urlparse, parse_qs
import threading

from supraxis.mempool import Mempool
from supraxis.node.blockstore import BlockStore
from supraxis.node.evidence_service import EvidenceService
from supraxis.node.governance_service import GovernanceService
from supraxis.node.state_service import StateService

@dataclass
class RPCContext:
    chain_id: int
    mempool: Optional[Mempool] = None
    blocks: Optional[BlockStore] = None
    evidence: Optional[EvidenceService] = None
    governance: Optional[GovernanceService] = None
    state: Optional[StateService] = None

def _json_response(handler: BaseHTTPRequestHandler, code: int, obj: Any) -> None:
    raw = json.dumps(obj, indent=2, sort_keys=True).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)

class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class RPCHandler(BaseHTTPRequestHandler):
    ctx: RPCContext = None  # type: ignore

    def log_message(self, fmt, *args):
        # quiet by default
        return

    def _read_json(self) -> Tuple[bool, Any]:
        try:
            n = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(n) if n > 0 else b"{}"
            return True, json.loads(raw.decode("utf-8"))
        except Exception as e:
            return False, {"error": "bad_json"}

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path.rstrip("/")
        qs = parse_qs(u.query)

        if path == "" or path == "/":
            return _json_response(self, 200, {"ok": True, "service": "supraxis_rpc", "chain_id": self.ctx.chain_id})

        if path == "/health":
            return _json_response(self, 200, {"ok": True, "chain_id": self.ctx.chain_id})

        if path == "/mempool":
            if self.ctx.mempool is None:
                return _json_response(self, 404, {"ok": False, "why": "no_mempool"})
            limit = int(qs.get("limit", ["100"])[0])
            txs = [tx.to_dict() for tx in self.ctx.mempool.top(limit=limit)]
            return _json_response(self, 200, {"ok": True, "size": self.ctx.mempool.size(), "txs": txs})

        if path.startswith("/block/"):
            if self.ctx.blocks is None:
                return _json_response(self, 404, {"ok": False, "why": "no_blockstore"})
            h = path.split("/block/")[1]
            b = self.ctx.blocks.get_block(h)
            if b is None:
                return _json_response(self, 404, {"ok": False, "why": "not_found"})
            return _json_response(self, 200, {"ok": True, "hash": h, "block": b})

        if path == "/evidence/status":
            if self.ctx.evidence is None:
                return _json_response(self, 404, {"ok": False, "why": "no_evidence"})
            pk = str(qs.get("pubkey", [""])[0])
            # reuse service handler logic
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.evidence.handle_status(Msg(P.REQ_EVIDENCE_STATUS, {"pubkey": pk})))
            return _json_response(self, 200, rsp.payload)


        if path == "/state/root":
            if self.ctx.state is None:
                return _json_response(self, 404, {"ok": False, "why": "no_state"})
            return _json_response(self, 200, {"ok": True, "height": self.ctx.state.state.height, "state_root": self.ctx.state.state.state_root()})

        if path == "/state/account":
            if self.ctx.state is None:
                return _json_response(self, 404, {"ok": False, "why": "no_state"})
            addr = str(qs.get("addr", [""])[0])
            a = self.ctx.state.state.get(addr)
            return _json_response(self, 200, {"ok": True, "addr": addr, "account": a.to_dict()})

        if path == "/governance/status":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            pid = str(qs.get("id", [""])[0])
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_status(Msg(P.REQ_GOV_STATUS, {"id": pid})))
            return _json_response(self, 200, rsp.payload)

        if path == "/snapshot/latest":
            if self.ctx.state is None or self.ctx.state.db is None:
                return _json_response(self, 404, {"ok": False, "why": "no_db"})
            snap = self.ctx.state.db.load_snapshot()
            if not snap:
                return _json_response(self, 404, {"ok": False, "why": "not_found"})
            return _json_response(self, 200, {"ok": True, "snapshot": snap})

        if path.startswith("/snapshot/") and path not in ("/snapshot/latest", "/snapshot/create", "/snapshot/restore"):
            if self.ctx.state is None or self.ctx.state.db is None:
                return _json_response(self, 404, {"ok": False, "why": "no_db"})
            sid = path.split("/snapshot/")[1]
            snap = self.ctx.state.db.load_snapshot(str(sid))
            if not snap:
                return _json_response(self, 404, {"ok": False, "why": "not_found"})
            return _json_response(self, 200, {"ok": True, "snapshot": snap})

        if path == "/sync/plan":
            if self.ctx.state is None or self.ctx.state.db is None:
                return _json_response(self, 404, {"ok": False, "why": "no_db"})
            snap = self.ctx.state.db.load_snapshot()
            snap_h = int(snap.get("height", 0)) if snap else 0
            # list blocks and include those with height > snap_h
            bdir = self.ctx.state.db._p("blocks")
            blocks = []
            if bdir.exists():
                for fp in sorted(bdir.glob("*.json")):
                    try:
                        import json as _json
                        b = _json.loads(fp.read_text(encoding="utf-8"))
                        if int(b.get("height", 0)) > snap_h:
                            blocks.append({"hash_file": fp.name, "height": int(b.get("height",0)), "parent_hash": b.get("parent_hash","")})
                    except Exception:
                        pass
            return _json_response(self, 200, {"ok": True, "snapshot": snap, "blocks_after_snapshot": blocks})

        return _json_response(self, 404, {"ok": False, "why": "unknown_path", "path": path})

    def do_POST(self):
        u = urlparse(self.path)
        path = u.path.rstrip("/")
        ok, body = self._read_json()
        if not ok:
            return _json_response(self, 400, body)

        if path == "/tx/submit":
            if self.ctx.mempool is None:
                return _json_response(self, 404, {"ok": False, "why": "no_mempool"})
            tx = body.get("tx") if isinstance(body, dict) else None
            if not isinstance(tx, dict):
                return _json_response(self, 400, {"ok": False, "why": "bad_tx"})
            ok2, why2, h = self.ctx.mempool.add_tx_dict(tx)
            code = 200 if ok2 else 400
            return _json_response(self, code, {"ok": ok2, "why": why2, "hash": h})

        if path == "/evidence/submit":
            if self.ctx.evidence is None:
                return _json_response(self, 404, {"ok": False, "why": "no_evidence"})
            ev = body.get("evidence") if isinstance(body, dict) else None
            if not isinstance(ev, dict):
                return _json_response(self, 400, {"ok": False, "why": "bad_evidence"})
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.evidence.handle_submit(Msg(P.REQ_EVIDENCE_SUBMIT, {"evidence": ev})))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        if path == "/governance/submit":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_submit(Msg(P.REQ_GOV_SUBMIT, body)))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        if path == "/governance/queue":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            pid = str(body.get("id",""))
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_queue(Msg(P.REQ_GOV_QUEUE, {"id": pid})))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        if path == "/governance/execute":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            pid = str(body.get("id",""))
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_execute(Msg(P.REQ_GOV_EXECUTE, {"id": pid})))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)


        if path == "/state/fund":
            if self.ctx.state is None:
                return _json_response(self, 404, {"ok": False, "why": "no_state"})
            addr = str(body.get("addr",""))
            amt = body.get("amount")
            if not isinstance(amt, int) or amt < 0 or addr == "":
                return _json_response(self, 400, {"ok": False, "why": "bad_request"})
            a = self.ctx.state.state.get(addr)
            a.balance += int(amt)
            self.ctx.state.persist()
            return _json_response(self, 200, {"ok": True, "addr": addr, "account": a.to_dict(), "state_root": self.ctx.state.state.state_root()})

        if path == "/state/apply_tx":
            if self.ctx.state is None:
                return _json_response(self, 404, {"ok": False, "why": "no_state"})
            tx = body.get("tx") if isinstance(body, dict) else None
            if not isinstance(tx, dict):
                return _json_response(self, 400, {"ok": False, "why": "bad_tx"})
            ok2, why2 = self.ctx.state.state.apply_tx_dict(tx)
            if ok2:
                self.ctx.state.persist()
            code = 200 if ok2 else 400
            return _json_response(self, code, {"ok": ok2, "why": why2, "state_root": self.ctx.state.state.state_root()})

        if path == "/snapshot/create":
            if self.ctx.state is None:
                return _json_response(self, 404, {"ok": False, "why": "no_state"})
            snap = self.ctx.state.create_snapshot()
            if not snap:
                return _json_response(self, 404, {"ok": False, "why": "no_db"})
            return _json_response(self, 200, {"ok": True, "snapshot": snap})

        if path == "/snapshot/restore":
            if self.ctx.state is None:
                return _json_response(self, 404, {"ok": False, "why": "no_state"})
            sid = str(body.get("id",""))
            snap = body.get("snapshot")
            if sid:
                ok3, why3 = self.ctx.state.restore_snapshot_id(sid)
                code = 200 if ok3 else 400
                return _json_response(self, code, {"ok": ok3, "why": why3})
            if isinstance(snap, dict):
                ok3, why3 = self.ctx.state.restore_snapshot(snap)
                code = 200 if ok3 else 400
                return _json_response(self, code, {"ok": ok3, "why": why3})
            return _json_response(self, 400, {"ok": False, "why": "bad_request"})

        if path == "/governance/emergency":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_emergency(Msg(P.REQ_GOV_EMERGENCY, body)))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        return _json_response(self, 404, {"ok": False, "why": "unknown_path", "path": path})

def start_rpc_server(host: str, port: int, ctx: RPCContext) -> Tuple[_ThreadingHTTPServer, threading.Thread]:
    def handler_factory(*args, **kwargs):
        h = RPCHandler(*args, **kwargs)
        return h

    # attach ctx on class (safe enough for single server)
    RPCHandler.ctx = ctx
    httpd = _ThreadingHTTPServer((host, int(port)), RPCHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd, t
