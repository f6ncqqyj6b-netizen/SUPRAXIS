from __future__ import annotations
from typing import Dict, Any, Tuple
from supraxis.sigverify import Signature, default_verifier

def _b(x: str) -> bytes:
    x = x or ""
    if x.startswith("0x"):
        x = x[2:]
    return bytes.fromhex(x) if x else b""

def verify_signed_message(scheme: int, pubkey_hex: str, sig_hex: str, msg_hex: str) -> bool:
    sig = Signature(int(scheme), _b(pubkey_hex), _b(sig_hex))
    msg = _b(msg_hex)
    return default_verifier().verify(sig, msg)

def verify_double_vote(e: Dict[str, Any]) -> Tuple[bool, str]:
    # Expect: scheme, pubkey, vote1_msg, vote1_sig, vote2_msg, vote2_sig
    req = ["scheme","pubkey","vote1_msg","vote1_sig","vote2_msg","vote2_sig"]
    for k in req:
        if k not in e:
            return False, f"missing {k}"
    if e["vote1_msg"] == e["vote2_msg"]:
        return False, "messages identical"
    ok1 = verify_signed_message(int(e["scheme"]), str(e["pubkey"]), str(e["vote1_sig"]), str(e["vote1_msg"]))
    ok2 = verify_signed_message(int(e["scheme"]), str(e["pubkey"]), str(e["vote2_sig"]), str(e["vote2_msg"]))
    if not (ok1 and ok2):
        return False, "invalid signature"
    return True, "ok"

def verify_equivocating_proposer(e: Dict[str, Any]) -> Tuple[bool, str]:
    # Expect: scheme, pubkey, prop1_msg, prop1_sig, prop2_msg, prop2_sig
    req = ["scheme","pubkey","prop1_msg","prop1_sig","prop2_msg","prop2_sig"]
    for k in req:
        if k not in e:
            return False, f"missing {k}"
    if e["prop1_msg"] == e["prop2_msg"]:
        return False, "messages identical"
    ok1 = verify_signed_message(int(e["scheme"]), str(e["pubkey"]), str(e["prop1_sig"]), str(e["prop1_msg"]))
    ok2 = verify_signed_message(int(e["scheme"]), str(e["pubkey"]), str(e["prop2_sig"]), str(e["prop2_msg"]))
    if not (ok1 and ok2):
        return False, "invalid signature"
    return True, "ok"
