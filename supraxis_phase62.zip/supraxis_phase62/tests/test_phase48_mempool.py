import unittest
import time

from supraxis.tx import make_tx, tx_from_dict
from supraxis.mempool import Mempool, MempoolPolicy
from supraxis.fees import FeeParams, estimate_fee

class TestPhase48(unittest.TestCase):
    def test_tx_hash_stable(self):
        d = make_tx(1, 0, "alice", "bob", "transfer", {"amt":1}, max_fee=10**9).to_dict()
        h1 = tx_from_dict(d).hash_hex()
        h2 = tx_from_dict(d).hash_hex()
        self.assertEqual(h1, h2)

    def test_fee_enforced(self):
        fp = FeeParams(base_fee=1000, per_byte_fee=1, per_param_fee=10, max_tx_bytes=50000)
        pol = MempoolPolicy(max_size=10, max_per_sender=10, max_age_sec=1000, fee_params=fp)
        mp = Mempool(chain_id=1, policy=pol)
        d = make_tx(1, 0, "alice", "bob", "transfer", {"amt":1}, max_fee=0).to_dict()
        ok, why, _ = mp.add_tx_dict(d)
        self.assertFalse(ok)
        self.assertEqual(why, "insufficient_max_fee")

        d2 = dict(d)
        d2["max_fee"] = estimate_fee(d2, fp) + 1000
        ok2, why2, h = mp.add_tx_dict(d2)
        self.assertTrue(ok2)
        self.assertIsNotNone(h)

    def test_eviction_low_fee(self):
        fp = FeeParams(base_fee=1, per_byte_fee=0, per_param_fee=0, max_tx_bytes=50000)
        pol = MempoolPolicy(max_size=1, max_per_sender=10, max_age_sec=1000, fee_params=fp)
        mp = Mempool(chain_id=1, policy=pol)

        d1 = make_tx(1, 0, "a", "b", "m", {}, max_fee=100).to_dict()
        ok1, _, h1 = mp.add_tx_dict(d1)
        self.assertTrue(ok1)
        # second tx with same fee policy but higher params count -> higher fee_required; should evict first
        d2 = make_tx(1, 1, "c", "d", "m", {"x":1, "y":2}, max_fee=100).to_dict()
        ok2, _, h2 = mp.add_tx_dict(d2)
        self.assertTrue(ok2)
        self.assertIsNone(mp.get(h1))
        self.assertIsNotNone(mp.get(h2))

    def test_expiry(self):
        fp = FeeParams(base_fee=1, per_byte_fee=0, per_param_fee=0, max_tx_bytes=50000)
        pol = MempoolPolicy(max_size=10, max_per_sender=10, max_age_sec=0, fee_params=fp)
        mp = Mempool(chain_id=1, policy=pol)
        d = make_tx(1, 0, "a", "b", "m", {}, max_fee=10).to_dict()
        ok, _, h = mp.add_tx_dict(d)
        self.assertTrue(ok)
        # immediately expired
        self.assertEqual(mp.size(), 0)

if __name__ == "__main__":
    unittest.main()
