import unittest, tempfile, json
from pathlib import Path
from urllib import request

from supraxis.node.db import NodeDB
from supraxis.node.state_service import StateService
from supraxis.ledger_state import LedgerState
from supraxis.rpc.server import RPCContext, start_rpc_server

class TestPhase61(unittest.TestCase):
    def test_snapshot_create_get_restore(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            stsvc = StateService(state=LedgerState(), db=db)
            stsvc.state.get("alice").balance = 9
            stsvc.persist()

            # create snapshot
            snap = stsvc.create_snapshot()
            self.assertTrue(snap and snap["id"])

            # mutate state
            stsvc.state.get("alice").balance = 0
            stsvc.persist()

            ok, why = stsvc.restore_snapshot_id(snap["id"])
            self.assertTrue(ok, why)
            self.assertEqual(stsvc.state.get("alice").balance, 9)

    def test_rpc_snapshot_latest(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            stsvc = StateService(state=LedgerState(), db=db)
            stsvc.state.get("alice").balance = 3
            stsvc.persist()
            stsvc.create_snapshot()

            ctx = RPCContext(chain_id=1, mempool=None, blocks=None, evidence=None, governance=None, state=stsvc)
            httpd, _t = start_rpc_server("127.0.0.1", 0, ctx)
            base = f"http://127.0.0.1:{httpd.server_port}"
            with request.urlopen(base + "/snapshot/latest", timeout=5) as r:
                obj = json.loads(r.read().decode("utf-8"))
            self.assertTrue(obj["ok"])
            self.assertEqual(obj["snapshot"]["state"]["accounts"]["alice"]["balance"], 3)
            httpd.shutdown(); httpd.server_close()

if __name__ == "__main__":
    unittest.main()
