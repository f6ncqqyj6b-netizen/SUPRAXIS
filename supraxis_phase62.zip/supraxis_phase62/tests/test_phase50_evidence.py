import unittest
import tempfile
from pathlib import Path
import asyncio

from supraxis.consensus import slashing
from supraxis.consensus.evidence import make_evidence, TYPE_DOUBLE_VOTE
from supraxis.node.evidence_store import EvidenceStore
from supraxis.node.evidence_service import EvidenceService
from supraxis.node.db import NodeDB
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P

class TestPhase50(unittest.IsolatedAsyncioTestCase):
    async def test_evidence_submit_and_persist(self):
        # monkeypatch signature verify to always true
        orig = slashing.verify_signed_message
        slashing.verify_signed_message = lambda scheme, pubkey_hex, sig_hex, msg_hex: True
        try:
            ev = make_evidence(TYPE_DOUBLE_VOTE, {
                "scheme": 1,
                "pubkey": "0x" + "11"*32,
                "vote1_msg": "0x" + "aa"*8,
                "vote1_sig": "0x" + "bb"*8,
                "vote2_msg": "0x" + "cc"*8,
                "vote2_sig": "0x" + "dd"*8,
            }).to_dict()

            with tempfile.TemporaryDirectory() as td:
                db = NodeDB(Path(td))
                store = EvidenceStore()
                svc = EvidenceService(store=store, db=db)
                rsp = await svc.handle_submit(Msg(P.REQ_EVIDENCE_SUBMIT, {"evidence": ev}))
                self.assertEqual(rsp.t, P.RSP_EVIDENCE)
                self.assertTrue(rsp.payload.get("ok"))
                pk = ev["data"]["pubkey"]
                self.assertTrue(pk in svc.store.slashed)

                # reload from db
                svc2 = EvidenceService(store=EvidenceStore(), db=db)
                svc2.load_from_db()
                self.assertTrue(pk in svc2.store.slashed)
        finally:
            slashing.verify_signed_message = orig

    async def test_invalid_evidence_rejected(self):
        store = EvidenceStore()
        ok, why, h = store.submit({"version": 1, "kind":"double_vote", "data": {}, "ts": 1})
        self.assertFalse(ok)

if __name__ == "__main__":
    unittest.main()
