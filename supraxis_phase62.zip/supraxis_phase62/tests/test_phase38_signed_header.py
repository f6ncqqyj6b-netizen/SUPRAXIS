import unittest
from supraxis.state import SupraxisState
from supraxis.consensus.types import QC
from supraxis.consensus.headerchain import Header
from supraxis.consensus.signed_header import SignedHeader, verify_signed_header, header_message
from supraxis.consensus.checkpoint import validators_hash
from supraxis.consensus.validator_set import validators_for_epoch, vmap
from supraxis.consensus.hotstuff import quorum_threshold
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign
from supraxis.consensus.vote_signing import SCHEME_ED25519

class TestPhase38(unittest.TestCase):
    def test_signed_header_quorum(self):
        st = SupraxisState()
        st.storage["epoch"] = 0
        k1 = ed25519_keygen(seed=b"\x01"*32)
        k2 = ed25519_keygen(seed=b"\x02"*32)
        v1 = "0x"+k1.public.hex()
        v2 = "0x"+k2.public.hex()
        st.storage["validators.epoch.0"] = [{"vid": v1, "power": 10}, {"vid": v2, "power": 10}]
        st.storage[f"validator.{v1}"] = {"vid": v1, "reward_address":"0x"+"aa"*32}
        st.storage[f"validator.{v2}"] = {"vid": v2, "reward_address":"0x"+"bb"*32}
        vh = validators_hash(st.storage["validators.epoch.0"])

        h = Header(chain_id=1, epoch=0, height=2, round=0, block_hash="02"*32, parent_hash="01"*32, proposer="p", validators_hash=vh, qc=None)
        msg = header_message(h)
        sh = SignedHeader(header=h, sigs={
            v1: {"scheme": SCHEME_ED25519, "sig": ed25519_sign(k1.private, msg)},
            v2: {"scheme": SCHEME_ED25519, "sig": ed25519_sign(k2.private, msg)},
        })

        vals = validators_for_epoch(st, 0)
        q = quorum_threshold(vals)
        ok, why, sp = verify_signed_header(sh, vmap(vals), q)
        self.assertTrue(ok)
        self.assertTrue(sp >= q)

if __name__ == "__main__":
    unittest.main()
