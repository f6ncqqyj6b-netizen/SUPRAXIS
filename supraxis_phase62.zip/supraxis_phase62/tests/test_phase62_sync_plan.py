import unittest, tempfile, json
from pathlib import Path
from urllib import request

from supraxis.node.db import NodeDB
from supraxis.node.state_service import StateService
from supraxis.ledger_state import LedgerState
from supraxis.rpc.server import RPCContext, start_rpc_server

class TestPhase62(unittest.TestCase):
    def test_sync_plan(self):
        with tempfile.TemporaryDirectory() as td:
            db = NodeDB(Path(td))
            stsvc = StateService(state=LedgerState(), db=db)
            stsvc.persist()
            stsvc.create_snapshot()
            # save fake block at height 2
            db.save_block("h2", {"height": 2, "parent_hash": "h1"})

            ctx = RPCContext(chain_id=1, mempool=None, blocks=None, evidence=None, governance=None, state=stsvc)
            httpd, _t = start_rpc_server("127.0.0.1", 0, ctx)
            base = f"http://127.0.0.1:{httpd.server_port}"
            with request.urlopen(base + "/sync/plan", timeout=5) as r:
                obj = json.loads(r.read().decode("utf-8"))
            self.assertTrue(obj["ok"])
            self.assertTrue(isinstance(obj["blocks_after_snapshot"], list))
            httpd.shutdown(); httpd.server_close()

if __name__ == "__main__":
    unittest.main()
