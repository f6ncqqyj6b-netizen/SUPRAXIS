import unittest
from supraxis.state import SupraxisState
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.crypto import sha256
from supraxis.sigverify import make_stub_signature

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class Phase26(unittest.TestCase):
    def _env(self, sender:int, nonce:int):
        payload=b'{"n":%d}'%nonce
        base = EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
            target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=1_000_000_000_000,
            payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[],
        )
        sig=make_stub_signature(1,b"pk_any", base.signing_message())
        return EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
            target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=1_000_000_000_000,
            payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[sig],
        )

    def test_state_commitment_emitted(self):
        st = SupraxisState()
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"EMIT","event":"HELLO","payload":{"x":1}},
            {"op":"RET"},
        ]})
        res = run_block(st, prog.functions, [self._env(1,1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(any(e["event"]=="STATE_COMMITMENT" for e in res.events))
        sc = [e for e in res.events if e["event"]=="STATE_COMMITMENT"][0]["payload"]
        self.assertIn("hash", sc)
        self.assertIn("snap", sc)

    def test_conservation_enforced_when_enabled(self):
        st = SupraxisState()
        gov = sha256(b"GOVERNANCE").hex()
        st.caps[gov] = {"scope":"global","chain":100,"expires":10**18}
        # Set supply total = 0 initially; enforce will require total_accounted equals 10 after mint-like credit
        st.credit("0x"+"01"*32, 10)
        total = st.total_accounted()
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"GOV_SET_SUPPLY","total":total,"enforce":1},
            {"op":"RET"},
        ]})
        res = run_block(st, prog.functions, [self._env(123,1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(any(e["event"]=="GOV_SUPPLY_SET" for e in res.events))

        # Now violate by crediting without adjusting supply.total, next block should fail
        st.credit("0x"+"02"*32, 1)
        prog2 = SirBinProgram(version=1, functions={"main":[
            {"op":"EMIT","event":"X","payload":{}},
            {"op":"RET"},
        ]})
        with self.assertRaises(Exception):
            run_block(st, prog2.functions, [self._env(5,2)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)

    def test_burn_category_mismatch_aborts(self):
        st = SupraxisState()
        st.burned = 5
        st.burned_fee = 4  # mismatch (should be 5 total across categories)
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"EMIT","event":"X","payload":{}},
            {"op":"RET"},
        ]})
        with self.assertRaises(Exception):
            run_block(st, prog.functions, [self._env(1,1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)

if __name__ == "__main__":
    unittest.main()
