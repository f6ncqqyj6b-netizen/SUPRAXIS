import unittest
from supraxis.state import SupraxisState
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.crypto import sha256
from supraxis.sigverify import make_stub_signature

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class Phase25(unittest.TestCase):
    def _env(self, sender:int, nonce:int):
        payload=b'{"n":%d}'%nonce
        base = EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
            target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=1_000_000_000_000,
            payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[],
        )
        sig=make_stub_signature(1,b"pk_any", base.signing_message())
        return EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
            target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=1_000_000_000_000,
            payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[sig],
        )

    def test_freeze_skips_batch_when_policy_enabled(self):
        st = SupraxisState()
        gov = sha256(b"GOVERNANCE").hex()
        st.caps[gov] = {"scope":"global","chain":100,"expires":10**18}
        st.insurance_pool = 100
        st.storage["insurance.max_payout"]=100
        st.storage["insurance.cooldown"]=0
        st.storage["insurance.claim_fee"]=0

        to=b32(1).hex()
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"INSURANCE_CLAIM","to":"0x"+to,"amount":20,"nonce":1,"tick":1},
            {"op":"RET"},
        ]})
        res = run_block(st, prog.functions, [self._env(9,1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        cid = [e["payload"]["claim_id"] for e in res.events if e["event"]=="CLAIM_SUBMITTED"][0]

        # freeze it
        prog2 = SirBinProgram(version=1, functions={"main":[
            {"op":"CLAIM_FREEZE","claim_id":"0x"+cid,"reason":"investigate"},
            {"op":"GOV_SET_CLAIMS_BATCH_POLICY","default_mode":"oldest","skip_frozen":1,"skip_disputed":0},
            {"op":"CLAIMS_BATCH_PAY","limit":10,"max_total":0,"tick":10},  # mode omitted uses default
            {"op":"RET"},
        ]})
        res2 = run_block(st, prog2.functions, [self._env(123,2)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        ev = [e for e in res2.events if e["event"]=="CLAIMS_BATCH_RESULT"][0]["payload"]
        self.assertEqual(ev["paid_count"], 0)
        self.assertEqual(st.balance_of(to), 0)

        # unfreeze and pay
        prog3 = SirBinProgram(version=1, functions={"main":[
            {"op":"CLAIM_UNFREEZE","claim_id":"0x"+cid},
            {"op":"CLAIMS_BATCH_PAY","limit":10,"max_total":0,"tick":11},
            {"op":"RET"},
        ]})
        res3 = run_block(st, prog3.functions, [self._env(123,3)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        ev3 = [e for e in res3.events if e["event"]=="CLAIMS_BATCH_RESULT"][0]["payload"]
        self.assertEqual(ev3["paid_count"], 1)
        self.assertEqual(st.balance_of(to), 20)

    def test_link_evidence_to_claim(self):
        st = SupraxisState()
        st.insurance_pool = 10
        st.storage["insurance.claim_fee"]=0
        to=b32(2).hex()
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"INSURANCE_CLAIM","to":"0x"+to,"amount":5,"nonce":1,"tick":1},
            {"op":"RET"},
        ]})
        res = run_block(st, prog.functions, [self._env(7,1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        cid = [e["payload"]["claim_id"] for e in res.events if e["event"]=="CLAIM_SUBMITTED"][0]
        evh = sha256(b"evidence").hex()

        prog2 = SirBinProgram(version=1, functions={"main":[
            {"op":"LINK_EVIDENCE_TO_CLAIM","claim_id":"0x"+cid,"evidence_hash":"0x"+evh,"tick":2},
            {"op":"RET"},
        ]})
        res2 = run_block(st, prog2.functions, [self._env(7,2)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(any(e["event"]=="EVIDENCE_LINKED" for e in res2.events))
        rec = st.storage.get("claim_evidence."+evh, None)
        self.assertIsNotNone(rec)
        self.assertEqual(rec["claim_id"], cid)

    def test_audit_reports_claim_counts(self):
        st = SupraxisState()
        st.insurance_pool = 10
        st.storage["insurance.claim_fee"]=0
        to=b32(3).hex()
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"INSURANCE_CLAIM","to":"0x"+to,"amount":5,"nonce":1,"tick":1},
            {"op":"AUDIT_INVARIANTS"},
            {"op":"RET"},
        ]})
        res = run_block(st, prog.functions, [self._env(7,3)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        inv = [e["payload"] for e in res.events if e["event"]=="AUDIT_INVARIANTS"][0]
        self.assertEqual(inv["claims_pending"], 1)
        self.assertEqual(inv["pending_sum"], 5)

if __name__ == "__main__":
    unittest.main()
