# Phase 28 — P2P Gossip + Mempool + Deterministic Ordering (Spec + Reference Scaffolding)

This phase adds a **reference networking/mempool layer** suitable for a sovereign L1.

> Scope: message formats, mempool rules, deterministic ordering, and a local gossip simulator.
> Actual sockets/libp2p integration is deferred (same interfaces can be swapped later).

---

## Goals

- Deterministic transaction ordering (critical for replayability and consensus safety).
- Basic anti-spam rules and per-peer rate limiting hooks.
- Gossip semantics for:
  - tx (envelopes)
  - proposals
  - votes
  - QCs/TCs
- Clean interfaces to feed consensus (Phase 27).

---

## Transaction Identity

A transaction is a Supraxis Envelope (v2) serialized deterministically.

`tx_id = sha256(envelope.signing_message())`

Nodes MUST treat `tx_id` as the canonical transaction key.

---

## Mempool Admission Rules (Minimal)

Reject if:
- tx_id already in mempool or already in chain
- gas_limit <= 0 or above configured max
- missing required signatures (policy)
- nonce too old (optional future)
- exceeds per-sender pending cap (default 256)

Accept if passes rules, then store in sender-queue.

---

## Deterministic Ordering

To guarantee all nodes propose the same ordering given the same mempool view:

Sort key:
1. `sender` (origin_sender hex) ascending
2. `nonce` ascending
3. `tx_id` ascending (tie-break)

Block assembly:
- Round-robin over senders in sorted order
- Take up to `max_txs_per_block`, respecting `max_gas_per_block`
- This reduces “sender starvation” and keeps ordering deterministic.

---

## Gossip Protocol (Abstract)

Message types:
- `TX_ANNOUNCE {tx_id}`
- `TX_REQUEST {tx_id}`
- `TX_PAYLOAD {envelope}`
- `BLOCK_PROPOSAL {proposal}`
- `VOTE {vote}`
- `QC {qc}`
- `TIMEOUT {timeout}`
- `TC {tc}`

Peers may announce tx ids first, request payloads on demand.

---

## What Phase 28 Provides

- `supraxis.net.mempool` deterministic mempool + ordering
- `supraxis.net.gossip` in-memory gossip simulator (deterministic)
- `supraxis.net.messages` typed message envelopes
- Unit tests verifying deterministic ordering and dedup behavior

Next:
- Phase 29 will replace signature stubs with production crypto and define canonical signature encoding.
