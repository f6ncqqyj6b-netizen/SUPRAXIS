import unittest
from supraxis.state import SupraxisState
from supraxis.crypto import sha256
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.canonical import bitset_len, bitset_set

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class AutoSlashDoubleSignTests(unittest.TestCase):
    def test_double_sign_same_nonce_slashes_quorum_signers(self):
        st = SupraxisState()
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global","chain":100,"expires":10**18}

        # 1) Create stake + committee from stake for epoch 7 (v2 governance envelope)
        functions = {"main":[
            {"op":"GOV_STAKE","pubkey":"0x706b31","amount":4,"lock_epochs":0},
            {"op":"GOV_STAKE","pubkey":"0x706b32","amount":3,"lock_epochs":0},
            {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE","epoch":7,"size":2},
            {"op":"RET"},
        ]}
        prog = SirBinProgram(version=1, functions=functions)
        payload=b'{"gov":1}'
        envg_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[])
        sigg=make_stub_signature(1,b"pk_gov", envg_base.signing_message())
        envg=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[sigg])
        run_block(st, prog.functions, [envg], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))

        cid = st.committee_registry["7"]
        cid_bytes = bytes.fromhex(cid)
        committee = st.get_committee_by_id(cid)
        assert committee is not None

        # 2) Create two v3 envelopes with same nonce=2 but different payload_hash
        prog2 = SirBinProgram(version=1, functions={"main":[{"op":"RET"}]})

        payloadA=b'{"A":1}'
        phA=sha256(payloadA)
        baseA=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloadA,phA,[],[],None)
        msgA=baseA.signing_message()

        payloadB=b'{"B":2}'
        phB=sha256(payloadB)
        baseB=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloadB,phB,[],[],None)
        msgB=baseB.signing_message()

        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)

        # Sign both with same quorum participants (bitmap both set)
        s0A=make_stub_signature(1,b"pk1",msgA)
        s1A=make_stub_signature(1,b"pk2",msgA)
        qpA=QuorumProofV1(bytes(bm), [Signature(s0A.scheme,b"",s0A.sig), Signature(s1A.scheme,b"",s1A.sig)])
        envA=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloadA,phA,[],[],qpA)

        s0B=make_stub_signature(1,b"pk1",msgB)
        s1B=make_stub_signature(1,b"pk2",msgB)
        qpB=QuorumProofV1(bytes(bm), [Signature(s0B.scheme,b"",s0B.sig), Signature(s1B.scheme,b"",s1B.sig)])
        envB=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloadB,phB,[],[],qpB)

        # Run block with A then B: B should trigger auto slash and be skipped.
        res = run_block(st, prog2.functions, [envA, envB], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7), auto_slash=True)
        # Stakes should reduce by default slash.double_sign=1 for each signer
        amt1,_ = st.stake_of("0x706b31")
        amt2,_ = st.stake_of("0x706b32")
        self.assertEqual(amt1, 3)
        self.assertEqual(amt2, 2)

        # Ensure slash events present
        slash_events = [e for e in res.events if e["event"]=="AUTO_SLASH_DOUBLE_SIGN"]
        self.assertEqual(len(slash_events), 2)

if __name__ == "__main__":
    unittest.main()
