import unittest
from supraxis.state import SupraxisState
from supraxis.crypto import sha256
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.canonical import bitset_len, bitset_set

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class AutoSlashBadQuorumTests(unittest.TestCase):
    def test_bad_quorum_proof_slashes_claimed_signers(self):
        st = SupraxisState()
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global","chain":100,"expires":10**18}

        # Governance: stake + committee epoch 7
        functions = {"main":[
            {"op":"GOV_STAKE","pubkey":"0x706b31","amount":4,"lock_epochs":0},
            {"op":"GOV_STAKE","pubkey":"0x706b32","amount":3,"lock_epochs":0},
            {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE","epoch":7,"size":2},
            {"op":"RET"},
        ]}
        prog = SirBinProgram(version=1, functions=functions)
        payload=b'{"gov":1}'
        envg_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[])
        sigg=make_stub_signature(1,b"pk_gov", envg_base.signing_message())
        envg=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[sigg])
        run_block(st, prog.functions, [envg], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))

        cid = st.committee_registry["7"]
        cid_bytes = bytes.fromhex(cid)
        committee = st.get_committee_by_id(cid)
        assert committee is not None

        # Build v3 envelope with quorum bitmap for both, but corrupt signatures so validation fails
        prog2 = SirBinProgram(version=1, functions={"main":[{"op":"RET"}]})
        payload2=b'{"v3":1}'
        ph2=sha256(payload2)
        base=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payload2,ph2,[],[],None)
        msg=base.signing_message()

        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)

        s0=make_stub_signature(1,b"pk1",msg)
        s1=make_stub_signature(1,b"pk2",msg)

        # Corrupt signature bytes
        bad0 = Signature(s0.scheme, b"", s0.sig[:-1] + bytes([ (s0.sig[-1] + 1) % 256 ]))
        bad1 = Signature(s1.scheme, b"", s1.sig[:-1] + bytes([ (s1.sig[-1] + 2) % 256 ]))
        qp=QuorumProofV1(bytes(bm), [bad0, bad1])
        env=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payload2,ph2,[],[],qp)

        # Should auto-slash (default 1 each) and skip execution (no exception)
        res = run_block(st, prog2.functions, [env], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7), auto_slash=True)

        amt1,_ = st.stake_of("0x706b31")
        amt2,_ = st.stake_of("0x706b32")
        self.assertEqual(amt1, 3)
        self.assertEqual(amt2, 2)

        slash_events = [e for e in res.events if e["event"]=="AUTO_SLASH_BAD_QUORUM"]
        self.assertEqual(len(slash_events), 2)

if __name__ == "__main__":
    unittest.main()
