import unittest
from supraxis.state import SupraxisState
from supraxis.committee import Committee
from supraxis.envelope import EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.crypto import sha256
from supraxis.canonical import bitset_len, bitset_set
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class StateDrivenCommitteeLookupTests(unittest.TestCase):
    def test_v3_quorum_validates_with_committee_from_state(self):
        committee = Committee.from_dict({
            "members":[
                {"pubkey":"0x706b31","weight":4,"schemes":[1]},
                {"pubkey":"0x706b32","weight":3,"schemes":[1]},
            ]
        })
        cid_hex = committee.committee_id()
        cid = bytes.fromhex(cid_hex)

        payload=b'{"s":12}'
        ph=sha256(payload)
        base = EnvelopeV3(3, 7, cid, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [], None)
        msg=base.signing_message()

        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)
        s0=make_stub_signature(1,b"pk1",msg)
        s1=make_stub_signature(1,b"pk2",msg)
        qp = QuorumProofV1(bytes(bm), [Signature(s0.scheme,b"",s0.sig), Signature(s1.scheme,b"",s1.sig)])
        env = EnvelopeV3(3, 7, cid, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [], qp)

        st = SupraxisState()
        # register JSON so committee is stored
        st.register_committee_json(7, committee.canonical_json())
        prog = SirBinProgram(version=1, functions={"main":[{"op":"RET"}]})

        # Provide policy WITHOUT committee: block should attach from state and succeed
        run_block(st, prog.functions, [env], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7))

if __name__ == "__main__":
    unittest.main()
