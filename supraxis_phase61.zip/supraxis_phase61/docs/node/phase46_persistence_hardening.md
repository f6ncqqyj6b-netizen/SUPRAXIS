# Phase 46 — Persistence Hardening (Atomic Writes, Corruption Checks, Snapshot Versioning)

This phase hardens disk persistence so a node can recover safely after crashes or partial writes.

## Additions

### Atomic + Checksummed IO
`src/supraxis/node/storage_io.py`
- `atomic_write_bytes`: temp file + fsync + rename
- `atomic_write_json`: deterministic JSON write
- checksum sidecar: `<file>.sha256.json`
- `read_json_with_checksum`: verifies checksum when present

### Versioned Snapshots
`src/supraxis/node/db.py`
- snapshots stored in `snapshots/snap_<id>.json`
- `snapshot_latest.json` points to current snapshot
- both snapshot and pointer are checksummed and written atomically

## Next
Phase 47: snapshot chunking + verification + state-sync improvements.
