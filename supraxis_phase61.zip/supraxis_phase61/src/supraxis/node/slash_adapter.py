from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from supraxis.node.evidence_store import EvidenceStore
from supraxis.consensus.stake_accounting import StakeSet

@dataclass
class SlashingAdapter:
    evidence: EvidenceStore
    vset: StakeSet

    def apply_new_slashes(self) -> int:
        count = 0
        for pk in list(self.evidence.slashed.keys()):
            ok, _ = self.vset.slash(pk)
            if ok:
                count += 1
        return count
