from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, List

from supraxis.mempool import Mempool
from supraxis.node.state_service import StateService
from supraxis.ledger_state import LedgerState
from supraxis.netblock import NetBlock as Block, make_netblock as make_block, make_netblock_with_root as make_block_with_root, netblock_from_dict as block_from_dict, validate_netblock_dict as validate_block_dict

GENESIS_PARENT = "0"*64

@dataclass
class BuildParams:
    max_txs: int = 2000

class BlockBuilder:
    def __init__(self, chain_id: int, proposer: str, mempool: Mempool, state: Optional[StateService] = None, params: Optional[BuildParams] = None):
        self.chain_id = int(chain_id)
        self.proposer = str(proposer)
        self.mempool = mempool
        self.state = state
        self.params = params or BuildParams()

    def build(self, height: int, parent_hash: str) -> Block:
        txs = [tx.to_dict() for tx in self.mempool.top(limit=int(self.params.max_txs))]
        if self.state is None:
            return make_block(self.chain_id, int(height), str(parent_hash), self.proposer, txs)
        # compute state_root on a cloned state (deterministic)
        st = self.state.clone_state()
        st.height = int(height)
        st.apply_txs(txs)
        root = st.state_root()
        return make_block_with_root(self.chain_id, int(height), str(parent_hash), self.proposer, txs, root)

    def accept_block(self, block_dict: dict) -> Tuple[bool,str,str]:
        ok, why = validate_block_dict(block_dict)
        if not ok:
            return False, why, ""
        if int(block_dict["chain_id"]) != self.chain_id:
            return False, "wrong_chain", ""
        b = block_from_dict(block_dict)
        # verify state_root if state service is present
        if self.state is not None:
            st = self.state.clone_state()
            st.height = int(b.height)
            st.apply_txs(list(b.txs))
            exp = st.state_root()
            if str(b.state_root) != str(exp):
                return False, "bad_state_root", ""
            # apply to real state and persist
            self.state.state.height = int(b.height)
            self.state.state.apply_txs(list(b.txs))
            self.state.persist()
        h = b.hash_hex()
        # remove txs included from mempool
        for txd in b.txs:
            try:
                # stable hash
                from supraxis.tx import tx_from_dict
                th = tx_from_dict(txd).hash_hex()
                self.mempool.remove(th)
            except Exception:
                pass
        return True, "ok", h
