from __future__ import annotations
from typing import Any
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

def storage_root(storage: dict) -> str:
    return sha256(canonical_json(storage)).hex()

def apply_block(state: Any, block: Any) -> None:
    # If runtime tx executor exists:
    rt = getattr(state, "runtime", None)
    txs = getattr(block, "txs", None) or getattr(block, "transactions", None) or []
    if rt is not None and hasattr(rt, "execute_tx"):
        for tx in list(txs):
            rt.execute_tx(state, tx)
    else:
        # fallback: if tx is dict with key/value writes, apply them
        for tx in list(txs):
            if isinstance(tx, dict) and "put" in tx and isinstance(tx["put"], dict):
                for k,v in tx["put"].items():
                    state.storage[str(k)] = v

    # update state root cached attribute
    state._state_root = storage_root(state.storage)

def ensure_state_has_executor(state: Any) -> None:
    if not hasattr(state, "apply_block"):
        setattr(state, "apply_block", lambda b: apply_block(state, b))
    if not hasattr(state, "storage_root"):
        setattr(state, "storage_root", lambda : storage_root(state.storage))
    if not hasattr(state, "state_root"):
        setattr(state, "state_root", lambda : getattr(state, "_state_root", storage_root(state.storage)))
