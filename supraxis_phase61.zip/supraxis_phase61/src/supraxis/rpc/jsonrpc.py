from __future__ import annotations
import json, time
from typing import Dict, Any, Callable

class RateLimiter:
    def __init__(self, max_per_sec: float = 50.0):
        self.max = max_per_sec
        self.tokens = max_per_sec
        self.last = time.time()

    def allow(self) -> bool:
        now = time.time()
        dt = now - self.last
        self.last = now
        self.tokens = min(self.max, self.tokens + dt * self.max)
        if self.tokens >= 1.0:
            self.tokens -= 1.0
            return True
        return False

class JSONRPCServer:
    def __init__(self, methods: Dict[str, Callable], auth_token: str | None = None):
        self.methods = methods
        self.auth_token = auth_token
        self.limiter = RateLimiter()

    def handle(self, body: Dict[str, Any], headers: Dict[str,str]) -> Dict[str, Any]:
        if not self.limiter.allow():
            return self._error(None, -32000, "rate_limited")

        if self.auth_token:
            tok = headers.get("Authorization","").replace("Bearer ","")
            if tok != self.auth_token:
                return self._error(None, -32001, "unauthorized")

        if body.get("jsonrpc") != "2.0":
            return self._error(body.get("id"), -32600, "invalid_request")

        method = body.get("method")
        params = body.get("params", {})
        mid = body.get("id")

        if method not in self.methods:
            return self._error(mid, -32601, "method_not_found")

        try:
            result = self.methods[method](params)
            return {"jsonrpc":"2.0","result":result,"id":mid}
        except Exception as e:
            return self._error(mid, -32099, str(e))

    def _error(self, id_, code, msg):
        return {"jsonrpc":"2.0","error":{"code":code,"message":msg},"id":id_}
