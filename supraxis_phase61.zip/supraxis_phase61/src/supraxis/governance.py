from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, Tuple, List
import time

from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

GOV_VERSION = 1
PROPOSAL_VERSION = 1

KIND_PARAM_CHANGE = "param_change"
KIND_UPGRADE = "upgrade"
KIND_EMERGENCY = "emergency"

STATUS_PENDING = "pending"
STATUS_QUEUED = "queued"
STATUS_EXECUTED = "executed"
STATUS_CANCELED = "canceled"
STATUS_EXPIRED = "expired"

@dataclass(frozen=True)
class GovParams:
    timelock_sec: int = 3600            # delay between queue and execute
    voting_period_sec: int = 3600       # placeholder for later
    grace_period_sec: int = 3600        # after timelock before expiration
    guardian_pubkeys: List[str] = field(default_factory=list)  # emergency brake keys
    min_guardians: int = 1
    allow_upgrade: bool = True

@dataclass(frozen=True)
class Proposal:
    version: int
    kind: str
    title: str
    payload: Dict[str, Any]
    proposer: str
    created_ts: int
    id: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": int(self.version),
            "kind": str(self.kind),
            "title": str(self.title),
            "payload": dict(self.payload),
            "proposer": str(self.proposer),
            "created_ts": int(self.created_ts),
            "id": str(self.id),
        }

def proposal_id(kind: str, title: str, payload: Dict[str, Any], proposer: str, created_ts: int) -> str:
    d = {"kind": kind, "title": title, "payload": payload, "proposer": proposer, "created_ts": int(created_ts)}
    return sha256(canonical_json(d)).hex()

def make_proposal(kind: str, title: str, payload: Dict[str, Any], proposer: str, created_ts: Optional[int]=None) -> Proposal:
    ts = int(created_ts or time.time())
    pid = proposal_id(kind, title, payload, proposer, ts)
    return Proposal(version=PROPOSAL_VERSION, kind=kind, title=title, payload=dict(payload), proposer=proposer, created_ts=ts, id=pid)

@dataclass
class GovState:
    params: GovParams = field(default_factory=GovParams)
    proposals: Dict[str, dict] = field(default_factory=dict)  # id -> record
    emergency_halt: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": GOV_VERSION,
            "params": {
                "timelock_sec": self.params.timelock_sec,
                "voting_period_sec": self.params.voting_period_sec,
                "grace_period_sec": self.params.grace_period_sec,
                "guardian_pubkeys": list(self.params.guardian_pubkeys),
                "min_guardians": self.params.min_guardians,
                "allow_upgrade": self.params.allow_upgrade,
            },
            "proposals": dict(self.proposals),
            "emergency_halt": bool(self.emergency_halt),
        }

    @staticmethod
    def from_dict(d: dict) -> "GovState":
        gs = GovState()
        p = d.get("params") or {}
        gs.params = GovParams(
            timelock_sec=int(p.get("timelock_sec", 3600)),
            voting_period_sec=int(p.get("voting_period_sec", 3600)),
            grace_period_sec=int(p.get("grace_period_sec", 3600)),
            guardian_pubkeys=[str(x) for x in (p.get("guardian_pubkeys") or [])],
            min_guardians=int(p.get("min_guardians", 1)),
            allow_upgrade=bool(p.get("allow_upgrade", True)),
        )
        gs.proposals = dict(d.get("proposals") or {})
        gs.emergency_halt = bool(d.get("emergency_halt", False))
        return gs

class GovernanceEngine:
    def __init__(self, state: Optional[GovState] = None):
        self.state = state or GovState()

    def submit(self, prop: Proposal) -> Tuple[bool,str]:
        if self.state.emergency_halt and prop.kind != KIND_EMERGENCY:
            return False, "halted"
        if prop.kind == KIND_UPGRADE and not self.state.params.allow_upgrade:
            return False, "upgrade_disabled"
        if prop.id in self.state.proposals:
            return False, "duplicate"
        self.state.proposals[prop.id] = {
            "proposal": prop.to_dict(),
            "status": STATUS_PENDING,
            "queued_ts": None,
            "executed_ts": None,
            "canceled_ts": None,
        }
        return True, "ok"

    def queue(self, pid: str, now: Optional[int]=None) -> Tuple[bool,str]:
        nowi = int(now or time.time())
        rec = self.state.proposals.get(pid)
        if not rec:
            return False, "missing"
        if rec["status"] != STATUS_PENDING:
            return False, "bad_status"
        rec["status"] = STATUS_QUEUED
        rec["queued_ts"] = nowi
        return True, "ok"

    def can_execute(self, pid: str, now: Optional[int]=None) -> Tuple[bool,str]:
        nowi = int(now or time.time())
        rec = self.state.proposals.get(pid)
        if not rec:
            return False, "missing"
        if rec["status"] != STATUS_QUEUED:
            return False, "bad_status"
        q = int(rec["queued_ts"] or 0)
        if nowi < q + int(self.state.params.timelock_sec):
            return False, "timelocked"
        if nowi > q + int(self.state.params.timelock_sec) + int(self.state.params.grace_period_sec):
            rec["status"] = STATUS_EXPIRED
            return False, "expired"
        return True, "ok"

    def execute(self, pid: str, now: Optional[int]=None) -> Tuple[bool,str,Optional[dict]]:
        ok, why = self.can_execute(pid, now=now)
        if not ok:
            return False, why, None
        rec = self.state.proposals[pid]
        prop = rec["proposal"]
        # NOTE: execution effects are applied by a separate host chain adapter; we return payload.
        rec["status"] = STATUS_EXECUTED
        rec["executed_ts"] = int(now or time.time())
        return True, "ok", prop

    def cancel(self, pid: str) -> Tuple[bool,str]:
        rec = self.state.proposals.get(pid)
        if not rec:
            return False, "missing"
        if rec["status"] in (STATUS_EXECUTED, STATUS_CANCELED):
            return False, "bad_status"
        rec["status"] = STATUS_CANCELED
        rec["canceled_ts"] = int(time.time())
        return True, "ok"

    def emergency_halt(self, guardians: List[str]) -> Tuple[bool,str]:
        # simple threshold check (signature checks in later phases)
        uniq = sorted(set([str(x) for x in guardians if str(x) in set(self.state.params.guardian_pubkeys)]))
        if len(uniq) < int(self.state.params.min_guardians):
            return False, "insufficient_guardians"
        self.state.emergency_halt = True
        return True, "halted"

    def emergency_resume(self, guardians: List[str]) -> Tuple[bool,str]:
        uniq = sorted(set([str(x) for x in guardians if str(x) in set(self.state.params.guardian_pubkeys)]))
        if len(uniq) < int(self.state.params.min_guardians):
            return False, "insufficient_guardians"
        self.state.emergency_halt = False
        return True, "resumed"
