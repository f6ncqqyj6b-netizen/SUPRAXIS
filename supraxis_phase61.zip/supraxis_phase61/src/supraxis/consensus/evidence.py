from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Tuple, Optional, List
import time

from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from supraxis.consensus import slashing

EVIDENCE_VERSION = 1
TYPE_DOUBLE_VOTE = "double_vote"
TYPE_EQUIVOCATING_PROPOSER = "equivocating_proposer"

@dataclass(frozen=True)
class Evidence:
    version: int
    kind: str
    data: Dict[str, Any]
    ts: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": int(self.version),
            "kind": str(self.kind),
            "data": dict(self.data),
            "ts": int(self.ts),
        }

    def hash_hex(self) -> str:
        return sha256(canonical_json(self.to_dict())).hex()

def validate_evidence_dict(d: Dict[str, Any]) -> Tuple[bool,str]:
    try:
        if int(d.get("version")) != EVIDENCE_VERSION:
            return False, "bad_version"
        if not isinstance(d.get("kind"), str) or d["kind"] not in (TYPE_DOUBLE_VOTE, TYPE_EQUIVOCATING_PROPOSER):
            return False, "bad_kind"
        if not isinstance(d.get("data"), dict):
            return False, "bad_data"
        if not isinstance(d.get("ts"), int) or int(d["ts"]) <= 0:
            return False, "bad_ts"
        return True, "ok"
    except Exception:
        return False, "exception"

def evidence_from_dict(d: Dict[str, Any]) -> Evidence:
    ok, why = validate_evidence_dict(d)
    if not ok:
        raise ValueError(why)
    return Evidence(version=int(d["version"]), kind=str(d["kind"]), data=dict(d["data"]), ts=int(d["ts"]))

def verify_evidence(ev: Evidence) -> Tuple[bool,str,Optional[str]]:
    """Returns (ok, why, pubkey_hex_if_any)."""
    if ev.kind == TYPE_DOUBLE_VOTE:
        ok, why = slashing.verify_double_vote(ev.data)
        pk = str(ev.data.get("pubkey","")) if ok else None
        return ok, why, pk
    if ev.kind == TYPE_EQUIVOCATING_PROPOSER:
        ok, why = slashing.verify_equivocating_proposer(ev.data)
        pk = str(ev.data.get("pubkey","")) if ok else None
        return ok, why, pk
    return False, "unknown_kind", None

def make_evidence(kind: str, data: Dict[str, Any]) -> Evidence:
    return Evidence(version=EVIDENCE_VERSION, kind=str(kind), data=dict(data), ts=int(time.time()))
