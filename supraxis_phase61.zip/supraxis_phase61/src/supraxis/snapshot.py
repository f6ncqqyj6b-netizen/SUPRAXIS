from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any
import time

from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

@dataclass
class Snapshot:
    id: str
    height: int
    state: Dict[str, Any]
    state_root: str
    ts: int

    def to_dict(self) -> dict:
        return {
            "id": str(self.id),
            "height": int(self.height),
            "state": self.state,
            "state_root": str(self.state_root),
            "ts": int(self.ts),
        }

def make_snapshot(height: int, state: Dict[str, Any], state_root: str) -> Snapshot:
    ts = int(time.time())
    sid = sha256(canonical_json({"height": int(height), "state_root": str(state_root), "ts": ts})).hex()[:16]
    return Snapshot(id=sid, height=int(height), state=state, state_root=str(state_root), ts=ts)
