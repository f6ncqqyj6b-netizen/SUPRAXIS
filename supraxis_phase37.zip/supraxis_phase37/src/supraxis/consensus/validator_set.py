from __future__ import annotations
from typing import List, Dict, Optional
from supraxis.state import SupraxisState
from .types import Validator

def _norm_vid(v: str) -> str:
    v = str(v)
    return v if v.startswith("0x") else "0x"+v

def validators_for_epoch(state: SupraxisState, epoch: Optional[int]=None) -> List[Validator]:
    """Return validator set for a given epoch.

    If epoch is None, uses state.storage['epoch'].
    If the exact epoch snapshot is missing, falls back to the previous epoch snapshot.
    """
    if epoch is None:
        epoch = int(state.storage.get("epoch", 0))

    snap = state.storage.get(f"validators.epoch.{int(epoch)}")
    if snap is None and int(epoch) > 0:
        snap = state.storage.get(f"validators.epoch.{int(epoch)-1}")

    if snap is None:
        return []

    out: List[Validator] = []
    for r in list(snap):
        vid = _norm_vid(r.get("vid", ""))
        power = int(r.get("power", 0))
        if vid and power > 0:
            out.append(Validator(vid=vid, power=power))

    out.sort(key=lambda x: x.vid)
    return out

def vmap(validators: List[Validator]) -> Dict[str, Validator]:
    return {v.vid: v for v in validators}
