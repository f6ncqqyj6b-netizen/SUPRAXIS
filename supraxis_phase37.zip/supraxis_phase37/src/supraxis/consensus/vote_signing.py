from __future__ import annotations
from typing import Tuple
from supraxis.canonjson import canonical_json
from supraxis.sigverify import Signature, default_verifier

def vote_message(chain_id: int, height: int, round: int, block_hash: str) -> bytes:
    """Domain-separated vote message bytes."""
    payload = {
        "t":"SUPRAXIS_VOTE_V1",
        "chain_id": int(chain_id),
        "height": int(height),
        "round": int(round),
        "block_hash": str(block_hash),
    }
    return b"SUPRAXIS|VOTE|V1|" + canonical_json(payload)

def _bhex(x: str) -> bytes:
    x = str(x)
    if x.startswith("0x"):
        x = x[2:]
    return bytes.fromhex(x) if x else b""

def infer_scheme(sig_bytes: bytes) -> int:
    # Reference: if 64 bytes -> Ed25519; else fallback to Ed25519 unless explicitly wrapped elsewhere.
    return 11 if len(sig_bytes) == 64 else 11

def verify_vote_sig(voter_vid: str, sig_bytes: bytes, msg: bytes) -> bool:
    scheme = infer_scheme(sig_bytes)
    sig = Signature(scheme=scheme, pubkey=_bhex(voter_vid), sig=sig_bytes)
    return default_verifier().verify(sig, msg)
