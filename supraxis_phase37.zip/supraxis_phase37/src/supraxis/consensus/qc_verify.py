from __future__ import annotations
from typing import Dict, Tuple, Any
from .types import QC, Validator
from .vote_signing import vote_message, verify_vote_sig

def verify_qc_crypto(qc: QC, vmap: Dict[str, Validator], quorum_power: int, chain_id: int) -> Tuple[bool,str,int]:
    """Cryptographic QC verification (reference: Ed25519 only, inferred by sig length).

    QC format: qc.sigs is Dict[voter_vid -> bytes(signature)].
    Verification:
    - voter must be in validator set
    - signature must verify over SUPRAXIS_VOTE_V1 message
    - signed power sum must reach quorum_power
    Returns (ok, reason, signed_power).
    """
    sigs: Any = getattr(qc, "sigs", {})
    if not isinstance(sigs, dict):
        return False, "bad_qc_format", 0

    msg = vote_message(chain_id=int(chain_id), height=int(qc.height), round=int(qc.round), block_hash=str(qc.block_hash))
    signed_power = 0

    for voter, sigb in sigs.items():
        voter = str(voter)
        v = vmap.get(voter)
        if v is None:
            continue
        if not isinstance(sigb, (bytes, bytearray)):
            continue
        if verify_vote_sig(voter, bytes(sigb), msg):
            signed_power += int(v.power)

    if signed_power < int(quorum_power):
        return False, "insufficient_qc_power", signed_power

    return True, "ok", signed_power
