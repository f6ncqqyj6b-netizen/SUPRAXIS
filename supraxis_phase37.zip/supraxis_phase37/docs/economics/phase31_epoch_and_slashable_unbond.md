# Phase 31 — Epoch Transitions + Validator Set Snapshots + Slashable Unbond Window

This phase closes key mainnet gaps:

1) **Epoch model** so the chain can define validator sets over time deterministically.
2) **Slashable unbond window** so validators cannot escape slashing by unbonding right before misbehavior is proven.

---

## Tick + Epoch

State:
- `tick` (monotonic integer)
- `epoch` (monotonic integer)

Governance policy:
- `epoch.len_ticks` (default 1000)
- `epoch.max_validators` (default 100)

Op:
- `EPOCH_ADVANCE`
  - increments `tick`
  - if `tick % epoch.len_ticks == 0`:
    - increments `epoch`
    - snapshots validator set from current stakes:
      - take top `epoch.max_validators` stakers
      - sort by `(-stake, pubkey_hex)`
    - store at: `storage["validators.epoch.<epoch>"]`
    - emit `EPOCH_ROLLOVER {epoch,tick,validators}`

This is deterministic and replay-safe.

---

## Slashable Unbond Window

Unbonding creates records:
- `storage["unbond.<pubkey>"] = [{to, amount, unlock_tick}, ...]`

Rule:
- Pending unbonds are **slashable until unlock_tick**.
- `slash_with_pending(pubkey, amount, tick)`:
  - slashes active stake first
  - then slashes unbond records where `unlock_tick > tick`

Consensus slashing ops now use this extended slashing primitive.

---

## Why this matters for mainnet

- Prevents “rage quit” unbond escapes.
- Produces an unambiguous validator set snapshot per epoch for consensus membership.
- Enables later fast sync / checkpoints to reference `validators.epoch.*` (Phase 32/33).


### Note on key normalization
Unbond records are stored under `unbond.<pubkey_hex>` where `<pubkey_hex>` includes the `0x` prefix.
Snapshot validator entries always emit `vid` with `0x` prefix.
