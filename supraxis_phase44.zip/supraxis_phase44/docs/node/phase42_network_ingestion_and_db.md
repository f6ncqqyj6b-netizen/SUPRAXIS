# Phase 42 — Networking Ingestion (Simulated) + Persistent DB

This phase introduces the scaffolding for real networking while keeping the build testable offline.

## P2P Framing

`src/supraxis/p2p/message.py`
- reference framing: **length-prefixed JSON**
- `encode(Msg)` / `decode(buf)` to stream multiple frames

## Sync Protocol Types

`src/supraxis/p2p/protocol.py`
- request/response message names for:
  - best checkpoint
  - signed headers path
  - blocks by hash
  - optional snapshot

## Persistence DB

`src/supraxis/node/db.py`
- JSON persistence for:
  - `gossip.json` (GossipStore)
  - `snapshot.json` (state snapshot)
  - `blocks.json` (blockstore)

## Sync Client

`src/supraxis/node/sync.py`
- `InMemoryPeer`: serves gossip/snapshot/blocks via protocol requests
- `SyncClient`: pulls best checkpoint + signed headers + snapshot into local stores

## Next

Phase 43: real socket transport + peer scoring + basic anti-spam limits.
