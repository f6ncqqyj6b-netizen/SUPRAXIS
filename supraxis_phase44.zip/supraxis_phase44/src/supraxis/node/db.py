from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Any, Dict
import json

from supraxis.consensus.gossip import GossipStore
from supraxis.node.blockstore import BlockStore

@dataclass
class NodeDB:
    """Very small disk persistence for reference build (JSON files).

    Layout:
      db/
        gossip.json
        snapshot.json
        blocks.json
        peers.json
    """
    path: Path

    def _p(self, name: str) -> Path:
        self.path.mkdir(parents=True, exist_ok=True)
        return self.path / name

    def save_gossip(self, gossip: GossipStore) -> None:
        self._p("gossip.json").write_text(json.dumps(gossip.to_dict(), indent=2), encoding="utf-8")

    def load_gossip(self) -> GossipStore:
        p = self._p("gossip.json")
        if not p.exists():
            return GossipStore()
        return GossipStore.from_dict(json.loads(p.read_text(encoding="utf-8")))

    def save_snapshot(self, snapshot: dict) -> None:
        self._p("snapshot.json").write_text(json.dumps(snapshot, indent=2), encoding="utf-8")

    def load_snapshot(self) -> Optional[dict]:
        p = self._p("snapshot.json")
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))

    def save_blocks(self, store: BlockStore) -> None:
        # blocks must be JSON serializable in this reference build
        self._p("blocks.json").write_text(json.dumps(store.blocks, indent=2), encoding="utf-8")

    def load_blocks(self) -> BlockStore:
        p = self._p("blocks.json")
        st = BlockStore()
        if not p.exists():
            return st
        st.blocks = json.loads(p.read_text(encoding="utf-8"))
        return st

    def save_peers(self, peers: dict) -> None:
        self._p("peers.json").write_text(json.dumps(peers, indent=2), encoding="utf-8")

    def load_peers(self) -> Optional[dict]:
        p = self._p("peers.json")
        if not p.exists():
            return None
        return json.loads(p.read_text(encoding="utf-8"))
