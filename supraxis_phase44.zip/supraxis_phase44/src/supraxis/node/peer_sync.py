from __future__ import annotations
import asyncio
import time
from dataclasses import dataclass
from typing import Optional, List, Tuple

from supraxis.p2p.transport import AsyncTCPClient
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P
from supraxis.node.peerdb import PeerDB

@dataclass
class Backoff:
    base: float = 0.5
    factor: float = 2.0
    cap: float = 30.0

    def delay(self, failures: int) -> float:
        return min(self.cap, self.base * (self.factor ** max(0, failures)))

class PeerSync:
    def __init__(self, chain_id: int, peerdb: PeerDB, backoff: Optional[Backoff]=None):
        self.chain_id = int(chain_id)
        self.peerdb = peerdb
        self.backoff = backoff or Backoff()

    async def query_peers_once(self, host: str, port: int, limit: int = 32, timeout: float = 2.0) -> Tuple[bool,str,List[dict]]:
        c = AsyncTCPClient(host, port)
        try:
            await c.connect()
            await c.send(Msg(P.REQ_HELLO, {"node_id":"sync","chain_id": self.chain_id, "version":"0.44.0"}))
            _ = await c.recv_one(timeout=timeout)  # hello_ok or error
            await c.send(Msg(P.REQ_PEERS, {"limit": int(limit)}))
            rsp = await c.recv_one(timeout=timeout)
            if rsp.t != P.RSP_PEERS:
                return False, "bad_response", []
            peers = list(rsp.payload.get("peers") or [])
            return True, "ok", peers
        except Exception as e:
            return False, "exception", []
        finally:
            try:
                await c.close()
            except Exception:
                pass

    async def step(self, seed_host: str, seed_port: int, limit: int = 32) -> Tuple[bool,str]:
        r = self.peerdb.upsert(seed_host, seed_port, seen=True)
        # respect backoff based on failures
        delay = self.backoff.delay(r.failures)
        # only backoff after failures have occurred
        if r.failures > 0 and delay > 0 and (time.time() - r.last_seen) < delay:
            return True, "backoff_wait"

        ok, why, peers = await self.query_peers_once(seed_host, seed_port, limit=limit)
        if not ok:
            self.peerdb.mark_failure(seed_host, seed_port)
            return False, why

        self.peerdb.upsert(seed_host, seed_port, seen=True, score_delta=+1.0)
        for p in peers:
            host = str(p.get("host",""))
            port = int(p.get("port",0))
            if host and port:
                self.peerdb.upsert(host, port, seen=False, score_delta=0.1)
        return True, "ok"
