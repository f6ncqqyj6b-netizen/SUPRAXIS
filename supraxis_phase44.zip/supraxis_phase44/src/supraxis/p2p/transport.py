from __future__ import annotations
import asyncio
import time
from dataclasses import dataclass, field
from typing import Optional, Callable, Awaitable, Dict, Any, Tuple

from supraxis.p2p.message import Msg, encode, decode
from supraxis.p2p.security import validate_frame_size, validate_payload_schema, DEFAULT_MAX_FRAME_BYTES
from supraxis.p2p.peer_manager import PeerManager, PeerInfo, PeerPolicy

Handler = Callable[[str, Msg], Awaitable[Optional[Msg]]]

@dataclass
class TransportConfig:
    chain_id: int
    max_frame_bytes: int = DEFAULT_MAX_FRAME_BYTES
    idle_timeout_sec: int = 120
    policy: PeerPolicy = field(default_factory=PeerPolicy)

class AsyncTCPServer:
    """Reference asyncio TCP server with strict message validation + peer scoring."""
    def __init__(self, host: str, port: int, config: TransportConfig, handler: Handler):
        self.host = host
        self.port = int(port)
        self.config = config
        self.handler = handler
        self.pm = PeerManager(config.policy)
        self._server: Optional[asyncio.base_events.Server] = None

    async def start(self) -> None:
        self._server = await asyncio.start_server(self._on_conn, self.host, self.port)

    async def close(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()

    async def _on_conn(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        conn_id = f"{writer.get_extra_info('peername')}-{id(writer)}"
        # pre-register peer with unknown hello; must hello first
        self.pm.add(conn_id, PeerInfo(node_id="unknown", chain_id=self.config.chain_id, version="unknown"))
        buf = b""
        last = time.monotonic()
        try:
            while True:
                # idle timeout
                if time.monotonic() - last > self.config.idle_timeout_sec:
                    break
                data = await reader.read(4096)
                if not data:
                    break
                last = time.monotonic()
                buf += data

                # process frames
                while True:
                    if len(buf) < 4:
                        break
                    n = int.from_bytes(buf[:4], "big")
                    ok, why = validate_frame_size(n, self.config.max_frame_bytes)
                    if not ok:
                        self.pm.score(conn_id, -10.0, why)
                        return
                    if len(buf) < 4 + n:
                        break
                    msg, buf = decode(buf)

                    # validate schema
                    ok2, why2 = validate_payload_schema(msg.t, msg.payload)
                    if not ok2:
                        self.pm.score(conn_id, -5.0, why2)
                        # respond error then continue (unless banned)
                        await self._send(writer, Msg("error", {"why": why2}))
                        ev, _ = self.pm.should_evict(conn_id)
                        if ev:
                            return
                        continue

                    # handshake chain_id enforcement on hello
                    if msg.t == "hello":
                        cid = msg.payload.get("chain_id", self.config.chain_id)
                        if cid != self.config.chain_id:
                            self.pm.score(conn_id, -20.0, "wrong_chain")
                            await self._send(writer, Msg("error", {"why":"wrong_chain"}))
                            return
                        p = self.pm.get(conn_id)
                        if p:
                            p.node_id = str(msg.payload.get("node_id","unknown"))
                            p.chain_id = int(cid)
                            p.version = str(msg.payload.get("version","unknown"))
                            self.pm.score(conn_id, +1.0, "hello_ok")

                    # request limits
                    ok3, why3 = self.pm.check_request_limits(conn_id, msg.t, msg.payload)
                    if not ok3:
                        await self._send(writer, Msg("error", {"why": why3}))
                        ev, _ = self.pm.should_evict(conn_id)
                        if ev:
                            return
                        continue

                    # handler
                    rsp = await self.handler(conn_id, msg)
                    if rsp is not None:
                        await self._send(writer, rsp)

                    # evict decision
                    self.pm.decay()
                    ev, evwhy = self.pm.should_evict(conn_id)
                    if ev:
                        await self._send(writer, Msg("error", {"why": evwhy}))
                        return
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass
            self.pm.remove(conn_id)

    async def _send(self, writer: asyncio.StreamWriter, msg: Msg) -> None:
        writer.write(encode(msg))
        await writer.drain()

class AsyncTCPClient:
    """Reference client used in tests."""
    def __init__(self, host: str, port: int):
        self.host = host
        self.port = int(port)
        self.reader: Optional[asyncio.StreamReader] = None
        self.writer: Optional[asyncio.StreamWriter] = None
        self.buf = b""

    async def connect(self) -> None:
        self.reader, self.writer = await asyncio.open_connection(self.host, self.port)

    async def close(self) -> None:
        if self.writer:
            self.writer.close()
            await self.writer.wait_closed()

    async def send(self, msg: Msg) -> None:
        assert self.writer is not None
        self.writer.write(encode(msg))
        await self.writer.drain()

    async def recv_one(self, timeout: float = 2.0) -> Msg:
        assert self.reader is not None
        start = time.monotonic()
        while True:
            # try decode
            if len(self.buf) >= 4:
                n = int.from_bytes(self.buf[:4], "big")
                if len(self.buf) >= 4+n:
                    m, rest = decode(self.buf)
                    self.buf = rest
                    return m
            if time.monotonic() - start > timeout:
                raise TimeoutError("recv_timeout")
            data = await self.reader.read(4096)
            if not data:
                raise EOFError("closed")
            self.buf += data
