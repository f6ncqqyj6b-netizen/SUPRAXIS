import unittest
from supraxis.state import SupraxisState
from supraxis.consensus.checkpoint import Checkpoint, validators_hash
from supraxis.consensus.signed_checkpoint import SignedCheckpoint, CheckpointSig
from supraxis.consensus.gossip import GossipStore
from supraxis.consensus.headerchain import Header
from supraxis.consensus.lightclient import LightClient
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign

class TestPhase35(unittest.TestCase):
    def test_gossip_best_checkpoint(self):
        st = SupraxisState()
        k1 = ed25519_keygen(seed=b"\x01"*32)
        v1 = "0x"+k1.public.hex()
        snap = [{"vid": v1, "power": 10}]
        st.storage["validators.epoch.0"] = snap
        # register validators (Phase 37 requirement)
        st.storage["validator." + "0x"+"01"*32] = {"vid":"0x"+"01"*32,"reward_address":"0x"+"aa"*32}
        st.storage["validator." + "0x"+"02"*32] = {"vid":"0x"+"02"*32,"reward_address":"0x"+"bb"*32}

        def mk(h):
            ck = Checkpoint(chain_id=1, epoch=0, height=h, state_root="11"*32, block_hash=f"{h:064x}", validators_hash=validators_hash(snap))
            msg = ck.signing_message()
            sig = "0x"+ed25519_sign(k1.private, msg).hex()
            return SignedCheckpoint(checkpoint=ck, sigs=[CheckpointSig(vid=v1, scheme=11, sig=sig)])

        g = GossipStore()
        g.add_checkpoint(mk(5))
        g.add_checkpoint(mk(9))
        best = g.best_checkpoint()
        self.assertEqual(best.checkpoint.height, 9)

    
    def test_lightclient_signed_header_sync(self):
        st = SupraxisState()
        # create 2 ed25519 validators and register
        from supraxis.crypto_keys import ed25519_keygen, ed25519_sign
        from supraxis.consensus.signed_header import SignedHeader, header_message
        from supraxis.consensus.vote_signing import SCHEME_ED25519
        k1 = ed25519_keygen(seed=bytes([1])*32)
        k2 = ed25519_keygen(seed=bytes([2])*32)
        v1 = "0x"+k1.public.hex()
        v2 = "0x"+k2.public.hex()
        st.storage["validators.epoch.0"] = [{"vid": v1, "power": 10}, {"vid": v2, "power": 10}]
        st.storage[f"validator.{v1}"] = {"vid": v1, "reward_address":"0x"+"aa"*32}
        st.storage[f"validator.{v2}"] = {"vid": v2, "reward_address":"0x"+"bb"*32}
        from supraxis.consensus.checkpoint import validators_hash
        vh = validators_hash(st.storage["validators.epoch.0"])

        lc = LightClient(chain_id=1, trusted=Checkpoint(chain_id=1, epoch=0, height=1, state_root="aa"*32, block_hash="01"*32, validators_hash=vh))

        hs = [
            Header(chain_id=1, epoch=0, height=2, round=0, block_hash="02"*32, parent_hash="01"*32, proposer="p", validators_hash=vh, qc=None),
            Header(chain_id=1, epoch=0, height=3, round=0, block_hash="03"*32, parent_hash="02"*32, proposer="p", validators_hash=vh, qc=None),
            Header(chain_id=1, epoch=0, height=4, round=0, block_hash="04"*32, parent_hash="03"*32, proposer="p", validators_hash=vh, qc=None),
        ]
        shs = []
        for h in hs:
            msg = header_message(h)
            shs.append(SignedHeader(header=h, sigs={
                v1: {"scheme": SCHEME_ED25519, "sig": ed25519_sign(k1.private, msg)},
                v2: {"scheme": SCHEME_ED25519, "sig": ed25519_sign(k2.private, msg)},
            }))

        ok, why = lc.sync_signed_headers(st, shs)
        self.assertTrue(ok)
        self.assertEqual(lc.trusted.height, 4)
        self.assertEqual(lc.trusted.block_hash, "04"*32)

if __name__ == "__main__":
    unittest.main()
