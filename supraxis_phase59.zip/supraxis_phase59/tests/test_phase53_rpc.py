import unittest
import threading
import time
import json
from urllib import request, parse

from supraxis.rpc.server import RPCContext, start_rpc_server
from supraxis.mempool import Mempool
from supraxis.node.blockstore import BlockStore
from supraxis.node.evidence_store import EvidenceStore
from supraxis.node.evidence_service import EvidenceService
from supraxis.node.db import NodeDB
from supraxis.governance import GovernanceEngine
from supraxis.node.governance_service import GovernanceService

from supraxis.tx import make_tx

class TestPhase53RPC(unittest.TestCase):
    def _get(self, url):
        with request.urlopen(url, timeout=5) as r:
            return json.loads(r.read().decode("utf-8"))

    def _post(self, url, obj):
        raw = json.dumps(obj).encode("utf-8")
        req = request.Request(url, data=raw, headers={"Content-Type":"application/json"})
        with request.urlopen(req, timeout=5) as r:
            return json.loads(r.read().decode("utf-8"))

    def test_rpc_endpoints(self):
        mp = Mempool(chain_id=1)
        blocks = BlockStore()
        evid = EvidenceService(store=EvidenceStore(), db=None)
        gov = GovernanceService(engine=GovernanceEngine(), db=None)

        ctx = RPCContext(chain_id=1, mempool=mp, blocks=blocks, evidence=evid, governance=gov)
        httpd, _t = start_rpc_server("127.0.0.1", 0, ctx)
        base = f"http://127.0.0.1:{httpd.server_port}"

        h = self._get(base + "/health")
        self.assertTrue(h["ok"])

        tx = make_tx(1, 0, "a", "b", "m", {"x":1}, max_fee=10**9).to_dict()
        r = self._post(base + "/tx/submit", {"tx": tx})
        self.assertTrue(r["ok"])

        mpq = self._get(base + "/mempool?limit=10")
        self.assertEqual(mpq["size"], 1)

        gs = self._post(base + "/governance/submit", {"kind":"param_change","title":"t","payload":{"x":1},"proposer":"alice"})
        self.assertTrue(gs["ok"])
        pid = gs["id"]
        st = self._get(base + "/governance/status?id=" + parse.quote(pid))
        self.assertEqual(st["id"], pid)

        httpd.shutdown()
        httpd.server_close()

if __name__ == "__main__":
    unittest.main()
