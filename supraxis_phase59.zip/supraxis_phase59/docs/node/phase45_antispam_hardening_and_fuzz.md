# Phase 45 — Anti-Spam Hardening + Protocol Fuzz Tests + Global Quotas

Builds on Phase 43/44 transport by adding **global** resource limits and fuzz-style regression tests.

## Additions

### GlobalLimiter
`src/supraxis/p2p/antispam.py`
- global token bucket shared across all connections
- quotas:
  - max header path items (hint-based)
  - max block request batch size

### Transport hardening
`src/supraxis/p2p/transport.py`
- enforces:
  - max concurrent connections
  - global rate limiting
  - global quotas (blocks/header paths)

### Fuzz tests
`tests/test_phase45_fuzz.py`
- random frame decode attempts (must not crash/hang)
- schema fuzz for known message types

## Next
Phase 46: persistence hardening (atomic writes, corruption checks, snapshot versioning).
