from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple, List

from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from supraxis.tx import validate_tx_dict, tx_from_dict

@dataclass
class Account:
    balance: int = 0
    nonce: int = 0

    def to_dict(self) -> dict:
        return {"balance": int(self.balance), "nonce": int(self.nonce)}

    @staticmethod
    def from_dict(d: dict) -> "Account":
        return Account(balance=int(d.get("balance", 0)), nonce=int(d.get("nonce", 0)))

@dataclass
class LedgerState:
    accounts: Dict[str, Account] = field(default_factory=dict)
    height: int = 0

    def get(self, addr: str) -> Account:
        a = self.accounts.get(str(addr))
        if a is None:
            a = Account()
            self.accounts[str(addr)] = a
        return a

    def snapshot_dict(self) -> dict:
        return {
            "height": int(self.height),
            "accounts": {k: self.accounts[k].to_dict() for k in sorted(self.accounts.keys())},
        }

    def state_root(self) -> str:
        return sha256(canonical_json(self.snapshot_dict())).hex()

    def apply_tx_dict(self, txd: dict) -> Tuple[bool, str]:
        ok, why = validate_tx_dict(txd)
        if not ok:
            return False, f"bad_tx:{why}"
        tx = tx_from_dict(txd)

        sender = self.get(tx.sender)
        if int(tx.nonce) != int(sender.nonce):
            return False, "bad_nonce"

        if tx.method != "transfer":
            return False, "unknown_method"

        amt = tx.params.get("amount")
        if not isinstance(amt, int) or amt <= 0:
            return False, "bad_amount"

        if sender.balance < amt:
            return False, "insufficient_funds"

        recv = self.get(tx.to)
        sender.balance -= int(amt)
        recv.balance += int(amt)
        sender.nonce += 1
        return True, "ok"

    def apply_txs(self, txs: List[dict]) -> Tuple[int, List[str]]:
        applied = 0
        errs: List[str] = []
        for i, txd in enumerate(txs):
            ok, why = self.apply_tx_dict(txd)
            if ok:
                applied += 1
            else:
                errs.append(f"{i}:{why}")
        return applied, errs


    def to_dict(self) -> dict:
        return self.snapshot_dict()

    @staticmethod
    def from_snapshot(d: dict) -> "LedgerState":
        st = LedgerState(height=int(d.get("height", 0)))
        accs = d.get("accounts") or {}
        if isinstance(accs, dict):
            for k, v in accs.items():
                st.accounts[str(k)] = Account.from_dict(v or {})
        return st

    def clone(self) -> "LedgerState":
        return LedgerState.from_snapshot(self.snapshot_dict())
