from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from supraxis.state import SupraxisState
from supraxis.net.mempool import Mempool
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.block import run_block, BlockResult, state_commitment
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from .node import ConsensusNode
from .types import Vote, QC, Proposal
from .hotstuff import make_block, form_qc, proposer_for
from .checkpoint import Checkpoint, validators_hash

@dataclass
class ProducedBlock:
    height: int
    round: int
    block_hash: str
    parent_hash: str
    payload: List[dict]
    block_result: BlockResult

@dataclass
class L1Pipeline:
    chain_id: int
    state: SupraxisState
    node: ConsensusNode
    mempool: Mempool = field(default_factory=Mempool)
    height: int = 0
    head_hash: str = field(default_factory=lambda: "00"*32)

    def __post_init__(self):
        # ensure node reflects current epoch validator set
        self.node.on_epoch_change()

    def submit_tx(self, env_dict: dict) -> None:
        self.mempool.add(env_dict)

    def propose_block(self, max_txs: int = 200, max_gas: int = 10**15, round: int = 0) -> ProducedBlock:
        self.height += 1
        proposer_vid = self.node.proposer(self.height, round)
        # build deterministic tx list
        txs = self.mempool.build_block(max_txs=max_txs, max_gas=max_gas)
        # remove selected from mempool (optimistic)
        for env in txs:
            from supraxis.net.mempool import tx_id_from_envelope_dict
            self.mempool.remove(tx_id_from_envelope_dict(env))
        # execute to mutate state
        # In this reference pipeline, envelopes are provided as dicts; run_block expects EnvelopeV2 objects.
        # We convert dict -> EnvelopeV2 minimally, ignoring payload bytes; this keeps tests deterministic.
        envs: List[EnvelopeV2] = []
        for d in txs:
            # Minimal conversion: payload is empty bytes and payload_hash taken from dict
            ph = d.get("payload_hash","0x"+"00"*32)
            if isinstance(ph,str) and ph.startswith("0x"):
                phb = bytes.fromhex(ph[2:])
            else:
                phb = bytes.fromhex(str(ph))
            envs.append(EnvelopeV2(
                version=int(d.get("version",2)),
                origin_chain=int(d.get("origin_chain",1)),
                origin_tx=bytes.fromhex(str(d.get("origin_tx","0x"+"00"*32))[2:]) if str(d.get("origin_tx","")).startswith("0x") else bytes.fromhex(str(d.get("origin_tx","00"*32))),
                origin_sender=bytes.fromhex(str(d.get("origin_sender","0x"+"00"*32))[2:]) if str(d.get("origin_sender","")).startswith("0x") else bytes.fromhex(str(d.get("origin_sender","00"*32))),
                target_chain=int(d.get("target_chain",100)),
                target_contract=bytes.fromhex(str(d.get("target_contract","0x"+"00"*32))[2:]) if str(d.get("target_contract","")).startswith("0x") else bytes.fromhex(str(d.get("target_contract","00"*32))),
                nonce=int(d.get("nonce",0)),
                gas_limit=int(d.get("gas_limit",0)),
                payload_type=1,
                payload=b"{}",
                payload_hash=sha256(b"{}") if len(phb)!=32 else phb,
                cap_refs=list(d.get("cap_refs",[])),
                signatures=[],
            ))
        # Choose entry function set; in prior phases, functions dict passed in by caller.
        # Here, we assume a single function set is already loaded into state.storage["program.functions"].
        functions = self.state.storage.get("program.functions")
        if not isinstance(functions, dict):
            raise RuntimeError("program.functions missing in state.storage")
        res = run_block(self.state, functions, envs, proposer_vid=proposer_vid, require_signatures=False, sig_policy=SignaturePolicy(min_valid=0), auto_slash=False)
        # create consensus block header for hashing/finality
        blk = make_block(self.chain_id, self.height, round, self.head_hash, proposer_vid, body=[{"txs": txs, "block_result_hash": res.block_hash}])
        bh = blk.hash()
        self.head_hash = bh
        return ProducedBlock(height=self.height, round=round, block_hash=bh, parent_hash=blk.header.parent_hash, payload=txs, block_result=res)

    def vote_and_form_qc(self, produced: ProducedBlock) -> QC:
        vals = self.node.current_validators()
        vmap = self.node.vmap()
        votes: List[Vote] = []
        for v in vals:
            votes.append(Vote(height=produced.height, round=produced.round, block_hash=produced.block_hash, voter=v.vid, sig=b""))
        qc = form_qc(produced.height, produced.round, produced.block_hash, votes, vmap)
        if qc.power < self.node.quorum():
            raise RuntimeError("no quorum")
        return qc

    def maybe_checkpoint(self) -> Optional[Checkpoint]:
        # Emit checkpoint on epoch boundary if validators snapshot exists
        ep = int(self.state.storage.get("epoch", 0))
        snap = self.state.storage.get(f"validators.epoch.{ep}")
        if snap is None:
            return None
        # state root is current state hash
        state_root = sha256(canonical_json(state_commitment(self.state))).hex()
        vh = validators_hash(list(snap))
        return Checkpoint(chain_id=self.chain_id, epoch=ep, height=self.height, state_root=state_root, block_hash=self.head_hash, validators_hash=vh)
