from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import json
from .canonical import pack_u16, pack_u32, pack_u64, read_u16, read_u32, read_u64
from .errors import ReplayError

MAGIC=b"SIRB"
VERSION=1

OP_CAP_REQUIRE=0x01
OP_EMIT=0x02
OP_STORE=0x03
OP_ASSERT=0x04

# Phase 13 governance opcodes
OP_GOV_REGISTER_COMMITTEE_JSON=0x20
OP_GOV_REGISTER_COMMITTEE_ID=0x21
OP_GOV_SET_GRACE=0x22

OP_CALL=0x10
OP_RET=0xFF

MAX_CALL_DEPTH=32

def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def _pack_str(s: str) -> bytes:
    b=s.encode("utf-8")
    return pack_u16(len(b))+b

def _read_str(buf: bytes, off: int) -> Tuple[str,int]:
    n, off = read_u16(buf, off)
    if off+n>len(buf): raise ReplayError("EOF str")
    return buf[off:off+n].decode("utf-8"), off+n

@dataclass(frozen=True)
class SirBinProgram:
    version: int
    functions: Dict[str, List[Dict[str, Any]]]

    def encode(self) -> bytes:
        out=bytearray()
        out+=MAGIC
        out+=pack_u16(VERSION)
        items=sorted(self.functions.items(), key=lambda kv: kv[0])
        out+=pack_u16(len(items))
        for name, ops in items:
            out+=_pack_str(name)
            out+=pack_u32(len(ops))
            for op in ops:
                out.append(opcode_for(op))
                out+=encode_operands(op)
        return bytes(out)

    @staticmethod
    def decode(buf: bytes) -> "SirBinProgram":
        if len(buf)<8 or buf[:4]!=MAGIC: raise ReplayError("bad SIRB")
        off=4
        ver, off = read_u16(buf, off)
        if ver!=VERSION: raise ReplayError("bad version")
        nfn, off = read_u16(buf, off)
        fns={}
        for _ in range(nfn):
            name, off = _read_str(buf, off)
            nop, off = read_u32(buf, off)
            ops=[]
            for _ in range(nop):
                if off>=len(buf): raise ReplayError("EOF opcode")
                opc=buf[off]; off+=1
                op, off = decode_op(buf, off, opc)
                ops.append(op)
            fns[name]=ops
        if off!=len(buf): raise ReplayError("trailing bytes")
        return SirBinProgram(version=VERSION, functions=fns)

def opcode_for(op: Dict[str,Any]) -> int:
    n=op.get("op")
    if n=="CAP_REQUIRE": return OP_CAP_REQUIRE
    if n=="EMIT": return OP_EMIT
    if n=="STORE": return OP_STORE
    if n=="ASSERT": return OP_ASSERT

    if n=="GOV_REGISTER_COMMITTEE_JSON": return OP_GOV_REGISTER_COMMITTEE_JSON
    if n=="GOV_REGISTER_COMMITTEE_ID": return OP_GOV_REGISTER_COMMITTEE_ID
    if n=="GOV_SET_GRACE": return OP_GOV_SET_GRACE

    if n=="CALL": return OP_CALL
    if n=="RET": return OP_RET
    raise ReplayError("unknown op")

def encode_operands(op: Dict[str,Any]) -> bytes:
    n=op["op"]
    if n=="CAP_REQUIRE": return _pack_str(str(op["cap"]))+_pack_str(str(op["scope"]))
    if n=="EMIT":
        pb=canonical_json_bytes(op.get("payload"))
        return _pack_str(str(op["event"]))+pack_u32(len(pb))+pb
    if n=="STORE":
        vb=canonical_json_bytes(op.get("value"))
        return _pack_str(str(op["key"]))+pack_u32(len(vb))+vb
    if n=="ASSERT": return bytes([1 if bool(op.get("value")) else 0])

    if n=="GOV_REGISTER_COMMITTEE_JSON":
        epoch=int(op["epoch"])
        cb=canonical_json_bytes(op["committee"])
        return pack_u64(epoch) + pack_u32(len(cb)) + cb
    if n=="GOV_REGISTER_COMMITTEE_ID":
        epoch=int(op["epoch"])
        return pack_u64(epoch) + _pack_str(str(op["committee_id"]))
    if n=="GOV_SET_GRACE":
        grace=int(op["grace"])
        return pack_u32(grace)

    if n=="CALL": return _pack_str(str(op["fn"]))
    if n=="RET": return b""
    raise ReplayError("bad op")

def decode_op(buf: bytes, off: int, opc: int):
    if opc==OP_CAP_REQUIRE:
        cap, off=_read_str(buf, off); scope, off=_read_str(buf, off)
        return {"op":"CAP_REQUIRE","cap":cap,"scope":scope}, off
    if opc==OP_EMIT:
        event, off=_read_str(buf, off)
        n, off=read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF payload")
        payload=json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"EMIT","event":event,"payload":payload}, off
    if opc==OP_STORE:
        key, off=_read_str(buf, off)
        n, off=read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF value")
        value=json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"STORE","key":key,"value":value}, off
    if opc==OP_ASSERT:
        if off>=len(buf): raise ReplayError("EOF assert")
        v=buf[off]; off+=1
        if v not in (0,1): raise ReplayError("bad assert")
        return {"op":"ASSERT","value":bool(v)}, off

    if opc==OP_GOV_REGISTER_COMMITTEE_JSON:
        epoch, off = read_u64(buf, off)
        n, off = read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF committee")
        committee = json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"GOV_REGISTER_COMMITTEE_JSON","epoch":int(epoch),"committee":committee}, off
    if opc==OP_GOV_REGISTER_COMMITTEE_ID:
        epoch, off = read_u64(buf, off)
        cid, off = _read_str(buf, off)
        return {"op":"GOV_REGISTER_COMMITTEE_ID","epoch":int(epoch),"committee_id":cid}, off
    if opc==OP_GOV_SET_GRACE:
        grace, off = read_u32(buf, off)
        return {"op":"GOV_SET_GRACE","grace":int(grace)}, off

    if opc==OP_CALL:
        fn, off=_read_str(buf, off)
        return {"op":"CALL","fn":fn}, off
    if opc==OP_RET:
        return {"op":"RET"}, off
    raise ReplayError("unknown opcode")

def disasm(buf: bytes) -> str:
    prog=SirBinProgram.decode(buf)
    lines=[f"; SIRB v{prog.version}"]
    for fn in sorted(prog.functions.keys()):
        lines.append(f"fn {fn}:")
        for i, op in enumerate(prog.functions[fn]):
            lines.append(f"  {i:04d}  {op}")
    return "\n".join(lines)+"\n"
