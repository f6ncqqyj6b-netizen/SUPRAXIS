from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Set, Optional
import json
from .committee import Committee

def _key(oc: int, os: bytes, tc: int, tct: bytes) -> str:
    return f"{oc}:{os.hex()}->{tc}:{tct.hex()}"

@dataclass
class SupraxisState:
    # Replay / nonce tracking
    nonces: Dict[str, int] = field(default_factory=dict)

    # Simple KV storage used by runtime opcodes
    storage: Dict[str, Any] = field(default_factory=dict)

    # Capability store (reserved)
    caps: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # Committee registry maps epoch -> committee_id_hex (64 chars)
    committee_registry: Dict[str, str] = field(default_factory=dict)

    # Phase 12: committee_store maps committee_id_hex -> canonical committee JSON
    committee_store: Dict[str, str] = field(default_factory=dict)

    # Rotation grace window
    rotation_grace_epochs: int = 0

    def get_last_nonce(self, oc: int, os: bytes, tc: int, tct: bytes) -> int:
        return int(self.nonces.get(_key(oc, os, tc, tct), 0))

    def set_last_nonce(self, oc: int, os: bytes, tc: int, tct: bytes, nonce: int) -> None:
        self.nonces[_key(oc, os, tc, tct)] = int(nonce)

    # Storage helpers
    def get(self, k: str, default: Any = None) -> Any:
        return self.storage.get(k, default)

    def put(self, k: str, v: Any) -> None:
        self.storage[k] = v

    # Committee registry
    def register_committee(self, epoch: int, committee_id_hex: str) -> None:
        e = str(int(epoch))
        cid = committee_id_hex.lower().strip()
        if cid.startswith("0x"):
            cid = cid[2:]
        if len(cid) != 64:
            raise ValueError("committee_id_hex must be 32 bytes (64 hex chars)")
        self.committee_registry[e] = cid

    def register_committee_json(self, epoch: int, committee_json: str) -> str:
        """Registers a committee by JSON, storing it in committee_store.

        Returns committee_id_hex (no 0x).
        """
        committee = Committee.from_json(committee_json)
        cid = committee.committee_id()
        self.committee_store[cid] = committee.canonical_json()
        self.register_committee(epoch, cid)
        return cid

    def get_committee_by_id(self, committee_id_hex: str) -> Optional[Committee]:
        cid = committee_id_hex.lower().strip()
        if cid.startswith("0x"): cid = cid[2:]
        js = self.committee_store.get(cid)
        if js is None:
            return None
        return Committee.from_json(js)

    def set_rotation_grace(self, grace_epochs: int) -> None:
        self.rotation_grace_epochs = int(grace_epochs)
        if self.rotation_grace_epochs < 0:
            self.rotation_grace_epochs = 0

    def allowed_committee_ids_for_epoch(self, epoch: int) -> Set[str]:
        ep = int(epoch)
        g = int(self.rotation_grace_epochs)
        allowed: Set[str] = set()
        for e_str, cid in self.committee_registry.items():
            try:
                e = int(e_str)
            except Exception:
                continue
            if ep - g <= e <= ep:
                allowed.add(cid)
        return allowed

    def committee_for_epoch(self, epoch: int, committee_id_hex: Optional[str] = None) -> Optional[Committee]:
        """Return a Committee object for an epoch.

        If committee_id_hex is provided, it is used (and must exist in store).
        Otherwise, uses committee_registry[epoch] if present.
        """
        cid = committee_id_hex
        if cid is None:
            cid = self.committee_registry.get(str(int(epoch)))
        if cid is None:
            return None
        return self.get_committee_by_id(cid)

    def to_json(self) -> str:
        obj = {
            "nonces": self.nonces,
            "storage": self.storage,
            "caps": self.caps,
            "committee_registry": {k: self.committee_registry[k] for k in sorted(self.committee_registry, key=lambda x: int(x)) if k in self.committee_registry},
            "committee_store": {k: self.committee_store[k] for k in sorted(self.committee_store.keys())},
            "rotation_grace_epochs": int(self.rotation_grace_epochs),
        }
        return json.dumps(obj, sort_keys=True, separators=(",", ":"))

    @staticmethod
    def from_json(s: str) -> "SupraxisState":
        d = json.loads(s)
        st = SupraxisState()
        st.nonces = {k: int(v) for k, v in d.get("nonces", {}).items()}
        st.storage = d.get("storage", {})
        st.caps = d.get("caps", {})
        st.committee_registry = {str(k): str(v) for k, v in d.get("committee_registry", {}).items()}
        st.committee_store = {str(k): str(v) for k, v in d.get("committee_store", {}).items()}
        st.rotation_grace_epochs = int(d.get("rotation_grace_epochs", 0))
        return st
