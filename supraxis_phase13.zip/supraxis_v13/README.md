# SUPRAXIS (Phase 13)

Phase 13 adds **protocol-governed committee rotation** via deterministic runtime opcodes.

Instead of editing state off-chain (CLI-only), committee registration and rotation parameters can now be updated **inside blocks**,
gated by a deterministic **GOVERNANCE** capability.

## What’s new

### Governance capability
Governance ops require the capability:

- `cap_name = "GOVERNANCE"`
- `scope = "global"`
- `chain = ctx.target_chain`
- `expires >= ctx.timestamp`

This capability is stored under `state.caps[sha256("GOVERNANCE")]`.

### New runtime ops

- `GOV_REGISTER_COMMITTEE_JSON`
  - Inputs: `epoch`, `committee` (JSON object)
  - Effect: canonicalizes committee JSON, computes `committee_id`, stores it in `state.committee_store`,
    and registers `committee_registry[epoch] = committee_id`.
  - Emits: `GOV_COMMITTEE_REGISTERED`

- `GOV_REGISTER_COMMITTEE_ID`
  - Inputs: `epoch`, `committee_id` (hex)
  - Effect: registers committee id for epoch (no JSON stored)
  - Emits: `GOV_COMMITTEE_ID_REGISTERED`

- `GOV_SET_GRACE`
  - Inputs: `grace` (int epochs)
  - Effect: updates `state.rotation_grace_epochs`
  - Emits: `GOV_GRACE_SET`

### Why this matters
This enables a clean, deterministic upgrade path:
1) A governance envelope registers the next committee for epoch N (and optionally sets grace)
2) Subsequent envelopes in the same block (or later blocks) can use EnvelopeV3 quorum proofs bound to that committee.

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
