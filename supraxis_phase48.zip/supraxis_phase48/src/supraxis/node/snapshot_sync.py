from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, List
import base64

from supraxis.p2p.transport import AsyncTCPClient
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P
from supraxis.node.snapshot_chunks import meta_from_dict, meta_to_dict, verify_chunks, bytes_to_snapshot
from supraxis.node.db import NodeDB

@dataclass
class SnapshotSyncConfig:
    chain_id: int
    timeout: float = 3.0
    max_chunks: int = 10_000

class SnapshotSync:
    def __init__(self, db: NodeDB, cfg: SnapshotSyncConfig):
        self.db = db
        self.cfg = cfg

    async def fetch_snapshot(self, host: str, port: int) -> Tuple[bool,str,Optional[str]]:
        c = AsyncTCPClient(host, port)
        try:
            await c.connect()
            await c.send(Msg(P.REQ_HELLO, {"node_id":"snap_sync","chain_id": int(self.cfg.chain_id), "version":"0.47.0"}))
            _ = await c.recv_one(timeout=self.cfg.timeout)

            # meta
            await c.send(Msg(P.REQ_SNAPSHOT_META, {"want": True}))
            rsp = await c.recv_one(timeout=self.cfg.timeout)
            if rsp.t != P.RSP_SNAPSHOT_META:
                return False, "no_meta", None
            meta = meta_from_dict(rsp.payload.get("meta") or {})
            if int(meta.chunks) > int(self.cfg.max_chunks):
                return False, "too_many_chunks", None

            chunks: List[bytes] = []
            for i in range(int(meta.chunks)):
                await c.send(Msg(P.REQ_SNAPSHOT_CHUNK, {"snapshot_id": meta.snapshot_id, "index": i}))
                cr = await c.recv_one(timeout=self.cfg.timeout)
                if cr.t != P.RSP_SNAPSHOT_CHUNK:
                    return False, "missing_chunk", None
                b64 = cr.payload.get("data_b64")
                if not isinstance(b64, str):
                    return False, "bad_chunk_data", None
                chunks.append(base64.b64decode(b64.encode("utf-8")))

            ok, why = verify_chunks(meta, chunks)
            if not ok:
                return False, f"verify_failed:{why}", None

            data = b"".join(chunks)
            snap = bytes_to_snapshot(data)
            sid = self.db.save_snapshot(snap, snapshot_id=meta.snapshot_id)
            return True, "ok", sid
        except Exception as e:
            return False, "exception", None
        finally:
            try:
                await c.close()
            except Exception:
                pass
