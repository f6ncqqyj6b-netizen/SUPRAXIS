from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import base64

from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P
from supraxis.consensus.gossip import GossipStore
from supraxis.node.blockstore import BlockStore
from supraxis.p2p.discovery import DiscoveryService

from supraxis.consensus.persist import dump_signed_checkpoint, dump_signed_header
from supraxis.node.db import NodeDB
from supraxis.node.snapshot_chunks import build_meta, meta_to_dict
from supraxis.node.tx_service import TxService

@dataclass
class NodeService:
    chain_id: int
    gossip: GossipStore
    blocks: BlockStore
    discovery: DiscoveryService
    db: Optional[NodeDB] = None
    tx_service: Optional[TxService] = None

    # cached snapshot served for this process lifetime
    _snap_id: Optional[str] = None
    _snap_meta: Optional[dict] = None
    _snap_chunks: Optional[list] = None

    def _ensure_snapshot_cache(self) -> bool:
        if self.db is None:
            return False
        snap = self.db.load_snapshot()
        if snap is None:
            return False
        # use stable id from snapshot_latest if present; else "latest"
        sid = "latest"
        # rebuild cache if missing
        if self._snap_meta is None or self._snap_chunks is None or self._snap_id != sid:
            meta, chunks = build_meta(sid, snap)
            self._snap_id = sid
            self._snap_meta = meta_to_dict(meta)
            self._snap_chunks = chunks
        return True

    async def handle(self, conn_id: str, msg: Msg) -> Optional[Msg]:
        if msg.t == P.REQ_HELLO:
            return Msg(P.RSP_HELLO, {"node_id": "node", "chain_id": int(self.chain_id), "version": "0.47.0"})

        if msg.t == P.REQ_BEST_CHECKPOINT:
            scp = self.gossip.best_checkpoint(min_height=int(msg.payload.get("min_height",0)))
            if scp is None:
                return Msg(P.RSP_ERROR, {"why":"no_checkpoint"})
            return Msg(P.RSP_BEST_CHECKPOINT, {"scp": dump_signed_checkpoint(scp)})

        if msg.t == P.REQ_SIGNED_HEADERS:
            start = str(msg.payload.get("start_hash",""))
            end = str(msg.payload.get("end_hash",""))
            path = self.gossip.signed_headers_from(start, end)
            return Msg(P.RSP_SIGNED_HEADERS, {"path": [dump_signed_header(sh) for sh in path]})

        if msg.t == P.REQ_BLOCKS:
            hashes = list(msg.payload.get("hashes") or [])
            out = {}
            for h in hashes:
                b = self.blocks.get_block(h)
                if b is not None:
                    out[str(h)] = b
            return Msg(P.RSP_BLOCKS, {"blocks": out})

        if msg.t == P.REQ_SNAPSHOT:
            return Msg(P.RSP_ERROR, {"why":"use_snapshot_meta"})

        if msg.t == P.REQ_SNAPSHOT_META:
            if not self._ensure_snapshot_cache():
                return Msg(P.RSP_ERROR, {"why":"no_snapshot"})
            return Msg(P.RSP_SNAPSHOT_META, {"meta": dict(self._snap_meta)})

        if msg.t == P.REQ_SNAPSHOT_CHUNK:
            if not self._ensure_snapshot_cache():
                return Msg(P.RSP_ERROR, {"why":"no_snapshot"})
            sid = str(msg.payload.get("snapshot_id",""))
            idx = int(msg.payload.get("index", -1))
            if sid != str(self._snap_id):
                return Msg(P.RSP_ERROR, {"why":"wrong_snapshot_id"})
            if idx < 0 or idx >= len(self._snap_chunks):
                return Msg(P.RSP_ERROR, {"why":"bad_index"})
            data_b64 = base64.b64encode(self._snap_chunks[idx]).decode("utf-8")
            return Msg(P.RSP_SNAPSHOT_CHUNK, {"snapshot_id": sid, "index": idx, "data_b64": data_b64})


        if msg.t == P.REQ_TXS:
            if self.tx_service is None:
                return Msg(P.RSP_ERROR, {"why":"no_mempool"})
            return await self.tx_service.handle_txs(msg)

        if msg.t == P.REQ_PEERS:
            limit = int(msg.payload.get("limit",32))
            peers = self.discovery.get_peers(limit=limit)
            return Msg(P.RSP_PEERS, {"peers": peers})

        return Msg(P.RSP_ERROR, {"why":"unknown_request"})
