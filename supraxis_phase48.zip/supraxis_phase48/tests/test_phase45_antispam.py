import unittest
import asyncio

from supraxis.p2p.transport import AsyncTCPServer, AsyncTCPClient, TransportConfig
from supraxis.p2p.peer_manager import PeerPolicy
from supraxis.p2p.antispam import GlobalLimits
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P

class TestPhase45AntiSpam(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        async def handler(conn_id, msg):
            if msg.t == P.REQ_HELLO:
                return Msg(P.RSP_HELLO, {"ok": True})
            if msg.t == P.REQ_PEERS:
                return Msg(P.RSP_PEERS, {"peers": []})
            return Msg("error", {"why":"unknown"})
        pol = PeerPolicy()
        pol.reqs_per_sec = 100.0
        pol.burst = 200.0
        gl = GlobalLimits()
        gl.max_reqs_per_sec = 1.0
        gl.burst = 2.0
        gl.max_block_batch = 2
        cfg = TransportConfig(chain_id=1, max_frame_bytes=16384, idle_timeout_sec=5, policy=pol, global_limits=gl)
        self.server = AsyncTCPServer("127.0.0.1", 0, cfg, handler)
        await self.server.start()
        self.port = self.server._server.sockets[0].getsockname()[1]

    async def asyncTearDown(self):
        await self.server.close()

    async def test_global_rate_limit(self):
        c = AsyncTCPClient("127.0.0.1", self.port)
        await c.connect()
        await c.send(Msg(P.REQ_HELLO, {"node_id":"x","chain_id":1,"version":"v"}))
        await c.recv_one()
        # spam peers requests; global limiter should trigger
        for _ in range(10):
            await c.send(Msg(P.REQ_PEERS, {"limit": 1}))
        saw = False
        for _ in range(10):
            m = await c.recv_one(timeout=2.0)
            if m.t == "error" and m.payload.get("why") == "global_rate_limited":
                saw = True
                break
        await c.close()
        self.assertTrue(saw)

    async def test_global_block_quota(self):
        async def handler(conn_id, msg):
            if msg.t == P.REQ_HELLO:
                return Msg(P.RSP_HELLO, {"ok": True})
            if msg.t == P.REQ_BLOCKS:
                return Msg(P.RSP_BLOCKS, {"blocks": {}})
            return Msg("error", {"why":"unknown"})
        # new server with high global rate but low block batch
        gl = GlobalLimits()
        gl.max_reqs_per_sec = 100.0
        gl.burst = 200.0
        gl.max_block_batch = 2
        pol = PeerPolicy()
        cfg = TransportConfig(chain_id=1, max_frame_bytes=16384, idle_timeout_sec=5, policy=pol, global_limits=gl)
        srv = AsyncTCPServer("127.0.0.1", 0, cfg, handler)
        await srv.start()
        port = srv._server.sockets[0].getsockname()[1]

        c = AsyncTCPClient("127.0.0.1", port)
        await c.connect()
        await c.send(Msg(P.REQ_HELLO, {"node_id":"x","chain_id":1,"version":"v"}))
        await c.recv_one()
        await c.send(Msg(P.REQ_BLOCKS, {"hashes": ["a","b","c"]}))
        m = await c.recv_one()
        self.assertEqual(m.t, "error")
        self.assertEqual(m.payload.get("why"), "global_block_quota")
        await c.close()
        await srv.close()

if __name__ == "__main__":
    unittest.main()
