# Phase 43 — Real Transport + Peer Scoring + Basic Anti-Spam

Adds an asyncio TCP transport with strict framing + validation, plus peer scoring and rate limiting.

## Modules
- `src/supraxis/p2p/transport.py`
  - AsyncTCPServer / AsyncTCPClient
  - strict frame-size caps
  - schema validation
  - hello handshake chain_id enforcement
- `src/supraxis/p2p/peer_manager.py`
  - PeerInfo, PeerPolicy, PeerManager
  - scoring, decay, ban + eviction
  - request batch limits
- `src/supraxis/p2p/security.py`
  - token bucket limiter
  - frame size validation
  - payload schema validation

## Security Invariants
- Reject frames above max size
- Reject unknown message types
- Enforce chain_id on hello
- Rate limit inbound requests per peer
- Evict peers with low score or bans

## Next
Phase 44: peer discovery + peer DB + reconnect/backoff.
