# Phase 39 — Signed Header Gossip + Light Client Preference Rules

This phase integrates Phase 38 SignedHeaders into the propagation/sync path.

## GossipStore

`src/supraxis/consensus/gossip.py`

Adds:
- `signed_headers: Dict[block_hash -> SignedHeader]`
- `add_signed_header(SignedHeader)` stores both the signed header and its raw Header in HeaderChain.
- `signed_headers_from(start_hash, end_hash)` returns a contiguous signed-header path when available.

## LightClient

`LightClient.sync_signed_headers(state, signed_headers)`:
- preferred sync path
- enforces quorum-signed headers per epoch validator set
- enforces validator key registration
- verifies parent linkage and contiguous heights
- optionally verifies embedded QC (defense-in-depth)

`LightClient.sync_headers(state, headers)`:
- unsigned headers now require a QC (`unsigned_header_requires_qc`)
- keeps cryptographic QC verification + epoch-aware validator updates (Phase 37/36)

## Next

Phase 40: end-to-end fast sync flow:
- choose best signed checkpoint
- fetch signed header chain from checkpoint head to tip
- verify + accept
- then transition to full node by fetching blocks/txs as needed.
