import unittest
from supraxis.envelope import EnvelopeV1
from supraxis.crypto import sha256

class EnvelopeTests(unittest.TestCase):
    def test_canonical_roundtrip(self):
        payload = b'{"a":1,"b":2}'
        env = EnvelopeV1(
            version=1,
            origin_chain=1,
            origin_tx=(b"\x00"*31)+b"\x01",
            origin_sender=(b"\x00"*31)+b"\x02",
            target_chain=100,
            target_contract=(b"\x00"*31)+b"\xaa",
            nonce=1,
            gas_limit=123,
            payload_type=1,
            payload=payload,
            payload_hash=sha256(payload),
            cap_refs=[],
            signatures=[],
        )
        b = env.canonical_bytes()
        env2 = EnvelopeV1.decode(b)
        env2.validate(require_signatures=False)
        self.assertEqual(env2.canonical_bytes(), b)

if __name__ == "__main__":
    unittest.main()
