Run tests (from repo root):

```bash
PYTHONPATH=src python -m unittest -q
```
