# SUPRAXIS (Phase 5)

This Phase 5 drop upgrades the Phase 4 scaffold with:

- **Binary SIR v1** canonical encoding (`.sirb`) + disassembler
- **Golden fixtures** (pinned `.sirb` bytes + expected replay hashes)
- **Block runner** (multi-envelope batches, canonical ordering, nonce checks)
- **Deterministic gas accounting** enforced against `Envelope.gas_limit`
- **Driver interface layer** (EVM / TON stubs) with clear adapter boundaries

> Still not production-ready (crypto + consensus + full compiler pipeline remain future work).

## Quickstart

```bash
# 1) run demo end-to-end using binary SIR
PYTHONPATH=src python -m supraxis.cli state init --out /tmp/state.json
PYTHONPATH=src python -m supraxis.cli cap add --state /tmp/state.json --name cap_ping --scope ping --chain 100 --expires 999999999

PYTHONPATH=src python -m supraxis.cli envelope create \
  --origin-chain 1 \
  --origin-tx 0x0000000000000000000000000000000000000000000000000000000000000001 \
  --origin-sender 0x0000000000000000000000000000000000000000000000000000000000000002 \
  --target-chain 100 \
  --target-contract 0x00000000000000000000000000000000000000000000000000000000000000aa \
  --nonce 1 \
  --gas-limit 500000 \
  --payload-type 1 \
  --payload-json examples/payload.json \
  --out /tmp/env.bin

# compile json SIR -> binary
PYTHONPATH=src python -m supraxis.cli sir compile --in examples/hello.sir.json --out /tmp/hello.sirb
PYTHONPATH=src python -m supraxis.cli sir disasm --in /tmp/hello.sirb

# block replay (supports multiple envelopes)
PYTHONPATH=src python -m supraxis.cli block run --sirb /tmp/hello.sirb --state /tmp/state.json --envelopes /tmp/env.bin --out /tmp/block.json
PYTHONPATH=src python -m supraxis.cli block hash --in /tmp/block.json
```

## Tests

```bash
PYTHONPATH=src python -m unittest -q
```
