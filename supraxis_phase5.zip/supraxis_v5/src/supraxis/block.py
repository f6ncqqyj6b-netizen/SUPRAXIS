from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List
import json

from .envelope import EnvelopeV1, envelope_sort_key
from .state import SupraxisState
from .runtime import execute_sir, canonical_json
from .crypto import sha256
from .errors import ReplayError
from .gas import gas_cost

@dataclass
class BlockResult:
    state_json: str
    events: List[Dict[str, Any]]
    block_hash: str

def run_block(state: SupraxisState, sir_ops: List[Dict[str, Any]], envelopes: List[EnvelopeV1]) -> BlockResult:
    envs = sorted(envelopes, key=envelope_sort_key)
    all_events: List[Dict[str, Any]] = []
    h = sha256(b"SUPRAXIS_BLOCK_V1")

    for env in envs:
        env.validate(require_signatures=False)

        last = state.get_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract)
        if env.nonce <= last:
            raise ReplayError("block rejected: nonce not increasing")

        # deterministic context derived only from envelope
        ctx = {
            "origin_chain": env.origin_chain,
            "origin_sender": env.origin_sender.hex(),
            "target_chain": env.target_chain,
            "target_contract": env.target_contract.hex(),
            "nonce": env.nonce,
            "gas_limit": env.gas_limit,
            "payload_type": env.payload_type,
            "payload_hash": env.payload_hash.hex(),
            "timestamp": 0,
        }

        # gas accounting
        gas_used = 0
        for op in sir_ops:
            gas_used += gas_cost(str(op.get("op")))
            if gas_used > env.gas_limit:
                raise ReplayError("out of gas (deterministic)")

        events = execute_sir(state, sir_ops, ctx)
        state.set_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract, env.nonce)

        for e in events:
            item = {"event": e.event, "payload": e.payload, "ctx": ctx}
            all_events.append(item)
            h = sha256(h + canonical_json(item))

        # include state hash step for stronger binding (still deterministic)
        h = sha256(h + state.to_json().encode("utf-8"))

    return BlockResult(state_json=state.to_json(), events=all_events, block_hash=h.hex())

def block_hash(block_json: str) -> str:
    obj = json.loads(block_json)
    return sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")).hex()
