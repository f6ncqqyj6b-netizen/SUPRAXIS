from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Optional
from .canonical import (
    pack_u16, pack_u32, pack_u64, pack_bytes_u16, pack_bytes_u32,
    read_u16, read_u32, read_u64, read_bytes32, read_bytes_u16, read_bytes_u32
)
from .crypto import sha256, Sig, verify_signature
from .errors import EnvelopeValidationError, CanonicalEncodingError

SCES_VERSION_V1 = 1

@dataclass(frozen=True)
class EnvelopeV1:
    version: int
    origin_chain: int
    origin_tx: bytes
    origin_sender: bytes
    target_chain: int
    target_contract: bytes
    nonce: int
    gas_limit: int
    payload_type: int
    payload: bytes
    payload_hash: bytes
    cap_refs: List[bytes]
    signatures: List[Sig]

    def canonical_bytes(self) -> bytes:
        # canonical sort lists
        caps = sorted(self.cap_refs)
        sigs = sorted(self.signatures, key=lambda s: (s.scheme, s.pubkey, s.sig))

        if len(self.origin_tx) != 32 or len(self.origin_sender) != 32 or len(self.target_contract) != 32 or len(self.payload_hash) != 32:
            raise CanonicalEncodingError("bytes32 field wrong length")

        out = bytearray()
        out += pack_u16(self.version)
        out += pack_u32(self.origin_chain)
        out += self.origin_tx
        out += self.origin_sender
        out += pack_u32(self.target_chain)
        out += self.target_contract
        out += pack_u64(self.nonce)
        out += pack_u64(self.gas_limit)
        out += pack_u16(self.payload_type)
        out += pack_bytes_u32(self.payload)
        out += self.payload_hash
        out += pack_u32(len(caps))
        for c in caps:
            if len(c) != 32:
                raise CanonicalEncodingError("cap_ref must be bytes32")
            out += c
        out += pack_u32(len(sigs))
        for s in sigs:
            out += pack_u16(int(s.scheme))
            out += pack_bytes_u16(s.pubkey)
            out += pack_bytes_u16(s.sig)
        return bytes(out)

    @staticmethod
    def decode(buf: bytes) -> "EnvelopeV1":
        off = 0
        version, off = read_u16(buf, off)
        origin_chain, off = read_u32(buf, off)
        origin_tx, off = read_bytes32(buf, off)
        origin_sender, off = read_bytes32(buf, off)
        target_chain, off = read_u32(buf, off)
        target_contract, off = read_bytes32(buf, off)
        nonce, off = read_u64(buf, off)
        gas_limit, off = read_u64(buf, off)
        payload_type, off = read_u16(buf, off)
        payload, off = read_bytes_u32(buf, off)
        payload_hash, off = read_bytes32(buf, off)
        cap_n, off = read_u32(buf, off)
        cap_refs: List[bytes] = []
        for _ in range(cap_n):
            c, off = read_bytes32(buf, off)
            cap_refs.append(c)
        sig_n, off = read_u32(buf, off)
        signatures: List[Sig] = []
        for _ in range(sig_n):
            scheme, off = read_u16(buf, off)
            pubkey, off = read_bytes_u16(buf, off)
            sig, off = read_bytes_u16(buf, off)
            signatures.append(Sig(scheme=scheme, pubkey=pubkey, sig=sig))
        if off != len(buf):
            raise CanonicalEncodingError("trailing bytes in envelope")
        env = EnvelopeV1(
            version=version,
            origin_chain=origin_chain,
            origin_tx=origin_tx,
            origin_sender=origin_sender,
            target_chain=target_chain,
            target_contract=target_contract,
            nonce=nonce,
            gas_limit=gas_limit,
            payload_type=payload_type,
            payload=payload,
            payload_hash=payload_hash,
            cap_refs=cap_refs,
            signatures=signatures,
        )
        return env

    def validate(self, require_signatures: bool = True) -> None:
        if self.version != SCES_VERSION_V1:
            raise EnvelopeValidationError(f"unsupported SCES version: {self.version}")
        # payload hash integrity
        if sha256(self.payload) != self.payload_hash:
            raise EnvelopeValidationError("payload_hash mismatch")
        # canonicality: re-encode must match (after canonical sorts)
        enc = self.canonical_bytes()
        dec2 = EnvelopeV1.decode(enc)
        if dec2.canonical_bytes() != enc:
            raise EnvelopeValidationError("canonical roundtrip mismatch")
        if require_signatures:
            if len(self.signatures) == 0:
                raise EnvelopeValidationError("missing signatures")
            msg = self.message_bytes_for_signing()
            for s in self.signatures:
                if not verify_signature(s, msg):
                    raise EnvelopeValidationError("signature verification failed")

    def message_bytes_for_signing(self) -> bytes:
        """Message to sign: canonical envelope without signatures list (sigs count = 0).
        This avoids signature malleability via ordering.
        """
        caps = sorted(self.cap_refs)
        if len(self.origin_tx) != 32 or len(self.origin_sender) != 32 or len(self.target_contract) != 32 or len(self.payload_hash) != 32:
            raise CanonicalEncodingError("bytes32 field wrong length")
        out = bytearray()
        out += pack_u16(self.version)
        out += pack_u32(self.origin_chain)
        out += self.origin_tx
        out += self.origin_sender
        out += pack_u32(self.target_chain)
        out += self.target_contract
        out += pack_u64(self.nonce)
        out += pack_u64(self.gas_limit)
        out += pack_u16(self.payload_type)
        out += pack_bytes_u32(self.payload)
        out += self.payload_hash
        out += pack_u32(len(caps))
        for c in caps:
            out += c
        out += pack_u32(0)  # signatures count
        return bytes(out)

def envelope_sort_key(env: EnvelopeV1) -> Tuple:
    return (
        env.origin_chain,
        env.origin_sender,
        env.target_chain,
        env.target_contract,
        env.nonce,
        env.payload_hash,
    )
