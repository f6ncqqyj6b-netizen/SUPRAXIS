from __future__ import annotations
from typing import Dict

# Deterministic gas costs (placeholder constants).
# Real deployments would calibrate per driver and keep it versioned.
GAS_TABLE: Dict[str, int] = {
    "CAP_REQUIRE": 500,
    "EMIT": 200,
    "STORE": 800,
    "ASSERT": 50,
    "RET": 0,
}

def gas_cost(op_name: str) -> int:
    return int(GAS_TABLE.get(op_name, 10_000_000))  # unknown ops are invalidly expensive
