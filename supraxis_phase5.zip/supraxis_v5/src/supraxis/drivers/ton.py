from __future__ import annotations
from .base import Driver, DriverContext

class TonDriver(Driver):
    def validate_target(self, ctx: DriverContext, target_contract: bytes) -> None:
        if len(target_contract) != 32:
            raise ValueError("TON driver expects target_contract as 32 bytes canonical id")

    def submit_envelope(self, ctx: DriverContext, envelope_bytes: bytes) -> str:
        return "ton:" + ("0"*64)
