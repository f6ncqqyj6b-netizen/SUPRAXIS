from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Optional

@dataclass(frozen=True)
class DriverContext:
    chain_id: int
    network: str  # e.g. "testnet", "mainnet"

class Driver(ABC):
    """Driver boundary: chain-specific validation and submission.

    Phase 5: purely structural; does not talk to networks.
    """

    @abstractmethod
    def validate_target(self, ctx: DriverContext, target_contract: bytes) -> None:
        ...

    @abstractmethod
    def submit_envelope(self, ctx: DriverContext, envelope_bytes: bytes) -> str:
        """Submit the envelope to the chain inbox. Returns chain tx hash (string)."""
        ...
