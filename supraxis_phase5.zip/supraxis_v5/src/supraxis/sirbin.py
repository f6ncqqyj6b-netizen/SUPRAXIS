from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import json

from .canonical import pack_u16, pack_u32, read_u16, read_u32
from .errors import ReplayError

MAGIC = b"SIRB"
VERSION = 1

# Opcodes
OP_CAP_REQUIRE = 0x01
OP_EMIT       = 0x02
OP_STORE      = 0x03
OP_ASSERT     = 0x04
OP_RET        = 0xFF

def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def _pack_str(s: str) -> bytes:
    b = s.encode("utf-8")
    return pack_u16(len(b)) + b

def _read_str(buf: bytes, off: int) -> Tuple[str, int]:
    n, off = read_u16(buf, off)
    if off + n > len(buf):
        raise ReplayError("unexpected EOF reading string")
    return buf[off:off+n].decode("utf-8"), off + n

@dataclass(frozen=True)
class SirBinProgram:
    version: int
    functions: Dict[str, List[Dict[str, Any]]]

    def encode(self) -> bytes:
        out = bytearray()
        out += MAGIC
        out += pack_u16(VERSION)
        fn_items = list(self.functions.items())
        out += pack_u16(len(fn_items))
        for name, ops in fn_items:
            out += _pack_str(name)
            out += pack_u32(len(ops))
            for op in ops:
                out += bytes([opcode_for(op)])
                out += encode_operands(op)
        return bytes(out)

    @staticmethod
    def decode(buf: bytes) -> "SirBinProgram":
        if len(buf) < 8 or buf[:4] != MAGIC:
            raise ReplayError("bad SIRB magic")
        off = 4
        ver, off = read_u16(buf, off)
        if ver != VERSION:
            raise ReplayError(f"unsupported SIRB version: {ver}")
        fn_count, off = read_u16(buf, off)
        fns: Dict[str, List[Dict[str, Any]]] = {}
        for _ in range(fn_count):
            name, off = _read_str(buf, off)
            op_count, off = read_u32(buf, off)
            ops: List[Dict[str, Any]] = []
            for _ in range(op_count):
                if off >= len(buf):
                    raise ReplayError("unexpected EOF reading opcode")
                opc = buf[off]
                off += 1
                op, off = decode_op(buf, off, opc)
                ops.append(op)
            fns[name] = ops
        if off != len(buf):
            raise ReplayError("trailing bytes in SIRB")
        return SirBinProgram(version=VERSION, functions=fns)

def opcode_for(op: Dict[str, Any]) -> int:
    name = op.get("op")
    if name == "CAP_REQUIRE":
        return OP_CAP_REQUIRE
    if name == "EMIT":
        return OP_EMIT
    if name == "STORE":
        return OP_STORE
    if name == "ASSERT":
        return OP_ASSERT
    if name == "RET":
        return OP_RET
    raise ReplayError(f"unknown op for encoding: {name}")

def encode_operands(op: Dict[str, Any]) -> bytes:
    name = op["op"]
    if name == "CAP_REQUIRE":
        return _pack_str(str(op["cap"])) + _pack_str(str(op["scope"]))
    if name == "EMIT":
        payload = op.get("payload")
        payload_b = canonical_json_bytes(payload)
        return _pack_str(str(op["event"])) + pack_u32(len(payload_b)) + payload_b
    if name == "STORE":
        val_b = canonical_json_bytes(op.get("value"))
        return _pack_str(str(op["key"])) + pack_u32(len(val_b)) + val_b
    if name == "ASSERT":
        v = 1 if bool(op.get("value")) else 0
        return bytes([v])
    if name == "RET":
        return b""
    raise ReplayError(f"cannot encode operands: {name}")

def decode_op(buf: bytes, off: int, opc: int) -> Tuple[Dict[str, Any], int]:
    if opc == OP_CAP_REQUIRE:
        cap, off = _read_str(buf, off)
        scope, off = _read_str(buf, off)
        return {"op":"CAP_REQUIRE","cap":cap,"scope":scope}, off
    if opc == OP_EMIT:
        event, off = _read_str(buf, off)
        n, off = read_u32(buf, off)
        if off + n > len(buf):
            raise ReplayError("unexpected EOF payload json")
        payload = json.loads(buf[off:off+n].decode("utf-8"))
        off += n
        return {"op":"EMIT","event":event,"payload":payload}, off
    if opc == OP_STORE:
        key, off = _read_str(buf, off)
        n, off = read_u32(buf, off)
        if off + n > len(buf):
            raise ReplayError("unexpected EOF value json")
        val = json.loads(buf[off:off+n].decode("utf-8"))
        off += n
        return {"op":"STORE","key":key,"value":val}, off
    if opc == OP_ASSERT:
        if off >= len(buf):
            raise ReplayError("unexpected EOF ASSERT")
        v = buf[off]
        off += 1
        if v not in (0,1):
            raise ReplayError("ASSERT_BOOL must be 0/1")
        return {"op":"ASSERT","value": bool(v)}, off
    if opc == OP_RET:
        return {"op":"RET"}, off
    raise ReplayError(f"unknown opcode: 0x{opc:02x}")

def disasm(buf: bytes) -> str:
    prog = SirBinProgram.decode(buf)
    lines: List[str] = []
    lines.append(f"; SIRB v{prog.version}")
    for fn, ops in prog.functions.items():
        lines.append(f"fn {fn}:")
        for i, op in enumerate(ops):
            lines.append(f"  {i:04d}  {op}")
    return "\n".join(lines) + "\n"
