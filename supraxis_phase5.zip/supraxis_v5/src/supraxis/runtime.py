from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List
import json
from .errors import ReplayError, CapabilityError
from .crypto import sha256
from .state import SupraxisState

@dataclass
class Event:
    event: str
    payload: Any  # JSON-serializable

def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def event_log_hash(events: List[Event]) -> bytes:
    # Deterministic: hash concatenation of canonical json lines
    h = sha256(b"SUPRAXIS_EVENTLOG_V1")
    for e in events:
        h = sha256(h + canonical_json({"event": e.event, "payload": e.payload}))
    return h

def cap_require(state: SupraxisState, cap_name: str, scope: str, chain_id: int, timestamp: int) -> None:
    # For skeleton, cap_id is sha256(cap_name) and stored in state.caps
    cap_id = sha256(cap_name.encode("utf-8")).hex()
    cap = state.caps.get(cap_id)
    if not cap:
        raise CapabilityError(f"missing capability: {cap_name}")
    if cap.get("scope") != scope:
        raise CapabilityError("cap scope mismatch")
    if int(cap.get("chain", -1)) != int(chain_id):
        raise CapabilityError("cap chain mismatch")
    if int(cap.get("expires", 0)) < int(timestamp):
        raise CapabilityError("cap expired")

def execute_sir(state: SupraxisState, sir_ops: List[Dict[str, Any]], ctx: Dict[str, Any]) -> List[Event]:
    events: List[Event] = []
    pc = 0
    while pc < len(sir_ops):
        op = sir_ops[pc]
        name = op.get("op")
        if name == "CAP_REQUIRE":
            cap_require(
                state=state,
                cap_name=str(op["cap"]),
                scope=str(op["scope"]),
                chain_id=int(ctx["target_chain"]),
                timestamp=int(ctx["timestamp"]),
            )
        elif name == "EMIT":
            events.append(Event(event=str(op["event"]), payload=op.get("payload")))
        elif name == "STORE":
            key = str(op["key"])
            state.storage[key] = op.get("value")
        elif name == "ASSERT":
            # deterministic assertion on JSON booleans only for skeleton
            if not bool(op.get("value")):
                raise ReplayError("ASSERT failed")
        elif name == "RET":
            break
        else:
            raise ReplayError(f"unknown op: {name}")
        pc += 1
    return events
