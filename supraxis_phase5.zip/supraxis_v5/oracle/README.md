# Oracle (Skeleton)

In production:
- 11 nodes (recommended)
- 7-of-11 quorum
- stake + slashing
- deterministic update epochs

Phase 4 provides an EVM quorum stub under token/evm/OracleQuorum.sol.
