# SCES v1 (Canonical Envelope)

This skeleton implements a minimal SCES v1 encoder/decoder with strict canonical rules.

## EnvelopeV1 fields (fixed order)
- version: u16 (must be 1)
- origin_chain: u32
- origin_tx: bytes32
- origin_sender: bytes32
- target_chain: u32
- target_contract: bytes32
- nonce: u64
- gas_limit: u64
- payload_type: u16
- payload: bytes (u32 length + bytes)
- payload_hash: bytes32 (SHA-256(payload))
- cap_refs: list<bytes32> (u32 count + items)
- signatures: list<Sig> (u32 count + each sig)

Sig:
- scheme: u16  (1=ed25519 placeholder, 2=secp256k1 placeholder)
- pubkey: bytes (u16 length + bytes)
- sig: bytes    (u16 length + bytes)

## Canonical Rules
- Big-endian integers
- Exact lengths for bytes32
- Lists sorted:
  - cap_refs sorted lexicographically
  - signatures sorted by (scheme, pubkey, sig) lexicographically on bytes
