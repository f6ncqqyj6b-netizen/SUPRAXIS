# SIR Binary v1 (.sirb)

This repo defines a minimal canonical binary encoding for SIR suitable for golden-byte fixtures.

## Header
- magic: 4 bytes = ASCII "SIRB"
- version: u16 = 1
- fn_count: u16 (Phase 5 uses 1: "main")

## Function Table
For each function:
- name_len: u16
- name: bytes (utf-8)
- op_count: u32
- ops: sequence of op records

## Op Record
- opcode: u8
- operand bytes: opcode-dependent, canonical big-endian

### Opcodes (v1)
0x01 CAP_REQUIRE
  - cap_name_len: u16 + cap_name utf-8
  - scope_len: u16 + scope utf-8

0x02 EMIT
  - event_len: u16 + event utf-8
  - payload_json_len: u32 + payload_json (canonical JSON bytes)

0x03 STORE
  - key_len: u16 + key utf-8
  - value_json_len: u32 + value_json (canonical JSON bytes)

0x04 ASSERT_BOOL
  - value: u8 (0 or 1)

0xFF RET
  - no operands

## Canonical JSON
Payload/value JSON must be encoded as:
`json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")`

## Determinism
- Function ops are executed in order.
- No optional fields; no varint ambiguity.
