import unittest
from supraxis.state import SupraxisState
from supraxis.crypto import sha256
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.committee import Committee
from supraxis.canonical import bitset_len, bitset_set

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class StakeSlashCommitteeFromStakeTests(unittest.TestCase):
    def _gov_state(self):
        st = SupraxisState()
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global", "chain":100, "expires": 10**18}
        return st

    def test_committee_from_stake_allows_weighted_quorum(self):
        st = self._gov_state()

        # Program: stake pk1=4, pk2=3, register committee for epoch 7 from top2; RET
        functions = {
            "main": [
                {"op":"GOV_STAKE", "pubkey":"0x706b31", "amount":4, "lock_epochs":0},
                {"op":"GOV_STAKE", "pubkey":"0x706b32", "amount":3, "lock_epochs":0},
                {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE", "epoch":7, "size":2},
                {"op":"RET"},
            ]
        }
        prog = SirBinProgram(version=1, functions=functions)

        # Envelope v2 to execute governance ops (nonce 1)
        payload=b'{"gov":1}'
        env1_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[])
        sig1=make_stub_signature(1,b"pk_gov", env1_base.signing_message())
        env1=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[sig1])

        # Run first block: committee stored & registered
        run_block(st, prog.functions, [env1], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))

        cid = st.committee_registry.get("7")
        self.assertIsNotNone(cid)
        committee = st.get_committee_by_id(cid)
        self.assertIsNotNone(committee)
        assert committee is not None

        # Build v3 envelope epoch 7 with quorum proof using both members (nonce 2)
        cid_bytes = bytes.fromhex(cid)
        payload2=b'{"v3":1}'
        ph2=sha256(payload2)
        base_v3=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payload2,ph2,[],[],None)
        msg2=base_v3.signing_message()
        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)
        s0=make_stub_signature(1,b"pk1",msg2)
        s1=make_stub_signature(1,b"pk2",msg2)
        qp=QuorumProofV1(bytes(bm), [Signature(s0.scheme,b"",s0.sig), Signature(s1.scheme,b"",s1.sig)])
        env2=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payload2,ph2,[],[],qp)

        # Program for v3 execution: RET only
        prog2 = SirBinProgram(version=1, functions={"main":[{"op":"RET"}]})

        # Should pass with min_weight=7 (4+3)
        run_block(st, prog2.functions, [env2], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7))

    def test_slash_can_break_weighted_quorum(self):
        st = self._gov_state()

        # Setup: stake & register committee epoch 7
        functions = {
            "main": [
                {"op":"GOV_STAKE", "pubkey":"0x706b31", "amount":4, "lock_epochs":0},
                {"op":"GOV_STAKE", "pubkey":"0x706b32", "amount":3, "lock_epochs":0},
                {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE", "epoch":7, "size":2},
                {"op":"RET"},
            ]
        }
        prog = SirBinProgram(version=1, functions=functions)

        payload=b'{"gov":1}'
        env1_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[])
        sig1=make_stub_signature(1,b"pk_gov", env1_base.signing_message())
        env1=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[sig1])
        run_block(st, prog.functions, [env1], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))

        # Slash pk2 by 2 (so weights become 4 and 1). Re-register committee epoch 7 from stake.
        functions_slash = {"main":[
            {"op":"GOV_SLASH", "pubkey":"0x706b32", "amount":2, "reason":"test"},
            {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE", "epoch":7, "size":2},
            {"op":"RET"},
        ]}
        prog_slash = SirBinProgram(version=1, functions=functions_slash)
        payloads=b'{"gov":2}'
        envs_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloads,sha256(payloads),[],[])
        sigs=make_stub_signature(1,b"pk_gov", envs_base.signing_message())
        envs=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payloads,sha256(payloads),[],[sigs])
        run_block(st, prog_slash.functions, [envs], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))

        cid = st.committee_registry.get("7")
        committee = st.get_committee_by_id(cid)
        assert committee is not None

        # v3 quorum with both signatures but min_weight 7 should now FAIL (total=5)
        cid_bytes=bytes.fromhex(cid)
        payload2=b'{"v3":1}'
        ph2=sha256(payload2)
        base_v3=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),3,10_000_000,1,payload2,ph2,[],[],None)
        msg2=base_v3.signing_message()
        bm=bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)
        s0=make_stub_signature(1,b"pk1",msg2)
        s1=make_stub_signature(1,b"pk2",msg2)
        qp=QuorumProofV1(bytes(bm), [Signature(s0.scheme,b"",s0.sig), Signature(s1.scheme,b"",s1.sig)])
        env2=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),3,10_000_000,1,payload2,ph2,[],[],qp)

        prog2 = SirBinProgram(version=1, functions={"main":[{"op":"RET"}]})
        with self.assertRaises(Exception):
            run_block(st, prog2.functions, [env2], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7))

if __name__ == "__main__":
    unittest.main()
