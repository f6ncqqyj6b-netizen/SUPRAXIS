from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List
import json
from .errors import ReplayError, CapabilityError
from .crypto import sha256
from .state import SupraxisState
from .sirbin import MAX_CALL_DEPTH
from .committee import Committee

@dataclass
class Event:
    event: str
    payload: Any

def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def cap_require(state: SupraxisState, cap_name: str, scope: str, chain_id: int, timestamp: int) -> None:
    cap_id = sha256(cap_name.encode("utf-8")).hex()
    cap = state.caps.get(cap_id)
    if not cap: raise CapabilityError("missing capability")
    if cap.get("scope") != scope: raise CapabilityError("scope mismatch")
    if int(cap.get("chain",-1)) != int(chain_id): raise CapabilityError("chain mismatch")
    if int(cap.get("expires",0)) < int(timestamp): raise CapabilityError("expired")

def gov_require(state: SupraxisState, ctx: Dict[str, Any]) -> None:
    # Deterministic governance gate. Must be provisioned in state.caps.
    cap_require(state, "GOVERNANCE", "global", int(ctx["target_chain"]), int(ctx["timestamp"]))

def execute_functions(state: SupraxisState, functions: Dict[str, List[Dict[str, Any]]], entry: str, ctx: Dict[str, Any]) -> List[Event]:
    if entry not in functions: raise ReplayError("missing entry")
    events: List[Event] = []
    call_stack=[entry]
    ip_stack=[0]
    while call_stack:
        if len(call_stack) > MAX_CALL_DEPTH: raise ReplayError("CALL depth exceeded")
        fn=call_stack[-1]; ops=functions[fn]; ip=ip_stack[-1]
        if ip >= len(ops): raise ReplayError("function ended without RET")
        op=ops[ip]; ip_stack[-1]=ip+1
        name=op.get("op")

        if name=="CAP_REQUIRE":
            cap_require(state, str(op["cap"]), str(op["scope"]), int(ctx["target_chain"]), int(ctx["timestamp"]))

        # -----------------------
        # Governance ops (Phase 13)
        # -----------------------
        elif name=="GOV_REGISTER_COMMITTEE_JSON":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            committee_json = json.dumps(op["committee"], sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            cid = state.register_committee_json(epoch, committee_json)
            events.append(Event(event="GOV_COMMITTEE_REGISTERED", payload={"epoch": epoch, "committee_id": cid}))

        elif name=="GOV_REGISTER_COMMITTEE_ID":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            cid = str(op["committee_id"])
            state.register_committee(epoch, cid)
            events.append(Event(event="GOV_COMMITTEE_ID_REGISTERED", payload={"epoch": epoch, "committee_id": cid.lower().replace("0x","")}))

        elif name=="GOV_SET_GRACE":
            gov_require(state, ctx)
            grace = int(op["grace"])
            state.set_rotation_grace(grace)
            events.append(Event(event="GOV_GRACE_SET", payload={"grace": int(state.rotation_grace_epochs)}))

        # -----------------------
        # Stake + slashing (Phase 14)
        # -----------------------
        elif name=="GOV_STAKE":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            lock_epochs = int(op.get("lock_epochs", 0))
            cur_epoch = int(ctx.get("epoch", 0))
            lock_until = cur_epoch + max(0, lock_epochs)
            state.stake_add(pubkey, amount, lock_until)
            amt, locked = state.stake_of(pubkey)
            events.append(Event(event="GOV_STAKED", payload={"pubkey": pubkey, "amount": int(amount), "new_total": int(amt), "locked_until": int(locked)}))

        elif name=="GOV_UNSTAKE":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            cur_epoch = int(ctx.get("epoch", 0))
            amt, locked = state.stake_of(pubkey)
            if cur_epoch < int(locked):
                raise ReplayError("stake locked")
            state.stake_sub(pubkey, amount)
            amt2, locked2 = state.stake_of(pubkey)
            events.append(Event(event="GOV_UNSTAKED", payload={"pubkey": pubkey, "amount": int(amount), "new_total": int(amt2), "locked_until": int(locked2)}))

        elif name=="GOV_SLASH":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            reason = str(op.get("reason", ""))
            taken = state.slash(pubkey, amount)
            amt2, locked2 = state.stake_of(pubkey)
            events.append(Event(event="GOV_SLASHED", payload={"pubkey": pubkey, "requested": int(amount), "slashed": int(taken), "new_total": int(amt2), "reason": reason}))

        elif name=="GOV_REGISTER_COMMITTEE_FROM_STAKE":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            size = int(op["size"])
            top = state.top_stakers(size)
            members = [{"pubkey": "0x"+pk, "weight": int(amt), "schemes": [1]} for pk, amt in top]
            committee = Committee.from_dict({"members": members})
            cid = committee.committee_id()
            # Store canonical json and register
            state.committee_store[cid] = committee.canonical_json()
            state.register_committee(epoch, cid)
            events.append(Event(event="GOV_COMMITTEE_FROM_STAKE", payload={"epoch": epoch, "committee_id": cid, "size": len(members)}))

        # -----------------------
        # General ops
        # -----------------------
        elif name=="EMIT":
            events.append(Event(event=str(op["event"]), payload=op.get("payload")))

        elif name=="STORE":
            state.storage[str(op["key"])] = op.get("value")

        elif name=="ASSERT":
            if not bool(op.get("value")): raise ReplayError("ASSERT failed")

        elif name=="CALL":
            callee=str(op["fn"])
            if callee not in functions: raise ReplayError("unknown callee")
            call_stack.append(callee); ip_stack.append(0)

        elif name=="RET":
            call_stack.pop(); ip_stack.pop()

        else:
            raise ReplayError("unknown op")
    return events
