# SUPRAXIS (Phase 14)

Phase 14 adds **stake-backed committees** and **slashing**.

You now have:
- A deterministic stake ledger in state
- Governance-gated stake/unstake/slash operations
- Deterministic committee derivation from stake for a given epoch
- All still replay-safe and fully deterministic

## New State Fields

- `stakes`: mapping `pubkey_hex -> { amount, locked_until }`

## New Governance Ops (runtime + SIRB)

All governance ops require the `GOVERNANCE` capability (same as Phase 13).

### `GOV_STAKE`
Adds stake to a pubkey, with optional lock duration.
- Inputs: `pubkey` (hex), `amount` (u64), `lock_epochs` (u32, optional)
- Behavior: `locked_until = max(existing_lock, ctx.epoch + lock_epochs)`

### `GOV_UNSTAKE`
Withdraw stake once unlocked.
- Inputs: `pubkey` (hex), `amount` (u64)
- Requires: `ctx.epoch >= locked_until`

### `GOV_SLASH`
Reduces stake (capped at existing stake).
- Inputs: `pubkey` (hex), `amount` (u64), `reason` (string optional)

### `GOV_REGISTER_COMMITTEE_FROM_STAKE`
Deterministically builds a committee from the top N stakers and registers it for an epoch.
- Inputs: `epoch` (u64), `size` (u32)
- Committee ordering: sorted by `(-stake_amount, pubkey_hex)`
- Weights: `weight = stake_amount`

This enables **stake-weighted quorum proofs** in EnvelopeV3.

## Tests

```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
