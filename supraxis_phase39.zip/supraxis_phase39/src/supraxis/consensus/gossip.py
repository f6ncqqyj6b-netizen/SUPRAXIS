from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from .signed_checkpoint import SignedCheckpoint
from .headerchain import Header, HeaderChain
from .signed_header import SignedHeader

@dataclass
class GossipStore:
    """In-memory cache for networkless simulation: stores signed checkpoints and headers.

    Phase 39: supports both raw headers and quorum-signed headers.
    """
    checkpoints: Dict[int, List[SignedCheckpoint]] = field(default_factory=dict)  # epoch -> list
    headers: HeaderChain = field(default_factory=HeaderChain)
    signed_headers: Dict[str, SignedHeader] = field(default_factory=dict)  # block_hash -> SignedHeader

    def add_checkpoint(self, scp: SignedCheckpoint) -> None:
        ep = int(scp.checkpoint.epoch)
        lst = self.checkpoints.get(ep, [])
        lst.append(scp)
        self.checkpoints[ep] = lst

    def best_checkpoint(self, min_height: int = 0) -> Optional[SignedCheckpoint]:
        best = None
        for _, lst in self.checkpoints.items():
            for scp in lst:
                if int(scp.checkpoint.height) < int(min_height):
                    continue
                if best is None or int(scp.checkpoint.height) > int(best.checkpoint.height):
                    best = scp
        return best

    def add_header(self, h: Header) -> None:
        self.headers.add(h)

    def add_signed_header(self, sh: SignedHeader) -> None:
        # Store signed header by hash and also store underlying header in header chain for parent-link pathfinding.
        self.signed_headers[str(sh.header.block_hash)] = sh
        self.headers.add(sh.header)

    def tip_header(self, chain_id: int) -> Optional[Header]:
        return self.headers.tip(chain_id)

    def tip_signed_header(self, chain_id: int) -> Optional[SignedHeader]:
        tip = self.headers.tip(chain_id)
        if tip is None:
            return None
        return self.signed_headers.get(str(tip.block_hash))

    def headers_from(self, start_hash: str, end_hash: str) -> List[Header]:
        return self.headers.path_from(start_hash, end_hash)

    def signed_headers_from(self, start_hash: str, end_hash: str) -> List[SignedHeader]:
        hs = self.headers.path_from(start_hash, end_hash)
        out: List[SignedHeader] = []
        for h in hs:
            sh = self.signed_headers.get(str(h.block_hash))
            if sh is None:
                # if any segment missing signatures, stop (caller can fallback to raw headers)
                break
            out.append(sh)
        return out
