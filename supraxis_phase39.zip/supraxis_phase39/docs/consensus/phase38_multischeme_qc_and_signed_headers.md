# Phase 38 — Multi-Scheme QCs + Signed Headers

This phase adds:

1) **Multi-scheme QC support** (Ed25519 + secp256k1).
2) **SignedHeader** primitive (validators can quorum-sign headers).

## QC Signature Format

`QC.sigs` is now:

`Dict[voter_vid -> {"scheme": int, "sig": bytes}]`

Schemes:
- 11 = Ed25519
- 12 = secp256k1 (ECDSA)

QC verification (`verify_qc_crypto`) checks each signature under its stated scheme.

## Signed Headers

`src/supraxis/consensus/signed_header.py`

- `header_message(Header)` is domain-separated:
  - `SUPRAXIS|HEADER|V1|...`
- `SignedHeader` contains:
  - `header: Header`
  - `sigs: Dict[voter_vid -> {"scheme": int, "sig": bytes}]`
- `verify_signed_header(...)` verifies quorum-signed power over that header message.

## Next

Phase 39: integrate signed headers into gossip + light client acceptance rules (prefer signed headers vs raw headers).
