# Phase 55 — State Machine Ledger (Accounts + Balances)

This phase adds a minimal deterministic ledger:
- accounts (balance, nonce)
- transfer method execution
- deterministic state root (sha256(canonical_json(state)))

## Core
- `src/supraxis/ledger_state.py`
  - `LedgerState.apply_tx_dict()` supports `method="transfer"` with `params={"amount": int}`
  - checks nonce, funds
  - updates balances and sender nonce
  - `state_root()` for reproducible hashing

## Persistence
- `state.json` stored by `NodeDB` with atomic write + checksum

## Node integration
- `src/supraxis/node/state_service.py`
- `scripts/supraxis_run_node.py` loads/persists state and exposes it via RPC

## RPC
Added endpoints:
- `GET /state/root`
- `GET /state/account?addr=...`
- `POST /state/fund` (dev utility)
- `POST /state/apply_tx` (executes a tx on the local state)

Next:
Phase 56 — compute block `state_root` during block building and verify state_root on block acceptance.
