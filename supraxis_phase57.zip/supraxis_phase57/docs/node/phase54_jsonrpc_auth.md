# Phase 54 — JSON-RPC 2.0 + Auth + Rate Limiting

Adds:
- JSON-RPC 2.0 request handler
- Bearer token authentication
- Basic token bucket rate limiter

File:
- src/supraxis/rpc/jsonrpc.py

Next:
Phase 55 — State machine ledger (accounts + balances).
