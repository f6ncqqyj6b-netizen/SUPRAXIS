import unittest
from supraxis.rpc.jsonrpc import JSONRPCServer

class TestJSONRPC(unittest.TestCase):
    def test_basic_call(self):
        srv = JSONRPCServer({"echo": lambda p: p})
        req = {"jsonrpc":"2.0","method":"echo","params":{"x":1},"id":1}
        rsp = srv.handle(req, {})
        self.assertEqual(rsp["result"]["x"], 1)

    def test_auth(self):
        srv = JSONRPCServer({"ok": lambda p: True}, auth_token="abc")
        req = {"jsonrpc":"2.0","method":"ok","id":1}
        rsp = srv.handle(req, {})
        self.assertTrue("error" in rsp)

if __name__ == "__main__":
    unittest.main()
