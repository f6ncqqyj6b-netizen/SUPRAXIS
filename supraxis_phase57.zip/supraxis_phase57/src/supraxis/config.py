from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any
import json
from pathlib import Path

from supraxis.canonjson import canonical_json
from supraxis.crypto import sha256

CFG_VERSION = 1

@dataclass(frozen=True)
class NetworkConfig:
    version: int
    chain_id: int
    network_name: str
    seed_nodes: List[str]          # ["host:port", ...]
    genesis_hash: str
    p2p_port: int = 30303
    rpc_port: int = 8545
    data_dir: str = "./data"
    max_frame_bytes: int = 2_000_000

    def to_dict(self) -> Dict[str, Any]:
        return {
            "version": int(self.version),
            "chain_id": int(self.chain_id),
            "network_name": str(self.network_name),
            "seed_nodes": list(self.seed_nodes),
            "genesis_hash": str(self.genesis_hash),
            "p2p_port": int(self.p2p_port),
            "rpc_port": int(self.rpc_port),
            "data_dir": str(self.data_dir),
            "max_frame_bytes": int(self.max_frame_bytes),
        }

def config_hash(cfg: Dict[str, Any]) -> str:
    return sha256(canonical_json(cfg)).hex()

def write_config(path: Path, cfg: NetworkConfig) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    d = cfg.to_dict()
    path.write_text(json.dumps(d, indent=2, sort_keys=True), encoding="utf-8")
    return config_hash(d)

def read_config(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))
