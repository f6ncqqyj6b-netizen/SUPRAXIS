from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, List

from supraxis.governance import GovernanceEngine, GovState, make_proposal, Proposal
from supraxis.node.db import NodeDB
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P

@dataclass
class GovernanceService:
    engine: GovernanceEngine
    db: Optional[NodeDB] = None

    def load_from_db(self) -> None:
        if self.db is None:
            return
        d = self.db.load_governance()
        if d is None:
            return
        self.engine.state = GovState.from_dict(d)

    def persist(self) -> None:
        if self.db is None:
            return
        self.db.save_governance(self.engine.state.to_dict())

    async def handle_submit(self, msg: Msg) -> Msg:
        payload = msg.payload or {}
        kind = str(payload.get("kind",""))
        title = str(payload.get("title",""))
        prop_payload = payload.get("payload") or {}
        proposer = str(payload.get("proposer",""))
        if not isinstance(prop_payload, dict):
            return Msg(P.RSP_GOV, {"ok": False, "why": "bad_payload"})
        prop = make_proposal(kind, title, prop_payload, proposer)
        ok, why = self.engine.submit(prop)
        if ok:
            self.persist()
        return Msg(P.RSP_GOV, {"ok": ok, "why": why, "id": prop.id, "proposal": prop.to_dict()})

    async def handle_queue(self, msg: Msg) -> Msg:
        pid = str((msg.payload or {}).get("id",""))
        ok, why = self.engine.queue(pid)
        if ok:
            self.persist()
        return Msg(P.RSP_GOV, {"ok": ok, "why": why, "id": pid})

    async def handle_execute(self, msg: Msg) -> Msg:
        pid = str((msg.payload or {}).get("id",""))
        ok, why, prop = self.engine.execute(pid)
        if ok:
            self.persist()
        return Msg(P.RSP_GOV, {"ok": ok, "why": why, "id": pid, "executed": prop})

    async def handle_status(self, msg: Msg) -> Msg:
        pid = str((msg.payload or {}).get("id",""))
        rec = self.engine.state.proposals.get(pid)
        return Msg(P.RSP_GOV_STATUS, {"id": pid, "record": rec})

    async def handle_emergency(self, msg: Msg) -> Msg:
        act = str((msg.payload or {}).get("action",""))
        guardians = list((msg.payload or {}).get("guardians") or [])
        guardians = [str(x) for x in guardians]
        if act == "halt":
            ok, why = self.engine.emergency_halt(guardians)
        elif act == "resume":
            ok, why = self.engine.emergency_resume(guardians)
        else:
            ok, why = False, "bad_action"
        if ok:
            self.persist()
        return Msg(P.RSP_GOV, {"ok": ok, "why": why, "halted": bool(self.engine.state.emergency_halt)})
