from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Optional, Any

@dataclass
class BlockStore:
    blocks: Dict[str, Any] = field(default_factory=dict)

    def put(self, block_hash: str, block: Any) -> None:
        self.blocks[str(block_hash)] = block

    def get_block(self, block_hash: str) -> Optional[Any]:
        return self.blocks.get(str(block_hash))
