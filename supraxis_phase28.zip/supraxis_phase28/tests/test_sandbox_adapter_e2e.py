import unittest, json
from supraxis.drivers import Sandbox, SandboxAdapter
from supraxis.sirbin import SirBinProgram
from supraxis.state import SupraxisState
from supraxis.envelope import EnvelopeV2
from supraxis.crypto import sha256
from supraxis.sigverify import make_stub_signature

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class SandboxAdapterE2E(unittest.TestCase):
    def test_adapter_runs_inbox(self):
        prog_json = {
          "version": 1,
          "functions": {
            "main": [
              {"op":"EMIT","event":"Inbox","payload":{"k":1}},
              {"op":"RET"}
            ]
          }
        }
        prog = SirBinProgram(version=1, functions=prog_json["functions"])
        prog = SirBinProgram.decode(prog.encode())

        sb = Sandbox()
        ad = SandboxAdapter(sb)
        st = SupraxisState()

        payload=b'{"p":1}'
        ph=sha256(payload)
        base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[])
        sig=make_stub_signature(1, b"pub", base.signing_message())
        env=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[sig])

        sb.inbox(100).submit(env.canonical_bytes())
        res = ad.run_inbox(100, st, prog, entry="main", require_signatures=True)
        self.assertEqual(len(res.events), 2)  # Inbox + STATE_COMMITMENT

if __name__ == "__main__":
    unittest.main()
