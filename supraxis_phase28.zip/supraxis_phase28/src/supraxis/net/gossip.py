from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Deque, Optional, Tuple
from collections import deque
from .messages import NetMessage, TxAnnounce, TxRequest, TxPayload
from .mempool import Mempool, tx_id_from_envelope_dict

@dataclass
class Peer:
    pid: str
    mempool: Mempool = field(default_factory=Mempool)
    inbox: Deque[Tuple[str, NetMessage]] = field(default_factory=deque)  # (from, msg)
    known_tx: set = field(default_factory=set)

@dataclass
class GossipSim:
    peers: Dict[str, Peer] = field(default_factory=dict)

    def add_peer(self, pid: str) -> Peer:
        p = Peer(pid=pid)
        self.peers[pid] = p
        return p

    def send(self, src: str, dst: str, msg: NetMessage) -> None:
        self.peers[dst].inbox.append((src, msg))

    def broadcast(self, src: str, msg: NetMessage) -> None:
        for pid in sorted(self.peers.keys()):
            if pid == src: 
                continue
            self.send(src, pid, msg)

    def step(self, max_msgs: int = 1000) -> int:
        # deterministically process in pid order
        processed = 0
        for pid in sorted(self.peers.keys()):
            peer = self.peers[pid]
            while peer.inbox and processed < max_msgs:
                src, msg = peer.inbox.popleft()
                processed += 1
                self._handle(peer, src, msg)
        return processed

    def _handle(self, peer: Peer, src: str, msg: NetMessage) -> None:
        if isinstance(msg, TxPayload):
            ok, reason, txid = peer.mempool.add(msg.envelope)
            peer.known_tx.add(txid)
            # announce further if accepted
            if ok:
                self.broadcast(peer.pid, TxAnnounce(tx_id=txid))
        elif isinstance(msg, TxAnnounce):
            if msg.tx_id in peer.known_tx or peer.mempool.has(msg.tx_id):
                return
            peer.known_tx.add(msg.tx_id)
            # request payload
            self.send(peer.pid, src, TxRequest(tx_id=msg.tx_id))
        elif isinstance(msg, TxRequest):
            # respond with payload if we have it
            if msg.tx_id in peer.mempool.txs:
                env = peer.mempool.txs[msg.tx_id]
                self.send(peer.pid, src, TxPayload(tx_id=msg.tx_id, envelope=env))
        else:
            # non-tx messages ignored in reference sim
            pass
