# SIR v1 (JSON IR for skeleton)

For Phase 4 we use a JSON IR so the replay harness is easy to inspect.

## Format
{
  "version": 1,
  "functions": {
    "main": [
      {"op":"CAP_REQUIRE","cap":"cap_ping","scope":"ping"},
      {"op":"EMIT","event":"Ping","payload":{"msg":"hello"}},
      {"op":"RET"}
    ]
  }
}

## Notes
- Determinism is validated at execution time.
- Future phases can define a binary SIR with canonical encoding and golden bytes.
