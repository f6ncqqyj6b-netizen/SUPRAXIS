# SUPRAXIS (Phase 4 Skeleton)

Deterministic cross-chain execution **above** chains.

This repo is a **scaffold**:
- Canonical envelope (SCES v1) encoding/decoding
- Deterministic ordering + nonce registry
- Capability gating hooks
- Replay harness (event-log hashing)
- Driver stubs (EVM / TON placeholders)
- Oracle + token contract stubs (EVM)

> This is not production-ready. It is designed to be an auditable starting point.

## Quickstart

```bash
python -m supraxis.cli --help
python -m supraxis.cli envelope create --payload-json examples/payload.json --out /tmp/env.bin
python -m supraxis.cli envelope verify --in /tmp/env.bin
python -m supraxis.cli replay run --sir examples/hello.sir.json --envelope /tmp/env.bin --state /tmp/state.json --out /tmp/replay.json
python -m supraxis.cli replay hash --in /tmp/replay.json
```

## Layout
- `src/supraxis/` core library + CLI
- `specs/` canonical encoding + SCES v1
- `examples/` hello SIR program + payload + demo scripts
- `token/evm/` Solidity stubs for SPX + Oracle quorum
- `tests/` deterministic golden tests (unittest)

## Determinism Rules (Enforced Here)
- Canonical serialization of envelope + payload bytes
- Deterministic envelope ordering
- No wall-clock, randomness, or floating point in runtime path
