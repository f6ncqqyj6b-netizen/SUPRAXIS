from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import json
from .errors import ReplayError

@dataclass
class SirProgram:
    version: int
    functions: Dict[str, List[Dict[str, Any]]]

    @staticmethod
    def load(path: str) -> "SirProgram":
        with open(path, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if int(obj.get("version", 0)) != 1:
            raise ReplayError("unsupported SIR version (expected 1)")
        fns = obj.get("functions")
        if not isinstance(fns, dict) or "main" not in fns:
            raise ReplayError("SIR must contain functions.main")
        return SirProgram(version=1, functions=fns)
