from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, List
import json
from .errors import EnvelopeValidationError, ReplayError
from .envelope import EnvelopeV1, envelope_sort_key
from .state import SupraxisState
from .runtime import execute_sir, event_log_hash, canonical_json
from .crypto import sha256

@dataclass
class ReplayResult:
    state_json: str
    events: List[Dict[str, Any]]
    event_log_hash: str

def run_replay(state: SupraxisState, sir_main: List[Dict[str, Any]], envelopes: List[EnvelopeV1]) -> ReplayResult:
    # Deterministic ordering
    envs = sorted(envelopes, key=envelope_sort_key)

    all_events: List[Dict[str, Any]] = []

    for env in envs:
        env.validate(require_signatures=False)  # signatures optional in skeleton runs
        last = state.get_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract)
        if env.nonce <= last:
            raise ReplayError("replay rejected: nonce not increasing")
        # context is derived from envelope only (no wall-clock)
        ctx = {
            "origin_chain": env.origin_chain,
            "origin_sender": env.origin_sender.hex(),
            "target_chain": env.target_chain,
            "target_contract": env.target_contract.hex(),
            "nonce": env.nonce,
            "gas_limit": env.gas_limit,
            "payload_type": env.payload_type,
            "payload_hash": env.payload_hash.hex(),
            "timestamp": 0,  # placeholder: future versions carry timestamp inside payload or envelope
        }
        events = execute_sir(state, sir_main, ctx)
        # Update nonce only after successful execution
        state.set_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract, env.nonce)
        for e in events:
            all_events.append({"event": e.event, "payload": e.payload, "ctx": ctx})

    # hash the whole log deterministically
    h = sha256(b"SUPRAXIS_REPLAY_V1")
    for item in all_events:
        h = sha256(h + canonical_json(item))
    return ReplayResult(
        state_json=state.to_json(),
        events=all_events,
        event_log_hash=h.hex()
    )

def replay_hash(replay_json: str) -> str:
    obj = json.loads(replay_json)
    # stable hash of replay result JSON canonical form
    return sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")).hex()
