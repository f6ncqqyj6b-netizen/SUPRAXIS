from __future__ import annotations
import argparse
import json
from pathlib import Path
from .envelope import EnvelopeV1
from .crypto import sha256, Sig
from .state import SupraxisState
from .sir import SirProgram
from .replay import run_replay, replay_hash

def _bytes32_from_hex(s: str) -> bytes:
    s = s.lower().strip()
    if s.startswith("0x"):
        s = s[2:]
    b = bytes.fromhex(s)
    if len(b) != 32:
        raise SystemExit("expected 32-byte hex (64 hex chars)")
    return b

def cmd_state_init(args: argparse.Namespace) -> None:
    st = SupraxisState()
    Path(args.out).write_text(st.to_json(), encoding="utf-8")
    print(f"Wrote state: {args.out}")

def cmd_cap_add(args: argparse.Namespace) -> None:
    st = SupraxisState.from_json(Path(args.state).read_text(encoding="utf-8"))
    cap_id = sha256(args.name.encode("utf-8")).hex()
    st.caps[cap_id] = {"scope": args.scope, "expires": int(args.expires), "chain": int(args.chain)}
    Path(args.state).write_text(st.to_json(), encoding="utf-8")
    print(f"Added cap {args.name} id={cap_id} to {args.state}")

def cmd_env_create(args: argparse.Namespace) -> None:
    payload_obj = json.loads(Path(args.payload_json).read_text(encoding="utf-8"))
    payload_bytes = json.dumps(payload_obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    payload_hash = sha256(payload_bytes)

    env = EnvelopeV1(
        version=1,
        origin_chain=int(args.origin_chain),
        origin_tx=_bytes32_from_hex(args.origin_tx),
        origin_sender=_bytes32_from_hex(args.origin_sender),
        target_chain=int(args.target_chain),
        target_contract=_bytes32_from_hex(args.target_contract),
        nonce=int(args.nonce),
        gas_limit=int(args.gas_limit),
        payload_type=int(args.payload_type),
        payload=payload_bytes,
        payload_hash=payload_hash,
        cap_refs=[_bytes32_from_hex(c) for c in (args.cap_ref or [])],
        signatures=[],  # add later
    )
    b = env.canonical_bytes()
    Path(args.out).write_bytes(b)
    print(f"Wrote envelope: {args.out} ({len(b)} bytes)")
    print(f"payload_hash: 0x{payload_hash.hex()}")

def cmd_env_verify(args: argparse.Namespace) -> None:
    buf = Path(args.infile).read_bytes()
    env = EnvelopeV1.decode(buf)
    env.validate(require_signatures=False)
    print("OK: envelope canonical + payload hash verified")
    print(f"origin_chain={env.origin_chain} target_chain={env.target_chain} nonce={env.nonce}")

def cmd_replay_run(args: argparse.Namespace) -> None:
    st = SupraxisState.from_json(Path(args.state).read_text(encoding="utf-8"))
    sir = SirProgram.load(args.sir)
    env = EnvelopeV1.decode(Path(args.envelope).read_bytes())

    res = run_replay(st, sir.functions["main"], [env])
    out_obj = {"state": json.loads(res.state_json), "events": res.events, "event_log_hash": res.event_log_hash}
    Path(args.out).write_text(json.dumps(out_obj, indent=2, sort_keys=True), encoding="utf-8")
    print(f"Wrote replay: {args.out}")
    print(f"event_log_hash: {res.event_log_hash}")

def cmd_replay_hash(args: argparse.Namespace) -> None:
    s = Path(args.infile).read_text(encoding="utf-8")
    print(replay_hash(s))

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="supraxis")
    sp = p.add_subparsers(dest="cmd", required=True)

    st = sp.add_parser("state", help="state operations")
    stsp = st.add_subparsers(dest="sub", required=True)
    st_init = stsp.add_parser("init", help="create empty state json")
    st_init.add_argument("--out", required=True)
    st_init.set_defaults(func=cmd_state_init)

    cap = sp.add_parser("cap", help="capability operations")
    capsp = cap.add_subparsers(dest="sub", required=True)
    cap_add = capsp.add_parser("add", help="add capability to state (skeleton)")
    cap_add.add_argument("--state", required=True)
    cap_add.add_argument("--name", required=True)
    cap_add.add_argument("--scope", required=True)
    cap_add.add_argument("--chain", required=True, type=int)
    cap_add.add_argument("--expires", required=True, type=int)
    cap_add.set_defaults(func=cmd_cap_add)

    env = sp.add_parser("envelope", help="envelope operations")
    envsp = env.add_subparsers(dest="sub", required=True)
    env_create = envsp.add_parser("create", help="create envelope from payload json")
    env_create.add_argument("--origin-chain", required=True, type=int)
    env_create.add_argument("--origin-tx", required=True)
    env_create.add_argument("--origin-sender", required=True)
    env_create.add_argument("--target-chain", required=True, type=int)
    env_create.add_argument("--target-contract", required=True)
    env_create.add_argument("--nonce", required=True, type=int)
    env_create.add_argument("--gas-limit", required=True, type=int)
    env_create.add_argument("--payload-type", required=True, type=int)
    env_create.add_argument("--payload-json", required=True)
    env_create.add_argument("--cap-ref", action="append", help="0x.. bytes32; can be repeated")
    env_create.add_argument("--out", required=True)
    env_create.set_defaults(func=cmd_env_create)

    env_verify = envsp.add_parser("verify", help="verify envelope canonicality")
    env_verify.add_argument("--in", dest="infile", required=True)
    env_verify.set_defaults(func=cmd_env_verify)

    rp = sp.add_parser("replay", help="replay operations")
    rpsp = rp.add_subparsers(dest="sub", required=True)
    rp_run = rpsp.add_parser("run", help="run replay for one envelope (skeleton)")
    rp_run.add_argument("--sir", required=True)
    rp_run.add_argument("--envelope", required=True)
    rp_run.add_argument("--state", required=True)
    rp_run.add_argument("--out", required=True)
    rp_run.set_defaults(func=cmd_replay_run)

    rp_hash = rpsp.add_parser("hash", help="hash a replay json file")
    rp_hash.add_argument("--in", dest="infile", required=True)
    rp_hash.set_defaults(func=cmd_replay_hash)

    return p

def main() -> None:
    p = build_parser()
    args = p.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()
