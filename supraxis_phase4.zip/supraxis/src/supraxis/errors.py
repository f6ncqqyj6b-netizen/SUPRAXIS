class SupraxisError(Exception):
    pass

class CanonicalEncodingError(SupraxisError):
    pass

class EnvelopeValidationError(SupraxisError):
    pass

class ReplayError(SupraxisError):
    pass

class CapabilityError(SupraxisError):
    pass
