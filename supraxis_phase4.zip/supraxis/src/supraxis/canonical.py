"""Canonical encoding helpers (big-endian)."""
from __future__ import annotations
import struct
from typing import Tuple
from .errors import CanonicalEncodingError

def pack_u16(x: int) -> bytes:
    if not (0 <= x <= 0xFFFF):
        raise CanonicalEncodingError(f"u16 out of range: {x}")
    return struct.pack(">H", x)

def pack_u32(x: int) -> bytes:
    if not (0 <= x <= 0xFFFFFFFF):
        raise CanonicalEncodingError(f"u32 out of range: {x}")
    return struct.pack(">I", x)

def pack_u64(x: int) -> bytes:
    if not (0 <= x <= 0xFFFFFFFFFFFFFFFF):
        raise CanonicalEncodingError(f"u64 out of range: {x}")
    return struct.pack(">Q", x)

def pack_bytes_u16(b: bytes) -> bytes:
    if len(b) > 0xFFFF:
        raise CanonicalEncodingError("bytes too long for u16 length")
    return pack_u16(len(b)) + b

def pack_bytes_u32(b: bytes) -> bytes:
    if len(b) > 0xFFFFFFFF:
        raise CanonicalEncodingError("bytes too long for u32 length")
    return pack_u32(len(b)) + b

def read_u16(buf: bytes, off: int) -> Tuple[int, int]:
    if off + 2 > len(buf):
        raise CanonicalEncodingError("unexpected EOF u16")
    return struct.unpack(">H", buf[off:off+2])[0], off + 2

def read_u32(buf: bytes, off: int) -> Tuple[int, int]:
    if off + 4 > len(buf):
        raise CanonicalEncodingError("unexpected EOF u32")
    return struct.unpack(">I", buf[off:off+4])[0], off + 4

def read_u64(buf: bytes, off: int) -> Tuple[int, int]:
    if off + 8 > len(buf):
        raise CanonicalEncodingError("unexpected EOF u64")
    return struct.unpack(">Q", buf[off:off+8])[0], off + 8

def read_bytes32(buf: bytes, off: int) -> Tuple[bytes, int]:
    if off + 32 > len(buf):
        raise CanonicalEncodingError("unexpected EOF bytes32")
    return buf[off:off+32], off + 32

def read_bytes_u16(buf: bytes, off: int) -> Tuple[bytes, int]:
    n, off = read_u16(buf, off)
    if off + n > len(buf):
        raise CanonicalEncodingError("unexpected EOF bytes(u16)")
    return buf[off:off+n], off + n

def read_bytes_u32(buf: bytes, off: int) -> Tuple[bytes, int]:
    n, off = read_u32(buf, off)
    if off + n > len(buf):
        raise CanonicalEncodingError("unexpected EOF bytes(u32)")
    return buf[off:off+n], off + n
