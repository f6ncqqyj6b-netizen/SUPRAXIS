"""Crypto placeholders.

Phase 4 focuses on determinism scaffolding, not production cryptography.
Signature verification is *stubbed* but structured so real verification can be swapped in.

All functions are PURE (no IO, no randomness).
"""
from __future__ import annotations
import hashlib
from dataclasses import dataclass

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

@dataclass(frozen=True)
class Sig:
    scheme: int
    pubkey: bytes
    sig: bytes

def verify_signature(sig: Sig, message: bytes) -> bool:
    """Placeholder verification.

    For Phase 4:
    - scheme 1 (ed25519) => accept if sha256(pubkey + message) starts with sig[:2]
    - scheme 2 (secp256k1) => accept if sha256(message + pubkey) starts with sig[:2]
    This keeps the pipeline deterministic without bringing heavy deps.
    """
    h = sha256(sig.pubkey + message) if sig.scheme == 1 else sha256(message + sig.pubkey)
    return sig.sig[:2] == h[:2]
