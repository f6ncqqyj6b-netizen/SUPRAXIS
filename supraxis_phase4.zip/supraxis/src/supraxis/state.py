from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Tuple, Any
import json
from .errors import ReplayError

NonceKey = Tuple[int, str, int, str]  # (origin_chain, origin_sender_hex, target_chain, target_contract_hex)

@dataclass
class SupraxisState:
    version: int = 1
    # nonce registry: monotonic per (origin_chain, origin_sender, target_chain, target_contract)
    nonce_registry: Dict[str, int] = None
    # application storage (key/value JSON for skeleton)
    storage: Dict[str, Any] = None
    # capability registry: cap_id_hex -> {scope:str, expires:int, chain:int}
    caps: Dict[str, Any] = None

    def __post_init__(self):
        if self.nonce_registry is None:
            self.nonce_registry = {}
        if self.storage is None:
            self.storage = {}
        if self.caps is None:
            self.caps = {}

    @staticmethod
    def key(origin_chain: int, origin_sender: bytes, target_chain: int, target_contract: bytes) -> str:
        return f"{origin_chain}:{origin_sender.hex()}:{target_chain}:{target_contract.hex()}"

    def get_last_nonce(self, origin_chain: int, origin_sender: bytes, target_chain: int, target_contract: bytes) -> int:
        return int(self.nonce_registry.get(self.key(origin_chain, origin_sender, target_chain, target_contract), 0))

    def set_last_nonce(self, origin_chain: int, origin_sender: bytes, target_chain: int, target_contract: bytes, nonce: int) -> None:
        self.nonce_registry[self.key(origin_chain, origin_sender, target_chain, target_contract)] = int(nonce)

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True, separators=(",", ":"))

    @staticmethod
    def from_json(s: str) -> "SupraxisState":
        obj = json.loads(s)
        st = SupraxisState(
            version=int(obj.get("version", 1)),
            nonce_registry=obj.get("nonce_registry") or {},
            storage=obj.get("storage") or {},
            caps=obj.get("caps") or {},
        )
        return st
