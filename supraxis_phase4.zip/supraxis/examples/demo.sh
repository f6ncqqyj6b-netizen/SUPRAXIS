#!/usr/bin/env bash
set -euo pipefail

STATE=./examples/state.json
ENV=./examples/env.bin
REPLAY=./examples/replay.json

python -m supraxis.cli state init --out $STATE
python -m supraxis.cli cap add --state $STATE --name cap_ping --scope ping --chain 100 --expires 999999999

python -m supraxis.cli envelope create \
  --origin-chain 1 \
  --origin-tx 0x0000000000000000000000000000000000000000000000000000000000000001 \
  --origin-sender 0x0000000000000000000000000000000000000000000000000000000000000002 \
  --target-chain 100 \
  --target-contract 0x00000000000000000000000000000000000000000000000000000000000000aa \
  --nonce 1 \
  --gas-limit 500000 \
  --payload-type 1 \
  --payload-json examples/payload.json \
  --out $ENV

python -m supraxis.cli envelope verify --in $ENV
python -m supraxis.cli replay run --sir examples/hello.sir.json --envelope $ENV --state $STATE --out $REPLAY
python -m supraxis.cli replay hash --in $REPLAY
