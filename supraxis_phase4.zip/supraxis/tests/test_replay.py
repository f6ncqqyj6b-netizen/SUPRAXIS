import unittest, json
from supraxis.state import SupraxisState
from supraxis.envelope import EnvelopeV1
from supraxis.crypto import sha256
from supraxis.replay import run_replay

class ReplayTests(unittest.TestCase):
    def test_replay_hash_stable(self):
        st = SupraxisState()
        # install capability for target_chain=100
        cap_id = sha256(b"cap_ping").hex()
        st.caps[cap_id] = {"scope":"ping","expires":999999999,"chain":100}

        sir_main = [
            {"op":"CAP_REQUIRE","cap":"cap_ping","scope":"ping"},
            {"op":"EMIT","event":"Ping","payload":{"msg":"hello"}},
            {"op":"RET"}
        ]
        payload = b'{"timestamp":0}'
        env = EnvelopeV1(
            version=1,
            origin_chain=1,
            origin_tx=(b"\x00"*31)+b"\x01",
            origin_sender=(b"\x00"*31)+b"\x02",
            target_chain=100,
            target_contract=(b"\x00"*31)+b"\xaa",
            nonce=1,
            gas_limit=500000,
            payload_type=1,
            payload=payload,
            payload_hash=sha256(payload),
            cap_refs=[],
            signatures=[],
        )
        res = run_replay(st, sir_main, [env])
        obj = {"state": json.loads(res.state_json), "events": res.events, "event_log_hash": res.event_log_hash}
        s1 = json.dumps(obj, sort_keys=True, separators=(",", ":"))
        s2 = json.dumps(obj, sort_keys=True, separators=(",", ":"))
        self.assertEqual(sha256(s1.encode()).hex(), sha256(s2.encode()).hex())

if __name__ == "__main__":
    unittest.main()
