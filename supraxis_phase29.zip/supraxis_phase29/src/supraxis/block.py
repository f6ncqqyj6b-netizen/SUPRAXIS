from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import json
from .envelope import Envelope, envelope_sort_key, SignaturePolicy
from .state import SupraxisState
from .runtime import execute_functions, canonical_json
from .crypto import sha256
from .errors import ReplayError
from .gas import gas_cost
from .canonical import bitset_test

@dataclass
class BlockResult:
    state_json: str
    events: List[Dict[str, Any]]
    block_hash: str


def state_commitment(state: SupraxisState) -> Dict[str, Any]:
    # Canonical snapshot for cross-chain verification (Phase 26)
    snap = {
        "treasury": int(state.treasury),
        "insurance_pool": int(state.insurance_pool),
        "committee_pool": int(state.committee_pool),
        "burned": int(getattr(state, "burned", 0)),
        "burned_slash": int(getattr(state, "burned_slash", 0)),
        "burned_fee": int(getattr(state, "burned_fee", 0)),
        "burned_penalty": int(getattr(state, "burned_penalty", 0)),
        "total_staked": int(state.total_staked()),
        "total_balances": int(state.total_balances()),
        "claims_pending": int(sum(1 for k,v in state.storage.items() if isinstance(k,str) and k.startswith("claim.") and isinstance(v,dict) and v.get("status")=="pending")),
        "claims_paid": int(sum(1 for k,v in state.storage.items() if isinstance(k,str) and k.startswith("claim.") and isinstance(v,dict) and v.get("status")=="paid")),
        "claims_rejected": int(sum(1 for k,v in state.storage.items() if isinstance(k,str) and k.startswith("claim.") and isinstance(v,dict) and v.get("status")=="rejected")),
        "pending_sum": int(sum(int(v.get("amount",0)) for k,v in state.storage.items() if isinstance(k,str) and k.startswith("claim.") and isinstance(v,dict) and v.get("status")=="pending")),
        "supply_total": int(state.supply_total()),
        "supply_enforce": int(state.supply_enforce()),
        "total_accounted": int(state.total_accounted()),
    }
    h = sha256(canonical_json({"snap": snap}))
    return {"hash": h.hex(), "snap": snap}

def _static_gas(ops: List[Dict[str, Any]], functions: Dict[str, List[Dict[str, Any]]], depth: int = 0) -> int:
    if depth > 32: raise ReplayError("static gas walk depth exceeded")
    total=0
    for op in ops:
        total += gas_cost(str(op.get("op")))
        if op.get("op") == "CALL":
            fn=str(op.get("fn"))
            if fn not in functions: raise ReplayError("unknown CALL target")
            total += _static_gas(functions[fn], functions, depth+1)
    return total

def _attach_state_committee(state: SupraxisState, env: Envelope, pol: Optional[SignaturePolicy]) -> Optional[SignaturePolicy]:
    if getattr(env, "version", 0) != 3:
        return pol
    if pol is not None and pol.committee is not None:
        return pol
    cid_hex = getattr(env, "committee_id", b"").hex()
    committee = state.get_committee_by_id(cid_hex)
    if committee is None:
        return pol
    base = pol or SignaturePolicy(min_valid=1)
    return SignaturePolicy(
        min_valid=base.min_valid,
        min_weight=base.min_weight,
        allowed_schemes=base.allowed_schemes,
        allowed_pubkeys=base.allowed_pubkeys,
        pubkey_weights=base.pubkey_weights,
        pubkey_allowed_schemes=base.pubkey_allowed_schemes,
        committee=committee,
        require_committee_id=True,
    )

def _relax_weight_policy_for_nonv3(env: Envelope, pol: Optional[SignaturePolicy]) -> Optional[SignaturePolicy]:
    if pol is None:
        return None
    if getattr(env, "version", 0) == 3:
        return pol
    if pol.min_weight is None:
        return pol
    has_weight_source = (pol.committee is not None) or (pol.pubkey_weights is not None and len(pol.pubkey_weights) > 0)
    if has_weight_source:
        return pol
    return SignaturePolicy(
        min_valid=pol.min_valid,
        min_weight=None,
        allowed_schemes=pol.allowed_schemes,
        allowed_pubkeys=pol.allowed_pubkeys,
        pubkey_weights=pol.pubkey_weights,
        pubkey_allowed_schemes=pol.pubkey_allowed_schemes,
        committee=pol.committee,
        require_committee_id=pol.require_committee_id,
    )


def _slash_v3_signers_for_double_sign(state: SupraxisState, env: Envelope, reason: str) -> List[Dict[str, Any]]:
    """Slash stake of quorum participants for v3 envelopes based on bitmap indices."""
    if getattr(env, "version", 0) != 3:
        return []
    qp = getattr(env, "quorum_proof", None)
    if qp is None:
        return []
    cid_hex = getattr(env, "committee_id", b"").hex()
    committee = state.get_committee_by_id(cid_hex)
    if committee is None:
        return []
    bitmap = getattr(qp, "bitmap", b"")
    slash_amt = state.slash_amount("double_sign", default=1)
    evs: List[Dict[str, Any]] = []
    members = committee.members  # Tuple[CommitteeMember,...] ordered by pubkey
    for i in range(len(members)):
        if bitset_test(bitmap, i):
            pk_hex = "0x" + committee.pubkey_at(i).hex()
            pk_norm = pk_hex[2:]
            taken = state.slash(pk_norm, slash_amt)
            evs.append({
                "event": "AUTO_SLASH_DOUBLE_SIGN",
                "payload": {
                    "pubkey": pk_hex,
                    "slashed": int(taken),
                    "requested": int(slash_amt),
                    "reason": reason,
                    "committee_id": cid_hex,
                    "epoch": int(getattr(env, "epoch", 0)),
                },
                "ctx": {},
            })
    return evs


def _slash_v3_signers_for_bad_quorum(state: SupraxisState, env: Envelope, reason: str) -> List[Dict[str, Any]]:
    """Slash stake of claimed quorum participants when a v3 envelope fails quorum verification."""
    if getattr(env, "version", 0) != 3:
        return []
    qp = getattr(env, "quorum_proof", None)
    if qp is None:
        return []
    cid_hex = getattr(env, "committee_id", b"").hex()
    committee = state.get_committee_by_id(cid_hex)
    if committee is None:
        return []
    bitmap = getattr(qp, "bitmap", b"")
    slash_amt = state.slash_amount("bad_quorum", default=1)
    evs: List[Dict[str, Any]] = []
    members = committee.members
    for i in range(len(members)):
        if bitset_test(bitmap, i):
            pk_hex = "0x" + committee.pubkey_at(i).hex()
            pk_norm = pk_hex[2:]
            taken = state.slash(pk_norm, slash_amt)
            evs.append({
                "event": "AUTO_SLASH_BAD_QUORUM",
                "payload": {
                    "pubkey": pk_hex,
                    "slashed": int(taken),
                    "requested": int(slash_amt),
                    "reason": reason,
                    "committee_id": cid_hex,
                    "epoch": int(getattr(env, "epoch", 0)),
                },
                "ctx": {},
            })
    return evs

def run_block(
    state: SupraxisState,
    functions: Dict[str, List[Dict[str, Any]]],
    envelopes: List[Envelope],
    entry: str="main",
    require_signatures: bool=False,
    sig_policy: Optional[SignaturePolicy]=None,
    enforce_committee_registry: bool=True,
    auto_slash: bool=True,
) -> BlockResult:
    if entry not in functions: raise ReplayError("missing entry")
    envs=sorted(envelopes, key=envelope_sort_key)
    events_all=[]
    h=sha256(b"SUPRAXIS_BLOCK_V15")
    for env in envs:
        # committee registry enforcement for v3
        if enforce_committee_registry and getattr(env, "version", 0) == 3:
            ep = int(getattr(env, "epoch", 0))
            cid_hex = getattr(env, "committee_id", b"").hex()
            allowed = state.allowed_committee_ids_for_epoch(ep)
            if len(allowed) == 0:
                raise ReplayError("committee not registered for epoch")
            if cid_hex not in allowed:
                raise ReplayError("committee_id not allowed for epoch (outside rotation window)")

        pol = _attach_state_committee(state, env, sig_policy)
        pol = _relax_weight_policy_for_nonv3(env, pol)

        # signature/canonical validation
        if hasattr(env, "validate"):
            try:
                try:
                    env.validate(require_signatures=require_signatures, policy=pol)  # type: ignore[arg-type]
                except TypeError:
                    env.validate(require_signatures=require_signatures)  # v1
            except Exception as e:
                # Phase 16: if v3 quorum proof is invalid, auto-slash claimed signers and skip execution.
                if auto_slash and getattr(env, "version", 0) == 3:
                    reason = f"v3 validation failed: {str(e)}"
                    slash_events = _slash_v3_signers_for_bad_quorum(state, env, reason=reason)
                    for se in slash_events:
                        se["ctx"] = {
                            "origin_chain": env.origin_chain,
                            "origin_sender": env.origin_sender.hex(),
                            "target_chain": env.target_chain,
                            "target_contract": env.target_contract.hex(),
                            "nonce": env.nonce,
                            "payload_hash": env.payload_hash.hex(),
                            "envelope_version": env.version,
                        }
                        events_all.append(se)
                        h = sha256(h + canonical_json(se))
                    h = sha256(h + state.to_json().encode("utf-8"))
                    continue
                raise
        else:
            raise ReplayError("invalid envelope")

        last=state.get_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract)
        if env.nonce < last:
            raise ReplayError("nonce not increasing")
        if env.nonce == last and last != 0:
            # Potential replay or double-sign: compare payload hash
            prev_ph = state.get_last_payload_hash(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract)
            cur_ph = env.payload_hash.hex()
            if prev_ph != "" and prev_ph != cur_ph:
                # Double-sign detected: slash quorum participants and skip execution
                if auto_slash:
                    slash_events = _slash_v3_signers_for_double_sign(state, env, reason="conflicting payload_hash for same nonce")
                    for se in slash_events:
                        se["ctx"] = {
                            "origin_chain": env.origin_chain,
                            "origin_sender": env.origin_sender.hex(),
                            "target_chain": env.target_chain,
                            "target_contract": env.target_contract.hex(),
                            "nonce": env.nonce,
                            "payload_hash": cur_ph,
                            "prev_payload_hash": prev_ph,
                            "envelope_version": env.version,
                        }
                        events_all.append(se)
                        h = sha256(h + canonical_json(se))
                    # commit state to hash for determinism
                    h = sha256(h + state.to_json().encode("utf-8"))
                # Do not execute, do not update nonce
                continue
            else:
                raise ReplayError("replay")

        ctx={
            "epoch": int(getattr(env, "epoch", 0)),
            "committee_id": getattr(env, "committee_id", b"").hex() if getattr(env, "committee_id", None) is not None else "",
            "origin_chain": env.origin_chain,
            "origin_sender": env.origin_sender.hex(),
            "target_chain": env.target_chain,
            "target_contract": env.target_contract.hex(),
            "nonce": env.nonce,
            "gas_limit": env.gas_limit,
            "payload_type": env.payload_type,
            "payload_hash": env.payload_hash.hex(),
            "timestamp": 0,
            "envelope_version": env.version,
        }
        if _static_gas(functions[entry], functions) > env.gas_limit:
            raise ReplayError("out of gas")
        evs=execute_functions(state, functions, entry, ctx)

        # Phase 26: hard economic invariants (conservation) if enabled
        try:
            state.assert_conservation()
        except Exception as e:
            raise ReplayError(f"conservation violation: {str(e)}")

        # Phase 26: deterministic state commitment
        sc = state_commitment(state)
        events_all.append({"event":"STATE_COMMITMENT","payload":sc,"ctx":ctx})
        h = sha256(h + canonical_json({"event":"STATE_COMMITMENT","payload":sc,"ctx":ctx}))


        # update replay tracking
        state.set_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract, env.nonce, env.payload_hash.hex())

        for e in evs:
            item={"event": e.event, "payload": e.payload, "ctx": ctx}
            events_all.append(item)
            h=sha256(h + canonical_json(item))
        h=sha256(h + state.to_json().encode("utf-8"))
    return BlockResult(state_json=state.to_json(), events=events_all, block_hash=h.hex())

def block_hash(block_json: str) -> str:
    obj=json.loads(block_json)
    return sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")).hex()
