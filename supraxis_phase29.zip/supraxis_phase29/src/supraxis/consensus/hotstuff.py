from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from .types import Validator, Vote, Timeout, QC, TC, Block, BlockHeader, Proposal

def quorum_threshold(validators: List[Validator]) -> int:
    total = sum(max(0,int(v.power)) for v in validators)
    return (2*total)//3 + 1

def proposer_for(chain_id: int, height: int, round: int, validators: List[Validator]) -> str:
    vids = [v.vid for v in sorted(validators, key=lambda x: x.vid)]
    if not vids:
        raise ValueError("no validators")
    b = canonical_json({"chain_id":chain_id,"h":int(height),"r":int(round)})
    idx = int.from_bytes(sha256(b), "big") % len(vids)
    return vids[idx]

def verify_qc(qc: QC, validators: Dict[str, Validator]) -> bool:
    # Phase 27 placeholder: verify only power threshold and voter set validity.
    power = 0
    for vid in qc.sigs.keys():
        if vid not in validators:
            return False
        power += int(validators[vid].power)
    return int(power) >= int(qc.power)

def form_qc(height: int, round: int, block_hash: str, votes: List[Vote], validators: Dict[str, Validator]) -> QC:
    sigs: Dict[str, bytes] = {}
    power = 0
    for v in votes:
        if v.voter in sigs:
            continue
        if v.height!=height or v.round!=round or v.block_hash!=block_hash:
            continue
        if v.voter not in validators:
            continue
        sigs[v.voter] = v.sig
        power += int(validators[v.voter].power)
    return QC(height=height, round=round, block_hash=block_hash, sigs=sigs, power=power)

def form_tc(height: int, round: int, high_qc_hash: str, tos: List[Timeout], validators: Dict[str, Validator]) -> TC:
    sigs: Dict[str, bytes] = {}
    power = 0
    for t in tos:
        if t.voter in sigs:
            continue
        if t.height!=height or t.round!=round or t.high_qc_hash!=high_qc_hash:
            continue
        if t.voter not in validators:
            continue
        sigs[t.voter] = t.sig
        power += int(validators[t.voter].power)
    return TC(height=height, round=round, high_qc_hash=high_qc_hash, sigs=sigs, power=power)

@dataclass
class ConsensusState:
    chain_id: int
    validators: List[Validator]
    # highest QC known
    high_qc: Optional[QC] = None
    # parent links for commit rule
    parent: Dict[str, str] = None  # block_hash -> parent_hash
    qc_for: Dict[str, QC] = None   # block_hash -> QC
    committed: List[str] = None

    def __post_init__(self):
        self.parent = {} if self.parent is None else self.parent
        self.qc_for = {} if self.qc_for is None else self.qc_for
        self.committed = [] if self.committed is None else self.committed

    def vmap(self) -> Dict[str, Validator]:
        return {v.vid: v for v in self.validators}

    def on_proposal(self, prop: Proposal) -> bool:
        # minimal checks
        want = proposer_for(self.chain_id, prop.block.header.height, prop.block.header.round, self.validators)
        return prop.block.header.proposer == want

    def on_qc(self, qc: QC) -> None:
        self.qc_for[qc.block_hash] = qc
        # update highQC by height/round lexicographic
        if self.high_qc is None:
            self.high_qc = qc
        else:
            if (qc.height, qc.round) > (self.high_qc.height, self.high_qc.round):
                self.high_qc = qc
        self.try_commit(qc.block_hash)

    def register_block(self, block_hash: str, parent_hash: str) -> None:
        self.parent[block_hash] = parent_hash

    def try_commit(self, bh: str) -> None:
        # 3-chain commit: if bh has QC, parent has QC, grandparent has QC => commit grandparent
        p = self.parent.get(bh)
        if not p: 
            return
        gp = self.parent.get(p)
        if not gp:
            return
        if bh in self.qc_for and p in self.qc_for and gp in self.qc_for:
            if gp not in self.committed:
                self.committed.append(gp)

def make_block(chain_id: int, height: int, round: int, parent_hash: str, proposer: str, body: List[dict]) -> Block:
    return Block(header=BlockHeader(chain_id=chain_id,height=height,round=round,parent_hash=parent_hash,proposer=proposer), body=body)
