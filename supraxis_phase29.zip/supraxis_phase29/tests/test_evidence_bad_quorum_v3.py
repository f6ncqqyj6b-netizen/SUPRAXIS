import unittest
from supraxis.state import SupraxisState
from supraxis.crypto import sha256
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.canonical import bitset_len, bitset_set
from supraxis.errors import ReplayError

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class EvidenceBadQuorumV3Tests(unittest.TestCase):
    def _setup_committee(self):
        st = SupraxisState()
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global","chain":100,"expires":10**18}
        st.storage["quorum.min_weight"] = 7
        # Governance: stake + committee epoch 7
        functions = {"main":[
            {"op":"GOV_STAKE","pubkey":"0x706b31","amount":4,"lock_epochs":0},
            {"op":"GOV_STAKE","pubkey":"0x706b32","amount":3,"lock_epochs":0},
            {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE","epoch":7,"size":2},
            {"op":"RET"},
        ]}
        prog = SirBinProgram(version=1, functions=functions)
        payload=b'{"gov":1}'
        envg_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[])
        sigg=make_stub_signature(1,b"pk_gov", envg_base.signing_message())
        envg=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,10_000_000,1,payload,sha256(payload),[],[sigg])
        run_block(st, prog.functions, [envg], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))
        cid = st.committee_registry["7"]
        return st, cid

    def _runner_env(self, nonce:int):
        payload=b'{"run":%d}'%nonce
        env_base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),nonce,10_000_000,1,payload,sha256(payload),[],[])
        sig=make_stub_signature(1,b"pk_any", env_base.signing_message())
        return EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),nonce,10_000_000,1,payload,sha256(payload),[],[sig])

    def test_evidence_bad_quorum_slashes_and_dedupes(self):
        st, cid = self._setup_committee()
        cid_bytes = bytes.fromhex(cid)
        committee = st.get_committee_by_id(cid)
        assert committee is not None

        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)

        payload2=b'{"v3":1}'
        ph2=sha256(payload2)
        base=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payload2,ph2,[],[],None)
        msg=base.signing_message()
        s0=make_stub_signature(1,b"pk1",msg)
        s1=make_stub_signature(1,b"pk2",msg)

        # Corrupt signature bytes -> invalid quorum proof
        bad0 = Signature(s0.scheme, b"", s0.sig[:-1] + bytes([(s0.sig[-1] + 1) % 256]))
        bad1 = Signature(s1.scheme, b"", s1.sig[:-1] + bytes([(s1.sig[-1] + 2) % 256]))
        qp=QuorumProofV1(bytes(bm), [bad0, bad1])
        bad_env=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payload2,ph2,[],[],qp)

        functions = {"main":[
            {"op":"EVIDENCE_BAD_QUORUM_V3", "env":"0x"+bad_env.canonical_bytes().hex()},
            {"op":"RET"},
        ]}
        prog = SirBinProgram(version=1, functions=functions)

        run_block(st, prog.functions, [self._runner_env(10)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))

        amt1,_ = st.stake_of("0x706b31")
        amt2,_ = st.stake_of("0x706b32")
        self.assertEqual(amt1, 3)
        self.assertEqual(amt2, 2)

        # Duplicate submission -> ignored, no further slash
        run_block(st, prog.functions, [self._runner_env(11)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))
        amt1b,_ = st.stake_of("0x706b31")
        amt2b,_ = st.stake_of("0x706b32")
        self.assertEqual(amt1b, 3)
        self.assertEqual(amt2b, 2)

    def test_evidence_rejected_if_envelope_valid(self):
        st, cid = self._setup_committee()
        cid_bytes = bytes.fromhex(cid)
        committee = st.get_committee_by_id(cid)
        assert committee is not None
        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)

        payload2=b'{"v3":1}'
        ph2=sha256(payload2)
        base=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payload2,ph2,[],[],None)
        msg=base.signing_message()
        s0=make_stub_signature(1,b"pk1",msg)
        s1=make_stub_signature(1,b"pk2",msg)
        qp=QuorumProofV1(bytes(bm), [Signature(s0.scheme,b"",s0.sig), Signature(s1.scheme,b"",s1.sig)])
        good_env=EnvelopeV3(3,7,cid_bytes,1,b32(1),b32(2),100,b32(0xAA),2,10_000_000,1,payload2,ph2,[],[],qp)

        functions = {"main":[
            {"op":"EVIDENCE_BAD_QUORUM_V3", "env":"0x"+good_env.canonical_bytes().hex()},
            {"op":"RET"},
        ]}
        prog = SirBinProgram(version=1, functions=functions)

        res = run_block(st, prog.functions, [self._runner_env(10)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(any(e["event"]=="EVIDENCE_REJECTED" for e in res.events))


if __name__ == "__main__":
    unittest.main()
