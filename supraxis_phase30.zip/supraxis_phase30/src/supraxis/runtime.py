from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List
import json
from .errors import ReplayError, CapabilityError
from .crypto import sha256
from .state import SupraxisState
from .sirbin import MAX_CALL_DEPTH
from .committee import Committee
from .envelope import decode_envelope, EnvelopeV3, SignaturePolicy

@dataclass
class Event:
    event: str
    payload: Any

def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def cap_require(state: SupraxisState, cap_name: str, scope: str, chain_id: int, timestamp: int) -> None:
    cap_id = sha256(cap_name.encode("utf-8")).hex()
    cap = state.caps.get(cap_id)
    if not cap: raise CapabilityError("missing capability")
    if cap.get("scope") != scope: raise CapabilityError("scope mismatch")
    if int(cap.get("chain",-1)) != int(chain_id): raise CapabilityError("chain mismatch")
    if int(cap.get("expires",0)) < int(timestamp): raise CapabilityError("expired")

def gov_require(state: SupraxisState, ctx: Dict[str, Any]) -> None:
    cap_require(state, "GOVERNANCE", "global", int(ctx["target_chain"]), int(ctx["timestamp"]))

def _policy_from_state(state: SupraxisState) -> SignaturePolicy:
    min_valid = int(state.storage.get("quorum.min_valid", 1))
    mw = state.storage.get("quorum.min_weight", None)
    min_weight = int(mw) if mw is not None else None
    return SignaturePolicy(min_valid=min_valid, min_weight=min_weight)

def _attach_committee(state: SupraxisState, env: EnvelopeV3, pol: SignaturePolicy) -> SignaturePolicy:
    committee = state.get_committee_by_id(env.committee_id.hex())
    if committee is None:
        return pol
    return SignaturePolicy(
        min_valid=pol.min_valid,
        min_weight=pol.min_weight,
        allowed_schemes=pol.allowed_schemes,
        allowed_pubkeys=pol.allowed_pubkeys,
        pubkey_weights=pol.pubkey_weights,
        pubkey_allowed_schemes=pol.pubkey_allowed_schemes,
        committee=committee,
        require_committee_id=True,
    )


def _evidence_rate_limit(state: SupraxisState, submitter_hex: str) -> bool:
    """Returns True if evidence is allowed, False if rate-limited."""
    cooldown = state.evidence_cooldown()
    if cooldown > 0:
        last = int(state.evidence_last_counter.get(submitter_hex, -10**18))
        if (int(state.evidence_counter) - last) < cooldown:
            return False
    cd_attempts = state.evidence_cooldown_attempts()
    if cd_attempts > 0:
        last_a = int(state.evidence_last_attempt.get(submitter_hex, -10**18))
        if (int(state.evidence_attempts) - last_a) < cd_attempts:
            return False
    return True


def _evidence_mark_accepted(state: SupraxisState, submitter_hex: str) -> None:
    state.evidence_last_counter[submitter_hex] = int(state.evidence_counter)
    state.evidence_counter = int(state.evidence_counter + 1)

def _evidence_mark_attempt(state: SupraxisState, submitter_hex: str) -> None:
    state.evidence_last_attempt[submitter_hex] = int(state.evidence_attempts)

def _evidence_mark_reject(state: SupraxisState, submitter_hex: str) -> None:
    state.evidence_last_reject[submitter_hex] = int(state.evidence_attempts)
    state.evidence_rejects = int(state.evidence_rejects + 1)

def _apply_bounty(state: SupraxisState, submitter_hex: str, total_slashed: int) -> Dict[str, int]:
    """Split slashed amount into submitter bounty + treasury remainder (with decay + cap)."""
    base_bps = state.evidence_bounty_bps()
    min_bps = state.evidence_bounty_min_bps()
    attempts_hist = max(0, int(state.evidence_attempts) - 1)  # exclude current attempt
    accepts_hist = int(state.evidence_counter)
    failures = max(0, int(attempts_hist) - int(accepts_hist))
    denom = max(1, int(attempts_hist))
    decayed_bps = int(base_bps) - int(base_bps) * int(failures) // int(denom)
    bps = max(int(min_bps), min(10_000, int(decayed_bps)))
    bounty = (int(total_slashed) * int(bps)) // 10_000
    max_b = state.evidence_max_bounty()
    if max_b > 0:
        bounty = min(int(bounty), int(max_b))
    bounty = max(0, min(int(total_slashed), int(bounty)))
    remainder = int(total_slashed) - int(bounty)
    if bounty > 0:
        state.credit(submitter_hex, bounty)
    if remainder > 0:
        state.treasury = int(state.treasury + remainder)
    return {"bounty": int(bounty), "treasury": int(remainder), "bps": int(bps), "base_bps": int(base_bps)}


def execute_functions(state: SupraxisState, functions: Dict[str, List[Dict[str, Any]]], entry: str, ctx: Dict[str, Any]) -> List[Event]:
    if entry not in functions: raise ReplayError("missing entry")
    events: List[Event] = []
    call_stack=[entry]
    ip_stack=[0]
    submitter = str(ctx.get("origin_sender","")).lower()  # 64-hex string from envelope sender

    while call_stack:
        if len(call_stack) > MAX_CALL_DEPTH: raise ReplayError("CALL depth exceeded")
        fn=call_stack[-1]; ops=functions[fn]; ip=ip_stack[-1]
        if ip >= len(ops): raise ReplayError("function ended without RET")
        op=ops[ip]; ip_stack[-1]=ip+1
        name=op.get("op")

        if name=="CAP_REQUIRE":
            cap_require(state, str(op["cap"]), str(op["scope"]), int(ctx["target_chain"]), int(ctx["timestamp"]))

        # -----------------------
        # Governance ops
        # -----------------------
        elif name=="GOV_REGISTER_COMMITTEE_JSON":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            committee_json = json.dumps(op["committee"], sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            cid = state.register_committee_json(epoch, committee_json)
            events.append(Event(event="GOV_COMMITTEE_REGISTERED", payload={"epoch": epoch, "committee_id": cid}))

        elif name=="GOV_REGISTER_COMMITTEE_ID":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            cid = str(op["committee_id"])
            state.register_committee(epoch, cid)
            events.append(Event(event="GOV_COMMITTEE_ID_REGISTERED", payload={"epoch": epoch, "committee_id": cid.lower().replace("0x","")}))

        elif name=="GOV_SET_GRACE":
            gov_require(state, ctx)
            grace = int(op["grace"])
            state.set_rotation_grace(grace)
            events.append(Event(event="GOV_GRACE_SET", payload={"grace": int(state.rotation_grace_epochs)}))

        elif name=="GOV_SET_SLASH_PARAM":
            gov_require(state, ctx)
            offense = str(op["offense"])
            amount = int(op["amount"])
            if amount < 0:
                raise ReplayError("slash param must be >=0")
            state.storage[f"slash.{offense}"] = int(amount)
            events.append(Event(event="GOV_SLASH_PARAM_SET", payload={"offense": offense, "amount": int(amount)}))

        elif name=="GOV_SET_EVIDENCE_PARAMS":
            gov_require(state, ctx)
            bounty_bps = int(op.get("bounty_bps", state.evidence_bounty_bps()))
            bounty_min_bps = int(op.get("bounty_min_bps", state.evidence_bounty_min_bps()))
            cooldown = int(op.get("cooldown", state.evidence_cooldown()))
            cooldown_attempts = int(op.get("cooldown_attempts", state.evidence_cooldown_attempts()))
            fee = int(op.get("fee", state.evidence_fee_base()))
            fee_mode = int(op.get("fee_mode", state.evidence_fee_mode()))
            fee_sink_mode = int(op.get("fee_sink_mode", state.evidence_fee_sink_mode()))
            fee_burn_bps = int(op.get("fee_burn_bps", state.evidence_fee_burn_bps()))
            fee_burn_reject_bps = int(op.get("fee_burn_reject_bps", state.evidence_fee_burn_reject_bps()))
            refund_bps = int(op.get("refund_bps", state.evidence_refund_bps()))
            max_bounty = int(op.get("max_bounty", state.evidence_max_bounty()))
            state.storage["evidence.bounty_bps"] = max(0, min(10_000, bounty_bps))
            state.storage["evidence.bounty_min_bps"] = max(0, min(10_000, bounty_min_bps))
            state.storage["evidence.cooldown"] = max(0, cooldown)
            state.storage["evidence.cooldown_attempts"] = max(0, cooldown_attempts)
            state.storage["evidence.fee"] = max(0, fee)
            state.storage["evidence.fee_mode"] = 1 if fee_mode != 0 else 0
            state.storage["evidence.fee_sink_mode"] = max(0, min(2, fee_sink_mode))
            state.storage["evidence.fee_burn_bps"] = max(0, min(10_000, fee_burn_bps))
            state.storage["evidence.fee_burn_reject_bps"] = max(0, min(10_000, fee_burn_reject_bps))
            state.storage["evidence.refund_bps"] = max(0, min(10_000, refund_bps))
            state.storage["evidence.max_bounty"] = max(0, max_bounty)
            events.append(Event(event="GOV_EVIDENCE_PARAMS_SET", payload={
                "bounty_bps": int(state.evidence_bounty_bps()),
                "bounty_min_bps": int(state.evidence_bounty_min_bps()),
                "cooldown": int(state.evidence_cooldown()),
                "cooldown_attempts": int(state.evidence_cooldown_attempts()),
                "fee": int(state.evidence_fee_base()),
                "fee_mode": int(state.evidence_fee_mode()),
                "fee_sink_mode": int(state.evidence_fee_sink_mode()),
                "fee_burn_bps": int(state.evidence_fee_burn_bps()),
                "fee_burn_reject_bps": int(state.evidence_fee_burn_reject_bps()),
                "refund_bps": int(state.evidence_refund_bps()),
                "max_bounty": int(state.evidence_max_bounty()),
            }))

        elif name=="GOV_SET_TREASURY_DISTRIBUTION":
            gov_require(state, ctx)
            interval = int(op.get("interval", state.treasury_dist_interval()))
            ins_bps = int(op.get("insurance_bps", state.treasury_dist_insurance_bps()))
            com_bps = int(op.get("committee_bps", state.treasury_dist_committee_bps()))
            if (ins_bps + com_bps) > 10_000: raise ReplayError("distribution bps sum > 10000")
            state.storage["treasury.dist_interval"] = max(0, interval)
            state.storage["treasury.dist_insurance_bps"] = max(0, min(10_000, ins_bps))
            state.storage["treasury.dist_committee_bps"] = max(0, min(10_000, com_bps))
            events.append(Event(event="GOV_TREASURY_DISTRIBUTION_SET", payload={
                "interval": int(state.treasury_dist_interval()),
                "insurance_bps": int(state.treasury_dist_insurance_bps()),
                "committee_bps": int(state.treasury_dist_committee_bps()),
            }))

        elif name=="GOV_SET_COMMITTEE_DISTRIBUTION":
            gov_require(state, ctx)
            interval = int(op.get("interval", state.committee_dist_interval()))
            cap = int(op.get("cap_per_member", state.committee_dist_cap_per_member()))
            state.storage["committee.dist_interval"] = max(0, interval)
            state.storage["committee.dist_cap_per_member"] = max(0, cap)
            events.append(Event(event="GOV_COMMITTEE_DISTRIBUTION_SET", payload={
                "interval": int(state.committee_dist_interval()),
                "cap_per_member": int(state.committee_dist_cap_per_member()),
            }))

        elif name=="TREASURY_DISTRIBUTE":
            interval = state.treasury_dist_interval()
            if interval <= 0:
                events.append(Event(event="TREASURY_DISTRIBUTE_SKIPPED", payload={"reason":"interval=0"}))
            else:
                tick = int(op.get("tick", 0))
                last = int(state.storage.get("treasury.last_dist_tick", -10**18))
                if (tick - last) < interval:
                    events.append(Event(event="TREASURY_DISTRIBUTE_SKIPPED", payload={"reason":"too_soon","tick":tick,"last":last}))
                else:
                    t = int(state.treasury)
                    ins = t * int(state.treasury_dist_insurance_bps()) // 10_000
                    com = t * int(state.treasury_dist_committee_bps()) // 10_000
                    ins = max(0, min(t, ins))
                    com = max(0, min(t - ins, com))
                    state.treasury = int(state.treasury - ins - com)
                    state.insurance_pool = int(state.insurance_pool + ins)
                    state.committee_pool = int(state.committee_pool + com)
                    state.storage["treasury.last_dist_tick"] = int(tick)
                    events.append(Event(event="TREASURY_DISTRIBUTED", payload={"tick":tick,"insurance":int(ins),"committee":int(com),"treasury_remaining":int(state.treasury)}))

        elif name=="AUTO_TREASURY_TO_INSURANCE":
            interval = int(state.treasury_to_insurance_interval())
            if interval <= 0:
                events.append(Event(event="TREASURY_TO_INSURANCE_SKIPPED", payload={"reason":"interval=0"}))
            else:
                tick = int(op.get("tick", 0))
                last = int(state.storage.get("treasury.last_to_insurance_tick", -10**18))
                if (tick - last) < interval:
                    events.append(Event(event="TREASURY_TO_INSURANCE_SKIPPED", payload={"reason":"too_soon","tick":tick,"last":last}))
                else:
                    bps = int(state.treasury_to_insurance_bps())
                    move = int(state.treasury) * bps // 10_000
                    move = max(0, min(int(state.treasury), int(move)))
                    state.treasury = int(state.treasury - move)
                    state.insurance_pool = int(state.insurance_pool + move)
                    state.storage["treasury.last_to_insurance_tick"] = int(tick)
                    events.append(Event(event="TREASURY_TO_INSURANCE_MOVED", payload={"tick":tick,"bps":bps,"amount":int(move),"treasury_remaining":int(state.treasury),"insurance_pool":int(state.insurance_pool)}))

        elif name=="INSURANCE_CLAIM":
            to = str(op.get("to",""))
            amt = int(op.get("amount", 0))
            nonce = int(op.get("nonce", 0))
            if amt < 0: raise ReplayError("negative claim amount")
            if to.startswith("0x") or to.startswith("0X"):
                to_hex = to[2:]
            else:
                to_hex = to
            if len(to_hex) != 64: raise ReplayError("to must be 32-byte hex")
            fee = int(state.insurance_claim_fee())
            if fee > 0:
                state.debit(submitter, fee)
                state.treasury = int(state.treasury + fee)
            cid = _claim_id(to_hex.lower(), amt, nonce, submitter)
            key = _claim_key(cid)
            if state.storage.get(key, None) is not None:
                events.append(Event(event="CLAIM_DUPLICATE_IGNORED", payload={"claim_id": cid}))
            else:
                state.storage[key] = {"status":"pending","to":to_hex.lower(),"amount":int(amt),"nonce":int(nonce),"submitter":submitter,"tick":int(op.get("tick",0))}
                state.insurance_claims = int(state.insurance_claims + 1)
                events.append(Event(event="CLAIM_SUBMITTED", payload={"claim_id": cid, "to": to_hex.lower(), "amount": int(amt), "fee": int(fee)}))

        elif name=="INSURANCE_CLAIM_PAY":
            gov_require(state, ctx)
            cid = str(op.get("claim_id",""))
            if cid.startswith("0x") or cid.startswith("0X"): cid = cid[2:]
            key = _claim_key(cid)
            claim = state.storage.get(key, None)
            if claim is None: raise ReplayError("claim not found")
            if claim.get("status") != "pending": raise ReplayError("claim not pending")
            to_hex = str(claim["to"])
            amt = int(claim["amount"])
            maxp = int(state.insurance_max_payout())
            if maxp > 0 and amt > maxp: raise ReplayError("claim exceeds max_payout")
            if amt > int(state.insurance_pool): raise ReplayError("insufficient insurance_pool")
            cooldown = int(state.insurance_cooldown())
            tick = int(op.get("tick", 0))
            last = int(state.insurance_last_paid_tick.get(to_hex, -10**18))
            if cooldown > 0 and (tick - last) < cooldown: raise ReplayError("insurance cooldown")
            state.insurance_pool = int(state.insurance_pool - amt)
            state.credit(to_hex, amt)
            state.insurance_paid = int(state.insurance_paid + amt)
            state.insurance_last_paid_tick[to_hex] = int(tick)
            claim["status"] = "paid"
            claim["paid_tick"] = int(tick)
            state.storage[key] = claim
            events.append(Event(event="CLAIM_PAID", payload={"claim_id": cid, "to": to_hex, "amount": int(amt), "tick": int(tick), "insurance_remaining": int(state.insurance_pool)}))

        elif name=="INSURANCE_CLAIM_REJECT":
            gov_require(state, ctx)
            cid = str(op.get("claim_id",""))
            if cid.startswith("0x") or cid.startswith("0X"): cid = cid[2:]
            key = _claim_key(cid)
            claim = state.storage.get(key, None)
            if claim is None: raise ReplayError("claim not found")
            if claim.get("status") != "pending": raise ReplayError("claim not pending")
            claim["status"] = "rejected"
            claim["reason"] = str(op.get("reason",""))[:200]
            state.storage[key] = claim
            events.append(Event(event="CLAIM_REJECTED", payload={"claim_id": cid, "reason": claim["reason"]}))

        elif name=="CLAIM_FREEZE":
            gov_require(state, ctx)
            cid = str(op.get("claim_id",""))
            if cid.startswith("0x") or cid.startswith("0X"): cid = cid[2:]
            key = _claim_key(cid)
            claim = state.storage.get(key, None)
            if claim is None: raise ReplayError("claim not found")
            claim["frozen"] = 1
            claim["freeze_reason"] = str(op.get("reason",""))[:200]
            state.storage[key] = claim
            events.append(Event(event="CLAIM_FROZEN", payload={"claim_id": cid, "reason": claim.get("freeze_reason","")}))

        elif name=="CLAIM_UNFREEZE":
            gov_require(state, ctx)
            cid = str(op.get("claim_id",""))
            if cid.startswith("0x") or cid.startswith("0X"): cid = cid[2:]
            key = _claim_key(cid)
            claim = state.storage.get(key, None)
            if claim is None: raise ReplayError("claim not found")
            claim["frozen"] = 0
            claim["freeze_reason"] = ""
            state.storage[key] = claim
            events.append(Event(event="CLAIM_UNFROZEN", payload={"claim_id": cid}))

        elif name=="DISPUTE_SUBMIT":
            cid = str(op.get("claim_id",""))
            if cid.startswith("0x") or cid.startswith("0X"): cid = cid[2:]
            key = _claim_key(cid)
            claim = state.storage.get(key, None)
            if claim is None: raise ReplayError("claim not found")
            note = str(op.get("note",""))[:200]
            nonce = int(op.get("nonce", 0))
            dkey = f"dispute.{cid}.{submitter}.{nonce}"
            if state.storage.get(dkey, None) is not None:
                events.append(Event(event="DISPUTE_DUPLICATE_IGNORED", payload={"dispute_key": dkey}))
            else:
                state.storage[dkey] = {"claim_id": cid, "submitter": submitter, "note": note, "tick": int(op.get("tick",0)), "status":"open"}
                events.append(Event(event="DISPUTE_SUBMITTED", payload={"claim_id": cid, "submitter": submitter, "note": note, "dispute_key": dkey}))

        elif name=="LINK_EVIDENCE_TO_CLAIM":
            # permissionless: link an evidence hash (hex32) to an existing claim id
            cid = str(op.get("claim_id",""))
            if cid.startswith("0x") or cid.startswith("0X"): cid = cid[2:]
            evh = str(op.get("evidence_hash",""))
            if evh.startswith("0x") or evh.startswith("0X"): evh = evh[2:]
            if len(evh) != 64: raise ReplayError("evidence_hash must be 32-byte hex")
            key = _claim_key(cid)
            if state.storage.get(key, None) is None: raise ReplayError("claim not found")
            mapk = f"claim_evidence.{evh.lower()}"
            state.storage[mapk] = {"claim_id": cid, "submitter": submitter, "tick": int(op.get("tick",0))}
            events.append(Event(event="EVIDENCE_LINKED", payload={"claim_id": cid, "evidence_hash": evh.lower(), "submitter": submitter}))

        elif name=="DISPUTE_RESOLVE":
            gov_require(state, ctx)
            dkey = str(op.get("dispute_key",""))
            rec = state.storage.get(dkey, None)
            if rec is None: raise ReplayError("dispute not found")
            if rec.get("status") != "open": raise ReplayError("dispute not open")
            rec["status"] = "resolved"
            rec["resolution"] = str(op.get("resolution",""))[:200]
            rec["resolved_tick"] = int(op.get("tick",0))
            state.storage[dkey] = rec
            events.append(Event(event="DISPUTE_RESOLVED", payload={"dispute_key": dkey, "claim_id": rec.get("claim_id"), "resolution": rec.get("resolution")}))

        elif name=="CLAIMS_BATCH_PAY":
            gov_require(state, ctx)
            mode = str(op.get("mode", state.claims_batch_default_mode()))
            limit = int(op.get("limit", 10))
            max_total = int(op.get("max_total", 0))
            tick = int(op.get("tick", 0))
            skip_frozen = int(state.claims_batch_skip_frozen())
            skip_disputed = int(state.claims_batch_skip_disputed())
            pending = []
            for cid, claim in _iter_pending_claims(state):
                pending.append((cid, claim))
            if mode == "smallest":
                pending.sort(key=lambda x: int(x[1].get("amount",0)))
            elif mode == "largest":
                pending.sort(key=lambda x: -int(x[1].get("amount",0)))
            else:
                pending.sort(key=lambda x: int(x[1].get("tick",0)))
            paid=[]
            total_paid=0
            for cid, claim in pending[:max(0,limit)]:
                if skip_frozen != 0 and int(claim.get("frozen",0)) != 0:
                    continue
                if skip_disputed != 0:
                    # any open dispute key prefix dispute.<cid>.
                    pref = f"dispute.{cid}."
                    disputed = 0
                    for kk, vv in state.storage.items():
                        if isinstance(kk,str) and kk.startswith(pref) and isinstance(vv,dict) and vv.get("status")=="open":
                            disputed = 1
                            break
                    if disputed != 0:
                        continue
                amt = int(claim.get("amount",0))
                if max_total>0 and (total_paid + amt) > max_total:
                    continue
                maxp = int(state.insurance_max_payout())
                if maxp > 0 and amt > maxp:
                    continue
                if amt > int(state.insurance_pool):
                    break
                to_hex = str(claim.get("to",""))
                cooldown = int(state.insurance_cooldown())
                last = int(state.insurance_last_paid_tick.get(to_hex, -10**18))
                if cooldown > 0 and (tick - last) < cooldown:
                    continue
                state.insurance_pool = int(state.insurance_pool - amt)
                state.credit(to_hex, amt)
                state.insurance_paid = int(state.insurance_paid + amt)
                state.insurance_last_paid_tick[to_hex] = int(tick)
                claim["status"]="paid"
                claim["paid_tick"]=int(tick)
                state.storage[_claim_key(cid)] = claim
                total_paid += amt
                paid.append({"claim_id": cid, "to": to_hex, "amount": int(amt)})
            events.append(Event(event="CLAIMS_BATCH_RESULT", payload={"mode": mode, "limit": int(limit), "max_total": int(max_total), "paid_count": len(paid), "total_paid": int(total_paid), "paid": paid, "insurance_remaining": int(state.insurance_pool)}))

        elif name=="AUDIT_INVARIANTS":
            inv = _audit_invariants(state)
            events.append(Event(event="AUDIT_INVARIANTS", payload=inv))

        elif name=="COMMITTEE_DISTRIBUTE":
            cid = str(op.get("committee_id", ""))
            if cid.startswith("0x") or cid.startswith("0X"):
                cid_hex = cid[2:].lower()
            else:
                cid_hex = cid.lower()
            tick = int(op.get("tick", 0))
            _committee_distribute(state, cid_hex, tick, events)

        elif name=="GOV_MINT":
            gov_require(state, ctx)
            to = str(op["to"])
            amount = int(op["amount"])
            if amount < 0:
                raise ReplayError("amount must be >=0")
            state.credit(to, amount)
            events.append(Event(event="GOV_MINTED", payload={"to": to, "amount": int(amount), "new_balance": int(state.balance_of(to))}))

        elif name=="INSURANCE_PAYOUT":
            gov_require(state, ctx)
            to = str(op.get("to", ""))
            amt = int(op.get("amount", 0))
            if amt < 0: raise ReplayError("negative payout")
            if amt > int(state.insurance_pool): raise ReplayError("insufficient insurance_pool")
            if to.startswith("0x") or to.startswith("0X"):
                to_hex = to[2:]
            else:
                to_hex = to
            if len(to_hex) != 64: raise ReplayError("to must be 32-byte hex")
            state.insurance_pool = int(state.insurance_pool - amt)
            state.credit(to_hex.lower(), amt)
            events.append(Event(event="INSURANCE_PAID", payload={"to": to_hex.lower(), "amount": int(amt), "remaining": int(state.insurance_pool)}))

        elif name=="GOV_SET_INSURANCE_POLICY":
            gov_require(state, ctx)
            max_payout = int(op.get("max_payout", state.insurance_max_payout()))
            cooldown = int(op.get("cooldown", state.insurance_cooldown()))
            fee = int(op.get("claim_fee", state.insurance_claim_fee()))
            state.storage["insurance.max_payout"] = max(0, max_payout)
            state.storage["insurance.cooldown"] = max(0, cooldown)
            state.storage["insurance.claim_fee"] = max(0, fee)
            events.append(Event(event="GOV_INSURANCE_POLICY_SET", payload={"max_payout": int(state.insurance_max_payout()), "cooldown": int(state.insurance_cooldown()), "claim_fee": int(state.insurance_claim_fee())}))

        elif name=="GOV_SET_TREASURY_TO_INSURANCE":
            gov_require(state, ctx)
            interval = int(op.get("interval", state.treasury_to_insurance_interval()))
            bps = int(op.get("bps", state.treasury_to_insurance_bps()))
            state.storage["treasury.to_insurance_interval"] = max(0, interval)
            state.storage["treasury.to_insurance_bps"] = max(0, min(10_000, bps))
            events.append(Event(event="GOV_TREASURY_TO_INSURANCE_SET", payload={"interval": int(state.treasury_to_insurance_interval()), "bps": int(state.treasury_to_insurance_bps())}))

        elif name=="GOV_SET_CLAIMS_BATCH_POLICY":
            gov_require(state, ctx)
            mode = str(op.get("default_mode", state.claims_batch_default_mode()))
            skip_frozen = 1 if int(op.get("skip_frozen", state.claims_batch_skip_frozen())) != 0 else 0
            skip_disputed = 1 if int(op.get("skip_disputed", state.claims_batch_skip_disputed())) != 0 else 0
            state.storage["claims.batch_default_mode"] = mode
            state.storage["claims.batch_skip_frozen"] = int(skip_frozen)
            state.storage["claims.batch_skip_disputed"] = int(skip_disputed)
            events.append(Event(event="GOV_CLAIMS_BATCH_POLICY_SET", payload={"default_mode": mode, "skip_frozen": int(skip_frozen), "skip_disputed": int(skip_disputed)}))

        elif name=="GOV_SET_SUPPLY":
            gov_require(state, ctx)
            total = int(op.get("total", state.supply_total()))
            enforce = 1 if int(op.get("enforce", state.supply_enforce())) != 0 else 0
            state.storage["supply.total"] = max(0, int(total))
            state.storage["supply.enforce"] = int(enforce)
            events.append(Event(event="GOV_SUPPLY_SET", payload={"total": int(state.supply_total()), "enforce": int(state.supply_enforce())}))

        elif name=="GOV_SET_FEE_POLICY":
            gov_require(state, ctx)
            gas_price = int(op.get("gas_price", int(state.storage.get("fees.gas_price", 0))))
            fee_burn_bps = int(op.get("fee_burn_bps", int(state.storage.get("fees.burn_bps", 0))))
            proposer_bps = int(op.get("proposer_bps", int(state.storage.get("fees.proposer_bps", 5000))))
            committee_bps = int(op.get("committee_bps", int(state.storage.get("fees.committee_bps", 2000))))
            if gas_price < 0: raise ReplayError("bad gas_price")
            for v in [fee_burn_bps, proposer_bps, committee_bps]:
                if v < 0 or v > 10000: raise ReplayError("bad bps")
            state.storage["fees.gas_price"] = int(gas_price)
            state.storage["fees.burn_bps"] = int(fee_burn_bps)
            state.storage["fees.proposer_bps"] = int(proposer_bps)
            state.storage["fees.committee_bps"] = int(committee_bps)
            events.append(Event(event="GOV_FEE_POLICY_SET", payload={"gas_price":gas_price,"fee_burn_bps":fee_burn_bps,"proposer_bps":proposer_bps,"committee_bps":committee_bps}))

        elif name=="GOV_STAKE":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            lock_epochs = int(op.get("lock_epochs", 0))
            cur_epoch = int(ctx.get("epoch", 0))
            lock_until = cur_epoch + max(0, lock_epochs)
            state.stake_add(pubkey, amount, lock_until)
            amt, locked = state.stake_of(pubkey)
            events.append(Event(event="GOV_STAKED", payload={"pubkey": pubkey, "amount": int(amount), "new_total": int(amt), "locked_until": int(locked)}))

        elif name=="VAL_REGISTER":
            # Governance-gated validator registration (Phase 30)
            gov_require(state, ctx)
            vid = str(op.get("vid",""))
            reward_address = str(op.get("reward_address",""))
            if not vid or not reward_address: raise ReplayError("missing fields")
            state.storage[f"validator.{vid}"] = {"vid":vid, "reward_address":reward_address}
            events.append(Event(event="VAL_REGISTERED", payload={"vid":vid,"reward_address":reward_address}))

        elif name=="STAKE_BOND":
            # Move balance -> stake (fixed supply, non-inflationary security)
            pubkey = str(op.get("pubkey",""))
            from_addr = str(op.get("from",""))
            amount = int(op.get("amount",0))
            lock = int(op.get("lock_until_epoch", ctx.get("epoch",0)))
            if amount <= 0: raise ReplayError("bad amount")
            state.debit(from_addr, amount)
            state.stake_add(pubkey, amount, lock)
            events.append(Event(event="STAKE_BONDED", payload={"pubkey":pubkey,"from":from_addr,"amount":amount,"lock_until_epoch":lock}))

        elif name=="STAKE_UNBOND_REQUEST":
            pubkey = str(op.get("pubkey",""))
            to_addr = str(op.get("to",""))
            amount = int(op.get("amount",0))
            tick = int(state.storage.get("tick", 0))
            delay = int(state.storage.get("stake.unbond_delay_ticks", 100))
            if amount <= 0: raise ReplayError("bad amount")
            # subtract active stake now; create pending unbond that remains slashable until unlock
            state.stake_sub(pubkey, amount)
            unlock = int(tick + delay)
            key = f"unbond.{pubkey}"
            recs = list(state.storage.get(key, []))
            recs.append({"to":to_addr,"amount":amount,"unlock":unlock})
            state.storage[key] = recs
            events.append(Event(event="STAKE_UNBOND_REQUESTED", payload={"pubkey":pubkey,"to":to_addr,"amount":amount,"unlock_tick":unlock}))

        elif name=="STAKE_WITHDRAW":
            pubkey = str(op.get("pubkey",""))
            to_addr = str(op.get("to",""))
            tick = int(state.storage.get("tick", 0))
            key = f"unbond.{pubkey}"
            recs = list(state.storage.get(key, []))
            out = []
            paid = 0
            for r in recs:
                if str(r.get("to",""))==to_addr and int(r.get("unlock",10**18)) <= tick:
                    amt = int(r.get("amount",0))
                    if amt>0:
                        paid += amt
                else:
                    out.append(r)
            if paid <= 0: raise ReplayError("nothing to withdraw")
            state.storage[key] = out
            state.credit(to_addr, paid)
            events.append(Event(event="STAKE_WITHDRAWN", payload={"pubkey":pubkey,"to":to_addr,"amount":paid}))

        elif name=="GOV_UNSTAKE":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            cur_epoch = int(ctx.get("epoch", 0))
            amt, locked = state.stake_of(pubkey)
            if cur_epoch < int(locked):
                raise ReplayError("stake locked")
            state.stake_sub(pubkey, amount)
            amt2, locked2 = state.stake_of(pubkey)
            events.append(Event(event="GOV_UNSTAKED", payload={"pubkey": pubkey, "amount": int(amount), "new_total": int(amt2), "locked_until": int(locked2)}))

        elif name=="GOV_SLASH":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            reason = str(op.get("reason", ""))
            taken = state.slash(pubkey, amount)
            amt2, locked2 = state.stake_of(pubkey)
            events.append(Event(event="GOV_SLASHED", payload={"pubkey": pubkey, "requested": int(amount), "slashed": int(taken), "new_total": int(amt2), "reason": reason}))

        elif name=="GOV_REGISTER_COMMITTEE_FROM_STAKE":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            size = int(op["size"])
            top = state.top_stakers(size)
            members = [{"pubkey": "0x"+pk, "weight": int(amt), "schemes": [1]} for pk, amt in top]
            committee = Committee.from_dict({"members": members})
            cid = committee.committee_id()
            state.committee_store[cid] = committee.canonical_json()
            state.register_committee(epoch, cid)
            events.append(Event(event="GOV_COMMITTEE_FROM_STAKE", payload={"epoch": epoch, "committee_id": cid, "size": len(members)}))

        # -----------------------
        # Evidence-based slashing (permissionless)
        # -----------------------
        elif name=="EVIDENCE_EQUIVOCATION_V3":
            if not _evidence_rate_limit(state, submitter):
                events.append(Event(event="EVIDENCE_RATE_LIMITED", payload={"op": "EVIDENCE_EQUIVOCATION_V3"}))
            else:
                a_hex = str(op["env_a"]); b_hex = str(op["env_b"])
                a = bytes.fromhex(a_hex[2:] if a_hex.lower().startswith("0x") else a_hex)
                b = bytes.fromhex(b_hex[2:] if b_hex.lower().startswith("0x") else b_hex)
                lo, hi = (a, b) if a <= b else (b, a)
                evid = sha256(b"EVIDENCE_V3_EQUIV" + lo + hi).hex()
                if state.storage.get(f"evidence.{evid}") == 1:
                    events.append(Event(event="EVIDENCE_DUPLICATE_IGNORED", payload={"evidence_id": evid}))
                else:
                    feeinfo = _charge_evidence_fee(state, submitter)
                    fee_paid = int(feeinfo.get("fee", 0))
                    try:
                        ea = decode_envelope(a); eb = decode_envelope(b)
                        if not isinstance(ea, EnvelopeV3) or not isinstance(eb, EnvelopeV3):
                            raise ReplayError("evidence requires two v3 envelopes")
                        same = (ea.origin_chain==eb.origin_chain and ea.origin_sender==eb.origin_sender and ea.target_chain==eb.target_chain and ea.target_contract==eb.target_contract and ea.nonce==eb.nonce)
                        if not same: raise ReplayError("evidence envelopes not same stream+nonce")
                        if ea.payload_hash == eb.payload_hash: raise ReplayError("evidence not equivocation (payload_hash equal)")
                        base_pol = _policy_from_state(state)
                        ea.validate(require_signatures=True, policy=_attach_committee(state, ea, base_pol))
                        eb.validate(require_signatures=True, policy=_attach_committee(state, eb, base_pol))
                        slash_amt = state.slash_amount("double_sign", default=1)
                        severity_bps = min(5000, int(slash_amt) * 100)
                        def signer_pubkeys(env: EnvelopeV3) -> List[str]:
                            committee = state.get_committee_by_id(env.committee_id.hex())
                            if committee is None or env.quorum_proof is None: return []
                            bm = env.quorum_proof.bitmap
                            from .canonical import bitset_test as _bst
                            pks=[]
                            for i in range(committee.size()):
                                if _bst(bm, i):
                                    pks.append(("0x"+committee.pubkey_at(i).hex()).lower())
                            return pks
                        signers = sorted(set(signer_pubkeys(ea) + signer_pubkeys(eb)))
                        slashed=[]
                        total=0
                        for pk in signers:
                            taken = state.slash(pk, slash_amt)
                            total += int(taken)
                            slashed.append({"pubkey": pk, "slashed": int(taken)})
                        split = _apply_bounty(state, submitter, total)
                        fee_final = _finalize_fee_on_accept(state, fee_paid, submitter, severity_bps)
                        state.storage[f"evidence.{evid}"] = 1
                        _evidence_mark_accepted(state, submitter)
                        events.append(Event(event="EVIDENCE_EQUIVOCATION_ACCEPTED", payload={
                            "evidence_id": evid,
                            "slash": {"offense": "double_sign", "amount": int(slash_amt), "total_slashed": int(total)},
                            "payout": {"submitter": submitter, **split, **feeinfo, **fee_final},
                            "slashed": slashed,
                        }))
                    except Exception as ex:
                        fee_final = _finalize_fee_on_reject(state, fee_paid, submitter)
                        events.append(Event(event="EVIDENCE_REJECTED", payload={"evidence_id": evid, "reason": str(ex), "fee": {**feeinfo, **fee_final}}))

        elif name=="EVIDENCE_BAD_QUORUM_V3":
            if not _evidence_rate_limit(state, submitter):
                events.append(Event(event="EVIDENCE_RATE_LIMITED", payload={"op": "EVIDENCE_BAD_QUORUM_V3"}))
            else:
                env_hex = str(op["env"])
                eb = bytes.fromhex(env_hex[2:] if env_hex.lower().startswith("0x") else env_hex)
                evid = sha256(b"EVIDENCE_V3_BADQ" + eb).hex()
                if state.storage.get(f"evidence.{evid}") == 1:
                    events.append(Event(event="EVIDENCE_DUPLICATE_IGNORED", payload={"evidence_id": evid}))
                else:
                    feeinfo = _charge_evidence_fee(state, submitter)
                    fee_paid = int(feeinfo.get("fee", 0))
                    try:
                        env = decode_envelope(eb)
                        if not isinstance(env, EnvelopeV3):
                            raise ReplayError("evidence requires v3 envelope")
                        committee = state.get_committee_by_id(env.committee_id.hex())
                        if committee is None:
                            raise ReplayError("committee not found for evidence")
                        base_pol = _policy_from_state(state)
                        pol = _attach_committee(state, env, base_pol)
                        try:
                            env.validate(require_signatures=True, policy=pol)
                            raise ReplayError("evidence not bad quorum (envelope valid)")
                        except ReplayError:
                            raise
                        except Exception:
                            slash_amt = state.slash_amount("bad_quorum", default=1)
                            severity_bps = min(5000, int(slash_amt) * 100)
                            bm = env.quorum_proof.bitmap if env.quorum_proof is not None else b""
                            from .canonical import bitset_test as _bst
                            slashed=[]
                            total=0
                            for i in range(committee.size()):
                                if _bst(bm, i):
                                    pk = ("0x"+committee.pubkey_at(i).hex()).lower()
                                    taken = state.slash(pk, slash_amt)
                                    total += int(taken)
                                    slashed.append({"pubkey": pk, "slashed": int(taken)})
                            split = _apply_bounty(state, submitter, total)
                            fee_final = _finalize_fee_on_accept(state, fee_paid, submitter, severity_bps)
                            state.storage[f"evidence.{evid}"] = 1
                            _evidence_mark_accepted(state, submitter)
                            events.append(Event(event="EVIDENCE_BAD_QUORUM_ACCEPTED", payload={
                                "evidence_id": evid,
                                "slash": {"offense": "bad_quorum", "amount": int(slash_amt), "total_slashed": int(total)},
                                "payout": {"submitter": submitter, **split, **feeinfo, **fee_final},
                                "slashed": slashed,
                            }))
                    except Exception as ex:
                        fee_final = _finalize_fee_on_reject(state, fee_paid, submitter)
                        events.append(Event(event="EVIDENCE_REJECTED", payload={"evidence_id": evid, "reason": str(ex), "fee": {**feeinfo, **fee_final}}))

        elif name=="EMIT":
            events.append(Event(event=str(op["event"]), payload=op.get("payload")))

        elif name=="STORE":
            state.storage[str(op["key"])] = op.get("value")

        elif name=="ASSERT":
            if not bool(op.get("value")): raise ReplayError("ASSERT failed")

        elif name=="CALL":
            callee=str(op["fn"])
            if callee not in functions: raise ReplayError("unknown callee")
            call_stack.append(callee); ip_stack.append(0)

        elif name=="CONSENSUS_SLASH_DOUBLE_VOTE":
            # Slash validator for double-vote evidence (Phase 30)
            from supraxis.consensus.slashing import verify_double_vote
            evidence = op.get("evidence", {})
            ok, why = verify_double_vote(evidence)
            if not ok: raise ReplayError(f"bad evidence: {why}")
            pubkey = str(evidence.get("pubkey",""))
            reporter = str(op.get("reporter",""))
            tick = int(state.storage.get("tick", 0))
            # slash rate in bps of total slashable (stake + pending unbonds still locked by delay; simplified)
            rate = int(state.storage.get("slash.rate_bps", 5000))
            burn_bps = int(state.storage.get("slash.burn_bps", 2000))
            tre_bps = int(state.storage.get("slash.treasury_bps", 7000))
            rep_bps = int(state.storage.get("slash.reporter_bps", 1000))
            cur, _ = state.stake_of(pubkey)
            amt = (int(cur) * rate)//10000
            taken = state.slash(pubkey, amt)
            if taken <= 0: raise ReplayError("nothing to slash")
            burn = (taken*burn_bps)//10000
            tre = (taken*tre_bps)//10000
            rep = taken - burn - tre
            if burn>0: state.burn(burn, reason="slash")
            state.treasury = int(state.treasury + tre)
            if reporter and rep>0: state.credit(reporter, rep)
            events.append(Event(event="CONSENSUS_SLASHED_DOUBLE_VOTE", payload={"pubkey":pubkey,"slashed":taken,"burned":burn,"treasury":tre,"reporter_paid":rep}))

        elif name=="CONSENSUS_SLASH_EQUIVOCATION":
            from supraxis.consensus.slashing import verify_equivocating_proposer
            evidence = op.get("evidence", {})
            ok, why = verify_equivocating_proposer(evidence)
            if not ok: raise ReplayError(f"bad evidence: {why}")
            pubkey = str(evidence.get("pubkey",""))
            reporter = str(op.get("reporter",""))
            rate = int(state.storage.get("slash.rate_bps", 5000))
            burn_bps = int(state.storage.get("slash.burn_bps", 2000))
            tre_bps = int(state.storage.get("slash.treasury_bps", 7000))
            rep_bps = int(state.storage.get("slash.reporter_bps", 1000))
            cur, _ = state.stake_of(pubkey)
            amt = (int(cur) * rate)//10000
            taken = state.slash(pubkey, amt)
            if taken <= 0: raise ReplayError("nothing to slash")
            burn = (taken*burn_bps)//10000
            tre = (taken*tre_bps)//10000
            rep = taken - burn - tre
            if burn>0: state.burn(burn, reason="slash")
            state.treasury = int(state.treasury + tre)
            if reporter and rep>0: state.credit(reporter, rep)
            events.append(Event(event="CONSENSUS_SLASHED_EQUIVOCATION", payload={"pubkey":pubkey,"slashed":taken,"burned":burn,"treasury":tre,"reporter_paid":rep}))

        elif name=="RET":
            call_stack.pop(); ip_stack.pop()

        else:
            raise ReplayError("unknown op")
        # Phase 26 invariants: hard-fail on non-negativity / category mismatch
        try:
            state.assert_non_negative()
        except Exception as e:
            raise ReplayError(f"invariant violation: {str(e)}")


    # Phase 26: final invariant check (non-negativity only here; conservation is checked at block layer if enabled)
    try:
        state.assert_non_negative()
    except Exception as e:
        raise ReplayError(f"invariant violation: {str(e)}")

    return events

def _charge_evidence_fee(state: SupraxisState, submitter_hex: str) -> Dict[str, int]:
    """Charge evidence fee; deposit to treasury (burn adjustments later). Always counts as an attempt."""
    base = state.evidence_fee_base()
    mode = int(state.evidence_fee_mode())
    if base <= 0:
        _evidence_mark_attempt(state, submitter_hex)
        state.evidence_attempts = int(state.evidence_attempts + 1)
        return {"fee": 0, "base": int(base), "mode": int(mode)}
    attempts = max(1, int(state.evidence_attempts))
    accepts = int(state.evidence_counter)
    failures = max(0, attempts - accepts)
    fee = int(base)
    if mode == 1:
        fee = int(base + (base * failures // attempts))
    state.debit(submitter_hex, fee)
    state.treasury = int(state.treasury + fee)
    _evidence_mark_attempt(state, submitter_hex)
    state.evidence_attempts = int(state.evidence_attempts + 1)
    return {"fee": int(fee), "base": int(base), "mode": int(mode), "attempts": int(attempts), "accepts": int(accepts)}

def _finalize_fee_on_accept(state: SupraxisState, fee_paid: int, submitter_hex: str, severity_bps: int = 0) -> Dict[str, int]:
    """Apply sink/burn and refund on accept."""
    sink = int(state.evidence_fee_sink_mode())
    burn_bps = int(state.evidence_fee_burn_bps())
    sev = max(0, min(5_000, int(severity_bps)))
    burn = 0
    if fee_paid > 0:
        if sink == 1:
            burn = int(fee_paid)
        elif sink == 2:
            burn = int(fee_paid) * int(min(10_000, burn_bps + sev)) // 10_000
        burn = max(0, min(int(fee_paid), int(burn)))
        if burn > 0:
            state.treasury = int(state.treasury - burn)
            state.burn(int(burn), reason="fee")
    refund_bps = int(state.evidence_refund_bps())
    refund = int(fee_paid) * int(refund_bps) // 10_000
    refund = max(0, min(int(fee_paid) - int(burn), int(refund)))
    if refund > 0:
        state.treasury = int(state.treasury - refund)
        state.credit(submitter_hex, refund)
    return {"burned_fee": int(burn), "refunded_fee": int(refund), "sink_mode": int(sink), "burn_bps": int(burn_bps), "severity_bps": int(sev)}

def _finalize_fee_on_reject(state: SupraxisState, fee_paid: int, submitter_hex: str) -> Dict[str, int]:
    """On reject, optionally burn a larger portion; no refund."""
    if fee_paid <= 0:
        _evidence_mark_reject(state, submitter_hex)
        return {"burned_fee": 0, "refunded_fee": 0}
    sink = int(state.evidence_fee_sink_mode())
    burn = 0
    if sink == 1:
        burn = int(fee_paid)
    elif sink == 2:
        burn_bps = int(state.evidence_fee_burn_reject_bps())
        burn = int(fee_paid) * int(burn_bps) // 10_000
    burn = max(0, min(int(fee_paid), int(burn)))
    if burn > 0:
        state.treasury = int(state.treasury - burn)
        state.burn(int(burn), reason="fee")
    _evidence_mark_reject(state, submitter_hex)
    return {"burned_fee": int(burn), "refunded_fee": 0, "sink_mode": int(sink)}
def _committee_distribute(state: SupraxisState, committee_id_hex: str, tick: int, events: List[Event]) -> None:
    interval = int(state.committee_dist_interval())
    if interval <= 0:
        events.append(Event(event="COMMITTEE_DISTRIBUTE_SKIPPED", payload={"reason":"interval=0"}))
        return
    last = int(state.committee_last_dist_tick)
    if (int(tick) - int(last)) < int(interval):
        events.append(Event(event="COMMITTEE_DISTRIBUTE_SKIPPED", payload={"reason":"too_soon","tick":int(tick),"last":int(last)}))
        return
    committee = state.get_committee_by_id(committee_id_hex)
    if committee is None:
        events.append(Event(event="COMMITTEE_DISTRIBUTE_SKIPPED", payload={"reason":"committee_not_found","committee_id":committee_id_hex}))
        return
    n = int(committee.size())
    if n <= 0:
        events.append(Event(event="COMMITTEE_DISTRIBUTE_SKIPPED", payload={"reason":"empty_committee","committee_id":committee_id_hex}))
        return
    total = int(state.committee_pool)
    if total <= 0:
        events.append(Event(event="COMMITTEE_DISTRIBUTE_SKIPPED", payload={"reason":"pool_empty","committee_id":committee_id_hex}))
        state.committee_last_dist_tick = int(tick)
        return
    share = total // n
    cap = int(state.committee_dist_cap_per_member())
    if cap > 0:
        share = min(int(share), int(cap))
    paid = 0
    payouts = []
    for i in range(n):
        pk = ("0x" + committee.pubkey_at(i).hex()).lower()
        if share > 0:
            state.stake_add(pk, int(share), 0)
            paid += int(share)
        payouts.append({"pubkey": pk, "amount": int(share)})
    state.committee_pool = int(state.committee_pool - paid)
    state.committee_last_dist_tick = int(tick)
    events.append(Event(event="COMMITTEE_DISTRIBUTED", payload={"committee_id": committee_id_hex, "tick": int(tick), "paid": int(paid), "per_member": int(share), "remaining": int(state.committee_pool), "payouts": payouts}))

def _claim_id(to_hex: str, amount: int, nonce: int, submitter_hex: str) -> str:
    b = bytes.fromhex(to_hex) + int(amount).to_bytes(8,'big') + int(nonce).to_bytes(8,'big') + bytes.fromhex(submitter_hex)
    return sha256(b"CLAIM" + b).hex()

def _claim_key(cid: str) -> str:
    return f"claim.{cid}"

def _iter_pending_claims(state: SupraxisState):
    for k, v in state.storage.items():
        if not isinstance(k, str):
            continue
        if not k.startswith("claim."):
            continue
        if isinstance(v, dict) and v.get("status") == "pending":
            yield k[6:], v

def _audit_invariants(state: SupraxisState) -> Dict[str, int]:
    fields = {
        "treasury": int(state.treasury),
        "burned": int(getattr(state, "burned", 0)),
        "insurance_pool": int(state.insurance_pool),
        "committee_pool": int(state.committee_pool),
        "total_supply": int(getattr(state, "total_supply", 0)),
    }
    ok = 1
    for v in fields.values():
        if int(v) < 0: ok = 0
    pending_ct=paid_ct=rej_ct=frozen_ct=0
    pending_sum=0
    for k, v in state.storage.items():
        if isinstance(k,str) and k.startswith("claim.") and isinstance(v,dict):
            st = v.get("status")
            if st=="pending":
                pending_ct += 1
                pending_sum += int(v.get("amount",0))
                if int(v.get("frozen",0))!=0: frozen_ct += 1
            elif st=="paid":
                paid_ct += 1
            elif st=="rejected":
                rej_ct += 1
    # soft check: pending_sum should not be negative
    if pending_sum < 0: ok = 0
    return {"ok": int(ok), **fields, "claims_pending": int(pending_ct), "claims_paid": int(paid_ct), "claims_rejected": int(rej_ct), "claims_frozen": int(frozen_ct), "pending_sum": int(pending_sum)}
