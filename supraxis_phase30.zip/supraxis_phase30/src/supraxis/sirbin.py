from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import json
from .canonical import pack_u16, pack_u32, pack_u64, read_u16, read_u32, read_u64
from .errors import ReplayError

MAGIC=b"SIRB"
VERSION=1

OP_CAP_REQUIRE=0x01
OP_EMIT=0x02
OP_STORE=0x03
OP_ASSERT=0x04

# Governance opcodes
OP_GOV_REGISTER_COMMITTEE_JSON=0x20
OP_GOV_REGISTER_COMMITTEE_ID=0x21
OP_GOV_SET_GRACE=0x22

# Stake + slashing
OP_GOV_STAKE=0x23
OP_GOV_UNSTAKE=0x24
OP_GOV_SLASH=0x25
OP_GOV_REGISTER_COMMITTEE_FROM_STAKE=0x26

# governance-settable slash parameter
OP_GOV_SET_SLASH_PARAM=0x27

# Phase 19: evidence rewards + spam controls (governance)
OP_GOV_SET_EVIDENCE_PARAMS=0x28
OP_GOV_MINT=0x29
OP_GOV_SET_TREASURY_DISTRIBUTION=0x2A

# Phase 17: evidence-based slashing
OP_EVIDENCE_EQUIVOCATION_V3=0x31

# Phase 18: evidence-based bad quorum proof
OP_EVIDENCE_BAD_QUORUM_V3=0x32
OP_TREASURY_DISTRIBUTE=0x33
OP_GOV_SET_COMMITTEE_DISTRIBUTION=0x34
OP_COMMITTEE_DISTRIBUTE=0x35
OP_INSURANCE_PAYOUT=0x36
OP_GOV_SET_INSURANCE_POLICY=0x37
OP_GOV_SET_TREASURY_TO_INSURANCE=0x38
OP_AUTO_TREASURY_TO_INSURANCE=0x39
OP_INSURANCE_CLAIM=0x3A
OP_INSURANCE_CLAIM_PAY=0x3B
OP_INSURANCE_CLAIM_REJECT=0x3C
OP_DISPUTE_SUBMIT=0x3D
OP_DISPUTE_RESOLVE=0x3E
OP_CLAIMS_BATCH_PAY=0x3F
OP_AUDIT_INVARIANTS=0x40
OP_GOV_SET_CLAIMS_BATCH_POLICY=0x41
OP_CLAIM_FREEZE=0x42
OP_CLAIM_UNFREEZE=0x43
OP_LINK_EVIDENCE_TO_CLAIM=0x44
OP_GOV_SET_SUPPLY=0x45
OP_CONSENSUS_SLASH_EQUIVOCATION=0x4C
OP_CONSENSUS_SLASH_DOUBLE_VOTE=0x4B
OP_STAKE_WITHDRAW=0x4A
OP_STAKE_UNBOND_REQUEST=0x49
OP_STAKE_BOND=0x48
OP_VAL_REGISTER=0x47
OP_GOV_SET_FEE_POLICY=0x46

OP_CALL=0x10
OP_RET=0xFF

MAX_CALL_DEPTH=32

def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def _pack_str(s: str) -> bytes:
    b=s.encode("utf-8")
    return pack_u16(len(b))+b

def _read_str(buf: bytes, off: int) -> Tuple[str,int]:
    n, off = read_u16(buf, off)
    if off+n>len(buf): raise ReplayError("EOF str")
    return buf[off:off+n].decode("utf-8"), off+n

def _pack_blob(b: bytes) -> bytes:
    return pack_u32(len(b)) + b

def _read_blob(buf: bytes, off: int) -> Tuple[bytes,int]:
    n, off = read_u32(buf, off)
    if off+n>len(buf): raise ReplayError("EOF blob")
    return buf[off:off+n], off+n

@dataclass(frozen=True)
class SirBinProgram:
    version: int
    functions: Dict[str, List[Dict[str, Any]]]

    def encode(self) -> bytes:
        out=bytearray()
        out+=MAGIC
        out+=pack_u16(VERSION)
        items=sorted(self.functions.items(), key=lambda kv: kv[0])
        out+=pack_u16(len(items))
        for name, ops in items:
            out+=_pack_str(name)
            out+=pack_u32(len(ops))
            for op in ops:
                out.append(opcode_for(op))
                out+=encode_operands(op)
        return bytes(out)

    @staticmethod
    def decode(buf: bytes) -> "SirBinProgram":
        if len(buf)<8 or buf[:4]!=MAGIC: raise ReplayError("bad SIRB")
        off=4
        ver, off = read_u16(buf, off)
        if ver!=VERSION: raise ReplayError("bad version")
        nfn, off = read_u16(buf, off)
        fns={}
        for _ in range(nfn):
            name, off = _read_str(buf, off)
            nop, off = read_u32(buf, off)
            ops=[]
            for _ in range(nop):
                if off>=len(buf): raise ReplayError("EOF opcode")
                opc=buf[off]; off+=1
                op, off = decode_op(buf, off, opc)
                ops.append(op)
            fns[name]=ops
        if off!=len(buf): raise ReplayError("trailing bytes")
        return SirBinProgram(version=VERSION, functions=fns)

def opcode_for(op: Dict[str,Any]) -> int:
    n=op.get("op")
    if n=="CAP_REQUIRE": return OP_CAP_REQUIRE
    if n=="EMIT": return OP_EMIT
    if n=="STORE": return OP_STORE
    if n=="ASSERT": return OP_ASSERT

    if n=="GOV_REGISTER_COMMITTEE_JSON": return OP_GOV_REGISTER_COMMITTEE_JSON
    if n=="GOV_REGISTER_COMMITTEE_ID": return OP_GOV_REGISTER_COMMITTEE_ID
    if n=="GOV_SET_GRACE": return OP_GOV_SET_GRACE

    if n=="GOV_STAKE": return OP_GOV_STAKE
    if n=="GOV_UNSTAKE": return OP_GOV_UNSTAKE
    if n=="GOV_SLASH": return OP_GOV_SLASH
    if n=="GOV_REGISTER_COMMITTEE_FROM_STAKE": return OP_GOV_REGISTER_COMMITTEE_FROM_STAKE

    if n=="GOV_SET_SLASH_PARAM": return OP_GOV_SET_SLASH_PARAM

    if n=="GOV_SET_EVIDENCE_PARAMS": return OP_GOV_SET_EVIDENCE_PARAMS
    if n=="GOV_MINT": return OP_GOV_MINT
    if n=="GOV_SET_TREASURY_DISTRIBUTION": return OP_GOV_SET_TREASURY_DISTRIBUTION

    if n=="EVIDENCE_EQUIVOCATION_V3": return OP_EVIDENCE_EQUIVOCATION_V3

    if n=="EVIDENCE_BAD_QUORUM_V3": return OP_EVIDENCE_BAD_QUORUM_V3
    if n=="TREASURY_DISTRIBUTE": return OP_TREASURY_DISTRIBUTE
    if n=="GOV_SET_COMMITTEE_DISTRIBUTION": return OP_GOV_SET_COMMITTEE_DISTRIBUTION
    if n=="COMMITTEE_DISTRIBUTE": return OP_COMMITTEE_DISTRIBUTE
    if n=="INSURANCE_PAYOUT": return OP_INSURANCE_PAYOUT
    if n=="GOV_SET_INSURANCE_POLICY": return OP_GOV_SET_INSURANCE_POLICY
    if n=="GOV_SET_TREASURY_TO_INSURANCE": return OP_GOV_SET_TREASURY_TO_INSURANCE
    if n=="AUTO_TREASURY_TO_INSURANCE": return OP_AUTO_TREASURY_TO_INSURANCE
    if n=="INSURANCE_CLAIM": return OP_INSURANCE_CLAIM
    if n=="INSURANCE_CLAIM_PAY": return OP_INSURANCE_CLAIM_PAY
    if n=="INSURANCE_CLAIM_REJECT": return OP_INSURANCE_CLAIM_REJECT
    if n=="DISPUTE_SUBMIT": return OP_DISPUTE_SUBMIT
    if n=="DISPUTE_RESOLVE": return OP_DISPUTE_RESOLVE
    if n=="CLAIMS_BATCH_PAY": return OP_CLAIMS_BATCH_PAY
    if n=="GOV_SET_FEE_POLICY": return OP_GOV_SET_FEE_POLICY
    if n=="VAL_REGISTER": return OP_VAL_REGISTER
    if n=="STAKE_BOND": return OP_STAKE_BOND
    if n=="STAKE_UNBOND_REQUEST": return OP_STAKE_UNBOND_REQUEST
    if n=="STAKE_WITHDRAW": return OP_STAKE_WITHDRAW
    if n=="CONSENSUS_SLASH_DOUBLE_VOTE": return OP_CONSENSUS_SLASH_DOUBLE_VOTE
    if n=="CONSENSUS_SLASH_EQUIVOCATION": return OP_CONSENSUS_SLASH_EQUIVOCATION
    if n=="AUDIT_INVARIANTS": return OP_AUDIT_INVARIANTS
    if n=="GOV_SET_CLAIMS_BATCH_POLICY": return OP_GOV_SET_CLAIMS_BATCH_POLICY
    if n=="CLAIM_FREEZE": return OP_CLAIM_FREEZE
    if n=="CLAIM_UNFREEZE": return OP_CLAIM_UNFREEZE
    if n=="LINK_EVIDENCE_TO_CLAIM": return OP_LINK_EVIDENCE_TO_CLAIM
    if n=="GOV_SET_SUPPLY": return OP_GOV_SET_SUPPLY

    if n=="CALL": return OP_CALL
    if n=="RET": return OP_RET
    raise ReplayError("unknown op")

def _hex_to_bytes(s: str) -> bytes:
    s=s.strip()
    if s.lower().startswith("0x"): s=s[2:]
    return bytes.fromhex(s)

def encode_operands(op: Dict[str,Any]) -> bytes:
    n=op["op"]
    if n=="CAP_REQUIRE": return _pack_str(str(op["cap"]))+_pack_str(str(op["scope"]))
    if n=="EMIT":
        pb=canonical_json_bytes(op.get("payload"))
        return _pack_str(str(op["event"]))+pack_u32(len(pb))+pb
    if n=="STORE":
        vb=canonical_json_bytes(op.get("value"))
        return _pack_str(str(op["key"]))+pack_u32(len(vb))+vb
    if n=="ASSERT": return bytes([1 if bool(op.get("value")) else 0])

    if n=="GOV_REGISTER_COMMITTEE_JSON":
        epoch=int(op["epoch"])
        cb=canonical_json_bytes(op["committee"])
        return pack_u64(epoch) + pack_u32(len(cb)) + cb
    if n=="GOV_REGISTER_COMMITTEE_ID":
        epoch=int(op["epoch"])
        return pack_u64(epoch) + _pack_str(str(op["committee_id"]))
    if n=="GOV_SET_GRACE":
        grace=int(op["grace"])
        return pack_u32(grace)

    if n=="GOV_STAKE":
        pk=_pack_str(str(op["pubkey"]))
        amount=pack_u64(int(op["amount"]))
        lock=pack_u32(int(op.get("lock_epochs", 0)))
        return pk + amount + lock
    if n=="GOV_UNSTAKE":
        pk=_pack_str(str(op["pubkey"]))
        amount=pack_u64(int(op["amount"]))
        return pk + amount
    if n=="GOV_SLASH":
        pk=_pack_str(str(op["pubkey"]))
        amount=pack_u64(int(op["amount"]))
        reason=_pack_str(str(op.get("reason","")))
        return pk + amount + reason
    if n=="GOV_REGISTER_COMMITTEE_FROM_STAKE":
        epoch=pack_u64(int(op["epoch"]))
        size=pack_u32(int(op["size"]))
        return epoch + size

    if n=="GOV_SET_SLASH_PARAM":
        offense=_pack_str(str(op["offense"]))
        amount=pack_u64(int(op["amount"]))
        return offense + amount

    if n=="GOV_SET_EVIDENCE_PARAMS":
        bounty=pack_u32(int(op.get("bounty_bps", 1000)))
        bounty_min=pack_u32(int(op.get("bounty_min_bps", 0)))
        cooldown=pack_u32(int(op.get("cooldown", 0)))
        cooldown_a=pack_u32(int(op.get("cooldown_attempts", 0)))
        fee=pack_u32(int(op.get("fee", 0)))
        fee_mode=pack_u32(int(op.get("fee_mode", 0)))
        sink_mode=pack_u32(int(op.get("fee_sink_mode", 0)))
        burn_bps=pack_u32(int(op.get("fee_burn_bps", 0)))
        burn_rej=pack_u32(int(op.get("fee_burn_reject_bps", 0)))
        refund=pack_u32(int(op.get("refund_bps", 10000)))
        maxb=pack_u32(int(op.get("max_bounty", 0)))
        return bounty + bounty_min + cooldown + cooldown_a + fee + fee_mode + sink_mode + burn_bps + burn_rej + refund + maxb

    if n=="GOV_SET_TREASURY_DISTRIBUTION":
        interval=pack_u32(int(op.get("interval", 0)))
        ins=pack_u32(int(op.get("insurance_bps", 0)))
        com=pack_u32(int(op.get("committee_bps", 0)))
        return interval + ins + com

    if n=="GOV_MINT":
        to=_pack_str(str(op["to"]))
        amount=pack_u64(int(op["amount"]))
        return to + amount

    if n=="TREASURY_DISTRIBUTE":
        if "tick" in op:
            return pack_u32(int(op.get("tick", 0)))
        return b""

    if n=="EVIDENCE_EQUIVOCATION_V3":
        a=_hex_to_bytes(str(op["env_a"]))
        b=_hex_to_bytes(str(op["env_b"]))
        return _pack_blob(a) + _pack_blob(b)

    if n=="EVIDENCE_BAD_QUORUM_V3":
        e=_hex_to_bytes(str(op["env"]))
        return _pack_blob(e)

    if n=="CALL": return _pack_str(str(op["fn"]))
    if n=="RET": return b""
    raise ReplayError("bad op")

def decode_op(buf: bytes, off: int, opc: int):
    if opc==OP_CAP_REQUIRE:
        cap, off=_read_str(buf, off); scope, off=_read_str(buf, off)
        return {"op":"CAP_REQUIRE","cap":cap,"scope":scope}, off
    if opc==OP_EMIT:
        event, off=_read_str(buf, off)
        n, off=read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF payload")
        payload=json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"EMIT","event":event,"payload":payload}, off
    if opc==OP_STORE:
        key, off=_read_str(buf, off)
        n, off=read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF value")
        value=json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"STORE","key":key,"value":value}, off
    if opc==OP_ASSERT:
        if off>=len(buf): raise ReplayError("EOF assert")
        v=buf[off]; off+=1
        if v not in (0,1): raise ReplayError("bad assert")
        return {"op":"ASSERT","value":bool(v)}, off

    if opc==OP_GOV_REGISTER_COMMITTEE_JSON:
        epoch, off = read_u64(buf, off)
        n, off = read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF committee")
        committee = json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"GOV_REGISTER_COMMITTEE_JSON","epoch":int(epoch),"committee":committee}, off
    if opc==OP_GOV_REGISTER_COMMITTEE_ID:
        epoch, off = read_u64(buf, off)
        cid, off = _read_str(buf, off)
        return {"op":"GOV_REGISTER_COMMITTEE_ID","epoch":int(epoch),"committee_id":cid}, off
    if opc==OP_GOV_SET_GRACE:
        grace, off = read_u32(buf, off)
        return {"op":"GOV_SET_GRACE","grace":int(grace)}, off

    if opc==OP_GOV_STAKE:
        pk, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        lock, off = read_u32(buf, off)
        return {"op":"GOV_STAKE","pubkey":pk,"amount":int(amount),"lock_epochs":int(lock)}, off
    if opc==OP_GOV_UNSTAKE:
        pk, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        return {"op":"GOV_UNSTAKE","pubkey":pk,"amount":int(amount)}, off
    if opc==OP_GOV_SLASH:
        pk, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        reason, off = _read_str(buf, off)
        return {"op":"GOV_SLASH","pubkey":pk,"amount":int(amount),"reason":reason}, off
    if opc==OP_GOV_REGISTER_COMMITTEE_FROM_STAKE:
        epoch, off = read_u64(buf, off)
        size, off = read_u32(buf, off)
        return {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE","epoch":int(epoch),"size":int(size)}, off

    if opc==OP_GOV_SET_SLASH_PARAM:
        offense, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        return {"op":"GOV_SET_SLASH_PARAM","offense":offense,"amount":int(amount)}, off

    if opc==OP_GOV_SET_EVIDENCE_PARAMS:
        bounty, off = read_u32(buf, off)
        bounty_min, off = read_u32(buf, off)
        cooldown, off = read_u32(buf, off)
        cooldown_a, off = read_u32(buf, off)
        fee, off = read_u32(buf, off)
        fee_mode, off = read_u32(buf, off)
        sink_mode, off = read_u32(buf, off)
        burn_bps, off = read_u32(buf, off)
        burn_rej, off = read_u32(buf, off)
        refund, off = read_u32(buf, off)
        maxb, off = read_u32(buf, off)
        return {"op":"GOV_SET_EVIDENCE_PARAMS","bounty_bps":int(bounty),"bounty_min_bps":int(bounty_min),"cooldown":int(cooldown),"cooldown_attempts":int(cooldown_a),"fee":int(fee),"fee_mode":int(fee_mode),"fee_sink_mode":int(sink_mode),"fee_burn_bps":int(burn_bps),"fee_burn_reject_bps":int(burn_rej),"refund_bps":int(refund),"max_bounty":int(maxb)}, off

    if opc==OP_GOV_SET_COMMITTEE_DISTRIBUTION:
        interval, off = read_u32(buf, off)
        cap, off = read_u32(buf, off)
        return {"op":"GOV_SET_COMMITTEE_DISTRIBUTION","interval":int(interval),"cap_per_member":int(cap)}, off

    if opc==OP_GOV_SET_TREASURY_DISTRIBUTION:
        interval, off = read_u32(buf, off)
        ins, off = read_u32(buf, off)
        com, off = read_u32(buf, off)
        return {"op":"GOV_SET_TREASURY_DISTRIBUTION","interval":int(interval),"insurance_bps":int(ins),"committee_bps":int(com)}, off

    if opc==OP_GOV_SET_INSURANCE_POLICY:
        maxp, off = read_u32(buf, off)
        cd, off = read_u32(buf, off)
        fee, off = read_u32(buf, off)
        return {"op":"GOV_SET_INSURANCE_POLICY","max_payout":int(maxp),"cooldown":int(cd),"claim_fee":int(fee)}, off

    if opc==OP_GOV_SET_TREASURY_TO_INSURANCE:
        interval, off = read_u32(buf, off)
        bps, off = read_u32(buf, off)
        return {"op":"GOV_SET_TREASURY_TO_INSURANCE","interval":int(interval),"bps":int(bps)}, off

    if opc==OP_AUTO_TREASURY_TO_INSURANCE:
        if off + 4 <= len(buf):
            tick, off = read_u32(buf, off)
            return {"op":"AUTO_TREASURY_TO_INSURANCE","tick":int(tick)}, off
        return {"op":"AUTO_TREASURY_TO_INSURANCE"}, off

    if opc==OP_INSURANCE_CLAIM:
        to, off = read_hex32(buf, off)
        amt, off = read_u32(buf, off)
        nonce, off = read_u32(buf, off)
        tick, off = read_u32(buf, off)
        return {"op":"INSURANCE_CLAIM","to":"0x"+to,"amount":int(amt),"nonce":int(nonce),"tick":int(tick)}, off

    if opc==OP_INSURANCE_CLAIM_PAY:
        cid, off = read_hex32(buf, off)
        tick, off = read_u32(buf, off)
        return {"op":"INSURANCE_CLAIM_PAY","claim_id":"0x"+cid,"tick":int(tick)}, off

    if opc==OP_DISPUTE_SUBMIT:
        cid, off = read_hex32(buf, off)
        nonce, off = read_u32(buf, off)
        tick, off = read_u32(buf, off)
        return {"op":"DISPUTE_SUBMIT","claim_id":"0x"+cid,"nonce":int(nonce),"tick":int(tick)}, off

    if opc==OP_DISPUTE_RESOLVE:
        dkey, off = read_str(buf, off)
        tick, off = read_u32(buf, off)
        return {"op":"DISPUTE_RESOLVE","dispute_key":dkey,"tick":int(tick)}, off

    if opc==OP_CLAIMS_BATCH_PAY:
        mode, off = read_str(buf, off)
        limit, off = read_u32(buf, off)
        max_total, off = read_u32(buf, off)
        tick, off = read_u32(buf, off)
        return {"op":"CLAIMS_BATCH_PAY","mode":mode,"limit":int(limit),"max_total":int(max_total),"tick":int(tick)}, off

    if opc==OP_GOV_SET_CLAIMS_BATCH_POLICY:
        mode, off = read_str(buf, off)
        sf, off = read_u32(buf, off)
        sd, off = read_u32(buf, off)
        return {"op":"GOV_SET_CLAIMS_BATCH_POLICY","default_mode":mode,"skip_frozen":int(sf),"skip_disputed":int(sd)}, off

    if opc==OP_CLAIM_FREEZE:
        cid, off = read_hex32(buf, off)
        return {"op":"CLAIM_FREEZE","claim_id":"0x"+cid}, off

    if opc==OP_CLAIM_UNFREEZE:
        cid, off = read_hex32(buf, off)
        return {"op":"CLAIM_UNFREEZE","claim_id":"0x"+cid}, off

    if opc==OP_LINK_EVIDENCE_TO_CLAIM:
        cid, off = read_hex32(buf, off)
        ev, off = read_hex32(buf, off)
        tick, off = read_u32(buf, off)
        return {"op":"LINK_EVIDENCE_TO_CLAIM","claim_id":"0x"+cid,"evidence_hash":"0x"+ev,"tick":int(tick)}, off

    if opc==OP_GOV_SET_SUPPLY:
        total, off = read_u32(buf, off)
        enforce, off = read_u32(buf, off)
        return {"op":"GOV_SET_SUPPLY","total":int(total),"enforce":int(enforce)}, off

    if opc==OP_GOV_SET_FEE_POLICY:
        gp, off = read_u32(buf, off)
        bb, off = read_u32(buf, off)
        pb, off = read_u32(buf, off)
        cb, off = read_u32(buf, off)
        return {"op":"GOV_SET_FEE_POLICY","gas_price":int(gp),"fee_burn_bps":int(bb),"proposer_bps":int(pb),"committee_bps":int(cb)}, off

    if opc==OP_VAL_REGISTER:
        vid, off = read_bytes(buf, off)
        addr, off = read_bytes(buf, off)
        return {"op":"VAL_REGISTER","vid":"0x"+vid.hex(),"reward_address":"0x"+addr.hex()}, off

    if opc==OP_STAKE_BOND:
        pk, off = read_bytes(buf, off)
        frm, off = read_bytes(buf, off)
        amt, off = read_u64(buf, off)
        lock, off = read_u64(buf, off)
        return {"op":"STAKE_BOND","pubkey":"0x"+pk.hex(),"from":"0x"+frm.hex(),"amount":int(amt),"lock_until_epoch":int(lock)}, off

    if opc==OP_STAKE_UNBOND_REQUEST:
        pk, off = read_bytes(buf, off)
        to, off = read_bytes(buf, off)
        amt, off = read_u64(buf, off)
        return {"op":"STAKE_UNBOND_REQUEST","pubkey":"0x"+pk.hex(),"to":"0x"+to.hex(),"amount":int(amt)}, off

    if opc==OP_STAKE_WITHDRAW:
        pk, off = read_bytes(buf, off)
        to, off = read_bytes(buf, off)
        return {"op":"STAKE_WITHDRAW","pubkey":"0x"+pk.hex(),"to":"0x"+to.hex()}, off

    if opc==OP_CONSENSUS_SLASH_DOUBLE_VOTE:
        evb, off = read_bytes(buf, off)
        rep, off = read_bytes(buf, off)
        return {"op":"CONSENSUS_SLASH_DOUBLE_VOTE","evidence":json.loads(evb.decode("utf-8")),"reporter":"0x"+rep.hex()}, off

    if opc==OP_CONSENSUS_SLASH_EQUIVOCATION:
        evb, off = read_bytes(buf, off)
        rep, off = read_bytes(buf, off)
        return {"op":"CONSENSUS_SLASH_EQUIVOCATION","evidence":json.loads(evb.decode("utf-8")),"reporter":"0x"+rep.hex()}, off

    if opc==OP_AUDIT_INVARIANTS:
        return {"op":"AUDIT_INVARIANTS"}, off

    if opc==OP_INSURANCE_CLAIM_REJECT:
        cid, off = read_hex32(buf, off)
        return {"op":"INSURANCE_CLAIM_REJECT","claim_id":"0x"+cid}, off

    if opc==OP_INSURANCE_PAYOUT:
        to, off = read_hex32(buf, off)
        amt, off = read_u32(buf, off)
        return {"op":"INSURANCE_PAYOUT","to":"0x"+to,"amount":int(amt)}, off

    if opc==OP_GOV_MINT:
        to, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        return {"op":"GOV_MINT","to":to,"amount":int(amount)}, off

    if opc==OP_COMMITTEE_DISTRIBUTE:
        cid, off = read_hex32(buf, off)
        if off + 4 <= len(buf):
            tick, off = read_u32(buf, off)
            return {"op":"COMMITTEE_DISTRIBUTE","committee_id":"0x"+cid,"tick":int(tick)}, off
        return {"op":"COMMITTEE_DISTRIBUTE","committee_id":"0x"+cid}, off

    if opc==OP_TREASURY_DISTRIBUTE:
        if off + 4 <= len(buf):
            tick, off = read_u32(buf, off)
            return {"op":"TREASURY_DISTRIBUTE","tick":int(tick)}, off
        return {"op":"TREASURY_DISTRIBUTE"}, off

    if opc==OP_EVIDENCE_EQUIVOCATION_V3:
        a, off = _read_blob(buf, off)
        b, off = _read_blob(buf, off)
        return {"op":"EVIDENCE_EQUIVOCATION_V3","env_a":"0x"+a.hex(),"env_b":"0x"+b.hex()}, off

    if opc==OP_EVIDENCE_BAD_QUORUM_V3:
        e, off = _read_blob(buf, off)
        return {"op":"EVIDENCE_BAD_QUORUM_V3","env":"0x"+e.hex()}, off

    if opc==OP_CALL:
        fn, off=_read_str(buf, off)
        return {"op":"CALL","fn":fn}, off
    if opc==OP_RET:
        return {"op":"RET"}, off
    raise ReplayError("unknown opcode")

def disasm(buf: bytes) -> str:
    prog=SirBinProgram.decode(buf)
    lines=[f"; SIRB v{prog.version}"]
    for fn in sorted(prog.functions.keys()):
        lines.append(f"fn {fn}:")
        for i, op in enumerate(prog.functions[fn]):
            lines.append(f"  {i:04d}  {op}")
    return "\n".join(lines)+"\n"
