# Phase 53 — RPC/API Surface + Minimal CLI Client

Adds an HTTP/JSON RPC server for local ops and a CLI to interact with it.

## RPC Server
`src/supraxis/rpc/server.py`

### GET endpoints
- `/health` → `{ok, chain_id}`
- `/mempool?limit=N` → mempool size + top txs
- `/block/<hash>` → block dict from BlockStore
- `/evidence/status?pubkey=<pk>` → slashed status
- `/governance/status?id=<proposal_id>` → proposal record

### POST endpoints
- `/tx/submit` body: `{ "tx": {..tx..} }`
- `/evidence/submit` body: `{ "evidence": {..} }`
- `/governance/submit` body: `{ kind, title, payload, proposer }`
- `/governance/queue` body: `{ id }`
- `/governance/execute` body: `{ id }`
- `/governance/emergency` body: `{ action: "halt"|"resume", guardians: [...] }`

## Node Bootstrap
`scripts/supraxis_run_node.py`
- starts the P2P server AND an RPC server on `rpc_port` from `network_config.json`

## CLI
`scripts/supraxis_cli.py`

Examples:
- `PYTHONPATH=src python scripts/supraxis_cli.py --rpc http://127.0.0.1:8545 health`
- `PYTHONPATH=src python scripts/supraxis_cli.py mempool --limit 20`
- `PYTHONPATH=src python scripts/supraxis_cli.py tx-submit --tx tx.json`

## Next
Phase 54: JSON-RPC 2.0 compatibility + auth tokens + rate limiting for RPC.
