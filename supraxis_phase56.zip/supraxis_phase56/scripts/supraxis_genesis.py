#!/usr/bin/env python3
from __future__ import annotations
import argparse
import json
from pathlib import Path

from supraxis.genesis import make_genesis, write_genesis
from supraxis.config import NetworkConfig, write_config

def main():
    ap = argparse.ArgumentParser(description="Supraxis genesis + config generator (reference)")
    ap.add_argument("--chain-id", type=int, required=True)
    ap.add_argument("--network-name", type=str, required=True)
    ap.add_argument("--validators", type=str, required=True, help="Path to validators.json: [{pubkey,stake},...]")
    ap.add_argument("--params", type=str, required=False, help="Path to params.json")
    ap.add_argument("--out-dir", type=str, default="./artifacts")
    ap.add_argument("--seed", type=str, action="append", default=[], help="Seed nodes host:port (repeatable)")
    ap.add_argument("--p2p-port", type=int, default=30303)
    ap.add_argument("--rpc-port", type=int, default=8545)
    args = ap.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)

    vals = json.loads(Path(args.validators).read_text(encoding="utf-8"))
    params = {}
    if args.params:
        params = json.loads(Path(args.params).read_text(encoding="utf-8"))

    g = make_genesis(args.chain_id, args.network_name, vals, params)
    genesis_path = out / "genesis.json"
    ghash = write_genesis(genesis_path, g)

    cfg = NetworkConfig(
        version=1,
        chain_id=args.chain_id,
        network_name=args.network_name,
        seed_nodes=list(args.seed),
        genesis_hash=ghash,
        p2p_port=args.p2p_port,
        rpc_port=args.rpc_port,
        data_dir=str(out / "data"),
        max_frame_bytes=2_000_000,
    )
    cfg_path = out / "network_config.json"
    ch = write_config(cfg_path, cfg)

    print("genesis:", genesis_path, ghash)
    print("config :", cfg_path, ch)

if __name__ == "__main__":
    main()
