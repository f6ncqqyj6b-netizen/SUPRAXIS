from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List
from ..drivers.sandbox import Sandbox
from ..envelope import decode_envelope, Envelope
from ..state import SupraxisState
from ..sirbin import SirBinProgram
from ..block import run_block, BlockResult

@dataclass
class SandboxAdapter:
    sandbox: Sandbox

    def run_inbox(self, chain_id: int, state: SupraxisState, prog: SirBinProgram, entry: str="main", require_signatures: bool=False) -> BlockResult:
        inbox = self.sandbox.inbox(chain_id)
        env_bytes = inbox.drain()
        envs: List[Envelope] = [decode_envelope(b) for b in env_bytes]
        return run_block(state, prog.functions, envs, entry=entry, require_signatures=require_signatures)
