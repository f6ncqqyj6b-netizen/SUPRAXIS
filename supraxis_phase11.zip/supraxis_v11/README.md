# SUPRAXIS (Phase 11)

Phase 11 adds **committee registry in state** plus a **rotation grace window**.

## What’s new

### Committee registry (state-level)
`SupraxisState` now includes:
- `committee_registry: { epoch -> committee_id_hex }`
- `rotation_grace_epochs: int`

During block execution (default), **EnvelopeV3** must satisfy:
- The envelope’s `committee_id` is **registered** for its `epoch`, OR
- The committee_id is registered in the **grace window**: any epoch in `[epoch - rotation_grace_epochs, epoch]`

This allows a controlled transition where (for example) epoch N+1 can still accept signatures from the epoch N committee,
without breaking determinism.

### CLI support
- Register committee:
```bash
PYTHONPATH=src python -m supraxis.cli state register-committee --state state.json --epoch 7 --committee examples/committee.json --out state.json
```
- Set grace window:
```bash
PYTHONPATH=src python -m supraxis.cli state set-grace --state state.json --grace 1 --out state.json
```
- Disable registry checks for experimentation:
```bash
PYTHONPATH=src python -m supraxis.cli block run ... --no-committee-registry
```

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
