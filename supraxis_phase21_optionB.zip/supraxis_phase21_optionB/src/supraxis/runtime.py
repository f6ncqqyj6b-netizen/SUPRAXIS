from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List
import json
from .errors import ReplayError, CapabilityError
from .crypto import sha256
from .state import SupraxisState
from .sirbin import MAX_CALL_DEPTH
from .committee import Committee
from .envelope import decode_envelope, EnvelopeV3, SignaturePolicy

@dataclass
class Event:
    event: str
    payload: Any

def canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def cap_require(state: SupraxisState, cap_name: str, scope: str, chain_id: int, timestamp: int) -> None:
    cap_id = sha256(cap_name.encode("utf-8")).hex()
    cap = state.caps.get(cap_id)
    if not cap: raise CapabilityError("missing capability")
    if cap.get("scope") != scope: raise CapabilityError("scope mismatch")
    if int(cap.get("chain",-1)) != int(chain_id): raise CapabilityError("chain mismatch")
    if int(cap.get("expires",0)) < int(timestamp): raise CapabilityError("expired")

def gov_require(state: SupraxisState, ctx: Dict[str, Any]) -> None:
    cap_require(state, "GOVERNANCE", "global", int(ctx["target_chain"]), int(ctx["timestamp"]))

def _policy_from_state(state: SupraxisState) -> SignaturePolicy:
    min_valid = int(state.storage.get("quorum.min_valid", 1))
    mw = state.storage.get("quorum.min_weight", None)
    min_weight = int(mw) if mw is not None else None
    return SignaturePolicy(min_valid=min_valid, min_weight=min_weight)

def _attach_committee(state: SupraxisState, env: EnvelopeV3, pol: SignaturePolicy) -> SignaturePolicy:
    committee = state.get_committee_by_id(env.committee_id.hex())
    if committee is None:
        return pol
    return SignaturePolicy(
        min_valid=pol.min_valid,
        min_weight=pol.min_weight,
        allowed_schemes=pol.allowed_schemes,
        allowed_pubkeys=pol.allowed_pubkeys,
        pubkey_weights=pol.pubkey_weights,
        pubkey_allowed_schemes=pol.pubkey_allowed_schemes,
        committee=committee,
        require_committee_id=True,
    )


def _evidence_rate_limit(state: SupraxisState, submitter_hex: str) -> bool:
    """Returns True if evidence is allowed, False if rate-limited."""
    cooldown = state.evidence_cooldown()
    if cooldown > 0:
        last = int(state.evidence_last_counter.get(submitter_hex, -10**18))
        if (int(state.evidence_counter) - last) < cooldown:
            return False
    cd_attempts = state.evidence_cooldown_attempts()
    if cd_attempts > 0:
        last_a = int(state.evidence_last_attempt.get(submitter_hex, -10**18))
        if (int(state.evidence_attempts) - last_a) < cd_attempts:
            return False
    return True


def _evidence_mark_accepted(state: SupraxisState, submitter_hex: str) -> None:
    state.evidence_last_counter[submitter_hex] = int(state.evidence_counter)
    state.evidence_counter = int(state.evidence_counter + 1)

def _evidence_mark_attempt(state: SupraxisState, submitter_hex: str) -> None:
    state.evidence_last_attempt[submitter_hex] = int(state.evidence_attempts)

def _evidence_mark_reject(state: SupraxisState, submitter_hex: str) -> None:
    state.evidence_last_reject[submitter_hex] = int(state.evidence_attempts)
    state.evidence_rejects = int(state.evidence_rejects + 1)

def _apply_bounty(state: SupraxisState, submitter_hex: str, total_slashed: int) -> Dict[str, int]:
    """Split slashed amount into submitter bounty + treasury remainder (with decay + cap)."""
    base_bps = state.evidence_bounty_bps()
    min_bps = state.evidence_bounty_min_bps()
    attempts_hist = max(0, int(state.evidence_attempts) - 1)  # exclude current attempt
    accepts_hist = int(state.evidence_counter)
    failures = max(0, int(attempts_hist) - int(accepts_hist))
    denom = max(1, int(attempts_hist))
    decayed_bps = int(base_bps) - int(base_bps) * int(failures) // int(denom)
    bps = max(int(min_bps), min(10_000, int(decayed_bps)))
    bounty = (int(total_slashed) * int(bps)) // 10_000
    max_b = state.evidence_max_bounty()
    if max_b > 0:
        bounty = min(int(bounty), int(max_b))
    bounty = max(0, min(int(total_slashed), int(bounty)))
    remainder = int(total_slashed) - int(bounty)
    if bounty > 0:
        state.credit(submitter_hex, bounty)
    if remainder > 0:
        state.treasury = int(state.treasury + remainder)
    return {"bounty": int(bounty), "treasury": int(remainder), "bps": int(bps), "base_bps": int(base_bps)}


def execute_functions(state: SupraxisState, functions: Dict[str, List[Dict[str, Any]]], entry: str, ctx: Dict[str, Any]) -> List[Event]:
    if entry not in functions: raise ReplayError("missing entry")
    events: List[Event] = []
    call_stack=[entry]
    ip_stack=[0]
    submitter = str(ctx.get("origin_sender","")).lower()  # 64-hex string from envelope sender

    while call_stack:
        if len(call_stack) > MAX_CALL_DEPTH: raise ReplayError("CALL depth exceeded")
        fn=call_stack[-1]; ops=functions[fn]; ip=ip_stack[-1]
        if ip >= len(ops): raise ReplayError("function ended without RET")
        op=ops[ip]; ip_stack[-1]=ip+1
        name=op.get("op")

        if name=="CAP_REQUIRE":
            cap_require(state, str(op["cap"]), str(op["scope"]), int(ctx["target_chain"]), int(ctx["timestamp"]))

        # -----------------------
        # Governance ops
        # -----------------------
        elif name=="GOV_REGISTER_COMMITTEE_JSON":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            committee_json = json.dumps(op["committee"], sort_keys=True, separators=(",", ":"), ensure_ascii=False)
            cid = state.register_committee_json(epoch, committee_json)
            events.append(Event(event="GOV_COMMITTEE_REGISTERED", payload={"epoch": epoch, "committee_id": cid}))

        elif name=="GOV_REGISTER_COMMITTEE_ID":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            cid = str(op["committee_id"])
            state.register_committee(epoch, cid)
            events.append(Event(event="GOV_COMMITTEE_ID_REGISTERED", payload={"epoch": epoch, "committee_id": cid.lower().replace("0x","")}))

        elif name=="GOV_SET_GRACE":
            gov_require(state, ctx)
            grace = int(op["grace"])
            state.set_rotation_grace(grace)
            events.append(Event(event="GOV_GRACE_SET", payload={"grace": int(state.rotation_grace_epochs)}))

        elif name=="GOV_SET_SLASH_PARAM":
            gov_require(state, ctx)
            offense = str(op["offense"])
            amount = int(op["amount"])
            if amount < 0:
                raise ReplayError("slash param must be >=0")
            state.storage[f"slash.{offense}"] = int(amount)
            events.append(Event(event="GOV_SLASH_PARAM_SET", payload={"offense": offense, "amount": int(amount)}))

        elif name=="GOV_SET_EVIDENCE_PARAMS":
            gov_require(state, ctx)
            bounty_bps = int(op.get("bounty_bps", state.evidence_bounty_bps()))
            bounty_min_bps = int(op.get("bounty_min_bps", state.evidence_bounty_min_bps()))
            cooldown = int(op.get("cooldown", state.evidence_cooldown()))
            cooldown_attempts = int(op.get("cooldown_attempts", state.evidence_cooldown_attempts()))
            fee = int(op.get("fee", state.evidence_fee_base()))
            fee_mode = int(op.get("fee_mode", state.evidence_fee_mode()))
            fee_sink_mode = int(op.get("fee_sink_mode", state.evidence_fee_sink_mode()))
            fee_burn_bps = int(op.get("fee_burn_bps", state.evidence_fee_burn_bps()))
            fee_burn_reject_bps = int(op.get("fee_burn_reject_bps", state.evidence_fee_burn_reject_bps()))
            refund_bps = int(op.get("refund_bps", state.evidence_refund_bps()))
            max_bounty = int(op.get("max_bounty", state.evidence_max_bounty()))
            state.storage["evidence.bounty_bps"] = max(0, min(10_000, bounty_bps))
            state.storage["evidence.bounty_min_bps"] = max(0, min(10_000, bounty_min_bps))
            state.storage["evidence.cooldown"] = max(0, cooldown)
            state.storage["evidence.cooldown_attempts"] = max(0, cooldown_attempts)
            state.storage["evidence.fee"] = max(0, fee)
            state.storage["evidence.fee_mode"] = 1 if fee_mode != 0 else 0
            state.storage["evidence.fee_sink_mode"] = max(0, min(2, fee_sink_mode))
            state.storage["evidence.fee_burn_bps"] = max(0, min(10_000, fee_burn_bps))
            state.storage["evidence.fee_burn_reject_bps"] = max(0, min(10_000, fee_burn_reject_bps))
            state.storage["evidence.refund_bps"] = max(0, min(10_000, refund_bps))
            state.storage["evidence.max_bounty"] = max(0, max_bounty)
            events.append(Event(event="GOV_EVIDENCE_PARAMS_SET", payload={
                "bounty_bps": int(state.evidence_bounty_bps()),
                "bounty_min_bps": int(state.evidence_bounty_min_bps()),
                "cooldown": int(state.evidence_cooldown()),
                "cooldown_attempts": int(state.evidence_cooldown_attempts()),
                "fee": int(state.evidence_fee_base()),
                "fee_mode": int(state.evidence_fee_mode()),
                "fee_sink_mode": int(state.evidence_fee_sink_mode()),
                "fee_burn_bps": int(state.evidence_fee_burn_bps()),
                "fee_burn_reject_bps": int(state.evidence_fee_burn_reject_bps()),
                "refund_bps": int(state.evidence_refund_bps()),
                "max_bounty": int(state.evidence_max_bounty()),
            }))

        elif name=="GOV_SET_TREASURY_DISTRIBUTION":
            gov_require(state, ctx)
            interval = int(op.get("interval", state.treasury_dist_interval()))
            ins_bps = int(op.get("insurance_bps", state.treasury_dist_insurance_bps()))
            com_bps = int(op.get("committee_bps", state.treasury_dist_committee_bps()))
            if (ins_bps + com_bps) > 10_000: raise ReplayError("distribution bps sum > 10000")
            state.storage["treasury.dist_interval"] = max(0, interval)
            state.storage["treasury.dist_insurance_bps"] = max(0, min(10_000, ins_bps))
            state.storage["treasury.dist_committee_bps"] = max(0, min(10_000, com_bps))
            events.append(Event(event="GOV_TREASURY_DISTRIBUTION_SET", payload={
                "interval": int(state.treasury_dist_interval()),
                "insurance_bps": int(state.treasury_dist_insurance_bps()),
                "committee_bps": int(state.treasury_dist_committee_bps()),
            }))

        elif name=="TREASURY_DISTRIBUTE":
            interval = state.treasury_dist_interval()
            if interval <= 0:
                events.append(Event(event="TREASURY_DISTRIBUTE_SKIPPED", payload={"reason":"interval=0"}))
            else:
                tick = int(op.get("tick", 0))
                last = int(state.storage.get("treasury.last_dist_tick", -10**18))
                if (tick - last) < interval:
                    events.append(Event(event="TREASURY_DISTRIBUTE_SKIPPED", payload={"reason":"too_soon","tick":tick,"last":last}))
                else:
                    t = int(state.treasury)
                    ins = t * int(state.treasury_dist_insurance_bps()) // 10_000
                    com = t * int(state.treasury_dist_committee_bps()) // 10_000
                    ins = max(0, min(t, ins))
                    com = max(0, min(t - ins, com))
                    state.treasury = int(state.treasury - ins - com)
                    state.insurance_pool = int(state.insurance_pool + ins)
                    state.committee_pool = int(state.committee_pool + com)
                    state.storage["treasury.last_dist_tick"] = int(tick)
                    events.append(Event(event="TREASURY_DISTRIBUTED", payload={"tick":tick,"insurance":int(ins),"committee":int(com),"treasury_remaining":int(state.treasury)}))

        elif name=="GOV_MINT":
            gov_require(state, ctx)
            to = str(op["to"])
            amount = int(op["amount"])
            if amount < 0:
                raise ReplayError("amount must be >=0")
            state.credit(to, amount)
            events.append(Event(event="GOV_MINTED", payload={"to": to, "amount": int(amount), "new_balance": int(state.balance_of(to))}))

        elif name=="GOV_STAKE":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            lock_epochs = int(op.get("lock_epochs", 0))
            cur_epoch = int(ctx.get("epoch", 0))
            lock_until = cur_epoch + max(0, lock_epochs)
            state.stake_add(pubkey, amount, lock_until)
            amt, locked = state.stake_of(pubkey)
            events.append(Event(event="GOV_STAKED", payload={"pubkey": pubkey, "amount": int(amount), "new_total": int(amt), "locked_until": int(locked)}))

        elif name=="GOV_UNSTAKE":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            cur_epoch = int(ctx.get("epoch", 0))
            amt, locked = state.stake_of(pubkey)
            if cur_epoch < int(locked):
                raise ReplayError("stake locked")
            state.stake_sub(pubkey, amount)
            amt2, locked2 = state.stake_of(pubkey)
            events.append(Event(event="GOV_UNSTAKED", payload={"pubkey": pubkey, "amount": int(amount), "new_total": int(amt2), "locked_until": int(locked2)}))

        elif name=="GOV_SLASH":
            gov_require(state, ctx)
            pubkey = str(op["pubkey"])
            amount = int(op["amount"])
            reason = str(op.get("reason", ""))
            taken = state.slash(pubkey, amount)
            amt2, locked2 = state.stake_of(pubkey)
            events.append(Event(event="GOV_SLASHED", payload={"pubkey": pubkey, "requested": int(amount), "slashed": int(taken), "new_total": int(amt2), "reason": reason}))

        elif name=="GOV_REGISTER_COMMITTEE_FROM_STAKE":
            gov_require(state, ctx)
            epoch = int(op["epoch"])
            size = int(op["size"])
            top = state.top_stakers(size)
            members = [{"pubkey": "0x"+pk, "weight": int(amt), "schemes": [1]} for pk, amt in top]
            committee = Committee.from_dict({"members": members})
            cid = committee.committee_id()
            state.committee_store[cid] = committee.canonical_json()
            state.register_committee(epoch, cid)
            events.append(Event(event="GOV_COMMITTEE_FROM_STAKE", payload={"epoch": epoch, "committee_id": cid, "size": len(members)}))

        # -----------------------
        # Evidence-based slashing (permissionless)
        # -----------------------
        elif name=="EVIDENCE_EQUIVOCATION_V3":
            if not _evidence_rate_limit(state, submitter):
                events.append(Event(event="EVIDENCE_RATE_LIMITED", payload={"op": "EVIDENCE_EQUIVOCATION_V3"}))
            else:
                a_hex = str(op["env_a"]); b_hex = str(op["env_b"])
                a = bytes.fromhex(a_hex[2:] if a_hex.lower().startswith("0x") else a_hex)
                b = bytes.fromhex(b_hex[2:] if b_hex.lower().startswith("0x") else b_hex)
                lo, hi = (a, b) if a <= b else (b, a)
                evid = sha256(b"EVIDENCE_V3_EQUIV" + lo + hi).hex()
                if state.storage.get(f"evidence.{evid}") == 1:
                    events.append(Event(event="EVIDENCE_DUPLICATE_IGNORED", payload={"evidence_id": evid}))
                else:
                    feeinfo = _charge_evidence_fee(state, submitter)
                    fee_paid = int(feeinfo.get("fee", 0))
                    try:
                        ea = decode_envelope(a); eb = decode_envelope(b)
                        if not isinstance(ea, EnvelopeV3) or not isinstance(eb, EnvelopeV3):
                            raise ReplayError("evidence requires two v3 envelopes")
                        same = (ea.origin_chain==eb.origin_chain and ea.origin_sender==eb.origin_sender and ea.target_chain==eb.target_chain and ea.target_contract==eb.target_contract and ea.nonce==eb.nonce)
                        if not same: raise ReplayError("evidence envelopes not same stream+nonce")
                        if ea.payload_hash == eb.payload_hash: raise ReplayError("evidence not equivocation (payload_hash equal)")
                        base_pol = _policy_from_state(state)
                        ea.validate(require_signatures=True, policy=_attach_committee(state, ea, base_pol))
                        eb.validate(require_signatures=True, policy=_attach_committee(state, eb, base_pol))
                        slash_amt = state.slash_amount("double_sign", default=1)
                        severity_bps = min(5000, int(slash_amt) * 100)
                        def signer_pubkeys(env: EnvelopeV3) -> List[str]:
                            committee = state.get_committee_by_id(env.committee_id.hex())
                            if committee is None or env.quorum_proof is None: return []
                            bm = env.quorum_proof.bitmap
                            from .canonical import bitset_test as _bst
                            pks=[]
                            for i in range(committee.size()):
                                if _bst(bm, i):
                                    pks.append(("0x"+committee.pubkey_at(i).hex()).lower())
                            return pks
                        signers = sorted(set(signer_pubkeys(ea) + signer_pubkeys(eb)))
                        slashed=[]
                        total=0
                        for pk in signers:
                            taken = state.slash(pk, slash_amt)
                            total += int(taken)
                            slashed.append({"pubkey": pk, "slashed": int(taken)})
                        split = _apply_bounty(state, submitter, total)
                        fee_final = _finalize_fee_on_accept(state, fee_paid, submitter, severity_bps)
                        state.storage[f"evidence.{evid}"] = 1
                        _evidence_mark_accepted(state, submitter)
                        events.append(Event(event="EVIDENCE_EQUIVOCATION_ACCEPTED", payload={
                            "evidence_id": evid,
                            "slash": {"offense": "double_sign", "amount": int(slash_amt), "total_slashed": int(total)},
                            "payout": {"submitter": submitter, **split, **feeinfo, **fee_final},
                            "slashed": slashed,
                        }))
                    except Exception as ex:
                        fee_final = _finalize_fee_on_reject(state, fee_paid, submitter)
                        events.append(Event(event="EVIDENCE_REJECTED", payload={"evidence_id": evid, "reason": str(ex), "fee": {**feeinfo, **fee_final}}))

        elif name=="EVIDENCE_BAD_QUORUM_V3":
            if not _evidence_rate_limit(state, submitter):
                events.append(Event(event="EVIDENCE_RATE_LIMITED", payload={"op": "EVIDENCE_BAD_QUORUM_V3"}))
            else:
                env_hex = str(op["env"])
                eb = bytes.fromhex(env_hex[2:] if env_hex.lower().startswith("0x") else env_hex)
                evid = sha256(b"EVIDENCE_V3_BADQ" + eb).hex()
                if state.storage.get(f"evidence.{evid}") == 1:
                    events.append(Event(event="EVIDENCE_DUPLICATE_IGNORED", payload={"evidence_id": evid}))
                else:
                    feeinfo = _charge_evidence_fee(state, submitter)
                    fee_paid = int(feeinfo.get("fee", 0))
                    try:
                        env = decode_envelope(eb)
                        if not isinstance(env, EnvelopeV3):
                            raise ReplayError("evidence requires v3 envelope")
                        committee = state.get_committee_by_id(env.committee_id.hex())
                        if committee is None:
                            raise ReplayError("committee not found for evidence")
                        base_pol = _policy_from_state(state)
                        pol = _attach_committee(state, env, base_pol)
                        try:
                            env.validate(require_signatures=True, policy=pol)
                            raise ReplayError("evidence not bad quorum (envelope valid)")
                        except ReplayError:
                            raise
                        except Exception:
                            slash_amt = state.slash_amount("bad_quorum", default=1)
                            severity_bps = min(5000, int(slash_amt) * 100)
                            bm = env.quorum_proof.bitmap if env.quorum_proof is not None else b""
                            from .canonical import bitset_test as _bst
                            slashed=[]
                            total=0
                            for i in range(committee.size()):
                                if _bst(bm, i):
                                    pk = ("0x"+committee.pubkey_at(i).hex()).lower()
                                    taken = state.slash(pk, slash_amt)
                                    total += int(taken)
                                    slashed.append({"pubkey": pk, "slashed": int(taken)})
                            split = _apply_bounty(state, submitter, total)
                            fee_final = _finalize_fee_on_accept(state, fee_paid, submitter, severity_bps)
                            state.storage[f"evidence.{evid}"] = 1
                            _evidence_mark_accepted(state, submitter)
                            events.append(Event(event="EVIDENCE_BAD_QUORUM_ACCEPTED", payload={
                                "evidence_id": evid,
                                "slash": {"offense": "bad_quorum", "amount": int(slash_amt), "total_slashed": int(total)},
                                "payout": {"submitter": submitter, **split, **feeinfo, **fee_final},
                                "slashed": slashed,
                            }))
                    except Exception as ex:
                        fee_final = _finalize_fee_on_reject(state, fee_paid, submitter)
                        events.append(Event(event="EVIDENCE_REJECTED", payload={"evidence_id": evid, "reason": str(ex), "fee": {**feeinfo, **fee_final}}))

        elif name=="EMIT":
            events.append(Event(event=str(op["event"]), payload=op.get("payload")))

        elif name=="STORE":
            state.storage[str(op["key"])] = op.get("value")

        elif name=="ASSERT":
            if not bool(op.get("value")): raise ReplayError("ASSERT failed")

        elif name=="CALL":
            callee=str(op["fn"])
            if callee not in functions: raise ReplayError("unknown callee")
            call_stack.append(callee); ip_stack.append(0)

        elif name=="RET":
            call_stack.pop(); ip_stack.pop()

        else:
            raise ReplayError("unknown op")

    return events

def _charge_evidence_fee(state: SupraxisState, submitter_hex: str) -> Dict[str, int]:
    """Charge evidence fee; deposit to treasury (burn adjustments later). Always counts as an attempt."""
    base = state.evidence_fee_base()
    mode = int(state.evidence_fee_mode())
    if base <= 0:
        _evidence_mark_attempt(state, submitter_hex)
        state.evidence_attempts = int(state.evidence_attempts + 1)
        return {"fee": 0, "base": int(base), "mode": int(mode)}
    attempts = max(1, int(state.evidence_attempts))
    accepts = int(state.evidence_counter)
    failures = max(0, attempts - accepts)
    fee = int(base)
    if mode == 1:
        fee = int(base + (base * failures // attempts))
    state.debit(submitter_hex, fee)
    state.treasury = int(state.treasury + fee)
    _evidence_mark_attempt(state, submitter_hex)
    state.evidence_attempts = int(state.evidence_attempts + 1)
    return {"fee": int(fee), "base": int(base), "mode": int(mode), "attempts": int(attempts), "accepts": int(accepts)}

def _finalize_fee_on_accept(state: SupraxisState, fee_paid: int, submitter_hex: str, severity_bps: int = 0) -> Dict[str, int]:
    """Apply sink/burn and refund on accept."""
    sink = int(state.evidence_fee_sink_mode())
    burn_bps = int(state.evidence_fee_burn_bps())
    sev = max(0, min(5_000, int(severity_bps)))
    burn = 0
    if fee_paid > 0:
        if sink == 1:
            burn = int(fee_paid)
        elif sink == 2:
            burn = int(fee_paid) * int(min(10_000, burn_bps + sev)) // 10_000
        burn = max(0, min(int(fee_paid), int(burn)))
        if burn > 0:
            state.treasury = int(state.treasury - burn)
            state.burned = int(state.burned + burn)
    refund_bps = int(state.evidence_refund_bps())
    refund = int(fee_paid) * int(refund_bps) // 10_000
    refund = max(0, min(int(fee_paid) - int(burn), int(refund)))
    if refund > 0:
        state.treasury = int(state.treasury - refund)
        state.credit(submitter_hex, refund)
    return {"burned_fee": int(burn), "refunded_fee": int(refund), "sink_mode": int(sink), "burn_bps": int(burn_bps), "severity_bps": int(sev)}

def _finalize_fee_on_reject(state: SupraxisState, fee_paid: int, submitter_hex: str) -> Dict[str, int]:
    """On reject, optionally burn a larger portion; no refund."""
    if fee_paid <= 0:
        _evidence_mark_reject(state, submitter_hex)
        return {"burned_fee": 0, "refunded_fee": 0}
    sink = int(state.evidence_fee_sink_mode())
    burn = 0
    if sink == 1:
        burn = int(fee_paid)
    elif sink == 2:
        burn_bps = int(state.evidence_fee_burn_reject_bps())
        burn = int(fee_paid) * int(burn_bps) // 10_000
    burn = max(0, min(int(fee_paid), int(burn)))
    if burn > 0:
        state.treasury = int(state.treasury - burn)
        state.burned = int(state.burned + burn)
    _evidence_mark_reject(state, submitter_hex)
    return {"burned_fee": int(burn), "refunded_fee": 0, "sink_mode": int(sink)}
