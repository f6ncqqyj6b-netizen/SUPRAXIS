# SUPRAXIS (Phase 12)

Phase 12 enables **state-driven committee lookup** so quorum proofs can be validated **without providing committee config externally**.

## What’s new

### State committee store
`SupraxisState` now persists committee configs:

- `committee_registry: { epoch -> committee_id_hex }`
- `committee_store: { committee_id_hex -> canonical committee JSON }`

New API:
- `register_committee_json(epoch, committee_json)` stores the canonical JSON and registers the derived committee_id.

### Automatic committee attachment during block validation
During `run_block(...)`, if an envelope is **v3** and the signature policy does **not** include a committee, the runtime will:
- Look up `env.committee_id` in `state.committee_store`
- Attach that committee to the signature policy so **QuorumProofV1** can be verified deterministically

Registry/grace checks remain enforced by default.

## CLI examples

Register committee JSON into state (writes committee_id to stdout):
```bash
PYTHONPATH=src python -m supraxis.cli state register-committee-json \
  --state state.json --epoch 7 --committee examples/committee.json --out state.json
```

Verify a v3 envelope using committee from state:
```bash
PYTHONPATH=src python -m supraxis.cli envelope verify --in env_v3.bin --require-sigs \
  --state state.json --use-state-committee --min-weight 7
```

Run a block with quorum proofs, using only state:
```bash
PYTHONPATH=src python -m supraxis.cli block run --sirb prog.sirb --state state.json --envelopes env_v3.bin \
  --require-sigs --use-state-committee --min-weight 7 --out block.json
```

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
