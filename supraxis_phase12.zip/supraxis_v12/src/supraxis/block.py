from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
import json
from .envelope import Envelope, envelope_sort_key, SignaturePolicy
from .state import SupraxisState
from .runtime import execute_functions, canonical_json
from .crypto import sha256
from .errors import ReplayError
from .gas import gas_cost

@dataclass
class BlockResult:
    state_json: str
    events: List[Dict[str, Any]]
    block_hash: str

def _static_gas(ops: List[Dict[str, Any]], functions: Dict[str, List[Dict[str, Any]]], depth: int = 0) -> int:
    if depth > 32: raise ReplayError("static gas walk depth exceeded")
    total=0
    for op in ops:
        total += gas_cost(str(op.get("op")))
        if op.get("op") == "CALL":
            fn=str(op.get("fn"))
            if fn not in functions: raise ReplayError("unknown CALL target")
            total += _static_gas(functions[fn], functions, depth+1)
    return total

def _attach_state_committee(state: SupraxisState, env: Envelope, pol: Optional[SignaturePolicy]) -> Optional[SignaturePolicy]:
    # Only applies to v3 envelopes
    if getattr(env, "version", 0) != 3:
        return pol
    if pol is not None and pol.committee is not None:
        return pol
    epoch = int(getattr(env, "epoch", 0))
    cid_hex = getattr(env, "committee_id", b"").hex()
    committee = state.get_committee_by_id(cid_hex)
    if committee is None:
        return pol  # registry might still permit but we can't validate quorum proofs without committee
    base = pol or SignaturePolicy(min_valid=1)
    # preserve thresholds/alloweds but bind committee
    return SignaturePolicy(
        min_valid=base.min_valid,
        min_weight=base.min_weight,
        allowed_schemes=base.allowed_schemes,
        allowed_pubkeys=base.allowed_pubkeys,
        pubkey_weights=base.pubkey_weights,
        pubkey_allowed_schemes=base.pubkey_allowed_schemes,
        committee=committee,
        require_committee_id=True,
    )

def run_block(
    state: SupraxisState,
    functions: Dict[str, List[Dict[str, Any]]],
    envelopes: List[Envelope],
    entry: str="main",
    require_signatures: bool=False,
    sig_policy: Optional[SignaturePolicy]=None,
    enforce_committee_registry: bool=True,
) -> BlockResult:
    if entry not in functions: raise ReplayError("missing entry")
    envs=sorted(envelopes, key=envelope_sort_key)
    events_all=[]
    h=sha256(b"SUPRAXIS_BLOCK_V8")
    for env in envs:
        # Phase 11: committee registry enforcement for v3
        if enforce_committee_registry and getattr(env, "version", 0) == 3:
            ep = int(getattr(env, "epoch", 0))
            cid_hex = getattr(env, "committee_id", b"").hex()
            allowed = state.allowed_committee_ids_for_epoch(ep)
            if len(allowed) == 0:
                raise ReplayError("committee not registered for epoch")
            if cid_hex not in allowed:
                raise ReplayError("committee_id not allowed for epoch (outside rotation window)")

        pol = _attach_state_committee(state, env, sig_policy)

        # signature/canonical validation
        if hasattr(env, "validate"):
            try:
                env.validate(require_signatures=require_signatures, policy=pol)  # type: ignore[arg-type]
            except TypeError:
                env.validate(require_signatures=require_signatures)  # v1
        else:
            raise ReplayError("invalid envelope")

        last=state.get_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract)
        if env.nonce <= last: raise ReplayError("nonce not increasing")

        ctx={
            "epoch": int(getattr(env, "epoch", 0)),
            "committee_id": getattr(env, "committee_id", b"").hex() if getattr(env, "committee_id", None) is not None else "",
            "origin_chain": env.origin_chain,
            "origin_sender": env.origin_sender.hex(),
            "target_chain": env.target_chain,
            "target_contract": env.target_contract.hex(),
            "nonce": env.nonce,
            "gas_limit": env.gas_limit,
            "payload_type": env.payload_type,
            "payload_hash": env.payload_hash.hex(),
            "timestamp": 0,
            "envelope_version": env.version,
        }
        if _static_gas(functions[entry], functions) > env.gas_limit:
            raise ReplayError("out of gas")
        evs=execute_functions(state, functions, entry, ctx)
        state.set_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract, env.nonce)
        for e in evs:
            item={"event": e.event, "payload": e.payload, "ctx": ctx}
            events_all.append(item)
            h=sha256(h + canonical_json(item))
        h=sha256(h + state.to_json().encode("utf-8"))
    return BlockResult(state_json=state.to_json(), events=events_all, block_hash=h.hex())

def block_hash(block_json: str) -> str:
    obj=json.loads(block_json)
    return sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")).hex()
