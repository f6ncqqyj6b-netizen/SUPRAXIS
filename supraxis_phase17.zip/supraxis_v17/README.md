# SUPRAXIS (Phase 17)

Phase 17 adds **evidence-based slashing** for equivocation **across forks / blocks**.

Auto-slashing (Phases 15–16) only triggers when a bad envelope is *seen during block processing*.
Phase 17 adds a deterministic way to submit *proof* of misbehavior and slash later.

## Evidence: V3 Equivocation Proof

### `EVIDENCE_EQUIVOCATION_V3`
A permissionless runtime opcode that accepts two **canonical EnvelopeV3 byte blobs** as evidence.

It verifies:
1. Both decode as **EnvelopeV3**
2. They share the same stream key:
   - `(origin_chain, origin_sender, target_chain, target_contract, nonce)`
3. Their `payload_hash` differs (equivocation)
4. **Both envelopes are valid** under deterministic policy:
   - policy uses `storage["quorum.min_weight"]` (optional) or `storage["quorum.min_valid"]` (default 1)
   - committee is loaded from `state.committee_store` using `committee_id`

If valid, it slashes the **union** of quorum participants claimed by both proofs using offense:
- `double_sign` (amount from `storage["slash.double_sign"]`, default 1)

### Replay protection for evidence
Each accepted proof stores:
- `storage["evidence.<evidence_id>"]=1`

Submitting the same proof again emits:
- `EVIDENCE_DUPLICATE_IGNORED`

## Gas + SIRB
- New opcode: `OP_EVIDENCE_EQUIVOCATION_V3=0x31`
- Gas: `EVIDENCE_EQUIVOCATION_V3` = 200,000

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
