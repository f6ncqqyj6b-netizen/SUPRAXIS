from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Tuple, Optional
from supraxis.canonjson import canonical_json
from supraxis.sigverify import Signature, default_verifier
from .headerchain import Header
from .vote_signing import SCHEME_ED25519, SCHEME_SECP256K1, _bhex  # reuse hex helper

def header_message(h: Header) -> bytes:
    payload = {
        "t":"SUPRAXIS_HEADER_V1",
        "chain_id": int(h.chain_id),
        "epoch": int(h.epoch),
        "height": int(h.height),
        "round": int(h.round),
        "block_hash": str(h.block_hash),
        "parent_hash": str(h.parent_hash),
        "proposer": str(h.proposer),
        "validators_hash": str(h.validators_hash),
    }
    return b"SUPRAXIS|HEADER|V1|" + canonical_json(payload)

@dataclass(frozen=True)
class SignedHeader:
    header: Header
    sigs: Dict[str, dict]  # voter_vid -> {"scheme": int, "sig": bytes}

def verify_signed_header(sh: SignedHeader, vmap: Dict[str, Any], quorum_power: int) -> Tuple[bool,str,int]:
    msg = header_message(sh.header)
    signed_power = 0
    if not isinstance(sh.sigs, dict):
        return False, "bad_sig_format", 0
    for voter, entry in sh.sigs.items():
        voter = str(voter)
        v = vmap.get(voter)
        if v is None:
            continue
        if not isinstance(entry, dict):
            continue
        scheme = int(entry.get("scheme", SCHEME_ED25519))
        sigb = entry.get("sig", b"")
        if not isinstance(sigb, (bytes, bytearray)):
            continue
        sig = Signature(scheme=scheme, pubkey=_bhex(voter), sig=bytes(sigb))
        if default_verifier().verify(sig, msg):
            signed_power += int(getattr(v, "power", 0))
    if signed_power < int(quorum_power):
        return False, "insufficient_quorum_power", signed_power
    return True, "ok", signed_power
