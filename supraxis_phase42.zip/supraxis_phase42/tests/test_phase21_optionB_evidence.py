import unittest
from supraxis.state import SupraxisState
from supraxis.crypto import sha256
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.sigverify import make_stub_signature

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class Phase21OptionB(unittest.TestCase):
    def _runner_env(self, origin_sender:int, nonce:int):
        payload=b'{"run":%d}'%nonce
        env_base=EnvelopeV2(
            version=2,
            origin_chain=1,
            origin_tx=b32(nonce),
            origin_sender=b32(origin_sender),
            target_chain=100,
            target_contract=b32(0xAA),
            nonce=nonce,
            gas_limit=1_000_000_000_000,
            payload_type=1,
            payload=payload,
            payload_hash=sha256(payload),
            cap_refs=[],
            signatures=[],
        )
        sig=make_stub_signature(1,b"pk_any", env_base.signing_message())
        env = EnvelopeV2(
            version=2,
            origin_chain=1,
            origin_tx=b32(nonce),
            origin_sender=b32(origin_sender),
            target_chain=100,
            target_contract=b32(0xAA),
            nonce=nonce,
            gas_limit=1_000_000_000_000,
            payload_type=1,
            payload=payload,
            payload_hash=sha256(payload),
            cap_refs=[],
            signatures=[sig],
        )
        return env

    def test_reject_emits_and_burns_split(self):
        st = SupraxisState()
        st.storage["evidence.fee"]=10
        st.storage["evidence.fee_mode"]=0
        st.storage["evidence.fee_sink_mode"]=2
        st.storage["evidence.fee_burn_reject_bps"]=8000
        st.storage["evidence.refund_bps"]=0
        st.storage["evidence.cooldown"]=0
        st.storage["evidence.cooldown_attempts"]=0

        submit_hex=b32(123).hex()
        st.credit(submit_hex, 100)

        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"EVIDENCE_BAD_QUORUM_V3", "env":"0x00"},
            {"op":"RET"},
        ]})

        res = run_block(st, prog.functions, [self._runner_env(123, 1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))
        self.assertTrue(any(e["event"]=="EVIDENCE_REJECTED" for e in res.events))
        self.assertEqual(st.balance_of(submit_hex), 90)
        self.assertEqual(st.burned, 8)
        self.assertEqual(st.treasury, 2)

    def test_adaptive_fee_increases(self):
        st = SupraxisState()
        st.storage["evidence.fee"]=10
        st.storage["evidence.fee_mode"]=1
        st.storage["evidence.fee_sink_mode"]=0
        st.storage["evidence.refund_bps"]=0
        st.storage["evidence.cooldown"]=0
        st.storage["evidence.cooldown_attempts"]=0

        submit_hex=b32(1).hex()
        st.credit(submit_hex, 1000)

        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"EVIDENCE_BAD_QUORUM_V3", "env":"0x00"},
            {"op":"RET"},
        ]})

        run_block(st, prog.functions, [self._runner_env(1, 1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))
        bal1 = st.balance_of(submit_hex)
        run_block(st, prog.functions, [self._runner_env(1, 2)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))
        bal2 = st.balance_of(submit_hex)
        self.assertEqual(bal1, 980)
        self.assertEqual(bal2, 960)

    def test_treasury_distribution(self):
        st = SupraxisState()
        st.treasury = 1000
        st.storage["treasury.dist_interval"]=5
        st.storage["treasury.dist_insurance_bps"]=2000
        st.storage["treasury.dist_committee_bps"]=3000

        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"TREASURY_DISTRIBUTE","tick":1000},
            {"op":"TREASURY_DISTRIBUTE","tick":1002},
            {"op":"RET"},
        ]})

        res = run_block(st, prog.functions, [self._runner_env(1, 10)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1))
        self.assertTrue(any(e["event"]=="TREASURY_DISTRIBUTED" for e in res.events))
        self.assertEqual(st.insurance_pool, 200)
        self.assertEqual(st.committee_pool, 300)
        self.assertEqual(st.treasury, 500)
        self.assertTrue(any(e["event"]=="TREASURY_DISTRIBUTE_SKIPPED" for e in res.events))

if __name__ == "__main__":
    unittest.main()
