# Phase 40 — End-to-End Fast Sync + Persistence

This phase adds a complete fast-sync *orchestrator* and persistence helpers.

## Persistence

`src/supraxis/consensus/persist.py`
- dump/load:
  - SignedCheckpoint
  - Header
  - SignedHeader
- helper:
  - canonical JSON dump (`dumps`)
  - content hash (`sha`)

`GossipStore.to_dict()` / `GossipStore.from_dict()`:
- persist gossip cache to/from plain dict for JSON storage.

## Fast Sync Orchestrator

`src/supraxis/consensus/fastsync.py`

Algorithm:
1) select `best_checkpoint()` from gossip
2) `LightClient.accept_signed_checkpoint(...)`
3) prefer `sync_signed_headers(...)` if contiguous signed-header path exists
4) fallback to raw header sync (`sync_headers`), which requires QCs

Returns: `(ok, reason, LightClient)`

## CLI Demo

`src/supraxis/cli_fastsync_demo.py`
- minimal demonstration entrypoint
- intended to be replaced by real peer/network ingestion later

## Next

Phase 41: wire fast-sync into a full node bootstrap:
- persist + load state snapshots
- fetch missing blocks/txs after header sync
- deterministic replay verification against state_root
