import unittest
from supraxis.envelope import EnvelopeV2
from supraxis.sigverify import make_stub_signature
from supraxis.crypto import sha256

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class CapRefBindingTests(unittest.TestCase):
    def test_cap_refs_are_in_signing_preimage(self):
        payload=b'{"a":1}'
        ph=sha256(payload)

        # envelope with one cap ref
        cap1 = b32(9)
        base = EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[cap1],[])
        sig = make_stub_signature(1, b"pub", base.signing_message())
        env = EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[cap1],[sig])
        env.validate(require_signatures=True)

        # same signature but different cap set should fail (preimage differs)
        cap2 = b32(10)
        env2 = EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[cap2],[sig])
        with self.assertRaises(Exception):
            env2.validate(require_signatures=True)

if __name__ == "__main__":
    unittest.main()
