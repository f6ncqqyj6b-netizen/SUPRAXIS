import unittest
from supraxis.committee import Committee
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.sigverify import make_stub_signature
from supraxis.crypto import sha256

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class CommitteeWeightedThresholdTests(unittest.TestCase):
    def test_weighted_threshold(self):
        committee = Committee.from_dict({
            "members": [
                {"pubkey":"0x706b31", "weight":4, "schemes":[1]},
                {"pubkey":"0x706b32", "weight":3, "schemes":[1]},
                {"pubkey":"0x706b33", "weight":2, "schemes":[1]},
            ]
        })

        payload=b'{"w":1}'
        ph=sha256(payload)
        base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[])
        msg=base.signing_message()

        s1=make_stub_signature(1, b"pk1", msg)  # weight 4
        s2=make_stub_signature(1, b"pk2", msg)  # weight 3
        s3=make_stub_signature(1, b"pk3", msg)  # weight 2

        env=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[s1,s2,s3])

        pol7 = SignaturePolicy(min_valid=1, min_weight=7, committee=committee)
        env.validate(require_signatures=True, policy=pol7)  # 4+3 >= 7 passes

        # Corrupt pk3 signature so only 4+3 weight remains (7); require 9 should fail
        s3_bad = s3.__class__(s3.scheme, s3.pubkey, b"xxxx")
        env_bad = EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[s1,s2,s3_bad])
        pol9 = SignaturePolicy(min_valid=1, min_weight=9, committee=committee)
        with self.assertRaises(Exception):
            env_bad.validate(require_signatures=True, policy=pol9)

    def test_allowlist_rejects_non_member(self):
        committee = Committee.from_dict({"members":[{"pubkey":"0x706b31","weight":4,"schemes":[1]}]})
        payload=b'{"a":1}'
        ph=sha256(payload)
        base=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[])
        msg=base.signing_message()
        s_non=make_stub_signature(1, b"not_member", msg)
        env=EnvelopeV2(2,1,b32(1),b32(2),100,b32(0xAA),1,500000,1,payload,ph,[],[s_non])
        pol = SignaturePolicy(min_valid=1, committee=committee)
        with self.assertRaises(Exception):
            env.validate(require_signatures=True, policy=pol)

if __name__ == "__main__":
    unittest.main()
