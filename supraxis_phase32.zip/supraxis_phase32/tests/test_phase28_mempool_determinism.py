import unittest
from supraxis.net.mempool import Mempool, MempoolConfig

def env(sender_hex: str, nonce: int, gas: int = 10):
    return {
        "version": 2,
        "origin_chain": 1,
        "origin_tx": "0x" + "00"*31 + "01",
        "origin_sender": sender_hex,
        "target_chain": 100,
        "target_contract": "0x" + "aa"*32,
        "nonce": nonce,
        "gas_limit": gas,
        "payload_hash": "0x" + "11"*32,
        "cap_refs": [],
    }

class TestMempoolDeterminism(unittest.TestCase):
    def test_round_robin_order(self):
        mp = Mempool(cfg=MempoolConfig(max_gas_per_tx=1000, max_sender_pending=10))
        # two senders with interleaving nonces
        mp.add(env("0x"+"01"*32, 2))
        mp.add(env("0x"+"01"*32, 1))
        mp.add(env("0x"+"02"*32, 1))
        mp.add(env("0x"+"02"*32, 3))
        mp.add(env("0x"+"02"*32, 2))
        # build block with generous limits
        block = mp.build_block(max_txs=10, max_gas=10_000)
        order = [(e["origin_sender"], e["nonce"]) for e in block]
        # sender order ascending, round-robin, nonce ascending within sender
        self.assertEqual(order, [
            ("0x"+"01"*32, 1),
            ("0x"+"02"*32, 1),
            ("0x"+"01"*32, 2),
            ("0x"+"02"*32, 2),
            ("0x"+"02"*32, 3),
        ])

    def test_dedup(self):
        mp = Mempool()
        ok1, _, tid1 = mp.add(env("0x"+"01"*32, 1))
        ok2, reason, tid2 = mp.add(env("0x"+"01"*32, 1))  # identical signing fields => same tx_id
        self.assertTrue(ok1)
        self.assertFalse(ok2)
        self.assertEqual(reason, "duplicate")
        self.assertEqual(tid1, tid2)

if __name__ == "__main__":
    unittest.main()
