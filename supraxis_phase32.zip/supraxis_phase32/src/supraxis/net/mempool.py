from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Iterable
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json

Hex = str

def tx_id_from_envelope_dict(env: dict) -> Hex:
    # Envelope signing message is deterministically reconstructed
    # We accept env as a dict; to keep deterministic identity, hash canonical_json of "signing fields"
    # In production, this should be the true EnvelopeV2.signing_message() bytes.
    signing = {
        "version": int(env.get("version", 0)),
        "origin_chain": int(env.get("origin_chain", 0)),
        "origin_tx": str(env.get("origin_tx","")),
        "origin_sender": str(env.get("origin_sender","")),
        "target_chain": int(env.get("target_chain", 0)),
        "target_contract": str(env.get("target_contract","")),
        "nonce": int(env.get("nonce", 0)),
        "gas_limit": int(env.get("gas_limit", 0)),
        "payload_hash": str(env.get("payload_hash","")),
        "cap_refs": env.get("cap_refs", []),
    }
    return sha256(canonical_json(signing)).hex()

def sender_of(env: dict) -> str:
    return str(env.get("origin_sender",""))

def nonce_of(env: dict) -> int:
    try:
        return int(env.get("nonce", 0))
    except Exception:
        return 0

def gas_of(env: dict) -> int:
    try:
        return int(env.get("gas_limit", 0))
    except Exception:
        return 0

@dataclass
class MempoolConfig:
    max_gas_per_tx: int = 1_000_000_000_000
    max_sender_pending: int = 256

@dataclass
class Mempool:
    cfg: MempoolConfig = field(default_factory=MempoolConfig)
    # tx_id -> env
    txs: Dict[Hex, dict] = field(default_factory=dict)
    # sender -> list of (nonce, tx_id)
    by_sender: Dict[str, List[Tuple[int, Hex]]] = field(default_factory=dict)
    # tx ids that are already committed (seen in chain)
    seen: set = field(default_factory=set)

    def has(self, tx_id: Hex) -> bool:
        return tx_id in self.txs or tx_id in self.seen

    def mark_seen(self, tx_id: Hex) -> None:
        self.seen.add(tx_id)
        self.txs.pop(tx_id, None)

    def add(self, env: dict) -> Tuple[bool, Optional[str], Hex]:
        tx_id = tx_id_from_envelope_dict(env)
        if self.has(tx_id):
            return False, "duplicate", tx_id
        g = gas_of(env)
        if g <= 0 or g > int(self.cfg.max_gas_per_tx):
            return False, "bad_gas", tx_id
        s = sender_of(env)
        if not s:
            return False, "missing_sender", tx_id
        q = self.by_sender.get(s, [])
        if len(q) >= int(self.cfg.max_sender_pending):
            return False, "sender_queue_full", tx_id
        n = nonce_of(env)
        # Insert while keeping nonce order stable (nonce, tx_id)
        q.append((n, tx_id))
        q.sort(key=lambda x: (int(x[0]), x[1]))
        self.by_sender[s] = q
        self.txs[tx_id] = env
        return True, None, tx_id

    def remove(self, tx_id: Hex) -> None:
        env = self.txs.pop(tx_id, None)
        if env is None:
            return
        s = sender_of(env)
        if s in self.by_sender:
            self.by_sender[s] = [(n,tid) for (n,tid) in self.by_sender[s] if tid != tx_id]
            if not self.by_sender[s]:
                self.by_sender.pop(s, None)

    def iter_ordered(self) -> Iterable[Tuple[str,int,Hex]]:
        # deterministic sender ordering
        senders = sorted(self.by_sender.keys())
        # produce round-robin
        idx = {s:0 for s in senders}
        remaining = True
        while remaining:
            remaining = False
            for s in senders:
                q = self.by_sender.get(s, [])
                i = idx.get(s, 0)
                if i < len(q):
                    remaining = True
                    n, tid = q[i]
                    idx[s] = i+1
                    yield s, int(n), tid

    def build_block(self, max_txs: int, max_gas: int) -> List[dict]:
        out: List[dict] = []
        gas_used = 0
        for _,_,tid in self.iter_ordered():
            env = self.txs.get(tid)
            if env is None:
                continue
            g = gas_of(env)
            if len(out) >= int(max_txs):
                break
            if gas_used + g > int(max_gas):
                continue
            out.append(env)
            gas_used += g
        return out
