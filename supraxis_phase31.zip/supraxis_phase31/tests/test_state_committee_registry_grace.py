import unittest
from supraxis.state import SupraxisState
from supraxis.committee import Committee
from supraxis.envelope import EnvelopeV3, QuorumProofV1, SignaturePolicy
from supraxis.sigverify import make_stub_signature, Signature
from supraxis.crypto import sha256
from supraxis.canonical import bitset_len, bitset_set
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class StateCommitteeRegistryGraceTests(unittest.TestCase):
    def _committee(self):
        return Committee.from_dict({
            "members":[
                {"pubkey":"0x706b31","weight":4,"schemes":[1]},
                {"pubkey":"0x706b32","weight":3,"schemes":[1]},
            ]
        })

    def _env_v3(self, epoch:int, committee, cid_bytes):
        payload=b'{"r":1}'
        ph=sha256(payload)
        base = EnvelopeV3(3, epoch, cid_bytes, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [], None)
        msg=base.signing_message()
        bm = bytearray(bitset_len(committee.size()))
        bitset_set(bm,0); bitset_set(bm,1)
        s0=make_stub_signature(1, b"pk1", msg)
        s1=make_stub_signature(1, b"pk2", msg)
        qp=QuorumProofV1(bytes(bm), [Signature(s0.scheme,b"",s0.sig), Signature(s1.scheme,b"",s1.sig)])
        return EnvelopeV3(3, epoch, cid_bytes, 1, b32(1), b32(2), 100, b32(0xAA), 1, 500000, 1, payload, ph, [], [], qp)

    def test_registry_required(self):
        committee = self._committee()
        cid = bytes.fromhex(committee.committee_id())
        env = self._env_v3(7, committee, cid)
        st = SupraxisState()
        prog = SirBinProgram(version=1, functions={"main":[{"op":"RET"}]})

        # no registry => fail
        with self.assertRaises(Exception):
            run_block(st, prog.functions, [env], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7, committee=committee))

        # register epoch => pass
        st.register_committee(7, committee.committee_id())
        run_block(st, prog.functions, [env], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7, committee=committee))

    def test_grace_allows_previous_epoch_committee(self):
        committee = self._committee()
        cid = bytes.fromhex(committee.committee_id())
        # env says epoch 8 but uses committee_id from epoch 7 (old committee)
        env = self._env_v3(8, committee, cid)
        st = SupraxisState()
        st.register_committee(7, committee.committee_id())
        st.register_committee(8, "00"*32)  # imagine new committee, but old allowed only via grace
        st.set_rotation_grace(1)
        prog = SirBinProgram(version=1, functions={"main":[{"op":"RET"}]})
        run_block(st, prog.functions, [env], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7, committee=committee))

        # grace=0 should fail because epoch 8 expects registered committee_id only
        st2 = SupraxisState()
        st2.register_committee(8, "00"*32)
        st2.set_rotation_grace(0)
        with self.assertRaises(Exception):
            run_block(st2, prog.functions, [env], require_signatures=True, sig_policy=SignaturePolicy(min_weight=7, committee=committee))

if __name__ == "__main__":
    unittest.main()
