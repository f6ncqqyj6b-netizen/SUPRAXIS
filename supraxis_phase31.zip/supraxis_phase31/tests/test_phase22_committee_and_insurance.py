import unittest
from supraxis.state import SupraxisState
from supraxis.committee import Committee
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.crypto import sha256
from supraxis.sigverify import make_stub_signature

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class Phase22(unittest.TestCase):
    def _env(self, sender:int, nonce:int):
        payload=b'{"n":%d}'%nonce
        base = EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
            target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=1_000_000_000_000,
            payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[],
        )
        sig=make_stub_signature(1,b"pk_any", base.signing_message())
        return EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
            target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=1_000_000_000_000,
            payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[sig],
        )

    def test_committee_distribute_pays_stake(self):
        committee_obj = {
            "members":[
                {"pubkey":"0x"+b32(1).hex(),"weight":1,"schemes":[1]},
                {"pubkey":"0x"+b32(2).hex(),"weight":1,"schemes":[1]},
            ]
        }
        committee = Committee.from_dict(committee_obj)
        cid_hex = committee.committee_id()  # hex string

        st = SupraxisState()
        # enable governance capability on chain 100 for committee registration
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global", "chain":100, "expires": 10**18}

        st.committee_pool = 100
        st.storage["committee.dist_interval"]=5
        st.storage["committee.dist_cap_per_member"]=0

        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"GOV_REGISTER_COMMITTEE_JSON","epoch":7,"committee":committee_obj},
            {"op":"COMMITTEE_DISTRIBUTE","committee_id":"0x"+cid_hex,"tick":10},
            {"op":"COMMITTEE_DISTRIBUTE","committee_id":"0x"+cid_hex,"tick":12},
            {"op":"RET"},
        ]})

        res = run_block(st, prog.functions, [self._env(7,1)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)

        self.assertTrue(any(e["event"]=="COMMITTEE_DISTRIBUTED" for e in res.events))
        self.assertTrue(any(e["event"]=="COMMITTEE_DISTRIBUTE_SKIPPED" for e in res.events))
        self.assertEqual(st.stake_of(("0x"+b32(1).hex()).lower())[0], 50)
        self.assertEqual(st.stake_of(("0x"+b32(2).hex()).lower())[0], 50)
        self.assertEqual(st.committee_pool, 0)

    def test_insurance_payout_gov(self):
        st = SupraxisState()
        st.insurance_pool = 200
        gov_cap_id = sha256(b"GOVERNANCE").hex()
        st.caps[gov_cap_id] = {"scope":"global", "chain":100, "expires": 10**18}

        to = b32(777).hex()
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"INSURANCE_PAYOUT","to":"0x"+to,"amount":60},
            {"op":"RET"},
        ]})
        res = run_block(st, prog.functions, [self._env(123,2)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(any(e["event"]=="INSURANCE_PAID" for e in res.events))
        self.assertEqual(st.insurance_pool, 140)
        self.assertEqual(st.balance_of(to), 60)

if __name__ == "__main__":
    unittest.main()
