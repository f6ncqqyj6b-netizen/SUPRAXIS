from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Set, Optional, Tuple, List
import json
from .committee import Committee

def _key(oc: int, os: bytes, tc: int, tct: bytes) -> str:
    return f"{oc}:{os.hex()}->{tc}:{tct.hex()}"

def _norm_hex(s: str) -> str:
    s = s.lower().strip()
    if s.startswith("0x"):
        s = s[2:]
    return s

@dataclass
class SupraxisState:
    # Replay / nonce tracking (key -> last_nonce)
    nonces: Dict[str, int] = field(default_factory=dict)

    # payload_hash recorded for last_nonce (key -> payload_hash_hex)
    nonce_payloads: Dict[str, str] = field(default_factory=dict)

    # Simple KV storage used by runtime opcodes
    storage: Dict[str, Any] = field(default_factory=dict)

    # Capability store
    caps: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    # Committee registry maps epoch -> committee_id_hex (64 chars)
    committee_registry: Dict[str, str] = field(default_factory=dict)

    # committee_store maps committee_id_hex -> canonical committee JSON
    committee_store: Dict[str, str] = field(default_factory=dict)

    # Rotation grace window
    rotation_grace_epochs: int = 0

    # Stake ledger (pubkey_hex -> {amount:int, locked_until:int})
    stakes: Dict[str, Dict[str, int]] = field(default_factory=dict)

    # Phase 19: balances + treasury + evidence rate limiting
    balances: Dict[str, int] = field(default_factory=dict)  # account_hex -> amount
    treasury: int = 0
    burned: int = 0
    burned_slash: int = 0
    burned_fee: int = 0
    burned_penalty: int = 0
    insurance_pool: int = 0
    insurance_claims: int = 0
    insurance_paid: int = 0
    insurance_last_paid_tick: Dict[str, int] = field(default_factory=dict)
    committee_pool: int = 0
    committee_last_dist_tick: int = -10**18
    evidence_attempts: int = 0  # fee-charged attempts (non-duplicate, non-rate-limited)
    evidence_rejects: int = 0
    evidence_last_attempt: Dict[str, int] = field(default_factory=dict)
    evidence_last_reject: Dict[str, int] = field(default_factory=dict)
    evidence_counter: int = 0  # increments on accepted evidence
    evidence_last_counter: Dict[str, int] = field(default_factory=dict)  # submitter_hex -> last accepted counter

    def get_last_nonce(self, oc: int, os: bytes, tc: int, tct: bytes) -> int:
        return int(self.nonces.get(_key(oc, os, tc, tct), 0))

    def get_last_payload_hash(self, oc: int, os: bytes, tc: int, tct: bytes) -> str:
        return str(self.nonce_payloads.get(_key(oc, os, tc, tct), ""))

    def set_last_nonce(self, oc: int, os: bytes, tc: int, tct: bytes, nonce: int, payload_hash_hex: str = "") -> None:
        k = _key(oc, os, tc, tct)
        self.nonces[k] = int(nonce)
        self.nonce_payloads[k] = str(payload_hash_hex)

    # Storage helpers
    def get(self, k: str, default: Any = None) -> Any:
        return self.storage.get(k, default)

    def put(self, k: str, v: Any) -> None:
        self.storage[k] = v

    # Slash parameters (stored in state.storage for determinism + governance)
    def slash_amount(self, offense: str, default: int = 1) -> int:
        v = self.storage.get(f"slash.{offense}", default)
        try:
            return max(0, int(v))
        except Exception:
            return max(0, int(default))

    # Evidence parameters
    def evidence_bounty_bps(self) -> int:
        v = self.storage.get("evidence.bounty_bps", 1000)  # 10%
        try:
            return max(0, min(10_000, int(v)))
        except Exception:
            return 1000

    def evidence_cooldown(self) -> int:
        v = self.storage.get("evidence.cooldown", 0)
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def evidence_fee_base(self) -> int:
        v = self.storage.get("evidence.fee", 0)
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def evidence_fee_mode(self) -> int:
        """0=fixed, 1=adaptive"""
        v = self.storage.get("evidence.fee_mode", 0)
        try:
            return 1 if int(v) != 0 else 0
        except Exception:
            return 0

    def evidence_fee_sink_mode(self) -> int:
        """0=treasury, 1=burn, 2=split"""
        v = self.storage.get("evidence.fee_sink_mode", 0)
        try:
            x = int(v)
            if x < 0: return 0
            if x > 2: return 2
            return x
        except Exception:
            return 0

    def evidence_fee_burn_bps(self) -> int:
        """Burn share on accept when sink_mode==2."""
        v = self.storage.get("evidence.fee_burn_bps", 0)
        try:
            return max(0, min(10_000, int(v)))
        except Exception:
            return 0

    def evidence_fee_burn_reject_bps(self) -> int:
        """Burn share on reject when sink_mode==2."""
        v = self.storage.get("evidence.fee_burn_reject_bps", 0)
        try:
            return max(0, min(10_000, int(v)))
        except Exception:
            return 0

    def evidence_refund_bps(self) -> int:
        v = self.storage.get("evidence.refund_bps", 10_000)
        try:
            return max(0, min(10_000, int(v)))
        except Exception:
            return 10_000

    def evidence_max_bounty(self) -> int:
        v = self.storage.get("evidence.max_bounty", 0)  # 0=unlimited
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def evidence_bounty_min_bps(self) -> int:
        v = self.storage.get("evidence.bounty_min_bps", 0)
        try:
            return max(0, min(10_000, int(v)))
        except Exception:
            return 0

    def evidence_cooldown_attempts(self) -> int:
        v = self.storage.get("evidence.cooldown_attempts", 0)
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def treasury_dist_interval(self) -> int:
        v = self.storage.get("treasury.dist_interval", 0)
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def treasury_dist_insurance_bps(self) -> int:
        v = self.storage.get("treasury.dist_insurance_bps", 0)
        try:
            return max(0, min(10_000, int(v)))
        except Exception:
            return 0

    def treasury_dist_committee_bps(self) -> int:
        v = self.storage.get("treasury.dist_committee_bps", 0)
        try:
            return max(0, min(10_000, int(v)))
        except Exception:
            return 0

    def committee_dist_interval(self) -> int:
        v = self.storage.get("committee.dist_interval", 0)
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def committee_dist_cap_per_member(self) -> int:
        v = self.storage.get("committee.dist_cap_per_member", 0)  # 0=unlimited
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def insurance_max_payout(self) -> int:
        v = self.storage.get("insurance.max_payout", 0)  # 0=unlimited
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def insurance_cooldown(self) -> int:
        v = self.storage.get("insurance.cooldown", 0)  # ticks
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def insurance_claim_fee(self) -> int:
        v = self.storage.get("insurance.claim_fee", 0)
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def treasury_to_insurance_interval(self) -> int:
        v = self.storage.get("treasury.to_insurance_interval", 0)
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def treasury_to_insurance_bps(self) -> int:
        v = self.storage.get("treasury.to_insurance_bps", 0)
        try:
            return max(0, min(10_000, int(v)))
        except Exception:
            return 0

    def claims_batch_default_mode(self) -> str:
        v = self.storage.get("claims.batch_default_mode", "oldest")
        return str(v)

    def claims_batch_skip_frozen(self) -> int:
        v = self.storage.get("claims.batch_skip_frozen", 1)
        try:
            return 1 if int(v) != 0 else 0
        except Exception:
            return 1

    def claims_batch_skip_disputed(self) -> int:
        v = self.storage.get("claims.batch_skip_disputed", 1)
        try:
            return 1 if int(v) != 0 else 0
        except Exception:
            return 1

    # Supply/invariants
    def supply_total(self) -> int:
        v = self.storage.get("supply.total", 0)  # 0 disables conservation check
        try:
            return max(0, int(v))
        except Exception:
            return 0

    def supply_enforce(self) -> int:
        v = self.storage.get("supply.enforce", 0)
        try:
            return 1 if int(v) != 0 else 0
        except Exception:
            return 0

    def total_balances(self) -> int:
        return int(sum(int(v) for v in self.balances.values()))

    def total_staked(self) -> int:
        return int(sum(int(rec.get("amount",0)) for rec in self.stakes.values()))

    def total_accounted(self) -> int:
        return int(self.total_balances() + int(self.treasury) + int(self.insurance_pool) + int(self.committee_pool) + int(self.burned) + int(self.total_staked()))

    def assert_non_negative(self) -> None:
        if int(self.treasury) < 0: raise ValueError("treasury negative")
        if int(self.insurance_pool) < 0: raise ValueError("insurance_pool negative")
        if int(self.committee_pool) < 0: raise ValueError("committee_pool negative")
        if int(self.burned) < 0: raise ValueError("burned negative")
        if int(self.burned_slash) < 0: raise ValueError("burned_slash negative")
        if int(self.burned_fee) < 0: raise ValueError("burned_fee negative")
        if int(self.burned_penalty) < 0: raise ValueError("burned_penalty negative")
        if int(self.burned) != int(self.burned_slash + self.burned_fee + self.burned_penalty):
            raise ValueError("burned categories mismatch")
        for a,v in self.balances.items():
            if int(v) < 0: raise ValueError("negative balance")
        for pk,rec in self.stakes.items():
            if int(rec.get("amount",0)) < 0: raise ValueError("negative stake")

    def assert_conservation(self) -> None:
        if int(self.supply_enforce()) == 0: return
        total = int(self.supply_total())
        if total <= 0: raise ValueError("supply.total not set")
        if int(self.total_accounted()) != int(total):
            raise ValueError("supply conservation violated")

    def burn(self, amount: int, reason: str="fee") -> None:
        if int(amount) < 0: raise ValueError("burn amount must be >=0")
        amt = int(amount)
        self.burned = int(self.burned + amt)
        if reason == "slash":
            self.burned_slash = int(self.burned_slash + amt)
        elif reason == "penalty":
            self.burned_penalty = int(self.burned_penalty + amt)
        else:
            self.burned_fee = int(self.burned_fee + amt)
        # keep categories aligned
        if int(self.burned) != int(self.burned_slash + self.burned_fee + self.burned_penalty):
            raise ValueError("burned categories mismatch")

    # Balances
    def balance_of(self, account_hex: str) -> int:
        a = _norm_hex(account_hex)
        return int(self.balances.get(a, 0))

    def credit(self, account_hex: str, amount: int) -> None:
        if amount < 0: raise ValueError("amount must be >=0")
        a = _norm_hex(account_hex)
        self.balances[a] = int(self.balance_of(a) + int(amount))

    def debit(self, account_hex: str, amount: int) -> None:
        if amount < 0: raise ValueError("amount must be >=0")
        a = _norm_hex(account_hex)
        cur = self.balance_of(a)
        if amount > cur: raise ValueError("insufficient balance")
        new = int(cur - int(amount))
        if new == 0:
            self.balances.pop(a, None)
        else:
            self.balances[a] = new

    # Committee registry
    def register_committee(self, epoch: int, committee_id_hex: str) -> None:
        e = str(int(epoch))
        cid = _norm_hex(committee_id_hex)
        if len(cid) != 64:
            raise ValueError("committee_id_hex must be 32 bytes (64 hex chars)")
        self.committee_registry[e] = cid

    def register_committee_json(self, epoch: int, committee_json: str) -> str:
        committee = Committee.from_json(committee_json)
        cid = committee.committee_id()
        self.committee_store[cid] = committee.canonical_json()
        self.register_committee(epoch, cid)
        return cid

    def get_committee_by_id(self, committee_id_hex: str) -> Optional[Committee]:
        cid = _norm_hex(committee_id_hex)
        js = self.committee_store.get(cid)
        if js is None:
            return None
        return Committee.from_json(js)

    def set_rotation_grace(self, grace_epochs: int) -> None:
        self.rotation_grace_epochs = max(0, int(grace_epochs))

    def allowed_committee_ids_for_epoch(self, epoch: int) -> Set[str]:
        ep = int(epoch)
        g = int(self.rotation_grace_epochs)
        allowed: Set[str] = set()
        for e_str, cid in self.committee_registry.items():
            try:
                e = int(e_str)
            except Exception:
                continue
            if ep - g <= e <= ep:
                allowed.add(cid)
        return allowed

    # Staking
    def stake_of(self, pubkey_hex: str) -> Tuple[int, int]:
        pk = _norm_hex(pubkey_hex)
        rec = self.stakes.get(pk)
        if rec is None:
            return (0, 0)
        return (int(rec.get("amount", 0)), int(rec.get("locked_until", 0)))

    def stake_add(self, pubkey_hex: str, amount: int, lock_until_epoch: int) -> None:
        if amount < 0:
            raise ValueError("amount must be >=0")
        pk = _norm_hex(pubkey_hex)
        cur_amt, cur_lock = self.stake_of(pk)
        self.stakes[pk] = {
            "amount": int(cur_amt + int(amount)),
            "locked_until": int(max(cur_lock, int(lock_until_epoch))),
        }

    def stake_sub(self, pubkey_hex: str, amount: int) -> None:
        if amount < 0:
            raise ValueError("amount must be >=0")
        pk = _norm_hex(pubkey_hex)
        cur_amt, cur_lock = self.stake_of(pk)
        if int(amount) > cur_amt:
            raise ValueError("insufficient stake")
        new_amt = int(cur_amt - int(amount))
        if new_amt == 0:
            self.stakes.pop(pk, None)
        else:
            self.stakes[pk] = {"amount": new_amt, "locked_until": int(cur_lock)}

    def slash(self, pubkey_hex: str, amount: int) -> int:
        """Reduce stake by up to amount. Returns actual slashed amount."""
        if amount < 0:
            raise ValueError("amount must be >=0")
        pk = _norm_hex(pubkey_hex)
        cur_amt, cur_lock = self.stake_of(pk)
        take = min(cur_amt, int(amount))
        if take == 0:
            return 0
        new_amt = int(cur_amt - take)
        if new_amt == 0:
            self.stakes.pop(pk, None)
        else:
            self.stakes[pk] = {"amount": new_amt, "locked_until": int(cur_lock)}
        return take

    def slash_with_pending(self, pubkey_hex: str, amount: int, tick: int) -> int:
        """Slash active stake first, then slash *pending unbond* records that are still locked (unlock > tick).
        Returns total slashed amount."""
        if amount < 0:
            raise ValueError("amount must be >=0")
        pk = _norm_hex(pubkey_hex)
        remaining = int(amount)
        taken = 0
        # 1) active stake
        take_stake = self.slash(pk, remaining)
        taken += int(take_stake)
        remaining -= int(take_stake)
        if remaining <= 0:
            return taken
        # 2) pending unbonds (still slashable until unlock)
        key = f"unbond.{('0x'+pk) if not str(pk).startswith('0x') else str(pk)}"
        recs = list(self.storage.get(key, []))
        out = []
        for r in recs:
            unlock = int(r.get("unlock", 10**18))
            amt = int(r.get("amount", 0))
            if amt <= 0:
                continue
            if unlock <= int(tick):
                out.append(r)
                continue
            if remaining <= 0:
                out.append(r)
                continue
            take = min(amt, remaining)
            amt2 = int(amt - take)
            taken += int(take)
            remaining -= int(take)
            if amt2 > 0:
                r2 = dict(r)
                r2["amount"] = int(amt2)
                out.append(r2)
            # else consumed fully (drop record)
        self.storage[key] = out
        return taken

    def epoch(self) -> int:
        return int(self.storage.get("epoch", 0))

    def tick(self) -> int:
        return int(self.storage.get("tick", 0))

    def snapshot_validators(self, max_validators: int) -> list:
        """Deterministically snapshot validator set from current stakes: top-N by stake, tie-break pubkey."""
        n = max(0, int(max_validators))
        top = self.top_stakers(n)
        # store as list of {vid,power} where vid = pubkey (hex)
        return [{"vid": ("0x"+pk) if not str(pk).startswith("0x") else str(pk), "power": int(p)} for (pk,p) in top]

    def top_stakers(self, n: int) -> List[Tuple[str, int]]:
        """Deterministically return top n stakers sorted by (-amount, pubkey_hex)."""
        items: List[Tuple[str,int]] = []
        for pk, rec in self.stakes.items():
            amt=int(rec.get("amount",0))
            if amt>0:
                items.append((pk, amt))
        items.sort(key=lambda x: (-x[1], x[0]))
        return items[: max(0, int(n))]

    def to_json(self) -> str:
        obj = {
            "nonces": self.nonces,
            "nonce_payloads": self.nonce_payloads,
            "storage": self.storage,
            "caps": self.caps,
            "committee_registry": {k: self.committee_registry[k] for k in sorted(self.committee_registry, key=lambda x: int(x)) if k in self.committee_registry},
            "committee_store": {k: self.committee_store[k] for k in sorted(self.committee_store.keys())},
            "rotation_grace_epochs": int(self.rotation_grace_epochs),
            "stakes": {k: {"amount": int(v.get("amount",0)), "locked_until": int(v.get("locked_until",0))} for k,v in sorted(self.stakes.items())},
            "balances": {k: int(v) for k,v in sorted(self.balances.items())},
            "treasury": int(self.treasury),
            "burned": int(self.burned),
            "burned_slash": int(self.burned_slash),
            "burned_fee": int(self.burned_fee),
            "burned_penalty": int(self.burned_penalty),
            "insurance_pool": int(self.insurance_pool),
            "insurance_claims": int(self.insurance_claims),
            "insurance_paid": int(self.insurance_paid),
            "insurance_last_paid_tick": dict(self.insurance_last_paid_tick),
            "committee_pool": int(self.committee_pool),
            "committee_last_dist_tick": int(self.committee_last_dist_tick),
            "evidence_attempts": int(self.evidence_attempts),
            "evidence_rejects": int(self.evidence_rejects),
            "evidence_last_attempt": dict(self.evidence_last_attempt),
            "evidence_last_reject": dict(self.evidence_last_reject),
            "evidence_counter": int(self.evidence_counter),
            "evidence_last_counter": {k: int(v) for k,v in sorted(self.evidence_last_counter.items())},
        }
        return json.dumps(obj, sort_keys=True, separators=(",", ":"))

    @staticmethod
    def from_json(s: str) -> "SupraxisState":
        d = json.loads(s)
        st = SupraxisState()
        st.nonces = {k: int(v) for k, v in d.get("nonces", {}).items()}
        st.nonce_payloads = {str(k): str(v) for k, v in d.get("nonce_payloads", {}).items()}
        st.storage = d.get("storage", {})
        st.caps = d.get("caps", {})
        st.committee_registry = {str(k): str(v) for k, v in d.get("committee_registry", {}).items()}
        st.committee_store = {str(k): str(v) for k, v in d.get("committee_store", {}).items()}
        st.rotation_grace_epochs = int(d.get("rotation_grace_epochs", 0))
        st.stakes = {str(k): {"amount": int(v.get("amount",0)), "locked_until": int(v.get("locked_until",0))} for k,v in d.get("stakes", {}).items()}
        st.balances = {str(k): int(v) for k,v in d.get("balances", {}).items()}
        st.treasury = int(d.get("treasury", 0))
        st.burned = int(d.get("burned", 0))
        st.burned_slash = int(d.get("burned_slash", 0))
        st.burned_fee = int(d.get("burned_fee", 0))
        st.burned_penalty = int(d.get("burned_penalty", 0))
        st.insurance_pool = int(d.get("insurance_pool", 0))
        st.insurance_claims = int(d.get("insurance_claims", 0))
        st.insurance_paid = int(d.get("insurance_paid", 0))
        st.insurance_last_paid_tick = dict(d.get("insurance_last_paid_tick", {}))
        st.committee_pool = int(d.get("committee_pool", 0))
        st.committee_last_dist_tick = int(d.get("committee_last_dist_tick", -10**18))
        st.evidence_attempts = int(d.get("evidence_attempts", 0))
        st.evidence_rejects = int(d.get("evidence_rejects", 0))
        st.evidence_last_attempt = dict(d.get("evidence_last_attempt", {}))
        st.evidence_last_reject = dict(d.get("evidence_last_reject", {}))
        st.evidence_counter = int(d.get("evidence_counter", 0))
        st.evidence_last_counter = {str(k): int(v) for k,v in d.get("evidence_last_counter", {}).items()}
        return st
