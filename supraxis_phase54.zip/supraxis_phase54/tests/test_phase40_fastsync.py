import unittest
from supraxis.state import SupraxisState
from supraxis.consensus.gossip import GossipStore
from supraxis.consensus.fastsync import fast_sync
from supraxis.consensus.headerchain import Header
from supraxis.consensus.signed_header import SignedHeader, header_message
from supraxis.consensus.signed_checkpoint import SignedCheckpoint, CheckpointSig
from supraxis.consensus.checkpoint import Checkpoint, validators_hash
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign
from supraxis.consensus.vote_signing import SCHEME_ED25519

class TestPhase40(unittest.TestCase):
    def test_end_to_end_fastsync_prefers_signed_headers(self):
        st = SupraxisState()
        g = GossipStore()
        k1 = ed25519_keygen(seed=bytes([7])*32)
        k2 = ed25519_keygen(seed=bytes([8])*32)
        v1 = "0x"+k1.public.hex()
        v2 = "0x"+k2.public.hex()

        st.storage["validators.epoch.0"] = [{"vid": v1, "power": 10}, {"vid": v2, "power": 10}]
        st.storage[f"validator.{v1}"] = {"vid": v1, "reward_address":"0x"+"aa"*32}
        st.storage[f"validator.{v2}"] = {"vid": v2, "reward_address":"0x"+"bb"*32}
        vh = validators_hash(st.storage["validators.epoch.0"])

        # Signed checkpoint at height 1
        ck = Checkpoint(chain_id=1, epoch=0, height=1, state_root="aa"*32, block_hash="01"*32, validators_hash=vh)
        msg = ck.signing_message()
        sig1 = "0x"+ed25519_sign(k1.private, msg).hex()
        sig2 = "0x"+ed25519_sign(k2.private, msg).hex()
        scp = SignedCheckpoint(checkpoint=ck, sigs=[
            CheckpointSig(vid=v1, scheme=SCHEME_ED25519, sig=sig1),
            CheckpointSig(vid=v2, scheme=SCHEME_ED25519, sig=sig2),
        ])
        g.add_checkpoint(scp)

        # Signed headers 2..3
        parent = "01"*32
        for hgt in [2,3]:
            bh = f"{hgt:02x}"*32
            h = Header(chain_id=1, epoch=0, height=hgt, round=0, block_hash=bh, parent_hash=parent, proposer="p", validators_hash=vh, qc=None)
            hm = header_message(h)
            sh = SignedHeader(header=h, sigs={
                v1: {"scheme": SCHEME_ED25519, "sig": ed25519_sign(k1.private, hm)},
                v2: {"scheme": SCHEME_ED25519, "sig": ed25519_sign(k2.private, hm)},
            })
            g.add_signed_header(sh)
            parent = bh

        ok, why, lc = fast_sync(st, g, chain_id=1)
        self.assertTrue(ok)
        self.assertEqual(lc.trusted.height, 3)
        self.assertEqual(lc.trusted.block_hash, "03"*32)

if __name__ == "__main__":
    unittest.main()
