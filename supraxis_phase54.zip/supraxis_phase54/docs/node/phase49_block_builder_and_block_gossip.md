# Phase 49 — Block Builder/Proposer + Block Gossip

This phase enables producing blocks from the mempool and propagating blocks over P2P.

## Block Format
`src/supraxis/netblock.py` (network block format)
- deterministic block encoding + `block_hash = sha256(canonical_json(block))`
- includes tx list (tx dicts)
- state_root placeholder (filled in later phases)

## Block Builder
`src/supraxis/node/block_builder.py`
- selects top-fee txs from mempool
- builds a block (height, parent_hash, proposer)
- on accepted block, removes included txs from mempool

## Block Gossip
Protocol:
- `new_block` / `new_block_ok`

Service:
`src/supraxis/node/block_gossip.py`
- validates and stores blocks into BlockStore
- optionally removes txs from mempool using BlockBuilder

Integration:
`src/supraxis/node/service.py`
- handles `new_block` if `block_gossip` is provided

## Next
Phase 50: slashing evidence plumbing end-to-end (detect → submit → verify → apply penalties).
