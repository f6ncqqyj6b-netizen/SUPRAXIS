from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict
from supraxis.node.peerdb import PeerDB, PeerRecord

@dataclass
class DiscoveryService:
    peerdb: PeerDB

    def get_peers(self, limit: int = 32) -> List[Dict]:
        out = []
        for r in self.peerdb.candidates(limit=limit):
            out.append({"host": r.host, "port": int(r.port)})
        return out
