from __future__ import annotations
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from dataclasses import dataclass
from typing import Optional, Callable, Dict, Any, Tuple
from urllib.parse import urlparse, parse_qs
import threading

from supraxis.mempool import Mempool
from supraxis.node.blockstore import BlockStore
from supraxis.node.evidence_service import EvidenceService
from supraxis.node.governance_service import GovernanceService

@dataclass
class RPCContext:
    chain_id: int
    mempool: Optional[Mempool] = None
    blocks: Optional[BlockStore] = None
    evidence: Optional[EvidenceService] = None
    governance: Optional[GovernanceService] = None

def _json_response(handler: BaseHTTPRequestHandler, code: int, obj: Any) -> None:
    raw = json.dumps(obj, indent=2, sort_keys=True).encode("utf-8")
    handler.send_response(code)
    handler.send_header("Content-Type", "application/json")
    handler.send_header("Content-Length", str(len(raw)))
    handler.end_headers()
    handler.wfile.write(raw)

class _ThreadingHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class RPCHandler(BaseHTTPRequestHandler):
    ctx: RPCContext = None  # type: ignore

    def log_message(self, fmt, *args):
        # quiet by default
        return

    def _read_json(self) -> Tuple[bool, Any]:
        try:
            n = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(n) if n > 0 else b"{}"
            return True, json.loads(raw.decode("utf-8"))
        except Exception as e:
            return False, {"error": "bad_json"}

    def do_GET(self):
        u = urlparse(self.path)
        path = u.path.rstrip("/")
        qs = parse_qs(u.query)

        if path == "" or path == "/":
            return _json_response(self, 200, {"ok": True, "service": "supraxis_rpc", "chain_id": self.ctx.chain_id})

        if path == "/health":
            return _json_response(self, 200, {"ok": True, "chain_id": self.ctx.chain_id})

        if path == "/mempool":
            if self.ctx.mempool is None:
                return _json_response(self, 404, {"ok": False, "why": "no_mempool"})
            limit = int(qs.get("limit", ["100"])[0])
            txs = [tx.to_dict() for tx in self.ctx.mempool.top(limit=limit)]
            return _json_response(self, 200, {"ok": True, "size": self.ctx.mempool.size(), "txs": txs})

        if path.startswith("/block/"):
            if self.ctx.blocks is None:
                return _json_response(self, 404, {"ok": False, "why": "no_blockstore"})
            h = path.split("/block/")[1]
            b = self.ctx.blocks.get_block(h)
            if b is None:
                return _json_response(self, 404, {"ok": False, "why": "not_found"})
            return _json_response(self, 200, {"ok": True, "hash": h, "block": b})

        if path == "/evidence/status":
            if self.ctx.evidence is None:
                return _json_response(self, 404, {"ok": False, "why": "no_evidence"})
            pk = str(qs.get("pubkey", [""])[0])
            # reuse service handler logic
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.evidence.handle_status(Msg(P.REQ_EVIDENCE_STATUS, {"pubkey": pk})))
            return _json_response(self, 200, rsp.payload)

        if path == "/governance/status":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            pid = str(qs.get("id", [""])[0])
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_status(Msg(P.REQ_GOV_STATUS, {"id": pid})))
            return _json_response(self, 200, rsp.payload)

        return _json_response(self, 404, {"ok": False, "why": "unknown_path", "path": path})

    def do_POST(self):
        u = urlparse(self.path)
        path = u.path.rstrip("/")
        ok, body = self._read_json()
        if not ok:
            return _json_response(self, 400, body)

        if path == "/tx/submit":
            if self.ctx.mempool is None:
                return _json_response(self, 404, {"ok": False, "why": "no_mempool"})
            tx = body.get("tx") if isinstance(body, dict) else None
            if not isinstance(tx, dict):
                return _json_response(self, 400, {"ok": False, "why": "bad_tx"})
            ok2, why2, h = self.ctx.mempool.add_tx_dict(tx)
            code = 200 if ok2 else 400
            return _json_response(self, code, {"ok": ok2, "why": why2, "hash": h})

        if path == "/evidence/submit":
            if self.ctx.evidence is None:
                return _json_response(self, 404, {"ok": False, "why": "no_evidence"})
            ev = body.get("evidence") if isinstance(body, dict) else None
            if not isinstance(ev, dict):
                return _json_response(self, 400, {"ok": False, "why": "bad_evidence"})
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.evidence.handle_submit(Msg(P.REQ_EVIDENCE_SUBMIT, {"evidence": ev})))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        if path == "/governance/submit":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_submit(Msg(P.REQ_GOV_SUBMIT, body)))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        if path == "/governance/queue":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            pid = str(body.get("id",""))
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_queue(Msg(P.REQ_GOV_QUEUE, {"id": pid})))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        if path == "/governance/execute":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            pid = str(body.get("id",""))
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_execute(Msg(P.REQ_GOV_EXECUTE, {"id": pid})))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        if path == "/governance/emergency":
            if self.ctx.governance is None:
                return _json_response(self, 404, {"ok": False, "why": "no_governance"})
            import asyncio
            from supraxis.p2p.message import Msg
            from supraxis.p2p import protocol as P
            rsp = asyncio.run(self.ctx.governance.handle_emergency(Msg(P.REQ_GOV_EMERGENCY, body)))
            code = 200 if rsp.payload.get("ok") else 400
            return _json_response(self, code, rsp.payload)

        return _json_response(self, 404, {"ok": False, "why": "unknown_path", "path": path})

def start_rpc_server(host: str, port: int, ctx: RPCContext) -> Tuple[_ThreadingHTTPServer, threading.Thread]:
    def handler_factory(*args, **kwargs):
        h = RPCHandler(*args, **kwargs)
        return h

    # attach ctx on class (safe enough for single server)
    RPCHandler.ctx = ctx
    httpd = _ThreadingHTTPServer((host, int(port)), RPCHandler)
    t = threading.Thread(target=httpd.serve_forever, daemon=True)
    t.start()
    return httpd, t
