from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

from supraxis.node.blockstore import BlockStore
from supraxis.node.block_builder import BlockBuilder
from supraxis.p2p.message import Msg
from supraxis.p2p import protocol as P
from supraxis.netblock import validate_netblock_dict as validate_block_dict, NetBlock as Block, netblock_from_dict as block_from_dict

@dataclass
class BlockGossipService:
    blockstore: BlockStore
    builder: Optional[BlockBuilder] = None  # used to remove txs from mempool on accept

    async def handle_new_block(self, msg: Msg) -> Msg:
        b = msg.payload.get("block") or {}
        ok, why = validate_block_dict(b) if isinstance(b, dict) else (False, "bad_block")
        if not ok:
            return Msg(P.RSP_NEW_BLOCK, {"ok": False, "why": why})
        block = block_from_dict(b)
        h = block.hash_hex()
        # store block dict by hash
        self.blockstore.put(h, block.to_dict())
        if self.builder is not None:
            self.builder.accept_block(block.to_dict())
        return Msg(P.RSP_NEW_BLOCK, {"ok": True, "hash": h})
