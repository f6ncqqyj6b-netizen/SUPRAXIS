# SUPRAXIS (Phase 10)

Phase 10 adds **committee rotation + epoch binding** and a **compact quorum proof** format.

## What’s new

### Envelope v3
- New envelope format **SCES v3** (`EnvelopeV3`)
- Adds fields that are part of the signing preimage:
  - `epoch: u64` — governance/rotation epoch
  - `committee_id: bytes32` — sha256(canonical committee JSON)
- Supports either:
  - explicit signatures (same as v2), or
  - **QuorumProofV1**: bitmap + signatures aligned to committee member indices (compact; pubkeys derived from committee)

### QuorumProofV1 (compact evidence)
- Store a bitmap of which committee members signed
- Store signatures in *index order*
- Verifier reconstructs pubkeys from committee members

### Committee rotation
Rotation is represented by changing `epoch` and/or `committee_id` in EnvelopeV3.
Validation (when a committee is supplied) enforces:
- `env.committee_id == sha256(committee.canonical_json)` (unless policy disables it)

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```

## CLI examples

Create a v3 envelope that binds to epoch + committee id (single stub signature):
```bash
PYTHONPATH=src python -m supraxis.cli envelope create-v3 \
  --epoch 42 --committee examples/committee.json \
  --origin-chain 1 --origin-tx 0x..32bytes.. --origin-sender 0x..32bytes.. \
  --target-chain 100 --target-contract 0x..32bytes.. \
  --nonce 1 --gas-limit 500000 --payload-type 1 --payload-json payload.json \
  --stub-sig-scheme 1 --stub-pubkey 0x706b31 --out env_v3.bin
```

Verify using committee + weighted threshold:
```bash
PYTHONPATH=src python -m supraxis.cli envelope verify --in env_v3.bin --require-sigs \
  --committee examples/committee.json --min-weight 7
```
