GAS_TABLE = {
    "CAP_REQUIRE": 500,
    "EMIT": 200,
    "STORE": 800,
    "ASSERT": 50,
    "CALL": 100,
    "RET": 0,
}
def gas_cost(op_name: str) -> int:
    return int(GAS_TABLE.get(op_name, 10_000_000))
