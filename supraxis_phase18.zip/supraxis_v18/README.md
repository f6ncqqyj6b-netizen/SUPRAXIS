# SUPRAXIS (Phase 18)

Phase 18 adds **evidence-based slashing for invalid V3 quorum proofs**.

Phase 16 auto-slashes invalid quorum proofs when they appear in-block.
Phase 18 lets anyone submit an invalid envelope later (even from another fork) and slash deterministically.

## Evidence: V3 Bad Quorum Proof

### `EVIDENCE_BAD_QUORUM_V3`
A permissionless runtime opcode that accepts one **canonical EnvelopeV3 byte blob**.

It verifies:
1. The blob decodes as **EnvelopeV3**
2. The referenced `committee_id` exists in `state.committee_store`
3. The envelope is **provably invalid** under deterministic validation:
   - policy uses `storage["quorum.min_weight"]` (optional) or `storage["quorum.min_valid"]` (default 1)
   - committee is loaded from state using `committee_id`
4. If the envelope is VALID, evidence is rejected.

If invalid, it slashes the **claimed quorum participants** (bitmap indices) using offense:
- `bad_quorum` (amount from `storage["slash.bad_quorum"]`, default 1)

### Replay protection for evidence
Accepted proofs store:
- `storage["evidence.<evidence_id>"]=1`

Submitting again emits:
- `EVIDENCE_DUPLICATE_IGNORED`

## Gas + SIRB
- New opcode: `OP_EVIDENCE_BAD_QUORUM_V3=0x32`
- Gas: `EVIDENCE_BAD_QUORUM_V3` = 150,000

## Previous phases still present
- Phase 17: `EVIDENCE_EQUIVOCATION_V3` (two-envelope proof of equivocation)
- Phase 15/16: auto-slashing for double-sign + bad quorum during block processing

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
