from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple
import json
from .canonical import pack_u16, pack_u32, pack_u64, read_u16, read_u32, read_u64
from .errors import ReplayError

MAGIC=b"SIRB"
VERSION=1

OP_CAP_REQUIRE=0x01
OP_EMIT=0x02
OP_STORE=0x03
OP_ASSERT=0x04

# Governance opcodes
OP_GOV_REGISTER_COMMITTEE_JSON=0x20
OP_GOV_REGISTER_COMMITTEE_ID=0x21
OP_GOV_SET_GRACE=0x22

# Stake + slashing
OP_GOV_STAKE=0x23
OP_GOV_UNSTAKE=0x24
OP_GOV_SLASH=0x25
OP_GOV_REGISTER_COMMITTEE_FROM_STAKE=0x26

# governance-settable slash parameter
OP_GOV_SET_SLASH_PARAM=0x27

# Phase 17: evidence-based slashing
OP_EVIDENCE_EQUIVOCATION_V3=0x31

# Phase 18: evidence-based bad quorum proof
OP_EVIDENCE_BAD_QUORUM_V3=0x32

OP_CALL=0x10
OP_RET=0xFF

MAX_CALL_DEPTH=32

def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

def _pack_str(s: str) -> bytes:
    b=s.encode("utf-8")
    return pack_u16(len(b))+b

def _read_str(buf: bytes, off: int) -> Tuple[str,int]:
    n, off = read_u16(buf, off)
    if off+n>len(buf): raise ReplayError("EOF str")
    return buf[off:off+n].decode("utf-8"), off+n

def _pack_blob(b: bytes) -> bytes:
    return pack_u32(len(b)) + b

def _read_blob(buf: bytes, off: int) -> Tuple[bytes,int]:
    n, off = read_u32(buf, off)
    if off+n>len(buf): raise ReplayError("EOF blob")
    return buf[off:off+n], off+n

@dataclass(frozen=True)
class SirBinProgram:
    version: int
    functions: Dict[str, List[Dict[str, Any]]]

    def encode(self) -> bytes:
        out=bytearray()
        out+=MAGIC
        out+=pack_u16(VERSION)
        items=sorted(self.functions.items(), key=lambda kv: kv[0])
        out+=pack_u16(len(items))
        for name, ops in items:
            out+=_pack_str(name)
            out+=pack_u32(len(ops))
            for op in ops:
                out.append(opcode_for(op))
                out+=encode_operands(op)
        return bytes(out)

    @staticmethod
    def decode(buf: bytes) -> "SirBinProgram":
        if len(buf)<8 or buf[:4]!=MAGIC: raise ReplayError("bad SIRB")
        off=4
        ver, off = read_u16(buf, off)
        if ver!=VERSION: raise ReplayError("bad version")
        nfn, off = read_u16(buf, off)
        fns={}
        for _ in range(nfn):
            name, off = _read_str(buf, off)
            nop, off = read_u32(buf, off)
            ops=[]
            for _ in range(nop):
                if off>=len(buf): raise ReplayError("EOF opcode")
                opc=buf[off]; off+=1
                op, off = decode_op(buf, off, opc)
                ops.append(op)
            fns[name]=ops
        if off!=len(buf): raise ReplayError("trailing bytes")
        return SirBinProgram(version=VERSION, functions=fns)

def opcode_for(op: Dict[str,Any]) -> int:
    n=op.get("op")
    if n=="CAP_REQUIRE": return OP_CAP_REQUIRE
    if n=="EMIT": return OP_EMIT
    if n=="STORE": return OP_STORE
    if n=="ASSERT": return OP_ASSERT

    if n=="GOV_REGISTER_COMMITTEE_JSON": return OP_GOV_REGISTER_COMMITTEE_JSON
    if n=="GOV_REGISTER_COMMITTEE_ID": return OP_GOV_REGISTER_COMMITTEE_ID
    if n=="GOV_SET_GRACE": return OP_GOV_SET_GRACE

    if n=="GOV_STAKE": return OP_GOV_STAKE
    if n=="GOV_UNSTAKE": return OP_GOV_UNSTAKE
    if n=="GOV_SLASH": return OP_GOV_SLASH
    if n=="GOV_REGISTER_COMMITTEE_FROM_STAKE": return OP_GOV_REGISTER_COMMITTEE_FROM_STAKE

    if n=="GOV_SET_SLASH_PARAM": return OP_GOV_SET_SLASH_PARAM

    if n=="EVIDENCE_EQUIVOCATION_V3": return OP_EVIDENCE_EQUIVOCATION_V3

    if n=="EVIDENCE_BAD_QUORUM_V3": return OP_EVIDENCE_BAD_QUORUM_V3

    if n=="CALL": return OP_CALL
    if n=="RET": return OP_RET
    raise ReplayError("unknown op")

def _hex_to_bytes(s: str) -> bytes:
    s=s.strip()
    if s.lower().startswith("0x"): s=s[2:]
    return bytes.fromhex(s)

def encode_operands(op: Dict[str,Any]) -> bytes:
    n=op["op"]
    if n=="CAP_REQUIRE": return _pack_str(str(op["cap"]))+_pack_str(str(op["scope"]))
    if n=="EMIT":
        pb=canonical_json_bytes(op.get("payload"))
        return _pack_str(str(op["event"]))+pack_u32(len(pb))+pb
    if n=="STORE":
        vb=canonical_json_bytes(op.get("value"))
        return _pack_str(str(op["key"]))+pack_u32(len(vb))+vb
    if n=="ASSERT": return bytes([1 if bool(op.get("value")) else 0])

    if n=="GOV_REGISTER_COMMITTEE_JSON":
        epoch=int(op["epoch"])
        cb=canonical_json_bytes(op["committee"])
        return pack_u64(epoch) + pack_u32(len(cb)) + cb
    if n=="GOV_REGISTER_COMMITTEE_ID":
        epoch=int(op["epoch"])
        return pack_u64(epoch) + _pack_str(str(op["committee_id"]))
    if n=="GOV_SET_GRACE":
        grace=int(op["grace"])
        return pack_u32(grace)

    if n=="GOV_STAKE":
        pk=_pack_str(str(op["pubkey"]))
        amount=pack_u64(int(op["amount"]))
        lock=pack_u32(int(op.get("lock_epochs", 0)))
        return pk + amount + lock
    if n=="GOV_UNSTAKE":
        pk=_pack_str(str(op["pubkey"]))
        amount=pack_u64(int(op["amount"]))
        return pk + amount
    if n=="GOV_SLASH":
        pk=_pack_str(str(op["pubkey"]))
        amount=pack_u64(int(op["amount"]))
        reason=_pack_str(str(op.get("reason","")))
        return pk + amount + reason
    if n=="GOV_REGISTER_COMMITTEE_FROM_STAKE":
        epoch=pack_u64(int(op["epoch"]))
        size=pack_u32(int(op["size"]))
        return epoch + size

    if n=="GOV_SET_SLASH_PARAM":
        offense=_pack_str(str(op["offense"]))
        amount=pack_u64(int(op["amount"]))
        return offense + amount

    if n=="EVIDENCE_EQUIVOCATION_V3":
        a=_hex_to_bytes(str(op["env_a"]))
        b=_hex_to_bytes(str(op["env_b"]))
        return _pack_blob(a) + _pack_blob(b)

    if n=="EVIDENCE_BAD_QUORUM_V3":
        e=_hex_to_bytes(str(op["env"]))
        return _pack_blob(e)

    if n=="CALL": return _pack_str(str(op["fn"]))
    if n=="RET": return b""
    raise ReplayError("bad op")

def decode_op(buf: bytes, off: int, opc: int):
    if opc==OP_CAP_REQUIRE:
        cap, off=_read_str(buf, off); scope, off=_read_str(buf, off)
        return {"op":"CAP_REQUIRE","cap":cap,"scope":scope}, off
    if opc==OP_EMIT:
        event, off=_read_str(buf, off)
        n, off=read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF payload")
        payload=json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"EMIT","event":event,"payload":payload}, off
    if opc==OP_STORE:
        key, off=_read_str(buf, off)
        n, off=read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF value")
        value=json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"STORE","key":key,"value":value}, off
    if opc==OP_ASSERT:
        if off>=len(buf): raise ReplayError("EOF assert")
        v=buf[off]; off+=1
        if v not in (0,1): raise ReplayError("bad assert")
        return {"op":"ASSERT","value":bool(v)}, off

    if opc==OP_GOV_REGISTER_COMMITTEE_JSON:
        epoch, off = read_u64(buf, off)
        n, off = read_u32(buf, off)
        if off+n>len(buf): raise ReplayError("EOF committee")
        committee = json.loads(buf[off:off+n].decode("utf-8")); off+=n
        return {"op":"GOV_REGISTER_COMMITTEE_JSON","epoch":int(epoch),"committee":committee}, off
    if opc==OP_GOV_REGISTER_COMMITTEE_ID:
        epoch, off = read_u64(buf, off)
        cid, off = _read_str(buf, off)
        return {"op":"GOV_REGISTER_COMMITTEE_ID","epoch":int(epoch),"committee_id":cid}, off
    if opc==OP_GOV_SET_GRACE:
        grace, off = read_u32(buf, off)
        return {"op":"GOV_SET_GRACE","grace":int(grace)}, off

    if opc==OP_GOV_STAKE:
        pk, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        lock, off = read_u32(buf, off)
        return {"op":"GOV_STAKE","pubkey":pk,"amount":int(amount),"lock_epochs":int(lock)}, off
    if opc==OP_GOV_UNSTAKE:
        pk, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        return {"op":"GOV_UNSTAKE","pubkey":pk,"amount":int(amount)}, off
    if opc==OP_GOV_SLASH:
        pk, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        reason, off = _read_str(buf, off)
        return {"op":"GOV_SLASH","pubkey":pk,"amount":int(amount),"reason":reason}, off
    if opc==OP_GOV_REGISTER_COMMITTEE_FROM_STAKE:
        epoch, off = read_u64(buf, off)
        size, off = read_u32(buf, off)
        return {"op":"GOV_REGISTER_COMMITTEE_FROM_STAKE","epoch":int(epoch),"size":int(size)}, off

    if opc==OP_GOV_SET_SLASH_PARAM:
        offense, off = _read_str(buf, off)
        amount, off = read_u64(buf, off)
        return {"op":"GOV_SET_SLASH_PARAM","offense":offense,"amount":int(amount)}, off

    if opc==OP_EVIDENCE_EQUIVOCATION_V3:
        a, off = _read_blob(buf, off)
        b, off = _read_blob(buf, off)
        return {"op":"EVIDENCE_EQUIVOCATION_V3","env_a":"0x"+a.hex(),"env_b":"0x"+b.hex()}, off

    if opc==OP_EVIDENCE_BAD_QUORUM_V3:
        e, off = _read_blob(buf, off)
        return {"op":"EVIDENCE_BAD_QUORUM_V3","env":"0x"+e.hex()}, off

    if opc==OP_CALL:
        fn, off=_read_str(buf, off)
        return {"op":"CALL","fn":fn}, off
    if opc==OP_RET:
        return {"op":"RET"}, off
    raise ReplayError("unknown opcode")

def disasm(buf: bytes) -> str:
    prog=SirBinProgram.decode(buf)
    lines=[f"; SIRB v{prog.version}"]
    for fn in sorted(prog.functions.keys()):
        lines.append(f"fn {fn}:")
        for i, op in enumerate(prog.functions[fn]):
            lines.append(f"  {i:04d}  {op}")
    return "\n".join(lines)+"\n"
