from __future__ import annotations
import argparse, json
from pathlib import Path
from .state import SupraxisState
from .crypto import sha256
from .envelope import EnvelopeV2, EnvelopeV3, QuorumProofV1, decode_envelope, SignaturePolicy
from .committee import Committee
from .sigverify import make_stub_signature, Signature
from .sirbin import SirBinProgram, disasm as sir_disasm
from .block import run_block, block_hash
from .canonical import bitset_len

def _bytes32(s: str) -> bytes:
    s=s.lower().strip()
    if s.startswith("0x"): s=s[2:]
    b=bytes.fromhex(s)
    if len(b)!=32: raise SystemExit("expected 32-byte hex")
    return b

def _policy(args, state: SupraxisState|None = None, env=None) -> SignaturePolicy:
    allowed = None
    if args.allowed_schemes:
        allowed = set(int(x) for x in args.allowed_schemes.split(",") if x.strip() != "")
    committee = None
    if args.committee:
        committee = Committee.from_json(Path(args.committee).read_text(encoding="utf-8"))
    elif args.use_state_committee and state is not None and env is not None and getattr(env, "version", 0) == 3:
        # Load committee by env.committee_id from state committee_store
        committee = state.get_committee_by_id(getattr(env, "committee_id", b"").hex())
    return SignaturePolicy(
        min_valid=int(args.sig_threshold),
        min_weight=(int(args.min_weight) if args.min_weight is not None else None),
        allowed_schemes=allowed,
        committee=committee,
        require_committee_id=True,
    )

def cmd_state_init(a):
    Path(a.out).write_text(SupraxisState().to_json(), encoding="utf-8")
    print(a.out)

def cmd_state_register_committee_id(a):
    st = SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8"))
    st.register_committee(int(a.epoch), a.committee_id)
    Path(a.out).write_text(st.to_json(), encoding="utf-8")
    print(a.out)

def cmd_state_register_committee_json(a):
    st = SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8"))
    js = Path(a.committee).read_text(encoding="utf-8")
    cid = st.register_committee_json(int(a.epoch), js)
    Path(a.out).write_text(st.to_json(), encoding="utf-8")
    print(cid)

def cmd_state_set_grace(a):
    st = SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8"))
    st.set_rotation_grace(int(a.grace))
    Path(a.out).write_text(st.to_json(), encoding="utf-8")
    print(a.out)

def cmd_committee_id(a):
    c = Committee.from_json(Path(a.infile).read_text(encoding="utf-8"))
    print(c.committee_id())

def cmd_env_verify(a):
    env=decode_envelope(Path(a.infile).read_bytes())
    state = SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8")) if a.state else None
    pol = _policy(a, state=state, env=env) if a.require_sigs else None
    try:
        env.validate(require_signatures=a.require_sigs, policy=pol)  # v2/v3
    except TypeError:
        env.validate(require_signatures=a.require_sigs)  # v1
    print("OK")

def cmd_env_create_v2(a):
    payload_obj=json.loads(Path(a.payload_json).read_text(encoding="utf-8"))
    payload=json.dumps(payload_obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ph=sha256(payload)
    env0 = EnvelopeV2(
        2, int(a.origin_chain), _bytes32(a.origin_tx), _bytes32(a.origin_sender),
        int(a.target_chain), _bytes32(a.target_contract),
        int(a.nonce), int(a.gas_limit), int(a.payload_type),
        payload, ph, [_bytes32(x) for x in (a.cap_ref or [])], []
    )
    msg = env0.signing_message()
    sigs=[]
    if a.stub_sig_scheme is not None:
        pk = bytes.fromhex(a.stub_pubkey[2:] if a.stub_pubkey.startswith("0x") else a.stub_pubkey)
        sigs=[make_stub_signature(int(a.stub_sig_scheme), pk, msg)]
    env = EnvelopeV2(
        2, int(a.origin_chain), _bytes32(a.origin_tx), _bytes32(a.origin_sender),
        int(a.target_chain), _bytes32(a.target_contract),
        int(a.nonce), int(a.gas_limit), int(a.payload_type),
        payload, ph, [_bytes32(x) for x in (a.cap_ref or [])], sigs
    )
    Path(a.out).write_bytes(env.canonical_bytes())
    print(a.out)

def cmd_env_create_v3(a):
    committee = Committee.from_json(Path(a.committee).read_text(encoding="utf-8"))
    cid = bytes.fromhex(committee.committee_id())

    payload_obj=json.loads(Path(a.payload_json).read_text(encoding="utf-8"))
    payload=json.dumps(payload_obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ph=sha256(payload)

    env0 = EnvelopeV3(
        3, int(a.epoch), cid,
        int(a.origin_chain), _bytes32(a.origin_tx), _bytes32(a.origin_sender),
        int(a.target_chain), _bytes32(a.target_contract),
        int(a.nonce), int(a.gas_limit), int(a.payload_type),
        payload, ph, [_bytes32(x) for x in (a.cap_ref or [])], [], None
    )
    msg = env0.signing_message()

    sigs=[]
    qp=None
    if a.quorum_bitmap is not None:
        bitmap = bytes.fromhex(a.quorum_bitmap[2:] if a.quorum_bitmap.startswith("0x") else a.quorum_bitmap)
        if len(bitmap) != bitset_len(committee.size()):
            raise SystemExit("bitmap length mismatch for committee")
        pubkeys = [bytes.fromhex(x[2:] if x.startswith("0x") else x) for x in (a.stub_pubkey_list or [])]
        if len(pubkeys) == 0:
            raise SystemExit("--stub-pubkey-list required for quorum proof (one per set bit)")
        indices=[]
        for i in range(committee.size()):
            if (bitmap[i//8] >> (7-(i%8))) & 1:
                indices.append(i)
        if len(indices) != len(pubkeys):
            raise SystemExit("pubkey-list count must equal number of set bits")
        qp_sigs=[]
        for pk in pubkeys:
            s = make_stub_signature(int(a.stub_sig_scheme or 1), pk, msg)
            qp_sigs.append(Signature(s.scheme, b"", s.sig))
        qp=QuorumProofV1(bitmap=bitmap, sigs=qp_sigs)
    else:
        if a.stub_sig_scheme is not None:
            pk = bytes.fromhex(a.stub_pubkey[2:] if a.stub_pubkey.startswith("0x") else a.stub_pubkey)
            sigs=[make_stub_signature(int(a.stub_sig_scheme), pk, msg)]

    env = EnvelopeV3(
        3, int(a.epoch), cid,
        int(a.origin_chain), _bytes32(a.origin_tx), _bytes32(a.origin_sender),
        int(a.target_chain), _bytes32(a.target_contract),
        int(a.nonce), int(a.gas_limit), int(a.payload_type),
        payload, ph, [_bytes32(x) for x in (a.cap_ref or [])], sigs, qp
    )
    Path(a.out).write_bytes(env.canonical_bytes())
    print(a.out)

def cmd_sir_compile(a):
    obj=json.loads(Path(a.infile).read_text(encoding="utf-8"))
    prog=SirBinProgram(version=1, functions=obj["functions"])
    Path(a.out).write_bytes(prog.encode())
    print(a.out)

def cmd_sir_disasm(a):
    print(sir_disasm(Path(a.infile).read_bytes()), end="")

def cmd_block_run(a):
    st=SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8"))
    prog=SirBinProgram.decode(Path(a.sirb).read_bytes())
    envs=[decode_envelope(Path(p).read_bytes()) for p in a.envelopes]
    pol = _policy(a, state=st, env=envs[0] if envs else None) if a.require_sigs else None
    res=run_block(
        st, prog.functions, envs,
        entry=a.entry,
        require_signatures=a.require_sigs,
        sig_policy=pol,
        enforce_committee_registry=not a.no_committee_registry,
    )
    out={"state": json.loads(res.state_json), "events": res.events, "block_hash": res.block_hash}
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True), encoding="utf-8")
    print(res.block_hash)

def cmd_block_hash(a):
    print(block_hash(Path(a.infile).read_text(encoding="utf-8")))

def build():
    p=argparse.ArgumentParser(prog="supraxis")
    sp=p.add_subparsers(dest="cmd", required=True)

    st=sp.add_parser("state"); sps=st.add_subparsers(dest="sub", required=True)
    x=sps.add_parser("init"); x.add_argument("--out", required=True); x.set_defaults(func=cmd_state_init)
    x=sps.add_parser("register-committee-id"); x.add_argument("--state", required=True); x.add_argument("--epoch", required=True, type=int)
    x.add_argument("--committee-id", required=True); x.add_argument("--out", required=True); x.set_defaults(func=cmd_state_register_committee_id)
    x=sps.add_parser("register-committee-json"); x.add_argument("--state", required=True); x.add_argument("--epoch", required=True, type=int)
    x.add_argument("--committee", required=True); x.add_argument("--out", required=True); x.set_defaults(func=cmd_state_register_committee_json)
    x=sps.add_parser("set-grace"); x.add_argument("--state", required=True); x.add_argument("--grace", required=True, type=int)
    x.add_argument("--out", required=True); x.set_defaults(func=cmd_state_set_grace)

    com=sp.add_parser("committee"); cps=com.add_subparsers(dest="sub", required=True)
    x=cps.add_parser("id"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_committee_id)

    env=sp.add_parser("envelope"); eps=env.add_subparsers(dest="sub", required=True)
    x=eps.add_parser("verify"); x.add_argument("--in", dest="infile", required=True)
    x.add_argument("--state", default=None, help="optional state.json to load committee store")
    x.add_argument("--use-state-committee", action="store_true", help="for v3, load committee by committee_id from state")
    x.add_argument("--require-sigs", action="store_true")
    x.add_argument("--sig-threshold", type=int, default=1)
    x.add_argument("--min-weight", type=int, default=None)
    x.add_argument("--allowed-schemes", default="")
    x.add_argument("--committee", default=None)
    x.set_defaults(func=cmd_env_verify)

    x=eps.add_parser("create-v2")
    x.add_argument("--origin-chain", required=True, type=int); x.add_argument("--origin-tx", required=True); x.add_argument("--origin-sender", required=True)
    x.add_argument("--target-chain", required=True, type=int); x.add_argument("--target-contract", required=True)
    x.add_argument("--nonce", required=True, type=int); x.add_argument("--gas-limit", required=True, type=int); x.add_argument("--payload-type", required=True, type=int)
    x.add_argument("--payload-json", required=True)
    x.add_argument("--cap-ref", action="append")
    x.add_argument("--stub-sig-scheme", type=int, default=None)
    x.add_argument("--stub-pubkey", default="0x01")
    x.add_argument("--out", required=True)
    x.set_defaults(func=cmd_env_create_v2)

    x=eps.add_parser("create-v3")
    x.add_argument("--epoch", required=True, type=int)
    x.add_argument("--committee", required=True, help="committee.json used to bind committee_id and quorum proofs")
    x.add_argument("--origin-chain", required=True, type=int); x.add_argument("--origin-tx", required=True); x.add_argument("--origin-sender", required=True)
    x.add_argument("--target-chain", required=True, type=int); x.add_argument("--target-contract", required=True)
    x.add_argument("--nonce", required=True, type=int); x.add_argument("--gas-limit", required=True, type=int); x.add_argument("--payload-type", required=True, type=int)
    x.add_argument("--payload-json", required=True)
    x.add_argument("--cap-ref", action="append")
    x.add_argument("--stub-sig-scheme", type=int, default=None)
    x.add_argument("--stub-pubkey", default="0x706b31")
    x.add_argument("--quorum-bitmap", default=None)
    x.add_argument("--stub-pubkey-list", action="append", default=None)
    x.add_argument("--out", required=True)
    x.set_defaults(func=cmd_env_create_v3)

    sir=sp.add_parser("sir"); sps=sir.add_subparsers(dest="sub", required=True)
    x=sps.add_parser("compile"); x.add_argument("--in", dest="infile", required=True); x.add_argument("--out", required=True); x.set_defaults(func=cmd_sir_compile)
    x=sps.add_parser("disasm"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_sir_disasm)

    blk=sp.add_parser("block"); bps=blk.add_subparsers(dest="sub", required=True)
    x=bps.add_parser("run"); x.add_argument("--sirb", required=True); x.add_argument("--state", required=True); x.add_argument("--envelopes", nargs="+", required=True)
    x.add_argument("--entry", default="main")
    x.add_argument("--require-sigs", action="store_true")
    x.add_argument("--use-state-committee", action="store_true", help="if no --committee, load committee from state committee_store")
    x.add_argument("--sig-threshold", type=int, default=1)
    x.add_argument("--min-weight", type=int, default=None)
    x.add_argument("--allowed-schemes", default="")
    x.add_argument("--committee", default=None)
    x.add_argument("--no-committee-registry", action="store_true")
    x.add_argument("--out", required=True)
    x.set_defaults(func=cmd_block_run)

    x=bps.add_parser("hash"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_block_hash)

    return p

def main():
    p=build()
    a=p.parse_args()
    a.func(a)

if __name__=="__main__":
    main()
