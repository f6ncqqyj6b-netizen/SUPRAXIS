# SUPRAXIS (Phase 16)

Phase 16 adds **automatic slashing for invalid quorum proofs** (v3 envelopes).

## New offense: bad_quorum

If an **EnvelopeV3** fails validation (e.g., invalid quorum proof, insufficient weight, bad committee binding),
the protocol can deterministically slash the **claimed quorum participants** (by bitmap indices) and skip execution.

### Deterministic behavior
- EnvelopeV3 `validate(...)` is attempted as normal.
- If validation raises:
  - If `auto_slash=True`, slash bitmap participants with offense `bad_quorum`
  - Emit `AUTO_SLASH_BAD_QUORUM` events (one per claimed signer)
  - Skip execution and continue block deterministically

### Slash parameter
Slash amount is read from:
- `storage["slash.bad_quorum"]` (default: `1`)

You can set it via governance (Phase 15):
- `GOV_SET_SLASH_PARAM("bad_quorum", amount)`

## Phase 15 still present
- Double-sign detection (same nonce, different payload_hash) still triggers `AUTO_SLASH_DOUBLE_SIGN`.

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```
