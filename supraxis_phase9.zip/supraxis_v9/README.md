# SUPRAXIS (Phase 9)

Phase 9 adds **committee-based signature policy**, **weighted thresholds**, and deterministic **signature set normalization**.

## What’s new

- **Committee** (`src/supraxis/committee.py`):
  - Canonical member ordering (by pubkey)
  - Deterministic `committee_id = sha256(canonical_json)`
  - Member weights + optional per-member allowed schemes

- **SignaturePolicy upgrades** (`src/supraxis/envelope.py`):
  - `min_valid = k` (k-of-n) OR `min_weight = W` (weighted threshold)
  - Committee can define allowed pubkeys + weights automatically
  - Deterministic normalization:
    - signatures are sorted canonically
    - only **one signature per pubkey** counts toward threshold (dedupe)

## Tests
```bash
PYTHONPATH=src python -m unittest discover -s tests -p "test_*.py" -q
```

## CLI examples

Compute committee id:
```bash
PYTHONPATH=src python -m supraxis.cli committee id --in committee.json
```

Verify envelope with committee allowlist + weight threshold:
```bash
PYTHONPATH=src python -m supraxis.cli envelope verify --in env.bin --require-sigs \
  --committee committee.json --min-weight 7
```
