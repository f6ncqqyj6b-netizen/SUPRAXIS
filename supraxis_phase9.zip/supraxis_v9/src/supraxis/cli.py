from __future__ import annotations
import argparse, json
from pathlib import Path
from .state import SupraxisState
from .crypto import sha256
from .envelope import EnvelopeV2, decode_envelope, SignaturePolicy
from .committee import Committee
from .sigverify import make_stub_signature
from .sirbin import SirBinProgram, disasm as sir_disasm
from .block import run_block, block_hash

def _bytes32(s: str) -> bytes:
    s=s.lower().strip()
    if s.startswith("0x"): s=s[2:]
    b=bytes.fromhex(s)
    if len(b)!=32: raise SystemExit("expected 32-byte hex")
    return b

def _load_committee(path: str|None) -> Committee|None:
    if not path:
        return None
    return Committee.from_json(Path(path).read_text(encoding="utf-8"))

def _policy(args) -> SignaturePolicy:
    allowed = None
    if args.allowed_schemes:
        allowed = set(int(x) for x in args.allowed_schemes.split(",") if x.strip() != "")
    committee = _load_committee(args.committee)
    return SignaturePolicy(
        min_valid=int(args.sig_threshold),
        min_weight=(int(args.min_weight) if args.min_weight is not None else None),
        allowed_schemes=allowed,
        allowed_pubkeys=None,
        pubkey_weights=None,
        pubkey_allowed_schemes=None,
        committee=committee,
    )

def cmd_env_verify(a):
    env=decode_envelope(Path(a.infile).read_bytes())
    pol = _policy(a) if a.require_sigs else None
    try:
        env.validate(require_signatures=a.require_sigs, policy=pol)  # v2
    except TypeError:
        env.validate(require_signatures=a.require_sigs)  # v1
    print("OK")

def cmd_committee_id(a):
    c = Committee.from_json(Path(a.infile).read_text(encoding="utf-8"))
    print(c.committee_id())

def cmd_env_create_v2(a):
    payload_obj=json.loads(Path(a.payload_json).read_text(encoding="utf-8"))
    payload=json.dumps(payload_obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    ph=sha256(payload)
    env0 = EnvelopeV2(
        2, int(a.origin_chain), _bytes32(a.origin_tx), _bytes32(a.origin_sender),
        int(a.target_chain), _bytes32(a.target_contract),
        int(a.nonce), int(a.gas_limit), int(a.payload_type),
        payload, ph, [_bytes32(x) for x in (a.cap_ref or [])], []
    )
    msg = env0.signing_message()
    sigs=[]
    if a.stub_sig_scheme is not None:
        pk = bytes.fromhex(a.stub_pubkey[2:] if a.stub_pubkey.startswith("0x") else a.stub_pubkey)
        sigs=[make_stub_signature(int(a.stub_sig_scheme), pk, msg)]
    env = EnvelopeV2(
        2, int(a.origin_chain), _bytes32(a.origin_tx), _bytes32(a.origin_sender),
        int(a.target_chain), _bytes32(a.target_contract),
        int(a.nonce), int(a.gas_limit), int(a.payload_type),
        payload, ph, [_bytes32(x) for x in (a.cap_ref or [])], sigs
    )
    Path(a.out).write_bytes(env.canonical_bytes())
    print(a.out)

def cmd_sir_compile(a):
    obj=json.loads(Path(a.infile).read_text(encoding="utf-8"))
    prog=SirBinProgram(version=1, functions=obj["functions"])
    Path(a.out).write_bytes(prog.encode())
    print(a.out)

def cmd_sir_disasm(a):
    print(sir_disasm(Path(a.infile).read_bytes()), end="")

def cmd_state_init(a):
    Path(a.out).write_text(SupraxisState().to_json(), encoding="utf-8")
    print(a.out)

def cmd_block_run(a):
    st=SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8"))
    prog=SirBinProgram.decode(Path(a.sirb).read_bytes())
    envs=[decode_envelope(Path(p).read_bytes()) for p in a.envelopes]
    pol = _policy(a) if a.require_sigs else None
    res=run_block(st, prog.functions, envs, entry=a.entry, require_signatures=a.require_sigs, sig_policy=pol)
    out={"state": json.loads(res.state_json), "events": res.events, "block_hash": res.block_hash}
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True), encoding="utf-8")
    print(res.block_hash)

def cmd_block_hash(a):
    print(block_hash(Path(a.infile).read_text(encoding="utf-8")))

def build():
    p=argparse.ArgumentParser(prog="supraxis")
    sp=p.add_subparsers(dest="cmd", required=True)

    st=sp.add_parser("state"); sps=st.add_subparsers(dest="sub", required=True)
    x=sps.add_parser("init"); x.add_argument("--out", required=True); x.set_defaults(func=cmd_state_init)

    com=sp.add_parser("committee"); cps=com.add_subparsers(dest="sub", required=True)
    x=cps.add_parser("id"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_committee_id)

    env=sp.add_parser("envelope"); eps=env.add_subparsers(dest="sub", required=True)
    x=eps.add_parser("verify"); x.add_argument("--in", dest="infile", required=True)
    x.add_argument("--require-sigs", action="store_true")
    x.add_argument("--sig-threshold", type=int, default=1)
    x.add_argument("--min-weight", type=int, default=None, help="weighted threshold; if set overrides sig-threshold")
    x.add_argument("--allowed-schemes", default="", help="comma-separated scheme ids, e.g. 11,12")
    x.add_argument("--committee", default=None, help="path to committee.json (pubkey allowlist + weights)")
    x.set_defaults(func=cmd_env_verify)

    x=eps.add_parser("create-v2")
    x.add_argument("--origin-chain", required=True, type=int); x.add_argument("--origin-tx", required=True); x.add_argument("--origin-sender", required=True)
    x.add_argument("--target-chain", required=True, type=int); x.add_argument("--target-contract", required=True)
    x.add_argument("--nonce", required=True, type=int); x.add_argument("--gas-limit", required=True, type=int); x.add_argument("--payload-type", required=True, type=int)
    x.add_argument("--payload-json", required=True)
    x.add_argument("--cap-ref", action="append", help="32-byte hex capability reference; can be repeated")
    x.add_argument("--stub-sig-scheme", type=int, default=None, help="0/1/2 for deterministic stub signature")
    x.add_argument("--stub-pubkey", default="0x01", help="hex bytes for stub pubkey (any length)")
    x.add_argument("--out", required=True)
    x.set_defaults(func=cmd_env_create_v2)

    sir=sp.add_parser("sir"); sps=sir.add_subparsers(dest="sub", required=True)
    x=sps.add_parser("compile"); x.add_argument("--in", dest="infile", required=True); x.add_argument("--out", required=True); x.set_defaults(func=cmd_sir_compile)
    x=sps.add_parser("disasm"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_sir_disasm)

    blk=sp.add_parser("block"); bps=blk.add_subparsers(dest="sub", required=True)
    x=bps.add_parser("run"); x.add_argument("--sirb", required=True); x.add_argument("--state", required=True); x.add_argument("--envelopes", nargs="+", required=True)
    x.add_argument("--entry", default="main")
    x.add_argument("--require-sigs", action="store_true")
    x.add_argument("--sig-threshold", type=int, default=1)
    x.add_argument("--min-weight", type=int, default=None)
    x.add_argument("--allowed-schemes", default="")
    x.add_argument("--committee", default=None)
    x.add_argument("--out", required=True)
    x.set_defaults(func=cmd_block_run)

    x=bps.add_parser("hash"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_block_hash)

    return p

def main():
    p=build()
    a=p.parse_args()
    a.func(a)

if __name__=="__main__":
    main()
