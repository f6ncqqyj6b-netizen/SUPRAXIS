from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple
import json
from .crypto import sha256

@dataclass(frozen=True)
class CommitteeMember:
    pubkey: bytes
    weight: int
    schemes: Optional[Set[int]] = None  # if None => any scheme

@dataclass(frozen=True)
class Committee:
    """Deterministic committee configuration used for signature policy.

    Members are identified by pubkey bytes. Weight is an integer >= 1.
    Optional per-member allowed schemes.

    committee_id is sha256(canonical_json) as hex.
    """
    members: Tuple[CommitteeMember, ...]

    @staticmethod
    def from_dict(d: dict) -> "Committee":
        ms = []
        for m in d.get("members", []):
            pk = bytes.fromhex(m["pubkey"][2:] if str(m["pubkey"]).startswith("0x") else str(m["pubkey"]))
            w = int(m.get("weight", 1))
            schemes = m.get("schemes")
            if schemes is not None:
                schemes = set(int(x) for x in schemes)
            ms.append(CommitteeMember(pubkey=pk, weight=w, schemes=schemes))
        # canonical ordering by pubkey bytes
        ms_sorted = tuple(sorted(ms, key=lambda x: x.pubkey))
        return Committee(members=ms_sorted)

    @staticmethod
    def from_json(s: str) -> "Committee":
        return Committee.from_dict(json.loads(s))

    def canonical_json(self) -> str:
        obj = {
            "members": [
                {"pubkey": "0x"+m.pubkey.hex(), "weight": int(m.weight),
                 **({ "schemes": sorted(list(m.schemes)) } if m.schemes is not None else {})}
                for m in self.members
            ]
        }
        return json.dumps(obj, sort_keys=True, separators=(",", ":"))

    def committee_id(self) -> str:
        return sha256(self.canonical_json().encode("utf-8")).hex()

    def weights_map(self) -> Dict[bytes, int]:
        return {m.pubkey: int(m.weight) for m in self.members}

    def schemes_map(self) -> Dict[bytes, Optional[Set[int]]]:
        return {m.pubkey: (set(m.schemes) if m.schemes is not None else None) for m in self.members}

    def pubkeys_set(self) -> Set[bytes]:
        return set(m.pubkey for m in self.members)
