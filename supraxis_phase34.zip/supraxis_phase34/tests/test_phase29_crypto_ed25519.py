import unittest
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.crypto import sha256
from supraxis.sigverify import default_verifier, Signature
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign, make_ed25519_signature

def b32(x:int)->bytes: return x.to_bytes(32,"big")

class TestPhase29Crypto(unittest.TestCase):
    def test_ed25519_verify(self):
        kp = ed25519_keygen(seed=b"\x01"*32)
        env = EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(1), origin_sender=b32(9),
            target_chain=100, target_contract=b32(0xAA), nonce=1, gas_limit=123,
            payload_type=1, payload=b"{}", payload_hash=sha256(b"{}"), cap_refs=[], signatures=[]
        )
        msg = env.signing_message()
        sigb = ed25519_sign(kp.private, msg)
        sig = make_ed25519_signature(kp.public, sigb)
        self.assertTrue(default_verifier().verify(sig, msg))

    def test_domain_separation_changes_message(self):
        env = EnvelopeV2(
            version=2, origin_chain=1, origin_tx=b32(2), origin_sender=b32(9),
            target_chain=100, target_contract=b32(0xAA), nonce=1, gas_limit=123,
            payload_type=1, payload=b"{}", payload_hash=sha256(b"{}"), cap_refs=[], signatures=[]
        )
        msg = env.signing_message()
        self.assertTrue(msg.startswith(b"SUPRAXIS|ENV2|"))

if __name__ == "__main__":
    unittest.main()
