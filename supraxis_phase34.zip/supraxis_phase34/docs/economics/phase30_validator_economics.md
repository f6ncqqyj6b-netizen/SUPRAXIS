# Phase 30 — Validator Economics (Fixed Supply) + Staking + Slashing Integration

This phase wires **security economics** into the chain without inflation.

## Fixed Supply Principle
- No new token issuance.
- Validators are compensated via:
  - **transaction fees**
  - **treasury distributions**
  - **slashing rewards** (reporters paid from slashed stake)

## Fee Market (Minimal)
Per envelope:
- `static_gas = _static_gas(entry_fn)`
- `fee_total = static_gas * fees.gas_price`
- Sender pays `fee_total` from balance.
- `fee_burned = fee_total * fees.burn_bps / 10_000`
- Remaining fee goes to `treasury`.

Parameters (governance):
- `fees.gas_price` (default 1)
- `fees.burn_bps` (default 0)
- `fees.proposer_bps` (default 5000)
- `fees.committee_bps` (default 2000)

## Rewards
At end of block:
- `delta = treasury_end - treasury_start`
- `proposer_reward = delta * proposer_bps / 10_000` (paid to proposer reward address)
- `committee_reward = delta * committee_bps / 10_000` (moved into `committee_pool`)
- remainder stays in treasury.

Proposer must be known via `VAL_REGISTER`.

## Staking Lifecycle
- `STAKE_BOND`: moves tokens from balance to stake (slashable)
- `STAKE_UNBOND_REQUEST`: moves tokens from stake to pending unbond record with unlock tick
- `STAKE_WITHDRAW`: after unlock tick, credits the recipient balance

Default parameter:
- `stake.unbond_delay_ticks` (default 100)

## Slashing
Ops:
- `CONSENSUS_SLASH_DOUBLE_VOTE` — requires two distinct signed vote messages
- `CONSENSUS_SLASH_EQUIVOCATION` — requires two distinct signed proposal messages

Slashing parameters:
- `slash.rate_bps` (default 5000 => 50% of current stake)
- `slash.burn_bps` (default 2000)
- `slash.treasury_bps` (default 7000)
- `slash.reporter_bps` (default 1000)

NOTE: this reference implementation slashes active stake (pending unbond slashing can be extended in Phase 31+).
