from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple
from supraxis.crypto import sha256
from supraxis.canonjson import canonical_json
from supraxis.block import state_commitment
from supraxis.state import SupraxisState
from .checkpoint import Checkpoint, validators_hash
from .signed_checkpoint import SignedCheckpoint, verify_signed_checkpoint
from .hotstuff import quorum_threshold
from .validator_set import validators_for_epoch

@dataclass
class LightClient:
    chain_id: int
    trusted: Optional[Checkpoint] = None

    def verify_checkpoint_self_consistent(self, state: SupraxisState, ck: Checkpoint) -> Tuple[bool,str]:
        if int(ck.chain_id) != int(self.chain_id):
            return False, "wrong_chain"
        # Verify validators hash matches snapshot
        snap = state.storage.get(f"validators.epoch.{int(ck.epoch)}")
        if snap is None and int(ck.epoch) > 0:
            snap = state.storage.get(f"validators.epoch.{int(ck.epoch)-1}")
        if snap is None:
            return False, "missing_validator_snapshot"
        vh = validators_hash(list(snap))
        if str(vh) != str(ck.validators_hash):
            return False, "bad_validators_hash"
        return True, "ok"

    def accept_signed_checkpoint(self, state: SupraxisState, scp: SignedCheckpoint) -> Tuple[bool,str]:
        ck = scp.checkpoint
        ok, why = self.verify_checkpoint_self_consistent(state, ck)
        if not ok:
            return False, why

        # Determine validator set for that epoch and compute quorum power
        vals = validators_for_epoch(state, int(ck.epoch))
        q = quorum_threshold(vals)

        snap = state.storage.get(f"validators.epoch.{int(ck.epoch)}")
        if snap is None and int(ck.epoch) > 0:
            snap = state.storage.get(f"validators.epoch.{int(ck.epoch)-1}")
        ok2, why2, signed_power = verify_signed_checkpoint(scp, list(snap or []), q)
        if not ok2:
            return False, why2

        # Monotonic acceptance
        if self.trusted is not None:
            if int(ck.height) <= int(self.trusted.height):
                return False, "non_increasing_height"
        self.trusted = ck
        return True, "ok"

    

    def sync_headers(self, state: SupraxisState, headers: list) -> tuple[bool,str]:
        """Header-only sync from an already trusted checkpoint.

        Verifies:
        - chain_id matches
        - parent linkage + contiguous heights
        - QC is cryptographically valid for the applicable epoch validator set (Ed25519 inferred)
        - validator keys are registered in state.storage (validator.<vid>)
        - optional header.validators_hash matches the epoch snapshot

        Updates validator set when header.epoch changes.
        """
        if self.trusted is None:
            return False, "no_trusted_checkpoint"
        if not headers:
            return True, "ok"

        from supraxis.consensus.validator_set import validators_for_epoch, vmap as make_vmap
        from supraxis.consensus.hotstuff import quorum_threshold
        from supraxis.consensus.qc_verify import verify_qc_crypto
        from supraxis.consensus.checkpoint import validators_hash as vh_fn

        prev_hash = str(self.trusted.block_hash)
        prev_h = int(self.trusted.height)
        cur_epoch = int(self.trusted.epoch)

        def _enforce_registration(epoch: int) -> tuple[bool,str]:
            snap = state.storage.get(f"validators.epoch.{int(epoch)}")
            if snap is None and int(epoch) > 0:
                snap = state.storage.get(f"validators.epoch.{int(epoch)-1}")
            if snap is None:
                return False, "missing_validator_snapshot"
            for r in list(snap or []):
                vid = str(r.get("vid",""))
                if not vid.startswith("0x"):
                    vid = "0x"+vid
                if state.storage.get(f"validator.{vid}") is None:
                    return False, "missing_validator_registration"
            return True, "ok"

        okreg, whyreg = _enforce_registration(cur_epoch)
        if not okreg:
            return False, whyreg

        vals = validators_for_epoch(state, cur_epoch)
        qpower = quorum_threshold(vals)
        vm = make_vmap(vals)

        for h in headers:
            if int(h.chain_id) != int(self.chain_id):
                return False, "wrong_chain"
            if str(h.parent_hash) != prev_hash:
                return False, "bad_parent_link"
            if int(h.height) != prev_h + 1:
                return False, "non_contiguous_height"

            hep = int(getattr(h, "epoch", cur_epoch))
            if hep != cur_epoch:
                cur_epoch = hep
                okreg, whyreg = _enforce_registration(cur_epoch)
                if not okreg:
                    return False, whyreg
                vals = validators_for_epoch(state, cur_epoch)
                qpower = quorum_threshold(vals)
                vm = make_vmap(vals)

            vhash = str(getattr(h, "validators_hash", ""))
            if vhash:
                snap = state.storage.get(f"validators.epoch.{int(cur_epoch)}")
                if snap is None and int(cur_epoch) > 0:
                    snap = state.storage.get(f"validators.epoch.{int(cur_epoch)-1}")
                if snap is None:
                    return False, "missing_validator_snapshot"
                if str(vh_fn(list(snap))) != vhash:
                    return False, "bad_validators_hash"

            if getattr(h, "qc", None) is not None:
                ok, why, sp = verify_qc_crypto(h.qc, vm, qpower, chain_id=int(self.chain_id))
                if not ok:
                    return False, why

            prev_hash = str(h.block_hash)
            prev_h = int(h.height)

        # Update trusted head to latest header; state_root unchanged for header-only mode
        last_vhash = str(getattr(headers[-1], "validators_hash", self.trusted.validators_hash))
        self.trusted = Checkpoint(chain_id=self.chain_id, epoch=cur_epoch, height=prev_h,
                                  state_root=str(self.trusted.state_root), block_hash=prev_hash,
                                  validators_hash=last_vhash or str(self.trusted.validators_hash))
        return True, "ok"
