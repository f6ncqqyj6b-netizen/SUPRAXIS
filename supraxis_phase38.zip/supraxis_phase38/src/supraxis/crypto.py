from __future__ import annotations
import hashlib
from .sigverify import Signature, default_verifier

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

Sig = Signature

def verify_signature(sig: Sig, message: bytes) -> bool:
    return default_verifier().verify(sig, message)
