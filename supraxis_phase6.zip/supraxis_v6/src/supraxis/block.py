from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List
import json
from .envelope import EnvelopeV1, envelope_sort_key
from .state import SupraxisState
from .runtime import execute_functions, canonical_json
from .crypto import sha256
from .errors import ReplayError
from .gas import gas_cost

@dataclass
class BlockResult:
    state_json: str
    events: List[Dict[str, Any]]
    block_hash: str

def _static_gas(ops: List[Dict[str, Any]], functions: Dict[str, List[Dict[str, Any]]], depth: int = 0) -> int:
    if depth > 32: raise ReplayError("static gas walk depth exceeded")
    total=0
    for op in ops:
        total += gas_cost(str(op.get("op")))
        if op.get("op") == "CALL":
            fn=str(op.get("fn"))
            if fn not in functions: raise ReplayError("unknown CALL target")
            total += _static_gas(functions[fn], functions, depth+1)
    return total

def run_block(state: SupraxisState, functions: Dict[str, List[Dict[str, Any]]], envelopes: List[EnvelopeV1], entry: str="main") -> BlockResult:
    if entry not in functions: raise ReplayError("missing entry")
    envs=sorted(envelopes, key=envelope_sort_key)
    events_all=[]
    h=sha256(b"SUPRAXIS_BLOCK_V2")
    for env in envs:
        env.validate(require_signatures=False)
        last=state.get_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract)
        if env.nonce <= last: raise ReplayError("nonce not increasing")
        ctx={
            "origin_chain": env.origin_chain,
            "origin_sender": env.origin_sender.hex(),
            "target_chain": env.target_chain,
            "target_contract": env.target_contract.hex(),
            "nonce": env.nonce,
            "gas_limit": env.gas_limit,
            "payload_type": env.payload_type,
            "payload_hash": env.payload_hash.hex(),
            "timestamp": 0,
        }
        if _static_gas(functions[entry], functions) > env.gas_limit:
            raise ReplayError("out of gas")
        evs=execute_functions(state, functions, entry, ctx)
        state.set_last_nonce(env.origin_chain, env.origin_sender, env.target_chain, env.target_contract, env.nonce)
        for e in evs:
            item={"event": e.event, "payload": e.payload, "ctx": ctx}
            events_all.append(item)
            h=sha256(h + canonical_json(item))
        h=sha256(h + state.to_json().encode("utf-8"))
    return BlockResult(state_json=state.to_json(), events=events_all, block_hash=h.hex())

def block_hash(block_json: str) -> str:
    obj=json.loads(block_json)
    return sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")).hex()
