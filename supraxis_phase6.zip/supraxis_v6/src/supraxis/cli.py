from __future__ import annotations
import argparse, json
from pathlib import Path
from .state import SupraxisState
from .crypto import sha256
from .envelope import EnvelopeV1
from .sirbin import SirBinProgram, disasm as sir_disasm
from .block import run_block, block_hash

def _bytes32(s: str) -> bytes:
    s=s.lower().strip()
    if s.startswith("0x"): s=s[2:]
    b=bytes.fromhex(s)
    if len(b)!=32: raise SystemExit("expected 32-byte hex")
    return b

def cmd_state_init(a):
    Path(a.out).write_text(SupraxisState().to_json(), encoding="utf-8")
    print(a.out)

def cmd_cap_add(a):
    st=SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8"))
    cap_id=sha256(a.name.encode()).hex()
    st.caps[cap_id]={"scope":a.scope,"expires":int(a.expires),"chain":int(a.chain)}
    Path(a.state).write_text(st.to_json(), encoding="utf-8")
    print(cap_id)

def cmd_env_create(a):
    payload_obj=json.loads(Path(a.payload_json).read_text(encoding="utf-8"))
    payload=json.dumps(payload_obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    env=EnvelopeV1(
        version=1,
        origin_chain=int(a.origin_chain),
        origin_tx=_bytes32(a.origin_tx),
        origin_sender=_bytes32(a.origin_sender),
        target_chain=int(a.target_chain),
        target_contract=_bytes32(a.target_contract),
        nonce=int(a.nonce),
        gas_limit=int(a.gas_limit),
        payload_type=int(a.payload_type),
        payload=payload,
        payload_hash=sha256(payload),
        cap_refs=[],
        signatures=[],
    )
    Path(a.out).write_bytes(env.canonical_bytes())
    print(a.out)

def cmd_env_verify(a):
    env=EnvelopeV1.decode(Path(a.infile).read_bytes())
    env.validate(require_signatures=False)
    print("OK")

def cmd_sir_compile(a):
    obj=json.loads(Path(a.infile).read_text(encoding="utf-8"))
    prog=SirBinProgram(version=1, functions=obj["functions"])
    Path(a.out).write_bytes(prog.encode())
    print(a.out)

def cmd_sir_disasm(a):
    print(sir_disasm(Path(a.infile).read_bytes()), end="")

def cmd_block_run(a):
    st=SupraxisState.from_json(Path(a.state).read_text(encoding="utf-8"))
    prog=SirBinProgram.decode(Path(a.sirb).read_bytes())
    envs=[EnvelopeV1.decode(Path(p).read_bytes()) for p in a.envelopes]
    res=run_block(st, prog.functions, envs, entry=a.entry)
    out={"state": json.loads(res.state_json), "events": res.events, "block_hash": res.block_hash}
    Path(a.out).write_text(json.dumps(out, indent=2, sort_keys=True), encoding="utf-8")
    print(res.block_hash)

def cmd_block_hash(a):
    print(block_hash(Path(a.infile).read_text(encoding="utf-8")))

def build():
    p=argparse.ArgumentParser(prog="supraxis")
    sp=p.add_subparsers(dest="cmd", required=True)

    st=sp.add_parser("state"); sps=st.add_subparsers(dest="sub", required=True)
    x=sps.add_parser("init"); x.add_argument("--out", required=True); x.set_defaults(func=cmd_state_init)

    cap=sp.add_parser("cap"); cps=cap.add_subparsers(dest="sub", required=True)
    x=cps.add_parser("add"); x.add_argument("--state", required=True); x.add_argument("--name", required=True)
    x.add_argument("--scope", required=True); x.add_argument("--chain", required=True, type=int); x.add_argument("--expires", required=True, type=int)
    x.set_defaults(func=cmd_cap_add)

    env=sp.add_parser("envelope"); eps=env.add_subparsers(dest="sub", required=True)
    x=eps.add_parser("create")
    x.add_argument("--origin-chain", required=True, type=int); x.add_argument("--origin-tx", required=True); x.add_argument("--origin-sender", required=True)
    x.add_argument("--target-chain", required=True, type=int); x.add_argument("--target-contract", required=True)
    x.add_argument("--nonce", required=True, type=int); x.add_argument("--gas-limit", required=True, type=int); x.add_argument("--payload-type", required=True, type=int)
    x.add_argument("--payload-json", required=True); x.add_argument("--out", required=True)
    x.set_defaults(func=cmd_env_create)
    x=eps.add_parser("verify"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_env_verify)

    sir=sp.add_parser("sir"); sps=sir.add_subparsers(dest="sub", required=True)
    x=sps.add_parser("compile"); x.add_argument("--in", dest="infile", required=True); x.add_argument("--out", required=True); x.set_defaults(func=cmd_sir_compile)
    x=sps.add_parser("disasm"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_sir_disasm)

    blk=sp.add_parser("block"); bps=blk.add_subparsers(dest="sub", required=True)
    x=bps.add_parser("run"); x.add_argument("--sirb", required=True); x.add_argument("--state", required=True); x.add_argument("--envelopes", nargs="+", required=True)
    x.add_argument("--entry", default="main"); x.add_argument("--out", required=True); x.set_defaults(func=cmd_block_run)
    x=bps.add_parser("hash"); x.add_argument("--in", dest="infile", required=True); x.set_defaults(func=cmd_block_hash)

    return p

def main():
    p=build()
    a=p.parse_args()
    a.func(a)

if __name__=="__main__":
    main()
