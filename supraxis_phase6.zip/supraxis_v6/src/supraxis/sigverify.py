from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol
import hashlib

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

@dataclass(frozen=True)
class Signature:
    scheme: int
    pubkey: bytes
    sig: bytes

class Verifier(Protocol):
    def verify(self, sig: Signature, message: bytes) -> bool: ...

class StubVerifier:
    """Deterministic placeholder verifier.
    - scheme 0: NONE (pubkey/sig must be empty)
    - scheme 1: sha256(pubkey||msg) prefix match
    - scheme 2: sha256(msg||pubkey) prefix match
    """
    def verify(self, sig: Signature, message: bytes) -> bool:
        if sig.scheme == 0:
            return sig.pubkey == b"" and sig.sig == b""
        if sig.scheme == 1:
            h = sha256(sig.pubkey + message)
            return sig.sig[:2] == h[:2]
        if sig.scheme == 2:
            h = sha256(message + sig.pubkey)
            return sig.sig[:2] == h[:2]
        return False

def default_verifier() -> Verifier:
    # Optional real crypto can be plugged in later. Keep deterministic fallback.
    return StubVerifier()
