from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List
from ..crypto import sha256

@dataclass
class MockInbox:
    chain_id: int
    mempool: List[bytes]

    def submit(self, envelope_bytes: bytes) -> str:
        self.mempool.append(envelope_bytes)
        return "0x" + sha256(envelope_bytes).hex()

class Sandbox:
    def __init__(self) -> None:
        self._inboxes: Dict[int, MockInbox] = {}

    def inbox(self, chain_id: int) -> MockInbox:
        if chain_id not in self._inboxes:
            self._inboxes[chain_id] = MockInbox(chain_id=chain_id, mempool=[])
        return self._inboxes[chain_id]
