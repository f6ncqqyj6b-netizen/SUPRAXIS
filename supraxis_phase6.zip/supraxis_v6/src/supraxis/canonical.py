from __future__ import annotations
import struct
from typing import Tuple
from .errors import ReplayError

def pack_u16(x: int) -> bytes: return struct.pack(">H", x)
def pack_u32(x: int) -> bytes: return struct.pack(">I", x)
def pack_u64(x: int) -> bytes: return struct.pack(">Q", x)

def read_u16(buf: bytes, off: int) -> Tuple[int, int]:
    if off + 2 > len(buf): raise ReplayError("EOF u16")
    return struct.unpack(">H", buf[off:off+2])[0], off+2

def read_u32(buf: bytes, off: int) -> Tuple[int, int]:
    if off + 4 > len(buf): raise ReplayError("EOF u32")
    return struct.unpack(">I", buf[off:off+4])[0], off+4

def read_u64(buf: bytes, off: int) -> Tuple[int, int]:
    if off + 8 > len(buf): raise ReplayError("EOF u64")
    return struct.unpack(">Q", buf[off:off+8])[0], off+8
