from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
from .canonical import pack_u16, pack_u32, pack_u64, read_u16, read_u32, read_u64
from .crypto import sha256
from .errors import EnvelopeValidationError, ReplayError

MAGIC = b"SCES"  # Supraxis Canonical Envelope Stream
VERSION = 1

def _pack_bytes(b: bytes) -> bytes:
    return pack_u32(len(b)) + b

def _read_bytes(buf: bytes, off: int) -> Tuple[bytes, int]:
    n, off = read_u32(buf, off)
    if off + n > len(buf):
        raise ReplayError("EOF bytes")
    return buf[off:off+n], off + n

@dataclass(frozen=True)
class EnvelopeV1:
    version: int
    origin_chain: int
    origin_tx: bytes
    origin_sender: bytes
    target_chain: int
    target_contract: bytes
    nonce: int
    gas_limit: int
    payload_type: int
    payload: bytes
    payload_hash: bytes
    cap_refs: List[bytes]
    signatures: List[bytes]  # placeholder for future

    def canonical_bytes(self) -> bytes:
        if len(self.origin_tx) != 32 or len(self.origin_sender) != 32 or len(self.target_contract) != 32:
            raise EnvelopeValidationError("expected 32-byte ids")
        out = bytearray()
        out += MAGIC
        out += pack_u16(self.version)
        out += pack_u32(self.origin_chain)
        out += self.origin_tx
        out += self.origin_sender
        out += pack_u32(self.target_chain)
        out += self.target_contract
        out += pack_u64(self.nonce)
        out += pack_u64(self.gas_limit)
        out += pack_u16(self.payload_type)
        out += _pack_bytes(self.payload)
        out += self.payload_hash
        # cap refs canonical: sort lexicographically
        caps = sorted(self.cap_refs)
        out += pack_u16(len(caps))
        for c in caps:
            if len(c) != 32:
                raise EnvelopeValidationError("cap_ref must be 32 bytes")
            out += c
        # signatures placeholder
        out += pack_u16(len(self.signatures))
        for s in self.signatures:
            out += _pack_bytes(s)
        return bytes(out)

    @staticmethod
    def decode(buf: bytes) -> "EnvelopeV1":
        if len(buf) < 4 or buf[:4] != MAGIC:
            raise ReplayError("bad envelope magic")
        off = 4
        ver, off = read_u16(buf, off)
        if ver != VERSION:
            raise ReplayError("unsupported envelope version")
        oc, off = read_u32(buf, off)
        if off + 32*2 > len(buf): raise ReplayError("EOF ids")
        origin_tx = buf[off:off+32]; off += 32
        origin_sender = buf[off:off+32]; off += 32
        tc, off = read_u32(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF target")
        target_contract = buf[off:off+32]; off += 32
        nonce, off = read_u64(buf, off)
        gas, off = read_u64(buf, off)
        ptype, off = read_u16(buf, off)
        payload, off = _read_bytes(buf, off)
        if off + 32 > len(buf): raise ReplayError("EOF payload_hash")
        ph = buf[off:off+32]; off += 32
        ncap, off = read_u16(buf, off)
        caps = []
        for _ in range(ncap):
            if off + 32 > len(buf): raise ReplayError("EOF cap")
            caps.append(buf[off:off+32]); off += 32
        nsig, off = read_u16(buf, off)
        sigs = []
        for _ in range(nsig):
            s, off = _read_bytes(buf, off)
            sigs.append(s)
        if off != len(buf):
            raise ReplayError("trailing bytes envelope")
        return EnvelopeV1(ver, oc, origin_tx, origin_sender, tc, target_contract, nonce, gas, ptype, payload, ph, caps, sigs)

    def validate(self, require_signatures: bool = False) -> None:
        if self.payload_hash != sha256(self.payload):
            raise EnvelopeValidationError("payload hash mismatch")
        # Signature verification plumbing is out-of-scope here; kept deterministic.
        if require_signatures and len(self.signatures) == 0:
            raise EnvelopeValidationError("missing signatures")
        # Canonical cap ordering check: decoding doesn't preserve order; compare re-encode
        b = self.canonical_bytes()
        if EnvelopeV1.decode(b).canonical_bytes() != b:
            raise EnvelopeValidationError("canonicalization mismatch")

def envelope_sort_key(env: EnvelopeV1):
    return (env.target_chain, env.target_contract, env.origin_chain, env.origin_sender, env.nonce)
