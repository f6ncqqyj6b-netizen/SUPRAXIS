import unittest, json, hashlib
from pathlib import Path
from supraxis.sirbin import SirBinProgram
from supraxis.state import SupraxisState
from supraxis.envelope import EnvelopeV1
from supraxis.crypto import sha256
from supraxis.block import run_block

class GoldenTests(unittest.TestCase):
    def test_sirb_roundtrip(self):
        b = Path("tests/golden/hello.sirb").read_bytes()
        prog = SirBinProgram.decode(b)
        self.assertEqual(prog.encode(), b)

    def test_block_hash_pinned(self):
        b = Path("tests/golden/hello.sirb").read_bytes()
        prog = SirBinProgram.decode(b)
        payload = b'{"t":0}'
        env = EnvelopeV1(
            1, 1, (b"\x00"*31)+b"\x01", (b"\x00"*31)+b"\x02",
            100, (b"\x00"*31)+b"\xaa", 1, 500000, 1,
            payload, sha256(payload), [], []
        )
        res = run_block(SupraxisState(), prog.functions, [env], entry="main")
        obj = {"state": json.loads(res.state_json), "events": res.events, "block_hash": res.block_hash}
        s = json.dumps(obj, sort_keys=True, separators=(",", ":"))
        got = hashlib.sha256(s.encode()).hexdigest()
        want = Path("tests/golden/hello.blockhash.txt").read_text(encoding="utf-8").strip()
        self.assertEqual(got, want)

if __name__ == "__main__":
    unittest.main()
