import unittest, json, hashlib
from pathlib import Path
from supraxis.envelope import EnvelopeV1

class VectorTests(unittest.TestCase):
    def test_valid_vector(self):
        b = Path("tests/vectors/env_valid_v1.bin").read_bytes()
        meta = json.loads(Path("tests/vectors/env_valid_v1.json").read_text(encoding="utf-8"))
        self.assertEqual(hashlib.sha256(b).hexdigest(), meta["sha256"])
        EnvelopeV1.decode(b).validate(require_signatures=False)

    def test_invalid_payloadhash(self):
        b = Path("tests/vectors/env_invalid_payloadhash.bin").read_bytes()
        with self.assertRaises(Exception):
            EnvelopeV1.decode(b).validate(require_signatures=False)

if __name__ == "__main__":
    unittest.main()
