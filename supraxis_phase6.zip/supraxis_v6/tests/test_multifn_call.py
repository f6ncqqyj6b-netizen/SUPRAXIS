import unittest, json
from supraxis.sirbin import SirBinProgram
from supraxis.state import SupraxisState
from supraxis.crypto import sha256
from supraxis.envelope import EnvelopeV1
from supraxis.block import run_block

class MultifnCallTests(unittest.TestCase):
    def test_call_executes_helper(self):
        with open("examples/multifn.sir.json", "r", encoding="utf-8") as f:
            multifn = json.load(f)
        prog = SirBinProgram(version=1, functions=multifn["functions"])
        decoded = SirBinProgram.decode(prog.encode())

        st = SupraxisState()
        cap_id = sha256(b"cap_ping").hex()
        st.caps[cap_id] = {"scope":"ping","expires":999999999,"chain":100}

        payload = b'{"timestamp":0}'
        env = EnvelopeV1(
            1, 1, (b"\x00"*31)+b"\x01", (b"\x00"*31)+b"\x02",
            100, (b"\x00"*31)+b"\xaa", 1, 500000, 1,
            payload, sha256(payload), [], []
        )

        res = run_block(st, decoded.functions, [env], entry="main")
        names = [e["event"] for e in res.events]
        self.assertIn("Helper", names)
        self.assertIn("Ping", names)

if __name__ == "__main__":
    unittest.main()
