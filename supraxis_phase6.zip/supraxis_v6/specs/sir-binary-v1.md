# SIR Binary v1 (.sirb)

Header: magic 'SIRB', version u16=1, fn_count u16.

Functions are encoded in lexicographic order by name.

Opcodes:
- 0x01 CAP_REQUIRE (cap_name, scope)
- 0x02 EMIT (event, payload_json)
- 0x03 STORE (key, value_json)
- 0x04 ASSERT_BOOL (0/1)
- 0x10 CALL (fn_name)
- 0xFF RET

Execution uses bounded call depth (MAX_CALL_DEPTH=32) and requires explicit RET.
