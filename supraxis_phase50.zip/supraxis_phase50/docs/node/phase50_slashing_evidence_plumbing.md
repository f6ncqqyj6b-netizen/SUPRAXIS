# Phase 50 — Slashing Evidence Plumbing (End-to-End)

This phase wires up slashing evidence submission and storage across the node and P2P layer.

## Evidence Types
`src/supraxis/consensus/evidence.py`
- `double_vote`
- `equivocating_proposer`
- deterministic `evidence_hash = sha256(canonical_json(evidence))`
- verification delegates to `src/supraxis/consensus/slashing.py`

## Evidence Store
`src/supraxis/node/evidence_store.py`
- deduplicates evidence by hash
- records `slashed[pubkey] = ts` (penalty application hook for later phases)
- serializable to/from dict

## Persistence
`src/supraxis/node/db.py`
- adds `evidence.json` with atomic write + checksum

## P2P Protocol
`src/supraxis/p2p/protocol.py`
- `evidence_submit` / `evidence_ok`
- `evidence_status` / `evidence_status_ok`

## Node Integration
`src/supraxis/node/evidence_service.py`
- handles submit + persists to NodeDB
- exposes slashed status query

`src/supraxis/node/service.py`
- routes the evidence requests if `evidence_service` is present

## Next
Phase 51: governance hardening (upgrade gates, timelocks, emergency brakes) and wiring slashing into validator sets/stake accounting.
