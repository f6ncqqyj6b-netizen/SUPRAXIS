# Phase 37 — Cryptographic QC Verification + Validator Key Enforcement

This phase hardens Phase 36:

1) QC checks become **cryptographic** (not just power structure).
2) Light clients enforce that epoch snapshot validators are **registered keys**.

## Vote Signing

`src/supraxis/consensus/vote_signing.py`

- Vote message is domain-separated:
  - `SUPRAXIS|VOTE|V1|{ canonical_json(...) }`
- In this reference build:
  - signature scheme is inferred (64 bytes => Ed25519)

## QC Crypto Verification

`src/supraxis/consensus/qc_verify.py`

`verify_qc_crypto(qc, vmap, quorum_power, chain_id)`:
- For each `(voter_vid -> sig_bytes)`:
  - voter must be in validator set
  - signature must verify over the vote message
- Sum powers of valid signatures
- Require `signed_power >= quorum_power`

## Validator Key Enforcement

Light client now requires:
- For every validator `vid` in the epoch snapshot,
- `state.storage["validator.<vid>"]` must exist (set by `VAL_REGISTER`).

This ensures epoch snapshots correspond to governance-registered validator keys.

Next: Phase 38 — signature schemes in QC (multi-scheme support) + signed headers.
