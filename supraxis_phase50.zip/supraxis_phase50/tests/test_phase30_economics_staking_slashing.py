import unittest
from supraxis.state import SupraxisState
from supraxis.sirbin import SirBinProgram
from supraxis.block import run_block
from supraxis.envelope import EnvelopeV2, SignaturePolicy
from supraxis.crypto import sha256
from supraxis.crypto_keys import ed25519_keygen, ed25519_sign, make_ed25519_signature
from supraxis.canonjson import canonical_json

def b32(x:int)->bytes: return x.to_bytes(32,"big")

def mk_env(sender:int, nonce:int, kp):
    payload=b'{"n":%d}'%nonce
    env0 = EnvelopeV2(
        version=2, origin_chain=1, origin_tx=b32(nonce), origin_sender=b32(sender),
        target_chain=100, target_contract=b32(0xAA), nonce=nonce, gas_limit=10**12,
        payload_type=1, payload=payload, payload_hash=sha256(payload), cap_refs=[], signatures=[]
    )
    msg = env0.signing_message()
    sigb = ed25519_sign(kp.private, msg)
    sig = make_ed25519_signature(kp.public, sigb)
    env1 = EnvelopeV2(
        version=env0.version, origin_chain=env0.origin_chain, origin_tx=env0.origin_tx, origin_sender=env0.origin_sender,
        target_chain=env0.target_chain, target_contract=env0.target_contract, nonce=env0.nonce, gas_limit=env0.gas_limit,
        payload_type=env0.payload_type, payload=env0.payload, payload_hash=env0.payload_hash, cap_refs=env0.cap_refs, signatures=[sig]
    )
    return env1

class Phase30(unittest.TestCase):
    def test_fee_and_proposer_reward(self):
        st = SupraxisState()
        # give sender balance
        sender_addr = "0x"+b32(1).hex()
        st.credit(sender_addr, 10**15)

        # register proposer
        gov = sha256(b"GOVERNANCE").hex()
        st.caps[gov] = {"scope":"global","chain":100,"expires":10**18}
        st.storage["fees.gas_price"]=1
        st.storage["fees.proposer_bps"]=5000
        st.storage["fees.committee_bps"]=0
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"VAL_REGISTER","vid":"0x"+"aa"*32,"reward_address":"0x"+"bb"*32},
            {"op":"RET"},
        ]})
        kp = ed25519_keygen(seed=b"\x02"*32)
        run_block(st, prog.functions, [mk_env(1,1,kp)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)

        # now execute a block with a no-op so fee is collected and proposer paid
        prog2 = SirBinProgram(version=1, functions={"main":[
            {"op":"EMIT","event":"X","payload":{}},
            {"op":"RET"},
        ]})
        tre_before = st.treasury
        bal_before = st.balance_of("0x"+"bb"*32)
        res = run_block(st, prog2.functions, [mk_env(1,2,kp)], proposer_vid="0x"+"aa"*32, require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertTrue(st.treasury >= tre_before)  # treasury grows then partly distributed
        self.assertTrue(st.balance_of("0x"+"bb"*32) >= bal_before)

    def test_stake_bond_unbond_withdraw(self):
        st = SupraxisState()
        st.storage["tick"]=0
        st.storage["stake.unbond_delay_ticks"]=5
        addr="0x"+"11"*32
        st.credit(addr, 1000)
        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"STAKE_BOND","pubkey":"0x"+"22"*32,"from":addr,"amount":500,"lock_until_epoch":0},
            {"op":"RET"},
        ]})
        kp = ed25519_keygen(seed=b"\x03"*32)
        run_block(st, prog.functions, [mk_env(1,1,kp)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertEqual(st.balance_of(addr), 500)
        self.assertEqual(st.stake_of("0x"+"22"*32)[0], 500)

        prog2 = SirBinProgram(version=1, functions={"main":[
            {"op":"STAKE_UNBOND_REQUEST","pubkey":"0x"+"22"*32,"to":addr,"amount":200},
            {"op":"RET"},
        ]})
        run_block(st, prog2.functions, [mk_env(1,2,kp)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertEqual(st.stake_of("0x"+"22"*32)[0], 300)
        st.storage["tick"]=10
        prog3 = SirBinProgram(version=1, functions={"main":[
            {"op":"STAKE_WITHDRAW","pubkey":"0x"+"22"*32,"to":addr},
            {"op":"RET"},
        ]})
        run_block(st, prog3.functions, [mk_env(1,3,kp)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        self.assertEqual(st.balance_of(addr), 700)

    def test_consensus_slash_double_vote(self):
        st = SupraxisState()
        # initial stake
        reporter="0x"+"44"*32
        # make two signed vote messages using Ed25519
        kp = ed25519_keygen(seed=b"\x04"*32)
        scheme=11
        pub="0x"+kp.public.hex()
        st.stake_add(pub, 1000, 0)
        # messages are just bytes; for test we use canonical_json wrapper
        m1 = canonical_json({"t":"vote","h":1,"r":1,"bh":"a","v":"X"})
        m2 = canonical_json({"t":"vote","h":1,"r":1,"bh":"b","v":"X"})
        s1 = ed25519_sign(kp.private, m1)
        s2 = ed25519_sign(kp.private, m2)
        evidence = {
            "scheme": scheme,
            "pubkey": pub,
            "vote1_msg": "0x"+m1.hex(),
            "vote1_sig": "0x"+s1.hex(),
            "vote2_msg": "0x"+m2.hex(),
            "vote2_sig": "0x"+s2.hex(),
        }
        st.storage["slash.rate_bps"]=5000
        st.storage["slash.burn_bps"]=2000
        st.storage["slash.treasury_bps"]=7000
        st.storage["slash.reporter_bps"]=1000

        prog = SirBinProgram(version=1, functions={"main":[
            {"op":"CONSENSUS_SLASH_DOUBLE_VOTE","evidence":evidence,"reporter":reporter},
            {"op":"RET"},
        ]})
        envkp = ed25519_keygen(seed=b"\x05"*32)
        run_block(st, prog.functions, [mk_env(1,1,envkp)], require_signatures=True, sig_policy=SignaturePolicy(min_valid=1), auto_slash=False)
        # stake should drop from 1000 to 500
        self.assertEqual(st.stake_of(pub)[0], 500)
        # reporter got paid something
        self.assertTrue(st.balance_of(reporter) > 0)

if __name__ == "__main__":
    unittest.main()
