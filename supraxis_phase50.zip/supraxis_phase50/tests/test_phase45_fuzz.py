import unittest
import random

from supraxis.p2p.message import decode, encode, Msg
from supraxis.p2p.security import validate_payload_schema, DEFAULT_MAX_FRAME_BYTES, validate_frame_size

class TestPhase45Fuzz(unittest.TestCase):
    def test_decode_fuzz_does_not_crash(self):
        # random bytes should either decode or raise ValueError, but never hang/crash
        for _ in range(500):
            n = random.randint(0, 200)
            buf = bytes(random.getrandbits(8) for _ in range(n))
            try:
                decode(buf)
            except Exception:
                pass

    def test_frame_size_limits(self):
        ok, why = validate_frame_size(DEFAULT_MAX_FRAME_BYTES + 1, DEFAULT_MAX_FRAME_BYTES)
        self.assertFalse(ok)
        self.assertEqual(why, "frame_too_large")

    def test_schema_fuzz(self):
        types = ["hello","best_checkpoint","signed_headers","blocks","snapshot","peers","unknown"]
        for _ in range(500):
            t = random.choice(types)
            payload = {}
            # randomize payload shapes
            if random.random() < 0.3:
                payload = {"x": random.randint(0,10)}
            if t == "blocks":
                payload["hashes"] = [str(random.randint(0,100)) for _ in range(random.randint(0,5))]
            if t == "signed_headers":
                payload["start_hash"] = "a"*64
                payload["end_hash"] = "b"*64
                if random.random() < 0.2:
                    payload["max_items"] = random.randint(0, 1000)
            ok, _ = validate_payload_schema(t, payload)
            # only guarantee: unknown type rejected
            if t == "unknown":
                self.assertFalse(ok)

    def test_encode_decode_roundtrip(self):
        m = Msg("hello", {"node_id":"x","chain_id":1,"version":"v"})
        b = encode(m)
        m2, rest = decode(b)
        self.assertEqual(rest, b"")
        self.assertEqual(m2.t, "hello")
        self.assertEqual(m2.payload["chain_id"], 1)

if __name__ == "__main__":
    unittest.main()
