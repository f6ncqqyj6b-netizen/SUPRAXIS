from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, List

from supraxis.mempool import Mempool
from supraxis.netblock import NetBlock as Block, make_netblock as make_block, netblock_from_dict as block_from_dict, validate_netblock_dict as validate_block_dict

GENESIS_PARENT = "0"*64

@dataclass
class BuildParams:
    max_txs: int = 2000

class BlockBuilder:
    def __init__(self, chain_id: int, proposer: str, mempool: Mempool, params: Optional[BuildParams] = None):
        self.chain_id = int(chain_id)
        self.proposer = str(proposer)
        self.mempool = mempool
        self.params = params or BuildParams()

    def build(self, height: int, parent_hash: str) -> Block:
        txs = [tx.to_dict() for tx in self.mempool.top(limit=int(self.params.max_txs))]
        return make_block(self.chain_id, int(height), str(parent_hash), self.proposer, txs)

    def accept_block(self, block_dict: dict) -> Tuple[bool,str,str]:
        ok, why = validate_block_dict(block_dict)
        if not ok:
            return False, why, ""
        if int(block_dict["chain_id"]) != self.chain_id:
            return False, "wrong_chain", ""
        b = block_from_dict(block_dict)
        h = b.hash_hex()
        # remove txs included from mempool
        for txd in b.txs:
            try:
                # stable hash
                from supraxis.tx import tx_from_dict
                th = tx_from_dict(txd).hash_hex()
                self.mempool.remove(th)
            except Exception:
                pass
        return True, "ok", h
